// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

import 'package:flutter/cupertino.dart';

FieldData fieldDataFromJson(String str) => FieldData.fromJson(json.decode(str));

String fieldDataToJson(FieldData data) => json.encode(data.toJson());

class FieldData {
  FieldData({
    this.success,
    this.moduleName,
    this.data,
  });

  bool?success;
  String?moduleName;
  List<Datum>?data;

  factory FieldData.fromJson(Map<String, dynamic> json) => FieldData(
    success: json["success"],
    moduleName: json["moduleName"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "success":success,
    "moduleName": moduleName,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.fieldName,
    this.fieldLabel,
    this.fieldType,
    this.mandatory,
    this.maxLength,
    this.textEditingController,
    this.selectedDropDownValue,
    this.dropDownList,
    this.dropDownValue
  });

  String?fieldName;
  String?fieldLabel;
  String?fieldType;
  String?mandatory;
  String?maxLength;
  TextEditingController?textEditingController;
  var selectedDropDownValue;
  var dropDownList;
  String?dropDownValue;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    fieldName: json["fieldName"],
    fieldLabel: json["fieldLabel"],
    fieldType: json["fieldType"],
    mandatory: json["mandatory"],// mandatoryValues.map[json["mandatory"]],
    maxLength: json["maxLength"],
    textEditingController: new TextEditingController(),
    dropDownValue: "",
    selectedDropDownValue: null,
    dropDownList:[],
  );

  Map<String, dynamic> toJson() => {
    "fieldName": fieldName,
    "fieldLabel": fieldLabel,
    "fieldType": fieldType,
    "mandatory": mandatory,
    "maxLength": maxLength,
    "dropDownValue": dropDownValue,
    "selectedDropDownValue": selectedDropDownValue,
    "dropDownList": dropDownList,
  };

}


