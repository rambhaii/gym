// To parse this JSON data, do
//
//     final leaveModel = leaveModelFromJson(jsonString);

import 'dart:convert';

LeaveModel leaveModelFromJson(String str) => LeaveModel.fromJson(json.decode(str));

String leaveModelToJson(LeaveModel data) => json.encode(data.toJson());

class LeaveModel {
  LeaveModel({
    this.statusCode,
    this.message,
  });

  String ?statusCode;
  List<Message>? message;

  factory LeaveModel.fromJson(Map<String, dynamic> json) => LeaveModel(
    statusCode: json["statusCode"],
    message: List<Message>.from(json["message"].map((x) => Message.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": List<dynamic>.from(message!.map((x) => x.toJson())),
  };
}

class Message {
  Message({
    this.id,
    this.memberId,
    this.priestName,
    this.leaveType,
    this.leavestartDate,
    this.leaveEndDate,
    this.reason,
    this.leaveStatus,
    this.productId,
    this.clientId,
    this.isChecked,
    this.leavestartTime,
    this.leaveEndTime,
    this.updateRemak,
  });

  String ?id;
  String ?memberId;
  dynamic? priestName;
  String ?leaveType;
  String ?leavestartDate;
  String ?updateRemak;
  String ?leaveEndDate;
  String ?reason;
  String? leaveStatus;
  String? productId;
  String? clientId;
  String? leavestartTime;
  String? leaveEndTime;
  bool? isChecked;

  factory Message.fromJson(Map<String, dynamic> json) => Message(
    id: json["_id"],
    memberId: json["memberId"]??"",
    priestName: json["memberName"]??"",
    leaveType: json["leaveType"]??"",
    leavestartDate: json["leavestartDate"]??"",
    leaveEndDate: json["leaveEndDate"]??"",
    reason: json["reason"]??"",
    leaveStatus: json["leaveStatus"]??"",
    productId: json["productId"]??"",
    clientId: json["clientId"]??"",
    leaveEndTime: json["leaveEndTime"]??"",
    updateRemak: json["updateRemak"]??"",
    leavestartTime: json["leavestartTime"]??"",
    isChecked: false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "memberId": memberId,
    "priestName": priestName,
    "leaveType": leaveType,
    "leavestartDate": leavestartDate,
    "leaveEndDate": leaveEndDate,
    "reason": reason,
    "leaveStatus": leaveStatus,
    "productId": productId,
    "clientId": clientId,
    "isChecked": isChecked,
    "leaveEndTime": leaveEndTime,
    "updateRemak": updateRemak,
    "leavestartTime": leavestartTime,
  };
}
