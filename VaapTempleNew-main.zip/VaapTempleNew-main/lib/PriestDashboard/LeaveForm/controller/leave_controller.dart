import 'dart:convert';

import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
import '../model/Leave_List_data.dart';

class LeaveController extends GetxController {

  RxString rxServiceDate="Select Date Range".obs;
  final GlobalKey<ExpansionTileCardState> Group1Key = new GlobalKey();
  final GlobalKey<FormState> formKey = new GlobalKey();
  TextEditingController etSearch= new TextEditingController();
  TextEditingController etfirstname = new TextEditingController();
  TextEditingController etNotes = new TextEditingController();
  TextEditingController etdate = new TextEditingController();
  TextEditingController etStartTime = new TextEditingController();
  TextEditingController etEndTime = new TextEditingController();
  TextEditingController etEndDate = new TextEditingController();
  TextEditingController etRange = new TextEditingController();
  TextEditingController etMonth = new TextEditingController();
  TextEditingController replayRemark = new TextEditingController();
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  final DateFormat formatter1 = DateFormat('MM/dd/yyyy');
  final DateFormat formatter2 = DateFormat('dd MMM,yyyy');
  DateTime? startPickedDate;
  var leaveModellist=LeaveModel().obs;
  var pickedRangeDate;
  var selectedDropDownValue;
  var selectedMonthValue;
  RxBool isExpanded=false.obs;
  RxString rxSelected="".obs;
   String startDate="";
   String endDate="";

  List<Map> leaveList=[
    {"name":"PERSIONAL LEAVE"} ,
    {"name":"SICK LEAVE"} ,
    {"name":"CASUAL LEAVE"}
  ];
  RxList<Map> monthList = [
    {
      "name": "January",
      "month": 01,
      "startDate": "01/01/",
      "endDate": "01/31/"
    },
    {
      "name": "February",
      "month": 02,
      "startDate": "02/01/",
      "endDate": "02/28/"
    },
    {"name": "March", "month": 03, "startDate": "03/01/", "endDate": "31/03/"},
    {"name": "April", "month": 04, "startDate": "04/01/", "endDate": "04/30/"},
    {"name": "May", "month": 05, "startDate": "05/01/", "endDate": "05/31/"},
    {"name": "June", "month": 06, "startDate": "06/01/", "endDate": "06/30/"},
    {"name": "July", "month": 07, "startDate": "07/01/", "endDate": "07/31/"},
    {"name": "August", "month": 08, "startDate": "08/01/", "endDate": "08/31/"},
    {
      "name": "September",
      "month": 09,
      "startDate": "09/01/",
      "endDate": "09/30/"
    },
    {
      "name": "October",
      "month": 10,
      "startDate": "10/01/",
      "endDate": "10/31/"
    },
    {
      "name": "November",
      "month": 11,
      "startDate": "11/01/",
      "endDate": "11/30/"
    },
    {
      "name": "December",
      "month": 12,
      "startDate": "12/01/",
      "endDate": "12/31/"
    },
  ].obs;
  RxString rxMessage="".obs;
  @override
  void onInit() {
    etfirstname.text=AppConstant.sharedPreference.getString(AppConstant.userName).toString();
    // TODO: implement onInit
    getLeaveData();
    super.onInit();
  }


  getLeaveData()async{
    var  bodyJson={
     if(AppConstant.sharedPreference.getBool(AppConstant.isMember)==true) "_id": AppConstant.sharedPreference.getString(AppConstant.memberId).toString().trim(),
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
    };
    print("dvbsdjkvbhsd");
    print(bodyJson);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getpriestLeaveDetailsByPriestID, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("dvbsdjkvbhsd");
    print(response);
    leaveModellist.value=leaveModelFromJson(response);
    if(jsonDecode(response)["statusCode"].toString()=="1")
    {

      if(leaveModellist.value.message!.isEmpty){
        rxMessage.value="No Data Available";
      }
    }

  }


  addLeaveForm()async{
    var  bodyJson={
      "memberId": AppConstant.sharedPreference.getString(AppConstant.memberId).toString().trim(),
      "memberName": etfirstname.text,
      "leaveType": selectedDropDownValue["name"],
      "leavestartDate": etdate.text,
      "leaveEndDate": etEndDate.text,
      "leavestartTime": etStartTime.text,
      "leaveEndTime": etEndTime.text,
      "reason":etNotes.text,
      "leaveStatus": "PENDING",
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
    };
    print(bodyJson);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.priestLeaveForm, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("dvbsdjkvbhsd");
    print(response);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1") {
      Get.back();
    }

  }

  String differTime(String startTime ,String startDate,String endtime,String endDate){
    DateFormat dateFormat2 = DateFormat("MM/dd/yyyy");
    print("Difference in Days: " + startTime);
    print("Difference in Hours: " +startDate);
    print("Difference in Minutes: " +endtime);
    print("Difference in Seconds: " +endDate);
    var date1=startDate;
    var date2=endDate;

    try {
      DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
      DateTime dt1 = dateFormat.parse("$date2 $endtime");
      DateTime dt2 = dateFormat.parse("$date1 $startTime");
      Duration diff = dt1.difference(dt2);
      var days = diff.inDays;
      var hours = diff.inHours % 12;
      var minutes = diff.inMinutes % 60;
      var seconds = diff.inSeconds % 60;
      print("Difference in Days: " + days.toString());
      print("Difference in Hours: " + hours.toString());
    print("Difference in Minutes: " + minutes.toString());
    print("Difference in Seconds: " +seconds.toString());
       if(days!=null && days!=0){
        return days.toString() + "  days " ;
       }




     return hours.toString()+" : "+minutes.toString()+ " Hrs";

    } on Exception catch (e) {
      // TODO
      print(e.toString());
      print("cshbkabscj");
      return "";
    }
  }


  UpdateStatusForm(String id,String status )async{
    var  bodyJson={
      "_id": id,
      "leaveStatus": status,
      "updateRemak":replayRemark.text,
      "statusUpdatedByID":AppConstant.sharedPreference.getString(AppConstant.memberId).toString().trim(),
      "productId":AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
    };
    print(bodyJson);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.priestLeaveFormUpdate, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("dvbsdjkvbhsd");
    print(response);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1") {

    }

  }


}