import 'dart:convert';

import 'package:aspgen_mobile/Templates/fieldPageNew.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../AppConstant/AppConstant.dart';
import '../../../Widget/CustomListshowLeave.dart';
import '../../../Widget/CustomListshowOnly.dart';
import '../../../Widget/DropdownButtonWidget.dart';
import '../../../Widget/EditextWidget.dart';
import '../../../Widget/SearchBarWidget.dart';
import '../controller/leave_controller.dart';
import 'leave_form.dart';
class LeaveListPage extends StatefulWidget {
  final int type;
  const LeaveListPage({Key? key, required this.type}) : super(key: key);

  @override
  State<LeaveListPage> createState() => _LeaveListPageState();
}

class _LeaveListPageState extends State<LeaveListPage> {

  LeaveController controller=Get.put(LeaveController());
  TextEditingController text=new TextEditingController();
  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer);
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: widget.type==1? AppBar(
        title: Text("Leave Requests",overflow: TextOverflow.clip,),
        actions: [
          if(AppConstant.sharedPreference.getBool(AppConstant.isMember)==true) Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            Get.to(()=>LeaveForm(title: 'Leave Form',displayName: "Leave Form",));
           }
            ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        )],
      ):null,
      body:RefreshIndicator(
        onRefresh:() {
      return Future.delayed(Duration.zero, () {
      controller.getLeaveData();
      });
        },
        child: SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Container(
            margin: EdgeInsets.only(top: 0),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(height: 10,),
                SizedBox(height: 4,),
                if(AppConstant.sharedPreference.getBool(AppConstant.isMember)==false) Obx(() =>controller.leaveModellist.value.message!=null?
                Column(
                  children: [
                    Obx(()=>ListView.builder(
                        itemCount:controller.leaveModellist.value.message!.length,
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemBuilder: (context,index)
                        {
                          final datum=controller.leaveModellist.value.message![index];
                          var startDate="";
                          var endDate="";

                          try{
                            startDate=controller.formatter2.format(controller.formatter1.parse(datum.leavestartDate!));
                            endDate=controller.formatter2.format(controller.formatter1.parse(datum.leaveEndDate!));
                          }
                          catch(e){

                          }
                          return CustomListLeaveWidget(title: datum.priestName??"",
                            subTitle: datum.leaveStatus??"",
                            subTitlea:  datum.leavestartDate??"",
                            subTitle2:datum.leaveType,
                            subTitle3:controller.differTime(datum.leavestartTime!, datum.leavestartDate!, datum.leaveEndTime!, datum.leaveEndDate!.isNotEmpty?datum.leaveEndDate!:datum.leavestartDate!),
                            viewMoreWidget: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children:[
                                  if(datum.leavestartDate!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                  if(datum.leavestartDate!.isNotEmpty) viewMore("Date  ",startDate+"  to  "+endDate),

                                  if(datum.leavestartTime!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                  if(datum.leavestartTime!.isNotEmpty) Row(
                                    children: [
                                      Expanded(flex:2,child: viewMore("Start Time", datum.leavestartTime??"")),
                                      Expanded(flex:2,child: viewMore("Finish Time  ", datum.leaveEndTime??"")),
                                    ],
                                  ),


                                  if(datum.updateRemak!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                  if(datum.updateRemak!.isNotEmpty) viewMore("Message  ", datum.updateRemak??""),

                                  if(datum.reason!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                  if(datum.reason!.isNotEmpty) viewMore("Reason  ", datum.reason??""),
                                ]),
                            textEditingController:controller.etSearch,
                            onTapVieMore: (){
                              datum.isChecked=!datum.isChecked!;
                              controller.leaveModellist.refresh();
                            },
                            editOnTap:(){
                              showModalBottomSheet(
                                      context: context,

                                      builder: (context) {
                                        return SingleChildScrollView(
                                          child: Container(
                                            margin: EdgeInsets.all(15),
                                            child: Padding(
                                              padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                                              child: Wrap(

                                                children: [
                                                  Row(
                                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                    children: [
                                                      Expanded(child: Text(datum.priestName!,style: Theme.of(context).textTheme.bodyText1,)),
                                                      IconButton(onPressed: (){
                                                        Get.back();
                                                      }, icon: Icon(Icons.clear,color: Colors.white70,))
                                                    ],
                                                  ),

                                                  EditTextWidget(
                                                    label: "Message",
                                                    controller:controller.replayRemark,
                                                    onchanged:( (value){
                                                    }),
                                                    hint: 'Enter Message',
                                                    validator: (value) {
                                                      if (value == null || value.isEmpty) {
                                                        return 'Please Message';
                                                      }
                                                      return null;
                                                    },

                                                    maxLength: 90,
                                                    keyboardtype: TextInputType.text,
                                                    isPassword: false,
                                                    maxline: 5,

                                                  ),
                                                  Row(
                                                    children: [
                                                      Spacer(flex: 1,),
                                                      Expanded(flex:8,child:ElevatedButton(
                                                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                                                        onPressed: (){
                                                          Get.back();
                                                          approveApprove(context,datum.id!);
                                                        },
                                                        child: Text("Approve"),
                                                      )),
                                                      Spacer(flex: 1,),
                                                      Expanded(flex:8,child:ElevatedButton(
                                                        style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                                                        onPressed: (){
                                                          Get.back();
                                                          cancelApprove(context,datum.id!);
                                                        },
                                                        child: Text("Cancel"),
                                                      )),
                                                      Spacer(flex: 1,)
                                                    ],
                                                  ),
                                                  SizedBox(height: 20,),
                                                ],
                                              ),
                                            ),
                                          ),
                                        );
                                      },
                                    );
                            }, isClicked: datum.isChecked!,
                          );



                        })
                // :
                //           Center(child: Text(controller.rxMessage.value),),
                    ),
                  ],
                ):Container(),),
                if(AppConstant.sharedPreference.getBool(AppConstant.isMember)==true) Obx(() =>controller.leaveModellist.value.message!=null?
                Column(
                  children: [
                    Obx(()=>ListView.builder(
                        itemCount:controller.leaveModellist.value.message!.length,
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemBuilder: (context,index)
                        {
                          final datum=controller.leaveModellist.value.message![index];
                          var startDate="";
                          var endDate="";

                          try{
                            startDate=controller.formatter2.format(controller.formatter1.parse(datum.leavestartDate!));
                            endDate=controller.formatter2.format(controller.formatter1.parse(datum.leaveEndDate!));
                          }
                          catch(e){

                          }
                          return CustomListLeaveWidget(title: datum.priestName??"",
                            subTitle: datum.leaveStatus??"",
                            subTitlea:  datum.leavestartDate??"",
                            subTitle2:datum.leaveType,
                            subTitle3:controller.differTime(datum.leavestartTime!, datum.leavestartDate!, datum.leaveEndTime!, datum.leaveEndDate!.isNotEmpty?datum.leaveEndDate!:datum.leavestartDate!),
                            viewMoreWidget: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children:[
                                  if(datum.leavestartDate!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                  if(datum.leavestartDate!.isNotEmpty) viewMore("Date  ",startDate+"  to  "+endDate),

                                  if(datum.leavestartTime!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                  if(datum.leavestartTime!.isNotEmpty) Row(
                                    children: [
                                      Expanded(flex:2,child: viewMore("Start Time", datum.leavestartTime??"")),
                                      Expanded(flex:2,child: viewMore("Finish Time  ", datum.leaveEndTime??"")),
                                    ],
                                  ),


                                  if(datum.updateRemak!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                  if(datum.updateRemak!.isNotEmpty) viewMore("Message  ", datum.updateRemak??""),

                                  if(datum.reason!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                  if(datum.reason!.isNotEmpty) viewMore("Reason  ", datum.reason??""),
                                ]),
                            textEditingController:controller.etSearch,
                            onTapVieMore: (){
                              datum.isChecked=!datum.isChecked!;
                              controller.leaveModellist.refresh();
                            },
                            editOnTap: null, isClicked: datum.isChecked!,
                          );



                        })
                      // :
                      //           Center(child: Text(controller.rxMessage.value),),
                    ),
                  ],
                )
                    :Container(),),


              ],
            ),
          ),
        ),
      ),

    );
  }

  void cancelApprove(BuildContext  context,String id)
  {
    showCupertinoDialog(
      context: context,
      builder: (context) {
        return CupertinoAlertDialog(
          title: Text("REJECTE !"),
          content: Text("Are you sure you want to Rejecte the Leave?"),

          actions: [
            CupertinoDialogAction(
                child: Text("No"),
                isDefaultAction: true,
                onPressed: ()
                {
                  Navigator.of(context).pop();
                }
            ),
            CupertinoDialogAction(
              child: Text("Yes?"),

              isDefaultAction: true,
              isDestructiveAction: true,
              onPressed: (){
                controller.UpdateStatusForm(id, "REJECTED");
                Navigator.of(context).pop();
              }
              ,
            )
          ],
        );
      },
    );
  }
  void approveApprove(BuildContext  context,String id)
  {
    showCupertinoDialog(
      context: context,
      builder: (context) {
        return CupertinoAlertDialog(
          title: Text("Approve !"),
          content: Text("Are you sure you want to Approve the Leave?"),

          actions: [
            CupertinoDialogAction(
                child: Text("No"),
                isDefaultAction: true,
                isDestructiveAction: true,
                onPressed: ()
                {
                  Navigator.of(context).pop();
                }
            ),
            CupertinoDialogAction(
              child: Text("Approve?"),

              isDefaultAction: true,

              onPressed: (){
                controller.UpdateStatusForm(id, "APPROVED");
                Navigator.of(context).pop();
              }
              ,
            )
          ],
        );
      },
    );
  }
}
