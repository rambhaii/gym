import 'dart:convert';

import 'package:aspgen_mobile/Templates/fieldPageNew.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../AppConstant/AppConstant.dart';
import '../../../Widget/DropdownButtonWidget.dart';
import '../../../Widget/EditextWidget.dart';
import '../../../Widget/SearchBarWidget.dart';
import '../controller/leave_controller.dart';
class LeaveForm extends StatefulWidget {
  final String title;
  final String displayName;
  const LeaveForm({Key? key, required this.title, required this.displayName}) : super(key: key);

  @override
  State<LeaveForm> createState() => _LeaveFormState();
}

class _LeaveFormState extends State<LeaveForm> {

  LeaveController controller=Get.find();
  @override
  void initState() {
    // TODO: implement initState
    controller.selectedDropDownValue=null;
    controller.etdate.text="";
    controller.etStartTime.text="";
    controller.etEndTime.text="";
    controller.etRange.text="";
    controller.etEndDate.text="";
    controller.etRange.text="";
    controller.selectedMonthValue=null;
    controller.etNotes.text="";

    super.initState();
  }
  @override
  Widget build(BuildContext context) {

    BoxDecoration decoration=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer);
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.displayName,overflow: TextOverflow.clip,),
        actions: [
       Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            if(controller.formKey.currentState!.validate())
              {
               if(controller.selectedDropDownValue!=null)
                 {
                   controller.addLeaveForm();
                 }
               else{
                 Get.snackbar("Alert!", "Please Select Day Type",borderRadius: 2,icon: Icon(Icons.warning_amber),
                     backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.amber,Colors.black12])
                 );
               }
                //;
              }
          
          }
            ,child: Icon(Icons.save),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        )],
      ),
      body:  SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 10,),
              Obx(()=> Container(
                  margin: EdgeInsets.only(top:15,left: 6,right: 6),
                  decoration:decoration.copyWith(border: Border.all(color: (controller.isExpanded.value==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                  child:Form(
                 key: controller.formKey,
                    child: ExpansionTileCard(
                        finalPadding: EdgeInsets.only(left: 10,right: 10,bottom: 8),
                        baseColor: Colors.transparent,
                        elevation: 0,
                        expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                        key: controller.Group1Key,
                        onExpansionChanged: ((value){
                          controller.isExpanded.value=value;
                        }),
                        title: Text("Leave Form"),
                        children:[
                          SizedBox(height: 8,),
                          EditTextWidget(
                            label: "User Name",
                            controller: controller.etfirstname,
                            hint: 'Enter first name',
                            isRead: true,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter form first name';
                              }
                              return null;
                            },
                            maxLength: 60,
                            keyboardtype: TextInputType.text,
                            isPassword: false,
                          ),
                          SizedBox(height: 6,),
                          DropdownButtonWidget(
                 change: (value) {
                     controller.selectedDropDownValue=value;
                     controller.rxSelected.value=controller.selectedDropDownValue["name"];
                     controller.isExpanded.refresh();
                 },
                 title: "Select Leave",
                 list:controller.leaveList,
                 hint:  "Select Leave",
                 selectvalue:controller.selectedDropDownValue,
                 onPress: '',
               ),
                          SizedBox(height: 12),
                          Row(
                            children: [
                              Expanded(
                                flex:2,
                                child: GestureDetector(
                                  onTap: ()async{
                                    controller.startPickedDate= await  showDatePicker(
                                        context: context,
                                        initialDate:DateTime.now(),
                                        firstDate: DateTime.now(),
                                        lastDate: DateTime(2100),
                                        builder: (context, child) {
                                          return Theme(
                                            data: ThemeData.dark().copyWith(
                                                colorScheme: const ColorScheme.dark(
                                                    onPrimary: Colors.white,
                                                    // selected text color
                                                    onSurface: Colors.white,
                                                    // default text color
                                                    primary: Colors
                                                        .teal // circle color
                                                ),
                                                dialogBackgroundColor: Theme
                                                    .of(context)
                                                    .backgroundColor,

                                                textButtonTheme: TextButtonThemeData(
                                                    style: TextButton.styleFrom(
                                                        textStyle: const TextStyle(
                                                            color: Colors.white,
                                                            fontWeight: FontWeight
                                                                .normal,
                                                            fontSize: 12,
                                                            fontFamily: 'Quicksand'),
                                                        primary: Colors.white,
                                                        // color of button's letters
                                                        backgroundColor: Colors
                                                            .black54,
                                                        // Background color
                                                        shape: RoundedRectangleBorder(
                                                            side: const BorderSide(
                                                                color: Colors
                                                                    .transparent,
                                                                width: 1,
                                                                style: BorderStyle
                                                                    .solid),
                                                            borderRadius: BorderRadius
                                                                .circular(50))))),

                                            child: child!,
                                          );
                                        }

                                    );

                                    final String formatted = controller.formatter.format(controller.startPickedDate!);
                                    controller.etEndDate.clear();
                                    controller.etdate.text=formatted;

                                  },
                                  child: AbsorbPointer(
                                    child: EditTextWidget(
                                      label: "Start Date",
                                      controller: controller.etdate,
                                      hint: 'Start Date',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please Select Date';
                                        }
                                        return null;
                                      },
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                  ),
                                ),
                              ),
                              SizedBox(width: 8,),
                              Expanded(
                                flex: 2,
                                child: GestureDetector(
                                  onTap: ()async{
                                    final DateTime? picked= await  showDatePicker(
                                        context: context,
                                        initialDate:controller.startPickedDate?? DateTime.now(),
                                        firstDate: DateTime.now(),
                                        lastDate: DateTime(2100),
                                        builder: (context, child) {
                                          return Theme(
                                            data: ThemeData.dark().copyWith(
                                                colorScheme: const ColorScheme.dark(
                                                    onPrimary: Colors.white,
                                                    // selected text color
                                                    onSurface: Colors.white,
                                                    // default text color
                                                    primary: Colors
                                                        .teal // circle color
                                                ),
                                                dialogBackgroundColor: Theme
                                                    .of(context)
                                                    .backgroundColor,

                                                textButtonTheme: TextButtonThemeData(
                                                    style: TextButton.styleFrom(
                                                        textStyle: const TextStyle(
                                                            color: Colors.white,
                                                            fontWeight: FontWeight
                                                                .normal,
                                                            fontSize: 12,
                                                            fontFamily: 'Quicksand'),
                                                        primary: Colors.white,
                                                        // color of button's letters
                                                        backgroundColor: Colors
                                                            .black54,
                                                        // Background color
                                                        shape: RoundedRectangleBorder(
                                                            side: const BorderSide(
                                                                color: Colors
                                                                    .transparent,
                                                                width: 1,
                                                                style: BorderStyle
                                                                    .solid),
                                                            borderRadius: BorderRadius
                                                                .circular(50))))),

                                            child: child!,
                                          );
                                        }

                                    );
                                    if(controller.startPickedDate!=null)
                                      {
                                        if(controller.startPickedDate!.isBefore(picked!))
                                        {
                                          final String formatted = controller.formatter.format(picked);
                                          controller.etEndDate.text=formatted;
                                        }
                                        else{
                                          controller.etEndDate.clear();
                                          Fluttertoast.showToast(msg:"End date must be after startDate");
                                        }

                                      }

                                    },
                                  child: AbsorbPointer(
                                    child: EditTextWidget(
                                      label: "End Date",
                                      controller: controller.etEndDate,
                                      hint: 'End Date',
                                      validator: (value) {
                                        return null;
                                      },
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                          SizedBox(height: 6,),
                          Row(
                            children: [
                              Expanded(child:  GestureDetector(
                                onTap: ()async{
                                  TimeOfDay? time = await showTimePicker(
                                      context: context,
                                      initialTime: TimeOfDay.now(),
                                      builder: (context, child) {
                                        return Theme(
                                          data: ThemeData.dark().copyWith(
                                              colorScheme: const ColorScheme.dark(
                                                  onPrimary: Colors.white,
                                                  onSurface: Colors.white,
                                                  primary: Colors.teal // circle color
                                              ),
                                              dialogBackgroundColor: Theme
                                                  .of(context)
                                                  .backgroundColor,

                                              textButtonTheme: TextButtonThemeData(
                                                  style: TextButton.styleFrom(
                                                      textStyle: const TextStyle(
                                                          color: Colors.white,
                                                          fontWeight: FontWeight
                                                              .normal,
                                                          fontSize: 12,
                                                          fontFamily: 'Quicksand'),
                                                      primary: Colors.white,
                                                      backgroundColor: Colors.black54,
                                                      shape: RoundedRectangleBorder(
                                                          side: const BorderSide(
                                                              color: Colors
                                                                  .transparent,
                                                              width: 1,
                                                              style: BorderStyle
                                                                  .solid),
                                                          borderRadius: BorderRadius
                                                              .circular(50))))),
                                          child: child!,
                                        );
                                      }
                                  );
                                  if(time!=null)
                                  {
                                    controller.etStartTime.text=formatTimeOfDay(time!);

                                  }
                                },
                                child: AbsorbPointer(
                                  child: EditTextWidget(
                                    label: "Start Time",
                                    controller: controller.etStartTime,
                                    hint: 'Start Time',
                                    isRead: true,
                                    validator: (value) {

                                    },
                                    maxLength: 60,
                                    keyboardtype: TextInputType.text,
                                    isPassword: false,
                                  ),
                                ),
                              ),),
                              SizedBox(width: 10,),
                              Expanded(child:  GestureDetector(
                                behavior: HitTestBehavior.translucent,
                                onTap: ()async{
                                  TimeOfDay? time = await showTimePicker(
                                      context: context,
                                      initialTime: TimeOfDay.now(),
                                      builder: (context, child) {
                                        return Theme(
                                          data: ThemeData.dark().copyWith(
                                              colorScheme: const ColorScheme.dark(
                                                  onPrimary: Colors.white,
                                                  onSurface: Colors.white,
                                                  primary: Colors.teal // circle color
                                              ),
                                              dialogBackgroundColor: Theme
                                                  .of(context)
                                                  .backgroundColor,

                                              textButtonTheme: TextButtonThemeData(
                                                  style: TextButton.styleFrom(
                                                      textStyle: const TextStyle(
                                                          color: Colors.white,
                                                          fontWeight: FontWeight
                                                              .normal,
                                                          fontSize: 12,
                                                          fontFamily: 'Quicksand'),
                                                      primary: Colors.white,
                                                      // color of button's letters
                                                      backgroundColor: Colors
                                                          .black54,
                                                      // Background color
                                                      shape: RoundedRectangleBorder(
                                                          side: const BorderSide(
                                                              color: Colors
                                                                  .transparent,
                                                              width: 1,
                                                              style: BorderStyle
                                                                  .solid),
                                                          borderRadius: BorderRadius
                                                              .circular(50))))),
                                          child: child!,
                                        );
                                      }
                                  );
                                  if(time!=null)
                                  {
                                    controller.etEndTime.text=formatTimeOfDay(time);
                                  }
                                },
                                child: AbsorbPointer(
                                  child: EditTextWidget(
                                    label: "End Time",
                                    controller: controller.etEndTime,
                                    hint: 'End Time',
                                    isRead: true,
                                    validator: (value) {

                                    },
                                    maxLength: 60,
                                    keyboardtype: TextInputType.text,
                                    isPassword: false,
                                  ),
                                ),
                               ),
                              ),
                            ],
                          ),

                          SizedBox(height: 6,),
                          EditTextWidget(
                            label: "Leave Reasons",
                            controller: controller.etNotes,
                            hint: 'Enter leave reasons',
                            validator: (value) {

                            },
                            maxLength: 2000,
                            keyboardtype: TextInputType.text,
                            isPassword: false,
                            maxline: 6,
                          ),
                            
                          SizedBox(height: 15),
                        ]
                    ),
                  ),
                ),
              ),

            ],
          ),
        ),
      ),

    );
  }
  dateTime()async{
    DateTimeRange? picked= await  showDateRangePicker(
        context: Get.context!,
        firstDate:DateTime.now(),
        lastDate: DateTime(DateTime.now().year+2),
        initialDateRange:controller.pickedRangeDate??  DateTimeRange(
          start: DateTime.now(),
          end:DateTime.now().add(Duration(hours: 24*1)),
        ),
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
                colorScheme: const ColorScheme.dark(
                    onPrimary: Colors.white,
                    // selected text color
                    onSurface: Colors.white,
                    // default text color
                    primary: Colors
                        .teal // circle color
                ),
                dialogBackgroundColor: Theme
                    .of(context)
                    .backgroundColor,

                textButtonTheme: TextButtonThemeData(
                    style: TextButton.styleFrom(
                        textStyle: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight
                                .normal,
                            fontSize: 12,
                            fontFamily: 'Quicksand'),
                        primary: Colors.white,
                        // color of button's letters
                        backgroundColor: Colors
                            .black54,
                        // Background color
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                color: Colors
                                    .transparent,
                                width: 1,
                                style: BorderStyle
                                    .solid),
                            borderRadius: BorderRadius
                                .circular(50))))),

            child: child!,
          );
        }

    );
    if(picked!=null)
    {
      controller.pickedRangeDate=picked;
      final String start = controller.formatter.format(picked.start)+ "  -  "+controller.formatter.format(picked.end);
      controller.startDate=controller.formatter.format(picked.start);
      controller.endDate=controller.formatter.format(picked.end);
      controller.etRange.text=start;
    }



  }
  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
    final format = DateFormat.jm(); // YOUR DATE GOES HERE
    return format.format(dt);
  }

}
