import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Request/model/service_model.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../Dashboard/Contact/Model/AllContactDatas.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/base_client.dart';


class PriestServiceRequestController extends GetxController{
  var bodyJson={};
  var bodyJson2={};
  var email="".obs;
  var phone="".obs;
  var selectedValue;
   RxBool isPriestAvl=false.obs;
   RxInt isSelected=0.obs;
  RxBool isExpend1=false.obs;
  RxBool isExpend2=false.obs;
  RxBool isExpend3=false.obs;
  RxBool isExpend4=false.obs;
  final DateFormat formatter = DateFormat('MMM dd , yyyy');
  final DateFormat formatter1 = DateFormat('MM/dd/yyyy');
  var datas=ServiceRequestData().obs;
  var filterdatas=ServiceRequestData().obs;
  var approveDatum={};
  TextEditingController etSearch= new TextEditingController();
  Rx<ServiceRequestDatum> datum=ServiceRequestDatum().obs;
  Rx<AllContactDatas> allContactDatas= AllContactDatas().obs;
 RxList<Map> map=RxList([]);
 RxString rxStatus="SCHEDULED".obs;

  var maskFormatter = new MaskTextInputFormatter(
      mask: '(###) ###-####',
      filter: {"#": RegExp(r'[0-9]')},
      type: MaskAutoCompletionType.lazy);

  List<String> statusList=[
    "SCHEDULED",
    "COMPLETED",
  ];
 RxString rxMessage="".obs;
  @override
  void onInit() {
    print("@@email");
    print(UtilMethods.decrypt(AppConstant.sharedPreference.getString(AppConstant.userEmail).toString().trim(),));
    fetchApi();
    super.onInit();
  }
  fetchApi()async{
    bodyJson={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
      "priestEmail": AppConstant.sharedPreference.getString(AppConstant.userEmail).toString().trim(),
      "status":rxStatus.value,
    };
    print("vdsbhvbdjs");
    print(bodyJson);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getServiceRequestByPriestID, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    print("sdbvhjdsbjkv");
    print(response);

    datas.value=ServiceRequestData.fromJson(jsonDecode(response));
    filterdatas.value=ServiceRequestData.fromJson(jsonDecode(response));
    if(datas.value.data!.isEmpty)
    {
      rxMessage.value="No Service Available";
    }

  }
  sendData(ServiceRequestDatum data){
    datum.value=data;
    email.value="";
    phone.value="";
  }



  approveApi(String id)async{
    var bodyrequest={};
    bodyrequest={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
      "serviceStatus":"COMPLETED",
       "_id":id,
    };
      Get.context!.loaderOverlay.show();
      var response=await BaseClient().post(APIsConstant.udateServiceRequestAPI, bodyrequest).catchError(BaseController().handleError);
      Get.context!.loaderOverlay.hide();
      if(response==null) return;
      if(jsonDecode(response)["statusCode"].toString()=="1"){
        Get.back();
        Get.snackbar("Success", "Status Updated",borderRadius: 2,icon: Icon(Icons.check_rounded),backgroundGradient: LinearGradient(colors: [
          Colors.green,Colors.black12
        ]));
         fetchApi();
      };
    }

  void filterData(String search){
    List<ServiceRequestDatum> result=[];
    if(search.isEmpty)
    {
      result=filterdatas.value.data!;
    }
    else{
      result=filterdatas.value.data!.where((element) =>element.serviceName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    datas.value.data=result;
    datas.refresh();
  }

  void showDialogApprove(BuildContext  context,String id)
  {
    showCupertinoDialog(
      context: context,
      builder: (context) {
        return CupertinoAlertDialog(
          title: Text("Complete!"),
          content: Text("Are you sure you want to Complete the Service?"),
          actions: [
            CupertinoDialogAction(
                child: Text("Cancel"),
                isDefaultAction: true,
                isDestructiveAction: true,
                onPressed: ()
                {
                  Navigator.of(context).pop();
                }
            ),
            CupertinoDialogAction(
              child: Text("Complete?"),
              isDefaultAction: true,
              onPressed: (){
                approveApi(id);
                Navigator.of(context).pop();
              }
              ,
            )
          ],
        );
      },
    );
  }

}