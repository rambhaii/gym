import 'package:aspgen_mobile/Dashboard/Request/conroller/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/Request/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/Request/service_request_details_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import '../../AppConstant/AppColors.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListFourTitleWidget.dart';
import '../../Widget/EditextWidget.dart';
import '../../Widget/SearchBarWidget.dart';
class PriestServiceRequestPage extends StatelessWidget {
   PriestServiceRequestPage({Key? key}) : super(key: key);
  PriestServiceRequestController _controller=Get.put(PriestServiceRequestController());
  @override
  Widget build(BuildContext context) {
       return Scaffold(
      appBar: AppBar(title: Text("Service Request"),
      actions: [
        Obx(() =>  PopupMenuButton<String>(
          child: Icon(Icons.filter_alt_outlined),
          color: Theme.of(context).colorScheme.onPrimaryContainer.withRed(3),
          offset: Offset(10, 50),
          elevation: 5,
          itemBuilder:(context) =>
              List.generate(_controller.statusList.length,(int index)=>
                  PopupMenuItem<String>(
                      value: _controller.statusList[index],
                      child:Text(_controller.statusList[index])
                  )

              ),
          initialValue: _controller.rxStatus.value,
          enabled: true,
          onSelected: (value) {
            _controller.rxStatus.value=value;
            _controller.fetchApi();
          },

        ),

        ),
        SizedBox(width: 15,)
      ],
      ),
      body: Container(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 10,),
              GetBuilder<PriestServiceRequestController>(
                builder: (controller)=>  SearchBarWidget(
                  hint: "Search",
                  controller: controller.etSearch,
                  onchange: (value){
                   _controller.filterData(value);
                  },
                  onCancel: (){
                    controller.etSearch.clear();
                    _controller.filterData(controller.etSearch.text);
                    controller.update();
                  },
                ),
              ),
              SizedBox(height: 8,),
              Obx(() =>(_controller.datas.value.data!=null && _controller.datas.value.data!.isNotEmpty)? ListView.builder(
                shrinkWrap: true,
                    itemCount: _controller.datas.value.data!.length,
                    itemBuilder: (context,index){
                  var dateTime="";

                      final datum=_controller.datas.value.data![index];
                  try{
                    dateTime=_controller.formatter.format(_controller.formatter1.parse(datum.serviceDate!));
                      }
                      catch(e){

                      }
                  return
                    CustomListFourWidget(title: dateTime + "  at " +datum.serviceTime!,
                    subTitle: datum.serviceName??"",
                    subTitle2: (datum.serviceCategoryTypes??""),
                    subTitle3: datum.comments!.contactName??"",
                    viewMoreWidget: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children:[
                          if(datum.prsnPhone!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          if(datum.prsnPhone!.isNotEmpty) viewMore("Phone  ",phoneFormatter(datum.prsnPhone!)),
                          if(datum.prsnEmail!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          if(datum.prsnEmail!.isNotEmpty) viewMore("Email  ", UtilMethods.decrypt(datum.prsnEmail!)),
                          if(datum.serviceStatus!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          if(datum.serviceStatus!.isNotEmpty) viewMore("Service Status  ",datum.serviceStatus??""),
                          if(datum.notes!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          if(datum.notes!.isNotEmpty) viewMore("Notes ",datum.notes??""),
                        ]),
                    textEditingController:_controller.etSearch,
                    onTapVieMore: (){
                      datum.isChecked=!datum.isChecked!;
                      _controller.datas.refresh();
                    },
                    icon: Icons.arrow_forward_ios,
                    iconColor:Colors.white,
                    editOnTap: (){
                      CheckInternetConnection().then((value) {
                        if(value==true)
                        {
                          _controller.sendData(datum);
                          Navigator.push(context,MaterialPageRoute(builder: (context)=>PriestServiceRequestDetailsPage()));
                        }
                      });
                    }, isClicked: datum.isChecked!,
                  );
                })

                  :Center(
                child: Text(_controller.rxMessage.value,style: Theme.of(context).textTheme.bodyText2,),
              ),
              ),
            ],
          ),
        ),
      ),
    );
  }
   void showCustomDialog(BuildContext context) {
     showGeneralDialog(
       context: context,
       barrierLabel: "Barrier",
       barrierDismissible: true,
       barrierColor: Colors.transparent,
       transitionDuration: Duration(milliseconds: 500),
       pageBuilder: (_, __, ___) {
         return Center(
           child: GlassmorphicContainer(
             borderRadius: 5,
             blur: 10,
             border: 0.1,
             linearGradient: LinearGradient(
                 begin: Alignment.topLeft,
                 end: Alignment.bottomRight,
                 colors: [
                   Color(0xFFffffff).withOpacity(0.1),
                   Color(0xFFFFFFFF).withOpacity(0.05),
                 ],
                 stops: [
                   0.1,
                   1,
                 ]),
             borderGradient: LinearGradient(
               begin: Alignment.topLeft,
               end: Alignment.bottomRight,
               colors: [
                 Color(0xFFffffff).withOpacity(0.5),
                 Color((0xFFFFFFFF)).withOpacity(0.5),
               ],
             ),
             height: 190,
             alignment: Alignment.center,
             width: Get.width*0.8,
             child:Column(
               crossAxisAlignment:CrossAxisAlignment.center,
               mainAxisAlignment: MainAxisAlignment.center,
               children: [

              if(_controller.rxStatus.value!="COMPLETED")   Row(
                   children: [
                     Spacer(flex: 1,),
                     Expanded(
                       flex: 10,
                       child: OutlinedButton(
                         child: Text('Complete Service'),
                         style: OutlinedButton.styleFrom(
                           backgroundColor: Colors.green.withOpacity(0.2),
                           side: BorderSide(color: Colors.grey, width: 0.5),
                             shape: StadiumBorder(),
                         ),
                         onPressed: () {
                           _controller.showDialogApprove(context, _controller.datum.value.id!);

                         },
                       ),
                     ),
                     Spacer(flex: 1,),
                   ],
                 ),
                 // Row(
                 //   children: [
                 //     Spacer(flex: 1,),
                 //     Expanded (
                 //         flex: 10,
                 //         child: OutlinedButton(
                 //         child: Text('Message Devotee'),
                 //         style: OutlinedButton.styleFrom(
                 //           backgroundColor: Colors.amber.withOpacity(0.2),
                 //           side: BorderSide(color: Colors.grey, width: 0.5),
                 //             shape: StadiumBorder(),
                 //            ),
                 //           onPressed: () {
                 //             showDataAlert(context);
                 //           },
                 //       ),
                 //     ),
                 //     Spacer(flex: 1,),
                 //   ],
                 // ),
                 // Row(
                 //   children: [
                 //     Spacer(flex: 1,),
                 //     Expanded(
                 //       flex: 10,
                 //       child: OutlinedButton(
                 //         child: Text('View Message'),
                 //         style: OutlinedButton.styleFrom(
                 //           backgroundColor:  Colors.blue.withOpacity(0.1),
                 //           side: BorderSide(color: Colors.grey, width: 0.5),
                 //             shape: StadiumBorder(),
                 //         ),
                 //         onPressed: () {
                 //           showMessageData(context);
                 //         },
                 //       ),
                 //     ),
                 //     Spacer(flex: 1,),
                 //   ],
                 // ),

                 Row(
                   children: [
                     Spacer(flex: 1,),
                     Expanded(
                       flex: 10,
                       child: OutlinedButton(
                         child: Text('View Service'),
                         style: OutlinedButton.styleFrom(
                           backgroundColor:Colors.purple.withOpacity(0.1),
                           side: BorderSide(color: Colors.grey, width: 0.5),
                             shape: StadiumBorder(),
                         ),
                         onPressed: () {
                           Get.off(()=>PriestServiceRequestDetailsPage());
                         },
                       ),
                     ),
                     Spacer(flex: 1,),
                   ],
                 ),

                 Row(
                   children: [
                     Spacer(flex: 1,),
                     Expanded(
                       flex: 10,
                       child: OutlinedButton(
                         child: Text('Cancel'),
                         style: OutlinedButton.styleFrom(
                           backgroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
                           side: BorderSide(color: Colors.grey, width: 0.5),
                             shape: StadiumBorder(),
                         ),
                         onPressed: () {
                         Get.back();
                         },
                       ),
                     ),
                     Spacer(flex: 1,),
                   ],
                 ),
               ],
             ),
             padding: EdgeInsets.all(15),


           ),
         );
       },
       transitionBuilder: (_, anim, __, child) {
         Tween<Offset> tween;
         if (anim.status == AnimationStatus.reverse) {
           tween = Tween(begin: Offset(-1, 0), end: Offset.zero);
         } else {
           tween = Tween(begin: Offset(1, 0), end: Offset.zero);
         }

         return SlideTransition(
           position: tween.animate(anim),
           child: FadeTransition(
             opacity: anim,
             child: child,
           ),
         );
       },
     );
   }

}
