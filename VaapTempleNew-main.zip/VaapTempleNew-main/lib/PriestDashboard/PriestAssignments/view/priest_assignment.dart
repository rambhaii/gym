import 'package:aspgen_mobile/Templates/fieldPageNew.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../Widget/SearchBarWidget.dart';
class PriestAssignmentPage extends StatefulWidget {
  final String title;
  final String displayName;
  const PriestAssignmentPage({Key? key, required this.title, required this.displayName}) : super(key: key);

  @override
  State<PriestAssignmentPage> createState() => _PriestAssignmentPageState();
}

class _PriestAssignmentPageState extends State<PriestAssignmentPage> {
  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.displayName,overflow: TextOverflow.clip,),
        actions: [  Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            CheckInternetConnection().then((value1) => value1==true? Get.to(()=>FieldPageNew(title: widget.title,type: 1,)):"");
          }
            ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        )],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 10,),
             SearchBarWidget(
                hint: "Search",
                controller: TextEditingController(),
                onchange: (value){
                  // value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi():"";
                  // controller.update();
                },
                onCancel: (){
                  // controller.etSearch.clear();
                  // controller.fetchApi();
                  // controller.update();
                },

            ),
            SizedBox(height: 4,),
            // Obx(() =>punchListController.purchaseData.value.data!=null?Expanded(
            //   child: RefreshIndicator(
            //     onRefresh: (){
            //       return Future.delayed(Duration.zero, () {
            //         punchListController.fetchApi();
            //       });
            //     },
            //     child: Column(
            //       children: [
            //         Expanded(
            //           child: ListView.builder(
            //               itemCount:punchListController.purchaseData.value.data!.length,
            //               itemBuilder: (context,index)
            //               {
            //                 final datum=punchListController.purchaseData.value.data![index];
            //                 return CustomListWidget(title: datum.title??"",
            //                   subTitle: datum.store??"",
            //                   viewMoreWidget: Column(
            //                       crossAxisAlignment: CrossAxisAlignment.start,
            //                       children:[
            //                         if(datum.item!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
            //                         if(datum.item!.isNotEmpty) viewMore("Item Name  ",datum.item??""),
            //                         if(datum.qty!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
            //                         if(datum.qty!.isNotEmpty) viewMore("Qty  ", datum.qty??""),
            //
            //                         // RichText(
            //                         //   text: TextSpan(
            //                         //     text: "Item Name :  ",
            //                         //     style: Theme.of(context).textTheme.bodyText2,
            //                         //     children: <TextSpan>[
            //                         //       TextSpan(text:datum.item!,
            //                         //           style: Theme.of(context).textTheme.bodyText1),
            //                         //
            //                         //     ],
            //                         //   ),
            //                         // ),
            //                         //
            //                         // RichText(
            //                         //   text: TextSpan(
            //                         //     text: 'Qty ',
            //                         //     style: Theme.of(context).textTheme.bodyText2,
            //                         //     children: <TextSpan>[
            //                         //       TextSpan(text:datum.qty,
            //                         //           style: Theme.of(context).textTheme.bodyText1),
            //                         //     ],
            //                         //   ),
            //                         // ),
            //
            //                       ]),
            //                   textEditingController:punchListController.etSearch,
            //                   onTapVieMore: (){
            //                     datum.isChecked=!datum.isChecked!;
            //                     punchListController.purchaseData.refresh();
            //                   },
            //                   editOnTap: (){
            //                     CheckInternetConnection().then((value) {
            //                       if(value==true)
            //                       {
            //                         Get.to(()=>FieldPageNew(title: widget.title,type: 2,id: datum.id,),arguments: {"data": json.decode(json.encode(datum))});
            //                       }
            //                     });
            //                   }, isClicked: datum.isChecked!,
            //                 );
            //
            //
            //               }),
            //         ),
            //       ],
            //     ),
            //   ),
            // ):Container(),
            // ),

          ],
        ),
      ),

    );
  }
}
