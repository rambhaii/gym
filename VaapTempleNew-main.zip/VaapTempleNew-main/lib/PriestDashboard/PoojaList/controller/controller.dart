import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Request/model/service_model.dart';
import 'package:aspgen_mobile/UtilMethods/BaseController.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:aspgen_mobile/UtilMethods/base_client.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:aspgen_mobile/PriestDashboard/PoojaList/view/ViewPoojaListPage.dart';
import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../Dashboard/Contact/Model/AllContactDatas.dart';



class PoojaListController extends GetxController{
  var bodyJson={};
  var bodyJson2={};
  var email="".obs;
  var phone="".obs;
  var selectedValue;
  RxBool isPriestAvl=false.obs;
  RxInt isSelected=0.obs;
  RxBool isExpend1=false.obs;
  RxBool isExpend2=false.obs;
  RxBool isExpend3=false.obs;
  var bodyJsonRequest={};
  final DateFormat formatter = DateFormat('MMM dd , yyyy');
  final DateFormat formatter1 = DateFormat('MM/dd/yyyy');
  var datas=ServiceRequestData().obs;

  RxList<PoojaList> poojaList=RxList<PoojaList>([]);

  var filterdatas=ServiceRequestData().obs;
  var approveDatum={};
  RxList<dynamic> rxfieldList=RxList([{
            "name": TextEditingController(),
            "qty":  TextEditingController(),
            "uom":  TextEditingController(),
          }
     ]);

  var fildDataList=[];
  TextEditingController etSearch= new TextEditingController();
  TextEditingController etProductName= new TextEditingController();
  TextEditingController etqty= new TextEditingController();
  TextEditingController etumo= new TextEditingController();
  Rx<ServiceRequestDatum> datum=ServiceRequestDatum().obs;
  Rx<AllContactDatas> allContactDatas= AllContactDatas().obs;
  RxList<Map> map=RxList([]);
  RxString rxStatus="SCHEDULED".obs;

  var maskFormatter = new MaskTextInputFormatter(
      mask: '(###) ###-####',
      filter: {"#": RegExp(r'[0-9]')},
      type: MaskAutoCompletionType.lazy);

  RxString rxMessage="".obs;
  @override
  void onInit() {
    print("@@email");

    print(UtilMethods.decrypt(AppConstant.sharedPreference.getString(AppConstant.userEmail).toString().trim(),));
    fetchApi();
    super.onInit();
  }


  fetchApi()async{
    bodyJson={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
      "username": AppConstant.sharedPreference.getString(AppConstant.userName).toString().trim(),
      "query": {"serviceStatus":rxStatus.value}
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getServiceRequest, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    datas.value=ServiceRequestData.fromJson(jsonDecode(response));
    filterdatas.value=ServiceRequestData.fromJson(jsonDecode(response));
    if(datas.value.data!.isEmpty)
    {
      rxMessage.value="No Service Available";
    }

  }
  sendData(ServiceRequestDatum data){
    datum.value=data;
    email.value="";
    phone.value="";
  }



  approveApi(String id)async{
    var bodyrequest={};
    bodyrequest={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
      "serviceStatus":"COMPLETED",
      "_id":id,
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.udateServiceRequestAPI, bodyrequest).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1"){
      Get.back();
      Get.snackbar("Success", "Status Updated",borderRadius: 2,icon: Icon(Icons.check_rounded),backgroundGradient: LinearGradient(colors: [
        Colors.green,Colors.black12
      ]));
      fetchApi();
    };
  }

  void filterData(String search)
  {
    List<ServiceRequestDatum> result=[];
    if(search.isEmpty)
    {
      result=filterdatas.value.data!;
    }
    else{
      result=filterdatas.value.data!.where((element) =>element.serviceName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    datas.value.data=result;
    datas.refresh();
  }

  sendPoojaList(List<PoojaList> poojadatum){
    poojaList.value=poojadatum;
   // getPoojaListById(datum.value.serviceId!);
  }


 addPoojaList() async{
   fildDataList.clear();
   rxfieldList.value.forEach((element) {
    fildDataList.add({"name":element["name"].text,"qty":element["qty"].text,"uom":element["uom"].text});
   });
   bodyJsonRequest["_id"]=datum.value.serviceId!;
   bodyJsonRequest["componentConfig"]={
     "moduleName":"Service Setup",
     "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
     "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
     "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
   };
   bodyJsonRequest["dataJson"]={
     "poojaList":fildDataList
   };

   Get.context!.loaderOverlay.show();
   var response=await BaseClient().post(APIsConstant.postAPI, bodyJsonRequest).catchError(BaseController().handleError);
   Get.context!.loaderOverlay.hide();
   if(response==null) return;
   if(jsonDecode(response)["statusCode"].toString().trim()=="1")
   {
     Fluttertoast.showToast(msg: jsonDecode(response)["message"]);
     Get.back();
     Get.back();
     fetchApi();
   }
   else{
     Get.snackbar("Error",jsonDecode(response)["message"].toString().trim(),
         backgroundGradient: LinearGradient(colors: [
           Colors.red,
           Colors.black26,
         ]),
         borderRadius: 2,
         icon: Icon(Icons.error)
     );
   }

 }
  addfield(){
    rxfieldList.value.add({
      "name": TextEditingController(),
      "qty":  TextEditingController(),
      "uom":  TextEditingController(),
    });
    rxfieldList.refresh();
  }
  deleteField(int i){
    rxfieldList.value.removeAt(i);
    rxfieldList.refresh();
  }

  getPoojaListById(String serviceId)async{
    var request={
      "text": serviceId,
      "componentConfig": {
        "moduleName":"Service Setup",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    print("dsvnjndsjkbvjdkk");
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("@@dsvnjndsjkbvjdkk");
    print(response);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    print("@@dsvnjndsjkbvjdkk");
    print(response);
  }

  sendPoojaListByPhoneEmail(String serviceName,String email,String phone)async{
    Get.back();
    if(poojaList.value.isEmpty)
      {
        Fluttertoast.showToast(msg: "Pooja List Not Available");
        return;
      }

    var catrequest={};
    catrequest["componentConfig"]={
      "moduleName":"Service Setup",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),

    };
    catrequest["dataJson"]={
         "email": "jitendravishwakarma913@gmail.com",
        "phone": phone,
        "serviceName": serviceName,
        "poojaList": jsonEncode(poojaList.value),
    };
    print("dsvnjndsjkbvjdkk");
    print(catrequest);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.sendPujaList, catrequest).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1") {
      Fluttertoast.showToast(msg: "Pooja list has been send successfuly");

    };

  }
}