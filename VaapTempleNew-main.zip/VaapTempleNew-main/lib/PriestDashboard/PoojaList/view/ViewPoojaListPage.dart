import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Request/conroller/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/PoojaList/controller/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/PoojaList/view/ViewPoja.dart';
import 'package:aspgen_mobile/PriestDashboard/Request/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/Request/service_request_details_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import '../../../AppConstant/AppColors.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/CustomListFourTitleWidget.dart';
import '../../../Widget/SearchBarWidget.dart';

class ViewPoojaListPage extends StatelessWidget {
  final int type;
  ViewPoojaListPage({Key? key, required this.type}) : super(key: key);
  PoojaListController _controller=Get.find();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:type==1? AppBar(title: Text("Pooja List"),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 4.0),
            child: RawMaterialButton(onPressed: (){
              CheckInternetConnection().then((value1) => value1==true? Get.to(()=>AddPoojaListPage()):"");
            }
              ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          ),

          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: RawMaterialButton(onPressed: (){
              showModalBottomSheet(
                context: context,
                builder: (context) {
                  return Wrap(
                    children: [
                      ListTile(
                        onTap: (){
                        _controller.sendPoojaListByPhoneEmail(_controller.datum.value.serviceName!,UtilMethods.decrypt(_controller.datum.value.comments!.email!), "");
                        },
                        leading: Icon(Icons.email,color:Colors.white70),
                        title: Text('Send To Email'),
                        subtitle: Text(UtilMethods.decrypt(_controller.datum.value.comments!.email!)),
                      ),
                      ListTile(
                        onTap: (){
                          _controller.sendPoojaListByPhoneEmail(_controller.datum.value.serviceName!,"", UtilMethods.decrypt(_controller.datum.value.comments!.phone!));

                        },
                        leading: Icon(Icons.phone,color:Colors.white70),
                        subtitle: Text(phoneFormatter(_controller.datum.value.comments!.phone!)),
                        title: Text('Send To SMS'),
                      ),
                      ListTile(
                        onTap: (){
                          Get.back();
                        },
                        leading: Icon(Icons.clear,color:Colors.red),
                        title: Text('Cancel',style: TextStyle(color: Colors.red),),
                      ),
                    ],
                  );
                },
              );
            }
              ,child: Icon(Icons.share),fillColor: Colors.white38.withOpacity(0.6),shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          ),

        ],
      ):AppBar(
        toolbarHeight: 45,
        automaticallyImplyLeading: false,
        backgroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
        title: Text("Pooja List",style: TextStyle(fontSize: 18)),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 4.0),
            child: RawMaterialButton(onPressed: (){
              CheckInternetConnection().then((value1) => value1==true? Get.to(()=>AddPoojaListPage()):"");
            }
              ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          ),

          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: RawMaterialButton(onPressed: (){
              showModalBottomSheet(
                context: context,
                builder: (context) {
                  return Wrap(
                    children: [
                      ListTile(
                        onTap: (){
                          _controller.sendPoojaListByPhoneEmail(_controller.datum.value.serviceName!,UtilMethods.decrypt(_controller.datum.value.comments!.email!),"");

                        },
                        leading: Icon(Icons.email,color:Colors.white70),
                        title: Text('Send To Email'),
                        subtitle: Text(UtilMethods.decrypt(_controller.datum.value.comments!.email!)),
                      ),
                      ListTile(
                        onTap: (){
                          _controller.sendPoojaListByPhoneEmail(_controller.datum.value.serviceName!,"", UtilMethods.decrypt(_controller.datum.value.comments!.phone!));

                        },
                        leading: Icon(Icons.phone,color:Colors.white70),
                        subtitle: Text(phoneFormatter(_controller.datum.value.comments!.phone!)),
                        title: Text('Send To SMS'),
                      ),
                      ListTile(
                        onTap: (){
                          Get.back();
                        },
                        leading: Icon(Icons.clear,color:Colors.red),
                        title: Text('Cancel',style: TextStyle(color: Colors.red),),
                      ),
                    ],
                  );
                },
              );
            }
              ,child: Icon(Icons.share),fillColor: Colors.white38.withOpacity(0.6),shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          ),

        ],
      ),
      body: Container(
        margin: EdgeInsets.only(left: 15,right: 15,top: 15),
        child: Column(
          children: [
            Text("LIST FOR ${_controller.datum.value.serviceName!.toUpperCase()}",style: TextStyle(fontSize: 16,color: Colors.amber,fontWeight: FontWeight.bold),textAlign: TextAlign.center,),
            SizedBox(height: 4,),
            Column(
              children:List.generate(_controller.poojaList.value.length, (index) =>
                  Container(
                margin: EdgeInsets.only(top: 10),
                decoration: BoxDecoration(
                  border: Border.all(color:Colors.grey.withOpacity(0.5),width: 0.5),
                  borderRadius: BorderRadius.circular(5),
                  color: Theme.of(context).colorScheme.onPrimaryContainer
                ),

                child: ListTile(
                 title: Text(_controller.poojaList.value[index].name!,style: Theme.of(context).textTheme.bodyText1,),
                  trailing:  Text(_controller.poojaList.value[index].qty!+"  "+_controller.poojaList.value[index].uom!,style: Theme.of(context).textTheme.bodyText1,),
                ),
              ))
            ),
          ],
        ),
      )
    );
  }


}
