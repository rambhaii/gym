import 'package:aspgen_mobile/Dashboard/Request/conroller/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/PoojaList/controller/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/PoojaList/view/ViewPoja.dart';

import 'package:aspgen_mobile/PriestDashboard/Request/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/Request/service_request_details_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import '../../../AppConstant/AppColors.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/CustomListFourTitleWidget.dart';
import '../../../Widget/SearchBarWidget.dart';
import 'ViewPoojaListPage.dart';

class PoojaListPage extends StatefulWidget {
  PoojaListPage({Key? key}) : super(key: key);

  @override
  State<PoojaListPage> createState() => _PoojaListPageState();
}

class _PoojaListPageState extends State<PoojaListPage> {
  PoojaListController _controller=Get.put(PoojaListController());


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Services"),
      ),
      body: Container(
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 10,),
              GetBuilder<PoojaListController>(
                builder: (controller)=>  SearchBarWidget(
                  hint: "Search",
                  controller: controller.etSearch,
                  onchange: (value){
                    _controller.filterData(value);
                  },
                  onCancel: (){
                    controller.etSearch.clear();
                    _controller.filterData(controller.etSearch.text);
                    controller.update();
                  },
                ),
              ),
              SizedBox(height: 8,),
              Obx(() =>(_controller.datas.value.data!=null && _controller.datas.value.data!.isNotEmpty)? ListView.builder(
                  shrinkWrap: true,
                  itemCount: _controller.datas.value.data!.length,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (context,index){
                    var dateTime="";

                    final datum=_controller.datas.value.data![index];
                    try{
                      dateTime=_controller.formatter.format(_controller.formatter1.parse(datum.serviceDate!));
                    }
                    catch(e){

                    }
                    return CustomListFourWidget(title: dateTime + "   " +datum.serviceTime!,
                        subTitle: datum.serviceName??"",
                        subTitle2: (datum.serviceCategoryTypes??""),
                        subTitle3: datum.comments!.contactName??"",
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              if(datum.prsnPhone!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.prsnPhone!.isNotEmpty) viewMore("Phone  ",phoneFormatter(datum.prsnPhone!)),
                              if(datum.prsnEmail!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.prsnEmail!.isNotEmpty) viewMore("Email  ", UtilMethods.decrypt(datum.prsnEmail!)),
                              if(datum.serviceStatus!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.serviceStatus!.isNotEmpty) viewMore("Service Status  ",datum.serviceStatus??""),
                              if(datum.notes!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.notes!.isNotEmpty) viewMore("Notes ",datum.notes??""),
                            ]),
                        textEditingController:_controller.etSearch,
                        onTapVieMore: (){
                          datum.isChecked=!datum.isChecked!;
                          _controller.datas.refresh();
                        },
                        icon: Icons.arrow_forward,
                        iconColor: Colors.white,
                        editOnTap: (){
                          CheckInternetConnection().then((value) {
                            if(value==true)
                            {
                              _controller.sendData(datum);
                             _controller.sendPoojaList(datum.poojaList!);
                              Get.to(()=>ViewPoojaListPage(type: 1,));
                            }
                          });
                        },
                      isClicked: datum.isChecked!,
                      );
                  })

                  :Center(
                child: Text(_controller.rxMessage.value,style: Theme.of(context).textTheme.bodyText2,),
              ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
