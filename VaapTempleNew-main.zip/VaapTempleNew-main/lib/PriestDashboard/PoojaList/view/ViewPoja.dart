import 'package:aspgen_mobile/Dashboard/Request/conroller/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/PoojaList/controller/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/Request/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/Request/service_request_details_page.dart';
import 'package:aspgen_mobile/Widget/EditextWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import '../../../AppConstant/AppColors.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/CustomListFourTitleWidget.dart';
import '../../../Widget/SearchBarWidget.dart';

class AddPoojaListPage extends StatefulWidget {
  AddPoojaListPage({Key? key}) : super(key: key);

  @override
  State<AddPoojaListPage> createState() => _AddPoojaListPageState();
}

class _AddPoojaListPageState extends State<AddPoojaListPage> {
  PoojaListController _controller=Get.find();
  @override
  void initState() {
    _controller.rxfieldList.clear();
    _controller.poojaList.value.forEach((element) {
      _controller.rxfieldList.add({
        "name": TextEditingController(text: element.name),
        "qty":  TextEditingController(text: element.qty),
        "uom":  TextEditingController(text: element.uom),
      });
    });

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.1),width: 0.4)),
        color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.3));
    return Scaffold(
      appBar: AppBar(title: Text("Add Pooja List"),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: RawMaterialButton(
              onPressed: () {
                _controller.addPoojaList();
                },
              child: Image.asset("assets/images/diskbold.png",height: 22,width: 22,color: Colors.white,),
              fillColor: Colors.green,
              shape: CircleBorder(),
              elevation: 5,
              constraints: BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          )
        ],
      ),
      body: Container(
        padding: EdgeInsets.all(5),
        child: SingleChildScrollView(
          child: Column(
            children: [
              Obx(() => Container(
                margin: EdgeInsets.only(top:15,left: 5,right: 5),
                decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend3.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.amber)),
                child: ListTileTheme(
                  dense: true,
                  horizontalTitleGap: 15.0,
                  minLeadingWidth: 0,
                  child: ExpansionTile(
                      collapsedTextColor: Colors.amber,
                      textColor: Colors.amber,
                      childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                      onExpansionChanged: (value){
                        _controller.isExpend3.value=value;
                      },
                      maintainState: true,
                      initiallyExpanded: _controller.isExpend3.value,
                      key: Key("2"),
                      title: Text("Pooja List Form",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                      children:<Widget>
                      [

                        Obx(() =>  ListView.builder(
                            physics: NeverScrollableScrollPhysics(),
                            shrinkWrap: true,
                            itemCount: _controller.rxfieldList.length,
                            itemBuilder: (context,index)
                            {
                              return Padding(
                                padding: const EdgeInsets.only(top: 4.0),
                                child: Card(
                                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                                  child: Padding(
                                    padding: const EdgeInsets.all(8),
                                    child: Column(
                                      children: [
                                        Row(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Expanded(
                                              flex: 14,
                                              child: EditTextWidget(
                                                maxLength: 20,
                                                hint: "Enter Material",
                                                isPassword: false,
                                                keyboardtype: TextInputType.text,
                                                label: "Enter Material",
                                                formatter:[],
                                                validator: (value) {
                                                  return null;
                                                },
                                                controller: _controller.rxfieldList[index]['name'],
                                                maxline: 1,
                                              ),
                                            ),
                                            SizedBox(width: 10,),
                                            Expanded(
                                                flex: 2,
                                                child: InkWell(
                                                  onTap: (){
                                                    _controller.deleteField(index);
                                                  },
                                                  child: Container(
                                                      margin: EdgeInsets.only(bottom: 10),
                                                      child: Icon(Icons.clear,size: 30,)),
                                                )
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 4,),
                                        Row(children: [
                                          Expanded(
                                            flex: 2,
                                            child: EditTextWidget(
                                              maxLength: 10,
                                              hint: "Oty",
                                              isPassword: false,
                                              keyboardtype: TextInputType.number,
                                              label: "Oty",
                                              formatter:[],
                                              validator: (value) {
                                                return null;
                                              },
                                              controller: _controller.rxfieldList[index]['qty'],
                                              maxline: 1,
                                            ),
                                          ),
                                          SizedBox(width: 10,),
                                          Expanded(
                                            flex: 2,
                                            child: EditTextWidget(
                                              maxLength: 20,
                                              hint: "UMO",
                                              isPassword: false,
                                              keyboardtype: TextInputType.text,
                                              label: "UMO",
                                              formatter:[],
                                              validator: (value) {
                                                return null;
                                              },
                                              controller: _controller.rxfieldList[index]['uom'],
                                              maxline: 1,
                                            ),
                                          ),
                                        ],)
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            }),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ElevatedButton(
                                style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                                onPressed: (){
                                  _controller.addfield();
                                },
                                child: Text("+ Add More")
                            ),
                            SizedBox(width: 10,)
                          ],
                        )
                      ]
                  ),
                ),
              ),
              ),
              SizedBox(height: 10,),


            ],
          ),
        ),
      ),
    );
  }
}
