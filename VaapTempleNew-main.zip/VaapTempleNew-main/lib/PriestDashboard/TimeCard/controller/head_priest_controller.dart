import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Request/model/service_model.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../Dashboard/Contact/Model/AllContactDatas.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
import '../model/CheckListData.dart';


class HeadPriestController extends GetxController{
  var datas=ServiceRequestData().obs;
  var filterdatas=ServiceRequestData().obs;
  var checkList=CheckListModel().obs;
  RxString rxstartTime="".obs;
  RxString rxendTime="".obs;
  RxString rxtotalDuration="".obs;
  RxList<ContactDatum> allContactDatas=  RxList<ContactDatum>([]);
  RxList<ContactDatum> filterAllContactDatas=  RxList<ContactDatum>([]);
   TextEditingController etSearch=TextEditingController();
  Rx<ServiceRequestDatum> datum=ServiceRequestDatum().obs;
  RxString rxMessage="".obs;
  @override
  void onInit() {
    final DateFormat formatter = DateFormat('MM/dd/yyyy');
    final String formatted = formatter.format(DateTime.now());
    fetchApi(formatted);
    super.onInit();
  }

  fetchApi(formatted)async{
    print("formatted");
    print(formatted);
   var bodyJson={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
      "username": AppConstant.sharedPreference.getString(AppConstant.userName).toString().trim(),
      "query": {"serviceStatus":"SCHEDULED","serviceDate":formatted}
    };

   print("sdbvhjdsbjkv");
   print(bodyJson);

    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getServiceRequest, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    datas.value=ServiceRequestData.fromJson(jsonDecode(response));
    filterdatas.value=ServiceRequestData.fromJson(jsonDecode(response));
    if(datas.value.data!.isEmpty)
    {
      rxMessage.value="No Service Available";
    }
  }
  String differTime(String startTime ,String startDate,String endtime,String endDate){
    DateFormat dateFormat2 = DateFormat("MM/dd/yyyy");
    var date1=startDate;
    var date2=endDate;

    try {
      DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
      DateTime dt1 = dateFormat.parse("$date2 $endtime");
      DateTime dt2 = dateFormat.parse("$date1 $startTime");
      Duration diff = dt1.difference(dt2);

      int min =(diff.inMinutes % 60);
      String finalHour=diff.inHours>0?diff.inHours.toString():"00";
      print(finalHour);
      String finalMinute=min<10?"0"+min.toString():min.toString();
      String difftime=finalHour+" : "+finalMinute;
      return difftime;

    } on Exception catch (e) {
      // TODO
      print(e.toString());
      print("cshbkabscj");
      return "";
    }
  }
  sendData(ServiceRequestDatum data){
    datum.value=data;
  }

  getAllPriest() async{
    var request={
      "text": "PRIEST",
      "componentConfig": {
        "moduleName":"Contacts",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    Get.context!.loaderOverlay.show();
    print(request);
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    allContactDatas.value=allContactDatasFromJson(response).data!;
    update();
  }
  void filterData(String search){
    List<ServiceRequestDatum> result=[];
    if(search.isEmpty)
    {
      result=filterdatas.value.data!;
    }
    else{
      result=filterdatas.value.data!.where((element) =>element.serviceName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    datas.value.data=result;
    datas.refresh();
  }



  getGetCheckDuration(String serviceId)async{
    var  bodyJson={
      "memberId":datum.value.priestDetail!.id!,
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "projectId": serviceId,
      "clientId":  AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getpriestTimeCardByPriestID, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("@@@fdbfbgf");
    print(response);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1") {
      checkList.value=checkListModelFromJson(response);
     if( checkList.value.message!.isNotEmpty)
       {
         print("bjjhvkjdsbvds");
         print(checkList.value.message!.first.checkinTime!);
         print(checkList.value.message!.first.checkoutTime!);
         rxstartTime.value=checkList.value.message!.last.checkinTime!;
         rxendTime.value=checkList.value.message!.first.checkoutTime!;
       }


      getTotalDuration();
      try {
      } on Exception catch (e) {

        // TODO
      }
    };

  }
  getTotalDuration(){
    Duration totalDurantion=Duration(hours: 0,minutes: 0);
    checkList.value.message!.forEach((element) {
      try {
        DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
        DateTime dt1 = dateFormat.parse("${element.checkOutdate} ${element.checkoutTime}");
        DateTime dt2 = dateFormat.parse("${element.checkinDate} ${element.checkinTime}");
        Duration diff = dt1.difference(dt2);
        totalDurantion=totalDurantion+diff;


      } on Exception catch (e) {
        // TODO
        print(e.toString());

      }
    });
    int min =(totalDurantion.inMinutes % 60);
    String finalHour=totalDurantion.inHours>0?totalDurantion.inHours.toString():"00";
    String finalMinute=min<10?"0"+min.toString():min.toString();
    String difftime=finalHour+" : "+finalMinute;
    print("vdfvdfvbfd");
    print(difftime);
    rxtotalDuration.value=difftime;
  }
}