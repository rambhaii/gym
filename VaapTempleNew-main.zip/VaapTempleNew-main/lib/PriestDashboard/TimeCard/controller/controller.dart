import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Request/model/service_model.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../Dashboard/Contact/Model/AllContactDatas.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
import '../model/CheckListData.dart';


class TimeCardController extends GetxController{
  final String priestEmail;
  final String memberId;
  final int type;
  TimeCardController(this.priestEmail, this.type,this.memberId):super();
  var bodyJson={};
  var bodyJson2={};
  var email="".obs;
  var phone="".obs;
  var selectedValue;
   RxBool isPriestAvl=false.obs;
   RxInt isSelected=0.obs;
  RxBool isExpend1=true.obs;
  RxBool isCheckIn=false.obs;
  RxBool isExpend2=false.obs;
  RxBool isExpend3=false.obs;
  RxString rxtotalDuration="".obs;
  final DateFormat formatter = DateFormat('MMM dd , yyyy');
  final DateFormat formatter1 = DateFormat('MM/dd/yyyy');
  var datas=ServiceRequestData().obs;
  var filterdatas=ServiceRequestData().obs;
  var approveDatum={};
  TextEditingController etSearch= new TextEditingController();
  Rx<ServiceRequestDatum> datum=ServiceRequestDatum().obs;
  Rx<AllContactDatas> allContactDatas= AllContactDatas().obs;

  var checkList=CheckListModel().obs;

 RxList<Map> map=RxList([]);
  String checkInId="";
 RxString rxStatus="SCHEDULED".obs;

  var maskFormatter = new MaskTextInputFormatter(
      mask: '(###) ###-####',
      filter: {"#": RegExp(r'[0-9]')},
      type: MaskAutoCompletionType.lazy);

  List<String> statusList=[
    "SCHEDULED",
    "COMPLETED",
  ];
 RxString rxMessage="".obs;
  @override
  void onInit() {
    print("@@email");
    print(UtilMethods.decrypt(AppConstant.sharedPreference.getString(AppConstant.userEmail).toString().trim(),));
    fetchApi();
    super.onInit();
  }
  fetchApi()async{
    bodyJson={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
      "priestEmail": priestEmail,
      "status":rxStatus.value,
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getServiceRequestByPriestID, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    datas.value=ServiceRequestData.fromJson(jsonDecode(response));
    filterdatas.value=ServiceRequestData.fromJson(jsonDecode(response));
    if(datas.value.data!.isEmpty)
    {
      rxMessage.value="No Service Available";
    }

  }
  sendData(ServiceRequestDatum data){
    datum.value=data;
    email.value="";
    phone.value="";
  }



  approveApi(String id)async{
    var bodyrequest={};
    bodyrequest={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
      "serviceStatus":"COMPLETED",
       "_id":id,
    };
      Get.context!.loaderOverlay.show();
      var response=await BaseClient().post(APIsConstant.udateServiceRequestAPI, bodyrequest).catchError(BaseController().handleError);
      Get.context!.loaderOverlay.hide();
      if(response==null) return;
      if(jsonDecode(response)["statusCode"].toString()=="1"){
        Get.back();
        Get.snackbar("Success", "Status Updated",borderRadius: 2,icon: Icon(Icons.check_rounded),backgroundGradient: LinearGradient(colors: [
          Colors.green,Colors.black12
        ]));
         fetchApi();
      };
    }

  void filterData(String search){
    List<ServiceRequestDatum> result=[];
    if(search.isEmpty)
    {
      result=filterdatas.value.data!;
    }
    else{
      result=filterdatas.value.data!.where((element) =>element.serviceName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    datas.value.data=result;
    datas.refresh();
  }

  checknInCheckOut(String checkinId ,String serviceId,bool checkStatus)async{
  var  bodyJson={
      "checkinId": checkinId,
      "projectId":  serviceId,
      "projectType": "SERVICE",
      "checkinTime":!isCheckIn.value? formatTimeOfDay(TimeOfDay.now()):"",
      "checkinDate":!isCheckIn.value? formatter1.format(DateTime.now()):"",
      "checkoutTime":isCheckIn.value?formatTimeOfDay(TimeOfDay.now()):"",
      "checkOutdate":isCheckIn.value?formatter1.format(DateTime.now()):"",
      "memberId": AppConstant.sharedPreference.getString(AppConstant.memberId).toString().trim(),
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId":  AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
    };

    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.priestTimeCard, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1")
      {
        if(checkStatus==false)
          {
            checkInId="";
          }
        isCheckIn.value=checkStatus;
        getCheckList(serviceId);
      }
  }
  getCheckList(String serviceId)async{
    var  bodyJson={
      "memberId":memberId,
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "projectId": serviceId,
      "clientId":  AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
    };
    print("xedcecfcr");
    print(bodyJson);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getpriestTimeCardByPriestID, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1") {
      print("dfbdffgf"+response);
      checkList.value=checkListModelFromJson(response);
      getTotalDuration();
      try {
        if(checkList.value.message!.isNotEmpty)
          {
            if(checkList.value.message![0].checkOutdate!.isEmpty)
            {
              isCheckIn.value=true;
              checkInId=checkList.value.message![0].id!;
            }
          }

      } on Exception catch (e) {

        // TODO
      }
    };

  }


  getGetCheckDuration(String serviceId)async{
    var  bodyJson={
      "memberId":memberId,
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "projectId": serviceId,
      "clientId":  AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
    };
    print("xedcecfcr");
    print(bodyJson);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getpriestTimeCardByPriestID, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("@@@fdbfbgf");
    print(response);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1") {
      checkList.value=checkListModelFromJson(response);
      getTotalDuration();
      try {
      } on Exception catch (e) {

        // TODO
      }
    };

  }



  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
    final format = DateFormat.jm(); // YOUR DATE GOES HERE
    return format.format(dt);
  }


  String differTime(String startTime ,String startDate,String endtime,String endDate){
    DateFormat dateFormat2 = DateFormat("MM/dd/yyyy");
    var date1=startDate;
    var date2=endDate;

    try {
      DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
      DateTime dt1 = dateFormat.parse("$date2 $endtime");
      DateTime dt2 = dateFormat.parse("$date1 $startTime");
      Duration diff = dt1.difference(dt2);

      int min =(diff.inMinutes % 60);
      String finalHour=diff.inHours>0?diff.inHours.toString():"00";
      print(finalHour);
      String finalMinute=min<10?"0"+min.toString():min.toString();
      String difftime=finalHour+" : "+finalMinute;



      return difftime;

    } on Exception catch (e) {
      // TODO
      print(e.toString());
      print("cshbkabscj");
      return "";
    }
  }
   getTotalDuration(){
     Duration totalDurantion=Duration(hours: 0,minutes: 0);
    checkList.value.message!.forEach((element) {
      try {
        DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
        DateTime dt1 = dateFormat.parse("${element.checkOutdate} ${element.checkoutTime}");
        DateTime dt2 = dateFormat.parse("${element.checkinDate} ${element.checkinTime}");
        Duration diff = dt1.difference(dt2);
        totalDurantion=totalDurantion+diff;


      } on Exception catch (e) {
        // TODO
        print(e.toString());

      }
    });
     int min =(totalDurantion.inMinutes % 60);
     String finalHour=totalDurantion.inHours>0?totalDurantion.inHours.toString():"00";
     String finalMinute=min<10?"0"+min.toString():min.toString();
     String difftime=finalHour+" : "+finalMinute;
     print("vdfvdfvbfd");
     print(difftime);
     rxtotalDuration.value=difftime;
  }



  getAllPriest(String text) async{
    var request={
      "text": text,
      "componentConfig": {
        "moduleName":"Contacts",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    Get.context!.loaderOverlay.show();
    print(request);
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    allContactDatas.value=allContactDatasFromJson(response);
    update();

  }
}