// To parse this JSON data, do
//
//     final operationsModel = operationsModelFromJson(jsonString);

import 'dart:convert';

CheckListModel checkListModelFromJson(String str) => CheckListModel.fromJson(json.decode(str));

String checkListModelToJson(CheckListModel data) => json.encode(data.toJson());

class CheckListModel {
  CheckListModel({
    this.statusCode,
    this.message,
  });

  String ?statusCode;
  List<CheckListDatum>? message;

  factory CheckListModel.fromJson(Map<String, dynamic> json) => CheckListModel(
    statusCode: json["statusCode"],
    message: List<CheckListDatum>.from(json["message"].map((x) => CheckListDatum.fromJson(x))).reversed.toList(),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": List<dynamic>.from(message!.map((x) => x.toJson())),
  };
}

class CheckListDatum {
  CheckListDatum({
    this.id,
    this.projectId,
    this.projectType,
    this.checkinTime,
    this.checkinDate,
    this.memberId,
    this.productId,
    this.clientId,

    this.checkOutdate,
    this.checkoutTime,
  });

  String ?id;
  String ?projectId;
  String ?projectType;
  String ?checkinTime;
  String ?checkinDate;
  String ?memberId;
  String ?productId;
  String ?clientId;
  String ?checkOutdate;
  String ?checkoutTime;
  factory CheckListDatum.fromJson(Map<String, dynamic> json) => CheckListDatum(
    id: json["_id"],
    projectId: json["projectId"],
    projectType: json["projectType"],
    checkinTime: json["checkinTime"],
    checkinDate: json["checkinDate"],
    memberId: json["memberId"],
    productId: json["productId"],
    clientId: json["clientId"],
    checkOutdate: json["checkOutdate"]??"",
    checkoutTime: json["checkoutTime"]??"",

  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "projectId": projectId,
    "projectType": projectType,
    "checkinTime": checkinTime,
    "checkinDate": checkinDate,
    "memberId": memberId,
    "productId": productId,
    "clientId": clientId,
    "checkOutdate": checkOutdate,
    "checkoutTime": checkoutTime
  };
}
