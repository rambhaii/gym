import 'package:aspgen_mobile/PriestDashboard/TimeCard/controller/controller.dart';
import 'package:aspgen_mobile/PriestDashboard/TimeCard/view/service_request_details_page.dart';
import 'package:aspgen_mobile/PriestDashboard/TimeCard/view/show_priest_check_details.dart';
import 'package:aspgen_mobile/Templates/fieldPageNew.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';

import '../../../Widget/CustomListFourTitleWidget.dart';
import '../../../Widget/SearchBarWidget.dart';
import '../../LeaveForm/view/leave_list.dart';
import '../../Request/service_request_details_page.dart';
class TimeCardPage extends StatefulWidget {
  final String email;
  final int type;  //type 1 for member priest and 2 for Head priest
  final String memberId;  //type 1 for member priest and 2 for Head priest
   TimeCardPage({Key? key, required this.email, required this.type, required this.memberId}) : super(key: key);

  @override
  State<TimeCardPage> createState() => _TimeCardPageState();
}

class _TimeCardPageState extends State<TimeCardPage> {

  late TimeCardController _controller;

  @override
  void initState() {
    _controller=Get.put(TimeCardController(widget.email,widget.type,widget.memberId));
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Text("Timecard",overflow: TextOverflow.clip,),
          bottom: TabBar(tabs: [
            Tab(text: "AT TEMPLE",),
            Tab(text: "BOOKINGS",),
            Tab(text: "LEAVE",),
          ]),
        ),
        body:TabBarView(
          children: [
            atTemple(),
            booking(),
            LeaveListPage(type: 2,),
          ],
        )   ,

      ),
    );
  }
Widget booking(){
    return SingleChildScrollView(
      child: Column(
        children: [
          SizedBox(height: 10,),
          GetBuilder<TimeCardController>(
            builder: (controller)=>  SearchBarWidget(
              hint: "Search",
              controller: controller.etSearch,
              onchange: (value){
                _controller.filterData(value);
              },
              onCancel: (){
                controller.etSearch.clear();
                _controller.filterData(controller.etSearch.text);
                controller.update();
              },
            ),
          ),
          SizedBox(height: 8,),
          Obx(() =>(_controller.datas.value.data!=null && _controller.datas.value.data!.isNotEmpty)? ListView.builder(
              shrinkWrap: true,
              itemCount: _controller.datas.value.data!.length,
              itemBuilder: (context,index){
                var dateTime="";

                final datum=_controller.datas.value.data![index];
                try{
                  dateTime=_controller.formatter.format(_controller.formatter1.parse(datum.serviceDate!));
                }
                catch(e){

                }
                return
                  CustomListFourWidget(title: dateTime + " " +datum.serviceTime!,
                    subTitle: datum.serviceName??"",
                    subTitle2: (datum.serviceLocationName??""),
                    subTitle3: datum.comments!.contactName??"",
                    viewMoreWidget: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children:[
                          if(datum.prsnPhone!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          if(datum.prsnPhone!.isNotEmpty) viewMore("Phone  ",phoneFormatter(datum.prsnPhone!)),
                          if(datum.prsnEmail!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          if(datum.prsnEmail!.isNotEmpty) viewMore("Email  ", UtilMethods.decrypt(datum.prsnEmail!)),
                          if(datum.serviceStatus!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          if(datum.serviceStatus!.isNotEmpty) viewMore("Service Status  ",datum.serviceStatus??""),
                          if(datum.notes!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          if(datum.notes!.isNotEmpty) viewMore("Notes ",datum.notes??""),
                        ]),
                    textEditingController:_controller.etSearch,
                    onTapVieMore: (){
                      datum.isChecked=!datum.isChecked!;
                      _controller.datas.refresh();
                    },
                    icon: Icons.arrow_forward,
                    iconColor: Colors.white,
                    editOnTap: (){
                      CheckInternetConnection().then((value) {
                        if(value==true)
                        {
                          _controller.sendData(datum);
                          if(widget.type==1)
                          {
                            Get.to(()=>CherckinServiceRequestDetailsPage());
                          }
                          else{
                            Get.to(()=>ShowPriestCherckinServiceDetailsPage());
                          }


                        }
                      });
                    }, isClicked: datum.isChecked!,
                  );
              }) :Center(child: Text(_controller.rxMessage.value,style: Theme.of(context).textTheme.bodyText2,),),
          ),
        ],
      ),
    );
}
Widget atTemple(){
    return Placeholder();
}
}
