import 'dart:convert';
import 'dart:math';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/PriestDashboard/TimeCard/controller/head_priest_controller.dart';
import 'package:aspgen_mobile/Widget/ButtonWidget.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../../AppConstant/AppColors.dart';
import '../../../UtilMethods/Utils.dart';

import '../controller/controller.dart';
import '../model/CheckListData.dart';
class ShowPriestCherckinServiceDetailsPage extends StatefulWidget {
  ShowPriestCherckinServiceDetailsPage({Key? key}) : super(key: key);

  @override
  State<ShowPriestCherckinServiceDetailsPage> createState() => _ShowPriestCherckinServiceDetailsPageState();
}

class _ShowPriestCherckinServiceDetailsPageState extends State<ShowPriestCherckinServiceDetailsPage> {
  HeadPriestController _controller=Get.find();
  final GlobalKey expansionTile = new GlobalKey();
  final GlobalKey<ExpansionTileCardState> expensionPriestKey =  GlobalKey();
  final GlobalKey<ExpansionTileCardState> expensionMemberKey =  GlobalKey();
  @override
  void initState() {
    super.initState();
    _controller.checkList.value=CheckListModel();
    _controller.getGetCheckDuration(_controller.datum.value.id!);
  }
  @override
  Widget build(BuildContext context) {
    final titlestyle=  TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w400);
    final w=MediaQuery.of(context).size.width;
    final datum=_controller.datum.value;
    BoxDecoration decoration=BoxDecoration(borderRadius: BorderRadius.circular(5), border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.1),width: 0.4)), color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.3));
    return Scaffold(
      appBar: AppBar(title: Text("Timecard"),

      actions: [
        Container(
            margin: EdgeInsets.all(10),
              height:30,
              child:
              ButtonWidget(
                  btnName:"APPROVE",
                onPress: (){

                  },
              )),

      ],
      ),
      body: SingleChildScrollView(
        child: Container(

          child:Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Container(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.only(
                    left: 20, right: 10, top: 10,bottom: 10),
                decoration: BoxDecoration(
                    border: Border(
                        top: BorderSide(
                            width: 0.1,
                            color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                        bottom: BorderSide(
                            width: 0.1,
                            color: Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                    color: Theme.of(context).colorScheme.onPrimaryContainer),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Row(
                      children: [
                       Icon(Icons.person,color: Colors.white38,),
                        SizedBox(width: 15,),
                        Text("Employee",style: Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.white70),)
                      ],
                    ),
                    SizedBox(height: 10,),
                    Container(
                      margin: EdgeInsets.only(left: 35),
                      width: MediaQuery.of(context).size.width,
                      child: Stack(
                        children: [
                          Positioned(
                             left: 40,
                            top: 8,
                            child: Container(
                              padding: EdgeInsets.only(left: 20,right: 15,top: 10,bottom: 10),

                              decoration: BoxDecoration(
                               borderRadius: BorderRadius.only(topRight: Radius.circular(5),bottomRight: Radius.circular(5)),
                                color: Theme.of(context).primaryColor.withOpacity(.5),

                                border: Border.all(color:Colors.grey,width: 0.2)
                              ),
                              child: Text(
                                  datum.requestForPriestName.toString(),
                                  style: Theme.of(context).textTheme.bodyText1
                              ),
                            ),
                          ),
                          Container(
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Color(0xff020209),
                                border: Border.all(color:Colors.grey,width: 0.2)
                            ),
                            child: datum.priestDetail!.priestImage!.isEmpty? CircleAvatar(
                              backgroundColor: Color(Random().nextInt(0xffffffff)),
                              child: Text(
                                  datum.requestForPriestName.toString()=="" ? "" : datum.requestForPriestName![0].toString().toUpperCase(),
                                  style: Theme.of(context).textTheme.headline4
                              ),
                              maxRadius: 27,
                            ):
                            CircleAvatar(
                              backgroundColor: Color(Random().nextInt(0xffffffff)),
                              backgroundImage: NetworkImage(APIsConstant.IP_Base_Url+datum.priestDetail!.priestImage!),
                              maxRadius: 27,
                            ),
                          ) ,
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.only(
                    left: 20, right: 10, top: 10,bottom: 10),
                decoration: BoxDecoration(
                    border: Border(
                        top: BorderSide(
                            width: 0.1,
                            color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                        bottom: BorderSide(
                            width: 0.1,
                            color: Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                    color: Theme.of(context).colorScheme.onPrimaryContainer),
                child: Column(

                  children: [
                    Row(
                      children: [
                        Icon(Icons.location_on,color: Colors.white38,),
                        SizedBox(width: 15,),
                        Text("Area",style: Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.white70),)
                      ],
                    ),
                    SizedBox(height: 10,),
                    Container(
                      margin: EdgeInsets.only(left: 35),
                      width: MediaQuery.of(context).size.width,
                      child: Row(
                        children: [
                          Container(
                            padding: EdgeInsets.all(8),

                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(100),
                                color: Colors.black45,

                                border: Border.all(color:Colors.grey,width: 0.2)
                            ),
                            child: Icon(Icons.location_on)
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Row(
                            mainAxisSize: MainAxisSize.max,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                         datum.serviceLocationName!,
                                style:titlestyle.copyWith(fontSize: 17,color: Colors.green),
                              ),
                            //  Icon(Icons.arrow_forward_ios,color: Colors.white38,size: 16,)
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 15,
              ),
              Container(
                  padding: EdgeInsets.only(
                    left: w * .045,
                    right: w * .02,
                  ),
                  decoration: BoxDecoration(
                      border: Border(
                          top: BorderSide(
                              width: 0.1,
                              color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                          bottom: BorderSide(
                              width: 0.1,
                              color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                      color: Theme.of(context).colorScheme.onPrimaryContainer),
                  width: MediaQuery.of(context).size.width,
                  child: Column(
                      crossAxisAlignment:
                      CrossAxisAlignment.start,
                      children: [
                        SizedBox(
                          height: 8,
                        ),
                        Row(
                          mainAxisAlignment:
                          MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "Service Name  ",
                              style: Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.white70),
                            ),

                          ],
                        ),
                        SizedBox(height: 6),
                        Text(
                          datum.serviceName!,
                          maxLines: 4,
                          overflow: TextOverflow.ellipsis,
                          style:Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.amber),
                        ),
                        SizedBox(
                          height: 4,
                        ),
                        Column(
                          crossAxisAlignment:
                          CrossAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: 6,
                            ),
                            Container(
                                padding: EdgeInsets.all(5),
                                width: MediaQuery.of(context)
                                    .size
                                    .width,
                                decoration: BoxDecoration(
                                    border: Border(
                                        top: BorderSide(
                                            width: 0.1,
                                            color: Colors
                                                .white70),
                                        bottom: BorderSide(
                                            width: 0.1,
                                            color: Colors
                                                .white70)),
                                    color: Theme.of(context).colorScheme.onPrimaryContainer),
                                child: Column(
                                  children: [
                                   SizedBox(height: 10,),
                                    Row(
                                      children: [
                                        Icon(
                                          Icons
                                              .calendar_month_sharp,
                                          color: Colors
                                              .white38,

                                        ),
                                        SizedBox(
                                          width: MediaQuery.of(
                                              context)
                                              .size
                                              .width /
                                              20,
                                        ),
                                        Expanded(
                                          child: Text(
                                            "Date",
                                            style: Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.white70),
                                          ),
                                        ),
                                        // Text(
                                        //   'All Day',
                                        //   style:titlestyle,
                                        // ),
                                        // Transform.scale(
                                        //     scale: 0.8,
                                        //     child:
                                        //     CupertinoSwitch(
                                        //       value: false,
                                        //       onChanged:
                                        //           (value) {
                                        //         setState(() {
                                        //           // _switchValue = value;
                                        //         });
                                        //       },
                                        //     ))
                                      ],
                                    ),

                                    SizedBox(height: 10,),
                                    Row(children: [
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                9),
                                        padding:
                                        EdgeInsets.all(
                                            8),
                                        decoration: BoxDecoration(
                                            color:Theme.of(context).primaryColor.withOpacity(0.5),
                                            borderRadius:
                                            BorderRadius
                                                .circular(
                                                5.0)),
                                        child: Text(datum.serviceDate??"",
                                            style:
                                            Theme.of(context).textTheme.bodyText1!),
                                      ),
                                    ]),
                                    Container(
                                      margin: EdgeInsets.only(
                                          left: MediaQuery.of(
                                              context)
                                              .size
                                              .width /
                                              9),
                                      padding:
                                      EdgeInsets.only(
                                          top: 5,
                                          bottom: 10),
                                      child: Divider(
                                        height: 1.0,
                                        thickness: 1.0,
                                        color:  Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                      ),
                                    ),
                                    Row(
                                      children: [
                                        SizedBox(
                                          width: MediaQuery.of(
                                              context)
                                              .size
                                              .width /
                                              9,
                                        ),
                                        Expanded(
                                          flex: 2,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Start Time",
                                                style: Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.white70),
                                              ),
                                              SizedBox(height: 8,),
                                       Obx(() =>   Text(
                                                    _controller.rxstartTime.value,
                                                  style: Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.lightGreenAccent),
                                                ),
                                       ),
                                            ],
                                          ),
                                        ),
                                        Expanded(
                                          flex: 2,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Finish Time",
                                                style: Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.white70)
                                              ),
                                              SizedBox(height: 8,),
                                          Obx(() =>  Text(
                                            _controller.rxendTime.value,
                                            style: Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.lightGreenAccent),
                                          ),)
                                            ],
                                          ),
                                        ),



                                      ],
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(
                                          left: MediaQuery.of(
                                              context)
                                              .size
                                              .width /
                                              9),
                                      padding:
                                      EdgeInsets.only(
                                          top: 10,
                                          bottom: 10),
                                      child: Divider(
                                        height: 1.0,
                                        thickness: 1.0,
                                        color:  Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                      ),
                                    ),

                                    Container(
                                      alignment: Alignment.topLeft,
                                      margin: EdgeInsets.only(
                                          left: MediaQuery.of(
                                              context)
                                              .size
                                              .width /
                                              9,top: 6,),
                                      child: InkWell(
                                        onTap: (){
                                          showDialog(context: context, builder: (context)=>bottomsheet());
                                        },
                                        child: Row(

                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text( "Breaks        ",
                                                    style:Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.white70)
                                                ),
                                                Obx(()=> Column(children: _controller.checkList.value.message!=null? List.generate(
                                                      _controller.checkList.value.message!.length, (index) =>
                                                      Row(
                                                        crossAxisAlignment: CrossAxisAlignment.center,
                                                        mainAxisAlignment: MainAxisAlignment.center,
                                                        children: [
                                                          Text(_controller.differTime(
                                                              _controller.checkList.value.message![index].checkinTime!,
                                                              _controller.checkList.value.message![index].checkinDate!,
                                                              _controller.checkList.value.message![index].checkoutTime!,
                                                              _controller.checkList.value.message![index].checkOutdate!
                                                          ).isNotEmpty?"0 * "+datum.serviceLocationName!.toLowerCase() +" ( total "+_controller.differTime(
                                                              _controller.checkList.value.message![index].checkinTime!,
                                                              _controller.checkList.value.message![index].checkinDate!,
                                                              _controller.checkList.value.message![index].checkoutTime!,
                                                              _controller.checkList.value.message![index].checkOutdate!
                                                          )+" min)   ":"",style: Theme.of(context).textTheme.bodyMedium!.copyWith(color:Colors.blue.withOpacity(.7)),)
                                                        ],
                                                      )
                                                  ):[],
                                                )
                                                ),
                                              ],
                                            ),
                                            Icon(Icons.arrow_forward_ios,color: Colors.white38,size: 16,)

                                          ],
                                        ),
                                      ),
                                    ),
                                    SizedBox(
                                      height: 8,
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(
                                          left: MediaQuery.of(
                                              context)
                                              .size
                                              .width /
                                              9),
                                      padding:
                                      EdgeInsets.only(
                                          top: 10,
                                          bottom: 10),
                                      child: Divider(
                                        height: 1.0,
                                        thickness: 1.0,
                                        color:  Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                      ),
                                    ),
                                    Container(
                                      margin: EdgeInsets.only(
                                          left: MediaQuery.of(
                                              context)
                                              .size
                                              .width /
                                              9,top: 6,bottom: 10),
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Text(
                                            "Total Time        ",
                                            style: titlestyle,),
                                          SizedBox(height: 8,),
                                          Obx(()=> Text(_controller.rxtotalDuration.value,
                                              style: TextStyle(
                                                  color: Colors
                                                      .white,
                                                  fontSize:
                                                  36,
                                                  fontWeight:
                                                  FontWeight.normal),
                                         ),
                                          ),
                                        ],
                                      ),
                                    ),


                                  ],
                                )),
                            SizedBox(
                              height: 6,
                            ),
                          ],
                        )
                      ])),
              SizedBox(
                height: 15,
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                padding: EdgeInsets.only(
                    left: 20, right: 10, top: 10),
                decoration: BoxDecoration(
                    border: Border(
                        top: BorderSide(
                            width: 0.1,
                            color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                        bottom: BorderSide(
                            width: 0.1,
                            color: Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                    color: Theme.of(context).colorScheme.onPrimaryContainer),
                child: Column(
                  children: [
                    ListTile(
                      visualDensity: VisualDensity(
                          horizontal: 0, vertical: -4),
                      leading: Icon(
                        Icons.bookmarks_sharp,
                        color: Theme.of(context).colorScheme.primary.withOpacity(0.7),
                        size: 20,
                      ),
                      contentPadding: EdgeInsets.symmetric(
                          vertical: -10.0),
                      title: Align(
                        child: Text(
                          'Shift Notes',
                          style:Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.white70),
                        ),
                        alignment: Alignment(-1.2, 0),
                      ),
                    ),
                    Row(
                      children: [
                        Text(
                          datum.notes!,
                          style:Theme.of(context).textTheme.bodyText1!,
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
      ),
    );
  }
  Widget bottomsheet(){
    return DraggableScrollableSheet(
        expand: true,
        snap: false,
        builder: (context,scrollController){
          return Container(
            color: Theme.of(context).colorScheme.onPrimaryContainer,
            margin: EdgeInsets.only(top: 20),
            child: SingleChildScrollView(
                controller: scrollController,

                child:Material(
                    color: Colors.transparent,
                    child: Column(
                      children: [

                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(width: 30,


                            ),
                            Container(
                              height: 8,
                              width: 50,
                              margin: EdgeInsets.only(top: 15,bottom: 15),
                              decoration: BoxDecoration(
                                  border: Border.all(color:Colors.grey.withOpacity(0.5),width: 1) ,
                                  borderRadius: BorderRadius.circular(10)
                              ),

                            ),
                            Container(child: IconButton(onPressed: (){
                              Get.back();
                            }, icon: Icon(Icons.clear)),),
                          ],
                        ),
                        Obx(()=> Column(
                          children: _controller.checkList.value.message!=null? List.generate(
                              _controller.checkList.value.message!.length, (index) =>
                              Container(
                                decoration: BoxDecoration(
                                    color:Theme.of(context).colorScheme.onPrimaryContainer,
                                    border: Border.all(color:Colors.grey.withOpacity(0.5),width: 0.5)
                                ),
                                margin: EdgeInsets.only(top: 8),
                                padding: EdgeInsets.only(top: 8,bottom: 8),
                                child: Row(
                                  children: [
                                    Expanded(
                                        flex:6,
                                        child:
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [

                                            Text(_controller.checkList.value.message![index].checkinTime!,style: Theme.of(context).textTheme.bodyText1,),
                                            SizedBox(height: 2,),
                                            Text(_controller.checkList.value.message![index].checkinDate!,style: Theme.of(context).textTheme.bodyText2)

                                          ],
                                        )
                                    ),

                                    Expanded(flex:4,child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text("Duration",style: Theme.of(context).textTheme.bodyText2,),
                                        SizedBox(height: 2,),
                                        Text(_controller.differTime(
                                            _controller.checkList.value.message![index].checkinTime!,
                                            _controller.checkList.value.message![index].checkinDate!,
                                            _controller.checkList.value.message![index].checkoutTime!,
                                            _controller.checkList.value.message![index].checkOutdate!
                                        ).isNotEmpty?_controller.differTime(
                                            _controller.checkList.value.message![index].checkinTime!,
                                            _controller.checkList.value.message![index].checkinDate!,
                                            _controller.checkList.value.message![index].checkoutTime!,
                                            _controller.checkList.value.message![index].checkOutdate!
                                        )+"":"",style: Theme.of(context).textTheme.bodyText1,)
                                      ],
                                    )),
                                    Expanded(
                                        flex:6,
                                        child:
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Text(_controller.checkList.value.message![index].checkoutTime!,style: Theme.of(context).textTheme.bodyText1,),
                                            SizedBox(height:2,),
                                            Text(_controller.checkList.value.message![index].checkOutdate!,style: Theme.of(context).textTheme.bodyText2)

                                          ],
                                        )
                                    ),

                                  ],
                                ),
                              )
                          ):[],
                        )
                        ),
                      ],
                    )
                )
            ),
          );
        });
  }
  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
    final format = DateFormat.jm(); // YOUR DATE GOES HERE
    return format.format(dt);
  }

}
