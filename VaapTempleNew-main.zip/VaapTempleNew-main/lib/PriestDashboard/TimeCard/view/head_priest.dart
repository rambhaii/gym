import 'dart:convert';
import 'dart:math';
import 'package:aspgen_mobile/AppConstant/config.dart';
import 'package:aspgen_mobile/Dashboard/Contact/Controller/contact_controller.dart';
import 'package:aspgen_mobile/PriestDashboard/TimeCard/view/show_priest_check_details.dart';
import 'package:aspgen_mobile/PriestDashboard/TimeCard/view/timecard.dart';
import 'package:aspgen_mobile/Templates/Model/ListingData.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:aspgen_mobile/Widget/SearchBarWidget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../Widget/CustomListFourTitleWidget.dart';
import '../../../Widget/FullScreenImageWidget.dart';
import '../controller/head_priest_controller.dart';

class AllPriestPage extends StatefulWidget {
  const AllPriestPage({Key? key}) : super(key: key);

  @override
  State<AllPriestPage> createState() => _AllPriestPageState();
}

class _AllPriestPageState extends State<AllPriestPage> {
  var contactFilterList2 = [];

  RxString date = "".obs;
  RxInt nextdate = 1.obs;
  RxInt previousdate = 1.obs;

  HeadPriestController _controller = Get.put(HeadPriestController());
  var bodyJson = {};
  late ComponentConfig componentConfig;

  @override
  void initState() {
    getDate();
    super.initState();
  }

  makingPhoneCall(String phone) async {
    var url = 'tel:' + phone;
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  getDate() {
    final DateFormat formatter = DateFormat('EE, MMM dd');
    final String formatted = formatter.format(DateTime.now());
    date.value = formatted;
  }
  String getEnd(date) {
    try {
      try {
        final DateFormat formatter = DateFormat('hh:mm a');
        DateTime tempDate = new DateFormat('hh:mm a').parse(date);
        final String formatted = formatter.format(tempDate.add(Duration(hours: 2)));
        return formatted;
      } on Exception catch (e) {
        // TODO
        return "";
      }
    } on Exception catch (e) {
      // TODO
      return "";
    }
  }
  getNextDate() {
    final DateFormat formatter = DateFormat('EE, MMM dd');
    DateTime tempDate = new DateFormat('EE, MMM dd').parse(date.value);
    final String formatted =
        formatter.format(tempDate.add(Duration(days: nextdate.value)));
    String tempDate2 = new DateFormat('MM/dd').format(new DateFormat('EE, MMM dd').parse(formatted));
    _controller.fetchApi(tempDate2+"/"+DateTime.now().year.toString());
      date.value = formatted;
  }

  getPreviousDate() {
    final DateFormat formatter = DateFormat('EE, MMM dd');
    DateTime tempDate = new DateFormat('EE, MMM dd').parse(date.value);
    final String formatted =
        formatter.format(tempDate.subtract(Duration(days: previousdate.value)));
    String tempDate2 = new DateFormat('MM/dd').format(new DateFormat('EE, MMM dd').parse(formatted));
    _controller.fetchApi(tempDate2+"/"+DateTime.now().year.toString());
    date.value = formatted;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: PreferredSize(
          preferredSize: Size.fromHeight(80.0),
          // here the desired height
          child:AppBar(

        flexibleSpace: SafeArea(
          child: Column(
            children: [
              Obx(() => Text(
                  new DateFormat('EE, MMM dd').parse(date.value).day==DateTime.now().day?"Today's Schedules":"Schedule For "+new DateFormat('EE, MMM dd').parse(date.value).day.toString(),
                  style: Theme.of(context).textTheme.headline4,
                ),
              ),
              SizedBox(height:9,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: InkWell(
                      onTap: () {
                        getPreviousDate();
                      },
                      child: Icon(
                        Icons.arrow_back_ios,
                        size: 20,
                      ),
                    ),
                  ),
                  Obx(() => Text(
                    date.value,
                    style: Theme.of(context).textTheme.bodyText1,
                  )),
                  Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: InkWell(
                      onTap: () {
                        getNextDate();
                      },
                      child: Icon(
                        Icons.arrow_forward_ios,
                        size: 20,
                      ),
                    ),
                  )
                ],
              ),
            ],
          ),
        ),

      )),
      body: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          SizedBox(
            height: 10,
          ),
          GetBuilder<HeadPriestController>(
            builder: (controller) => SearchBarWidget(
              hint: "Search",
              controller: controller.etSearch,
              onchange: (value) {
                _controller.filterData(value);
              },
              onCancel: () {
                controller.etSearch.clear();
                _controller.filterData(controller.etSearch.text);
                controller.update();
              },
            ),
          ),
          SizedBox(
            height: 8,
          ),
          Obx(
            () => (_controller.datas.value.data != null &&
                    _controller.datas.value.data!.isNotEmpty)
                ? ListView.builder(
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemCount: _controller.datas.value.data!.length,
                    itemBuilder: (context, index) {
                      var dateTime = "";
                      final datum = _controller.datas.value.data![index];
                      return Row(
                        children: [
                          Container(
                            margin:
                                EdgeInsets.only(left: 8, right: 8, bottom: 8),
                            child: datum.priestDetail!.priestImage!.isEmpty
                                ? CircleAvatar(
                                    backgroundColor:
                                        Color(Random().nextInt(0xffffffff)),
                                    child: Text(
                                        datum.requestForPriestName!
                                                    .toString()
                                                    .toUpperCase() ==
                                                ""
                                            ? ""
                                            : datum.requestForPriestName![0]
                                                .toString()
                                                .toUpperCase(),
                                        style: Theme.of(context)
                                            .textTheme
                                            .bodyText1),
                                    maxRadius: 25,
                                  )
                                : CircleAvatar(
                                    backgroundColor:
                                        Color(Random().nextInt(0xffffffff)),
                                    backgroundImage: NetworkImage(
                                        APIsConstant.IP_Base_Url +
                                            datum.priestDetail!.priestImage!),
                                    maxRadius: 25,
                                  ),
                          ),
                          Expanded(
                              child: GestureDetector(
                                onTap: (){
                                  _controller.sendData(datum);
                                  Get.to(() => ShowPriestCherckinServiceDetailsPage());
                                },
                                child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                                SizedBox(
                                  height: 4,
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        SizedBox(
                                          height:10,
                                        ),
                                        HigliteText(
                                            textData: datum
                                                .requestForPriestName!
                                                .toString(),
                                            query: _controller.etSearch.text,
                                            textStyle: TextStyle(
                                                fontSize: 15,
                                                color: Colors.white,
                                                fontFamily: "Raleway",
                                                fontWeight: FontWeight.w600)),
                                        SizedBox(
                                          height:10,
                                        ),
                                        Text(
                                          datum.serviceTime! +
                                              " - " + getEnd(datum.serviceTime!)+" at "+
                                              datum.serviceLocationName!
                                                  .toString(),
                                          style: TextStyle(
                                              fontSize: 14,
                                              fontFamily: "Raleway",
                                              color:
                                                  Colors.amber.withOpacity(0.7),
                                              fontWeight: FontWeight.w600,),
                                        ),
                                      ],
                                    ),
                                    Padding(
                                      padding:
                                          const EdgeInsets.only(right: 8.0),
                                      child: Icon(
                                        Icons.arrow_forward_ios_rounded,
                                        size: 16,
                                        color: Colors.white38,
                                      ),
                                    )
                                  ],
                                ),
                                SizedBox(
                                  height: 6,
                                ),
                                Divider(
                                  thickness: 0.5,
                                  color: Colors.grey.withOpacity(0.2),
                                )
                            ],
                          ),
                              ))
                        ],
                      );
                    })
                : Center(
                    child: Text(
                      _controller.rxMessage.value,
                      style: Theme.of(context).textTheme.bodyText2,
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
