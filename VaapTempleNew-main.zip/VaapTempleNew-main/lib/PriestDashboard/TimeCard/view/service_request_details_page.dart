import 'dart:convert';

import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../../UtilMethods/Utils.dart';

import '../controller/controller.dart';
import '../model/CheckListData.dart';
class CherckinServiceRequestDetailsPage extends StatefulWidget {
   CherckinServiceRequestDetailsPage({Key? key}) : super(key: key);

  @override
  State<CherckinServiceRequestDetailsPage> createState() => _CherckinServiceRequestDetailsPageState();
}

class _CherckinServiceRequestDetailsPageState extends State<CherckinServiceRequestDetailsPage> {
  TimeCardController _controller=Get.find();
   final GlobalKey expansionTile = new GlobalKey();
   final GlobalKey<ExpansionTileCardState> expensionPriestKey =  GlobalKey();
   final GlobalKey<ExpansionTileCardState> expensionMemberKey =  GlobalKey();
   @override
   void initState() {
     super.initState();
     _controller.isCheckIn.value=false;
     _controller.checkList.value=CheckListModel();
     _controller.getCheckList(_controller.datum.value.id!);
   }
   @override
  Widget build(BuildContext context) {
     final datum=_controller.datum.value;
    final devoteedatum=_controller.datum.value.comments!;
    TextStyle title=Theme.of(context).textTheme.bodyText1!;
    TextStyle subTitle=Theme.of(context).textTheme.bodyText2!;
    BoxDecoration decoration=BoxDecoration(
      borderRadius: BorderRadius.circular(5), border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.1),width: 0.4)), color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.3));
    return Scaffold(
      appBar: AppBar(title: Text("Timecard"),

      actions: [
        Center(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text("Total Time",style: Theme.of(context).textTheme.bodyText2,),
              Obx(()=>Text(_controller.rxtotalDuration.value,style: Theme.of(context).textTheme.bodyText1,)),
            ],
          ),
        ),
        SizedBox(width: 15,)
      ],
      ),
      body: SingleChildScrollView(
        child: Container(

          child: Column(
            children: [
              SizedBox(height: 15,),
        if(_controller.type==1)     Obx(()=> Row(children: [
                  Spacer(flex: 1,),
                  Expanded(
                    flex:5,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.teal,
                            disabledBackgroundColor: Colors.grey
                        ),
                        onPressed:!_controller.isCheckIn.value? (){
                          _controller.checknInCheckOut("",datum.id!,true);
                        }:null,
                        icon: Icon(Icons.login),
                        label: Text("Check-In"),
                      )
                  ),
               Spacer(flex: 1,),
                  Expanded(
                    flex: 5,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal,
                          disabledBackgroundColor: Colors.grey
                        ),
                        onPressed:_controller.isCheckIn.value? (){
                          _controller.checknInCheckOut(_controller.checkInId,datum.id!,false);
                        }:null,
                        icon: Icon(Icons.logout),
                        label: Text("Check-Out"),
                      )
                  ),
                  Spacer(flex: 1,),
                ],),
              ),



              Obx(()=> ListView(
                physics: NeverScrollableScrollPhysics(),
                shrinkWrap: true,
                    key: Key('builder ${_controller.isSelected.value.toString()}'),
                  children:[
                    Obx(()=>Container(
                      margin: EdgeInsets.only(top:15,left: 5,right: 5),
                      decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend1.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                      child: ListTileTheme(
                        dense: true,
                        horizontalTitleGap: 15.0,
                        minLeadingWidth: 0,
                        child: ExpansionTile(
                            key: Key("0"),
                            collapsedTextColor: Colors.tealAccent,
                            textColor: Colors.tealAccent,
                            childrenPadding: EdgeInsets.only(top: 0,bottom: 10),
                            onExpansionChanged: (value){
                              _controller.isExpend1.value=value;
                              _controller.isExpend2.value=false;
                              _controller.isExpend3.value=false;
                              _controller.isSelected.value=0;
                            },
                            initiallyExpanded: _controller.isExpend1.value,
                            title: Text("Check In / Out Info",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                            children:_controller.checkList.value.message!=null?
                            List.generate(
                                _controller.checkList.value.message!.length, (index) =>
                            Container(
                              decoration: BoxDecoration(
                                color:Theme.of(context).colorScheme.onPrimaryContainer,
                                border: Border.all(color:Colors.grey.withOpacity(0.5),width: 0.5)
                              ),
                              margin: EdgeInsets.only(top: 8),
                              padding: EdgeInsets.only(top: 8,bottom: 8),
                              child: Row(
                                children: [
                                  Expanded(
                                      flex:6,
                                      child:
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [

                                          Text(_controller.checkList.value.message![index].checkinTime!,style: Theme.of(context).textTheme.bodyText1,),
                                          SizedBox(height: 2,),
                                          Text(_controller.checkList.value.message![index].checkinDate!,style: Theme.of(context).textTheme.bodyText2)

                                        ],
                                      )
                                  ),

                                  Expanded(flex:4,child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text("Duration",style: Theme.of(context).textTheme.bodyText2,),
                                      SizedBox(height: 2,),
                                      Text(_controller.differTime(
                                        _controller.checkList.value.message![index].checkinTime!,
                                        _controller.checkList.value.message![index].checkinDate!,
                                        _controller.checkList.value.message![index].checkoutTime!,
                                        _controller.checkList.value.message![index].checkOutdate!
                                      ).isNotEmpty?_controller.differTime(
                                          _controller.checkList.value.message![index].checkinTime!,
                                          _controller.checkList.value.message![index].checkinDate!,
                                          _controller.checkList.value.message![index].checkoutTime!,
                                          _controller.checkList.value.message![index].checkOutdate!
                                      )+"":"",style: Theme.of(context).textTheme.bodyText1,)
                                    ],
                                  )),
                                  Expanded(
                                      flex:6,
                                      child:
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Text(_controller.checkList.value.message![index].checkoutTime!,style: Theme.of(context).textTheme.bodyText1,),
                                          SizedBox(height:2,),
                                          Text(_controller.checkList.value.message![index].checkOutdate!,style: Theme.of(context).textTheme.bodyText2)

                                        ],
                                      )
                                  ),

                                ],
                              ),
                            )
                            ):[],
                        ),
                      ),
                    ),
                    ),



                   Obx(()=>Container(
                      margin: EdgeInsets.only(top:15,left: 5,right: 5),
                      decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend2.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.amber)),
                      child: ListTileTheme(
                        dense: true,
                        horizontalTitleGap: 15.0,
                        minLeadingWidth: 0,
                        child: ExpansionTile(
                            key: Key("1"),
                           collapsedTextColor: Colors.amber,
                           textColor: Colors.amber,
                          childrenPadding: EdgeInsets.only(left: 10,right: 10),
                          onExpansionChanged: (value){
                            _controller.isExpend1.value=false;
                            _controller.isExpend2.value=value;
                            _controller.isExpend3.value=false;
                            _controller.isSelected.value=0;
                          },
                            initiallyExpanded: _controller.isExpend2.value,
                            title: Text("Devotee Info",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                            children:<Widget>
                            [
                              Column(
                                children: [
                                  SizedBox(height: 4,),
                                  SizedBox(height: 12,),  InputDecorator(decoration: InputDecoration(
                                    labelText:"Devotee Name  ",
                                    labelStyle: subTitle,
                                    contentPadding: EdgeInsets.only(left: 15,right: 15),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(2.0),
                                      borderSide: const BorderSide(
                                          color: Colors.white70, width: 0.0),
                                    ),
                                    border: const OutlineInputBorder(),
                                  ),
                                    child: Text(devoteedatum.contactName!,style: title,)
                                    ,
                                  ),
                                  SizedBox(height: 12,),  InputDecorator(decoration: InputDecoration(
                                    labelText:"Devotee Email  ",
                                    labelStyle: subTitle,
                                    contentPadding: EdgeInsets.only(left: 15,right: 15),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(2.0),
                                      borderSide: const BorderSide(
                                          color: Colors.white70, width: 0.0),
                                    ),
                                    border: const OutlineInputBorder(),
                                  ),
                                    child: Text(UtilMethods.decrypt(devoteedatum.email!),style: title,),
                                  ),
                                  SizedBox(height: 12,),  InputDecorator(decoration: InputDecoration(
                                    labelText:"Devotee Phone  ",
                                    labelStyle: subTitle,
                                    contentPadding: EdgeInsets.only(left: 15,right: 15),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(2.0),
                                      borderSide: const BorderSide(
                                          color: Colors.white70, width: 0.0),
                                    ),
                                    border: const OutlineInputBorder(),
                                  ),
                                    child: Text(phoneFormatter(devoteedatum.phone!),style: title,)
                                    ,
                                  ),
                                  SizedBox(height: 12,),
                                  Row(
                                    children: [
                                      Expanded(
                                        flex: 4,
                                        child: InputDecorator(decoration: InputDecoration(
                                          labelText:"Gotra",
                                          labelStyle: subTitle,
                                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(2.0),
                                            borderSide: const BorderSide(
                                                color: Colors.white70, width: 0.0),
                                          ),
                                          border: const OutlineInputBorder(),
                                        ),
                                          child: Text(devoteedatum.gotraName??"",style: title,)
                                          ,
                                        ),
                                      ),
                                      SizedBox(width: 12,),
                                      Expanded(
                                        flex: 4,
                                        child: InputDecorator(decoration: InputDecoration(
                                          labelText:"Nakshatra ",
                                          labelStyle: subTitle,
                                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(2.0),
                                            borderSide: const BorderSide(
                                                color: Colors.white70, width: 0.0),
                                          ),
                                          border: const OutlineInputBorder(),
                                        ),
                                          child: Text(devoteedatum.nakshatraName??"",style: title,)
                                          ,
                                        ),
                                      ),
                                      SizedBox(width: 12,),
                                      Expanded(
                                        flex: 4,
                                        child: InputDecorator(decoration: InputDecoration(
                                          labelText:"Rashi",
                                          labelStyle: subTitle,
                                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(2.0),
                                            borderSide: const BorderSide(
                                                color: Colors.white70, width: 0.0),
                                          ),
                                          border: const OutlineInputBorder(),
                                        ),
                                          child: Text(devoteedatum.rashiName??"",style: title,)
                                          ,
                                        ),
                                      ),
                                    ],
                                  ),


                                  SizedBox(height: 12,),

                                  InputDecorator(decoration: InputDecoration(
                                    labelText:"Address  ",
                                    labelStyle: subTitle,
                                    contentPadding: EdgeInsets.only(left: 15,right: 15),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(2.0),
                                      borderSide: const BorderSide(
                                          color: Colors.white70, width: 0.0),
                                    ),
                                    border: const OutlineInputBorder(),
                                  ),
                                    child: Text(devoteedatum.address??"",style: title,),),
                                  SizedBox(height: 12,),
                                  Row(
                                    children: [
                                      Expanded(
                                        flex: 4,
                                        child: InputDecorator(decoration: InputDecoration(
                                          labelText:"State",
                                          labelStyle: subTitle,
                                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(2.0),
                                            borderSide: const BorderSide(
                                                color: Colors.white70, width: 0.0),
                                          ),
                                          border: const OutlineInputBorder(),
                                        ),
                                          child: Text(devoteedatum.state??"",style: title,)
                                          ,
                                        ),
                                      ),
                                      SizedBox(width: 12,),
                                      Expanded(
                                        flex: 4,
                                        child: InputDecorator(decoration: InputDecoration(
                                          labelText:"City ",
                                          labelStyle: subTitle,
                                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(2.0),
                                            borderSide: const BorderSide(
                                                color: Colors.white70, width: 0.0),
                                          ),
                                          border: const OutlineInputBorder(),
                                        ),
                                          child: Text(devoteedatum.city??"",style: title,)
                                          ,
                                        ),
                                      ),
                                      SizedBox(width: 12,),
                                      Expanded(
                                        flex: 4,
                                        child: InputDecorator(decoration: InputDecoration(
                                          labelText:"Zip ",
                                          labelStyle: subTitle,
                                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(2.0),
                                            borderSide: const BorderSide(
                                                color: Colors.white70, width: 0.0),
                                          ),
                                          border: const OutlineInputBorder(),
                                        ),
                                          child: Text(devoteedatum.zip??"",style: title,)
                                          ,
                                        ),
                                      ),
                                    ],
                                  ),

                                  SizedBox(height: 12,),
                                  Column(children: List.generate(devoteedatum.memberDetail!.length, (index) =>Container(
                                    padding: EdgeInsets.only(left: 10,right: 10),
                                    decoration: BoxDecoration(
                                        color:Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.6),
                                        border: Border.all(color:Colors.tealAccent.withOpacity(0.3),width: 0.5)

                                    ),
                                    child: Column(
                                      children: [
                                        SizedBox(height:12,),

                                        InputDecorator(decoration: InputDecoration(
                                          labelText:"Member Name "+(index+1).toString(),
                                          labelStyle: subTitle,
                                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                                          enabledBorder: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(2.0),
                                            borderSide: const BorderSide(
                                                color: Colors.white70, width: 0.0),
                                          ),
                                          border: const OutlineInputBorder(),
                                        ),
                                          child: Text(devoteedatum.memberDetail![index].memberName!,style: title,)
                                          ,
                                        ),
                                        SizedBox(height: 12,),
                                        Row(
                                          children: [
                                            Expanded(
                                              flex: 4,
                                              child: InputDecorator(decoration: InputDecoration(
                                                labelText:"Nakshatra",
                                                labelStyle: subTitle,
                                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                                enabledBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(2.0),
                                                  borderSide: const BorderSide(
                                                      color: Colors.white70, width: 0.0),
                                                ),
                                                border: const OutlineInputBorder(),
                                              ),
                                                child: Text(devoteedatum.memberDetail![index].nakshatra!,style: title,)
                                                ,
                                              ),
                                            ),
                                            SizedBox(width: 12,),
                                            Expanded(
                                              flex: 4,
                                              child: InputDecorator(decoration: InputDecoration(
                                                labelText:"Rashi ",
                                                labelStyle: subTitle,
                                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                                enabledBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(2.0),
                                                  borderSide: const BorderSide(
                                                      color: Colors.white70, width: 0.0),
                                                ),
                                                border: const OutlineInputBorder(),
                                              ),
                                                child: Text(devoteedatum.memberDetail![index].rashi!,style: title,)
                                                ,
                                              ),
                                            ),
                                          ],
                                        ),
                                        SizedBox(height: 12,),
                                      ],
                                    ),
                                  ),growable: true),),
                                  SizedBox(height: 12,),
                                ],
                              ),


                            ]
                        ),
                      ),
                    ),
                  ),

                   Obx(()=> Container(
                        margin: EdgeInsets.only(top:15,left: 5,right: 5),
                        decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend3.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.purple)),
                        child: ListTileTheme(
                        dense: true,
                        horizontalTitleGap: 15.0,
                        minLeadingWidth: 0,
                        child: ExpansionTile(
                            maintainState: true,
                            collapsedTextColor: Colors.purple,
                            textColor: Colors.purple,
                            childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                            onExpansionChanged: (value){
                              _controller.isExpend2.value=false;
                              _controller.isExpend1.value=false;
                              _controller.isExpend3.value=value;
                              _controller.isSelected.value=1;
                            },
                            initiallyExpanded: _controller.isExpend3.value,
                         key: Key("2"),
                            title: Text("Service Request Details",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                            children:<Widget>
                            [
                        Column(
                          children: [

                            SizedBox(height: 4,),
                            InputDecorator(decoration: InputDecoration(
                              labelText:"Service Name  ",
                              labelStyle: subTitle,
                              contentPadding: EdgeInsets.only(left: 15,right: 15),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(2.0),
                                borderSide: const BorderSide(
                                    color: Colors.white70, width: 0.0),
                              ),
                              border: const OutlineInputBorder(),
                            ),
                              child: Text(datum.serviceName??"",style: title,),
                            ),

                            SizedBox(height: 12,),
                            Row(
                              children: [
                                Expanded(
                                  flex: 4,
                                  child: GestureDetector(
                                    onTap: ()async{
                                 final DateTime? date=await showDatePicker(
                                          context: context,
                                          initialDate:DateTime.now(),
                                      firstDate: DateTime(1900),
                                      lastDate: DateTime(2100),
                                      builder: (context, child) {
                                      return Theme(
                                      data: ThemeData.dark().copyWith(
                                      colorScheme: const ColorScheme.dark(
                                      onPrimary: Colors.white,
                                      // selected text color
                                      onSurface: Colors.white,
                                      // default text color
                                      primary: Colors
                                          .teal // circle color
                                      ),
                                      dialogBackgroundColor: Theme
                                          .of(context)
                                          .backgroundColor,
                                      textButtonTheme: TextButtonThemeData(
                                      style: TextButton.styleFrom(
                                      textStyle: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight
                                          .normal,
                                      fontSize: 12,
                                      fontFamily: 'Quicksand'),
                                      primary: Colors.white,
                                      // color of button's letters
                                      backgroundColor: Colors
                                          .black54,
                                      // Background color
                                      shape: RoundedRectangleBorder(
                                      side: const BorderSide(
                                      color: Colors
                                          .transparent,
                                      width: 1,
                                      style: BorderStyle
                                          .solid),
                                      borderRadius: BorderRadius
                                          .circular(50))))),
                                      child: child!,
                                      );
                                      });
                                 if(date!=null)
                                   {
                                     _controller.datum.value.serviceDate=_controller.formatter1.format(date!);

                                     setState(() {

                                     });


                                   }

                                    },
                                    child: InputDecorator(decoration: InputDecoration(
                                      labelText:"Service Date  ",
                                      labelStyle: subTitle,
                                      contentPadding: EdgeInsets.only(left: 15,right: 15),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(2.0),
                                        borderSide: const BorderSide(
                                            color: Colors.white70, width: 0.0),
                                      ),
                                      border: const OutlineInputBorder(),
                                    ),
                                      child: Text(datum.serviceDate??"",style: title,)
                                      ,
                                    ),
                                  ),
                                ),
                                SizedBox(width: 12,),
                                Expanded(
                                  flex: 4,
                                  child: GestureDetector(
                                    onTap: ()async{
                                      TimeOfDay? time = await showTimePicker(
                                          context: context,
                                          initialTime: TimeOfDay.now(),
                                          builder: (context, child) {
                                            return Theme(
                                              data: ThemeData.dark().copyWith(
                                                  colorScheme: const ColorScheme.dark(
                                                      onPrimary: Colors.white,
                                                      onSurface: Colors.white,
                                                      primary: Colors.teal // circle color
                                                  ),
                                                  dialogBackgroundColor: Theme
                                                      .of(context)
                                                      .backgroundColor,

                                                  textButtonTheme: TextButtonThemeData(
                                                      style: TextButton.styleFrom(
                                                          textStyle: const TextStyle(
                                                              color: Colors.white,
                                                              fontWeight: FontWeight
                                                                  .normal,
                                                              fontSize: 12,
                                                              fontFamily: 'Quicksand'),
                                                          primary: Colors.white,
// color of button's letters
                                                          backgroundColor: Colors
                                                              .black54,
// Background color
                                                          shape: RoundedRectangleBorder(
                                                              side: const BorderSide(
                                                                  color: Colors
                                                                      .transparent,
                                                                  width: 1,
                                                                  style: BorderStyle
                                                                      .solid),
                                                              borderRadius: BorderRadius
                                                                  .circular(50))))),
                                              child: child!,
                                            );
                                          }

                                      );
                                      if(time!=null)
                                        {
                                          _controller.datum.value.serviceTime= formatTimeOfDay(time) ;
                                          setState(() {

                                          });
                                        }
                                    },
                                    child: InputDecorator(decoration: InputDecoration(
                                      labelText:"Service Time  ",
                                      labelStyle: subTitle,
                                      contentPadding: EdgeInsets.only(left: 15,right: 15),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(2.0),
                                        borderSide: const BorderSide(
                                            color: Colors.white70, width: 0.0),
                                      ),
                                      border: const OutlineInputBorder(),
                                    ),
                                      child: Text(datum.serviceTime??"",style: title,)
                                      ,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 12,),
                            Row(
                              children: [
                                Expanded(
                                  flex: 4,
                                  child: GestureDetector(
                                    onTap: (){
                                      showDailog();
                                    },
                                    child: InputDecorator(decoration: InputDecoration(
                                      labelText:"Location",
                                      labelStyle: subTitle,
                                      contentPadding: EdgeInsets.only(left: 15,right: 15),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(2.0),
                                        borderSide: const BorderSide(
                                            color: Colors.white70, width: 0.0),
                                      ),
                                      border: const OutlineInputBorder(),
                                    ),
                                      child: Text(datum.serviceLocationName??"",style: title,)
                                      ,
                                    ),
                                  ),
                                ),
                                SizedBox(width: 12,),
                                Expanded(
                                  flex: 4,
                                  child: InputDecorator(decoration: InputDecoration(
                                    labelText:"Service Amount  ",
                                    labelStyle: subTitle,
                                    contentPadding: EdgeInsets.only(left: 15,right: 15),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(2.0),
                                      borderSide: const BorderSide(
                                          color: Colors.white70, width: 0.0),
                                    ),
                                    border: const OutlineInputBorder(),
                                  ),
                                    child: Text("\$ "+datum.serviceAmount.toString(),style: title,)
                                    ,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 12,),
                            InputDecorator(decoration: InputDecoration(
                              labelText:"Language",
                              labelStyle: subTitle,
                              contentPadding: EdgeInsets.only(left: 15,right: 15),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(2.0),
                                borderSide: const BorderSide(
                                    color: Colors.white70, width: 0.0),
                              ),
                              border: const OutlineInputBorder(),
                            ),
                              child: Text(datum.languagePreferenceName??"",style: title,)
                              ,
                            ), SizedBox(height: 12,),
                            InputDecorator(decoration: InputDecoration(
                              labelText:"Notes",
                              labelStyle: subTitle,
                              contentPadding: EdgeInsets.only(left: 15,right: 15),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(2.0),
                                borderSide: const BorderSide(
                                    color: Colors.white70, width: 0.0),
                              ),
                              border: const OutlineInputBorder(),
                            ),
                              child: Text(datum.notes??"",style: title,)
                              ,
                            ),
                            SizedBox(height: 4,),
                          ],
                        ),


                            ]
                        ),
                  ),
                      ),
                    ),

                  // Obx(() => Container(
                  // margin: EdgeInsets.only(top:15,left: 5,right: 5),
                  // decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend3.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.amber)),
                  // child: ListTileTheme(
                  //       dense: true,
                  //       horizontalTitleGap: 15.0,
                  //       minLeadingWidth: 0,
                  //       child: ExpansionTile(
                  //
                  //           collapsedTextColor: Colors.amber,
                  //           textColor: Colors.amber,
                  //           childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                  //           onExpansionChanged: (value){
                  //             _controller.isExpend3.value=value;
                  //             _controller.isExpend2.value=false;
                  //             _controller.isExpend1.value=false;
                  //             _controller.isSelected.value=2;
                  //           },
                  //           maintainState: true,
                  //           initiallyExpanded: _controller.isExpend3.value,
                  //           key: Key("2"),
                  //           title: Text("Priest Request",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                  //           children:<Widget>
                  //           [
                  //             Column(
                  //               children: [
                  //                 SizedBox(height: 4,),
                  //                 Obx(()=> _controller.map.isNotEmpty?
                  //                 Container(
                  //                   height: 50,
                  //                   width: Get.width,
                  //
                  //                   child:  DropdownButtonWidget(
                  //                     change: (value) {
                  //                         setState(() {
                  //                             _controller.selectedValue=value;
                  //                             _controller.email.value=_controller.selectedValue["email"];
                  //                             _controller.phone.value=_controller.selectedValue["phone"];
                  //                         });
                  //                       // controller.selectedValue=value;
                  //                      // controller.update();
                  //                     },
                  //                     title: "Select Member Type",
                  //                     list:_controller.map.value,
                  //                     hint: "Select Member Type",
                  //                     selectvalue: _controller.selectedValue,
                  //                     onPress: '',
                  //                   ),
                  //
                  //                 ):Container()
                  //                   ,),
                  //                SizedBox(height: 14,),
                  //                 InputDecorator(decoration: InputDecoration(
                  //                   labelText:"Priest Email",
                  //                   labelStyle: subTitle,
                  //                   contentPadding: EdgeInsets.only(left: 15,right: 15),
                  //                   enabledBorder: OutlineInputBorder(
                  //                     borderRadius: BorderRadius.circular(2.0),
                  //                     borderSide: const BorderSide(
                  //                         color: Colors.white70, width: 0.0),
                  //                   ),
                  //                   border: const OutlineInputBorder(),
                  //                 ),
                  //                   child: Text(_controller.email.value,style: title,)
                  //                   ,
                  //                 ),
                  //                 SizedBox(height: 12,),  InputDecorator(decoration: InputDecoration(
                  //                   labelText:"Priest Phone ",
                  //                   labelStyle: subTitle,
                  //                   contentPadding: EdgeInsets.only(left: 15,right: 15),
                  //                   enabledBorder: OutlineInputBorder(
                  //                     borderRadius: BorderRadius.circular(2.0),
                  //                     borderSide: const BorderSide(
                  //                         color: Colors.white70, width: 0.0),
                  //                   ),
                  //                   border: const OutlineInputBorder(),
                  //                 ),
                  //                   child: Text( MaskTextInputFormatter(
                  //                       initialText:_controller.phone.value, mask: '(###) ###-####',
                  //                       filter: {"#": RegExp(r'[0-9]')},
                  //                       type: MaskAutoCompletionType.lazy ).getMaskedText(),style: title,)
                  //                   ,
                  //                 ),
                  //                 SizedBox(height: 4,),
                  //               ],
                  //             ),
                  //
                  //
                  //           ]
                  //       ),
                  //     ),
                  // ),
                 // ),
                  ]
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

   String formatTimeOfDay(TimeOfDay tod) {
     final now = new DateTime.now();
     final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
     final format = DateFormat.jm(); // YOUR DATE GOES HERE
     return format.format(dt);
   }

   showDailog() {
    return showDialog(context: context, builder: (context) =>
        SimpleDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(4.0))),
          backgroundColor: Theme
              .of(context)
              .dialogBackgroundColor
              .withOpacity(0.9),
          title: Text("Select Location"),
          children: [
            SimpleDialogOption(
              onPressed: (){
                Get.back();
                setState(() {
                  _controller.datum.value.serviceLocationName="IN-TEMPLE";
                });

              },
              child: Text("IN-TEMPLE", style: Theme
                  .of(context)
                  .textTheme
                  .bodyText2,)
            ),
            SimpleDialogOption(
              onPressed: (){
                 Get.back();
                 setState(() {
                   _controller.datum.value.serviceLocationName="OUT-TEMPLE";
                 });


              },
              child: Text("OUT-TEMPLE", style: Theme
                  .of(context)
                  .textTheme
                  .bodyText2,),
            ),

          ],
        ));
  }
}
