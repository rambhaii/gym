import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/Notification/page/NotificationPage.dart';
import 'package:aspgen_mobile/calendar/Booking/BookingCalender.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:curved_navigation_bar/curved_navigation_bar.dart';

import '../AppConstant/AppConstant.dart';
import '../Dashboard/Contact/ContactPage.dart';
import '../Dashboard/ProfilePage.dart';
import '../Dashboard/dashboard.dart';
import '../Dashboard/member_profile.dart';
import '../Notification/RecievedNotification/controller.dart';
import '../Notification/RecievedNotification/recieve_notification.dart';
import '../calendar/calendar.dart';
import 'dash_controller.dart';
class DashboardNavBar extends StatefulWidget {
  const DashboardNavBar({Key? key}) : super(key: key);
  @override
  State<DashboardNavBar> createState() => _DashboardNavBarState();
}

class _DashboardNavBarState extends State<DashboardNavBar> {
  int _page = 0;
  DateTime ?currentBackPressTime;

  final DashController _controller=Get.put(DashController(),permanent: true);
  ReciveNotiController notiController = Get.put(ReciveNotiController());
  @override
  void initState() {
    // TODO: implement initState

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return  WillPopScope(
      onWillPop: onWillPop,
      child: Scaffold(
        extendBody: true,
  body:  Obx(()=>_controller.index.value!=-1? LayoutBuilder(
            builder: (BuildContext ctx, BoxConstraints constraints) {
              switch(_controller.index.value){
                case 0:
                  return Dashboard();
                  case 1:
                  return ContactPage(title: 'Contacts',displayName: "Contacts",);
                  case 2:
                  return RecieveNotificationPage(title: 'Notifications',);
                  case 3:
                  return BookingCalendar(title: 'Calendar', displayName: 'Bookings',);
                  case 4:
                  return AppConstant.sharedPreference.getBool(AppConstant.isMember)==false?  ProfilePage(title: 'Profile Page',): MemberProfilePage(title: 'Profile Page',);
                default:
                  return Dashboard();
              }
            })
      :
  Container(),
  ),

 bottomNavigationBar:Obx(()=>CurvedNavigationBar(
           height: 60,
           color:Theme.of(context).bottomAppBarColor,
             buttonBackgroundColor:AppColor.primaryColor,
             backgroundColor: Colors.transparent,
             animationCurve: Curves.easeInOut,
             animationDuration: Duration(milliseconds: 600),
             key:_controller.bottomNavigationKey,
           items: <Widget>[
              Icon(Icons.home, size: 30,color:_controller.index==0?Colors.white:Colors.white,),
              Icon(Icons.contacts_sharp, size: 30,color:_controller.index==1?Colors.white:Colors.white,),
              Obx(()=>notiController.notiCount.value!=0?
              Badge(label: Text(notiController.notiCount.toString(),style: TextStyle(color: Colors.white),),child: Icon(Icons.notifications_active, size: 30,color:_controller.index==2?Colors.white:Colors.white, )):Icon(Icons.notifications_active, size: 30,color:_controller.index==2?Colors.white:Colors.white, )),
              Icon(Icons.calendar_today, size: 30,color:_controller.index==3?Colors.white:Colors.white,),
              Icon(Icons.perm_identity, size: 30,color:_controller.index==4?Colors.white:Colors.white,),
            ],
            onTap: (index) {
              _controller.index.value=index;
            },),
 ),
      ),
    );
  }

  Future<bool> onWillPop() {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null || now.difference(currentBackPressTime!) > Duration(seconds: 2)) {
      currentBackPressTime = now;
      Fluttertoast.showToast(msg: "Press again to exit");
      return Future.value(false);
    }
    return Future.value(true);
  }
}
