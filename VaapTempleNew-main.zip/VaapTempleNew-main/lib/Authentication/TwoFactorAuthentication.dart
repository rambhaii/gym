

import 'dart:convert';

import 'package:aspgen_mobile/BottomBar/dashboard_nav.dart';
import 'package:aspgen_mobile/Dashboard/dashboard.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

import '../AppConstant/AppConstant.dart';
import '../UtilMethods/RemoteServices.dart';

class TwoFactorAuthentication extends StatefulWidget {
  final String email;
  const TwoFactorAuthentication({Key? key, required this.email}) : super(key: key);

  @override
  State<TwoFactorAuthentication> createState() => _TwoFactorAuthenticationState();
}

class _TwoFactorAuthenticationState extends State<TwoFactorAuthentication> {
  final _formKey = GlobalKey<FormState>();
  int _time = 60;
  String otp = "";
  String time = "00";
  bool resend = false;

  Future<void> startTime() async {
    if (_time > 0) {
      resend = false;
      await Future.delayed(Duration(seconds: 1));
      setState(() {
        time = _time.toString();
      });
      _time--;
      startTime();
    }else{
      setState(() {
        resend = true;
      });
    }
  }
  @override
  void initState() {
    print("sdvbsvjsjk");

    startTime();
    // TODO: implement initState
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Two factor Verification") ,),
      body:Stack(
        children: [
          SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 20.0,
                    ),
                    Text( "You will get SMS with a confirmation\ncode to this email \n ${widget.email} ",textAlign: TextAlign.center,style: Theme.of(context).textTheme.bodyText2!.copyWith(color: Colors.white),),
                    SizedBox(
                      height: 25.0,
                    ),
                    Text("Please input code below"),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 40.0, horizontal: 35.0),
                      child: PinCodeTextField(
                        appContext: context,
                        length: 6,
                        validator: (value) {
                          if (value!.isEmpty || value.length < 6) {
                            return "Please Enter OTP";
                          }
                          return null;
                        },
                        onChanged: (value) {
                          otp = value;
                        },
                        keyboardType: TextInputType.number,
                        obscureText: false,
                        pinTheme: PinTheme(
                          inactiveColor: Colors.teal,
                          selectedColor: Colors.white70,
                          shape: PinCodeFieldShape.box,
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                    ),
                    Text(time),
                    SizedBox(
                      height: 16.0,
                    ),
                    ElevatedButton(onPressed: (){
                      if(_formKey.currentState!.validate())
                        {
                          CheckInternetConnection().then((value) {
                            if(value==true)
                            {
                              verifyCode(otp);
                              //signIn(otp);
                              // verifyOTP(context);
                            }
                          });
                        }

                    }
                      ,child: Text("Verify",style: TextStyle( fontSize: 16,color: Colors.white),),
                      // color: Colors.teal,
                      // padding: EdgeInsets.only(left: 25,right: 25,top: 10,bottom: 10),

                    ),
                    // ElevatedButton(
                    //   onPressed:  () {
                    //     CheckInternetConnection().then((value) {
                    //       if(value==true)
                    //       {
                    //         signIn(otp);
                    //         // verifyOTP(context);
                    //       }
                    //     });
                    //
                    //   },
                    //   child: Text(
                    //     "Verify",
                    //     style: TextStyle(color: Colors.white),
                    //   ),
                    //
                    //   style:ButtonStyle(
                    //     backgroundColor: Colors.red,
                    //   ),
                    // ),
                    SizedBox(
                      height: 26.0,
                    ),
                    resend ? InkWell(onTap: () {
                      
                    }, child: Text("RESEND CODE")) : Container(),
                  ],
                ),
              ),
            ),
          ),
        ],
      ) ,
    );
  }
  verifyCode(String otp){
    UtilMethods.verifyAuth(context, widget.email, int.parse(otp)).then((value) async{
       if(jsonDecode(value)["user"]["statusCode"]==1)
         {
           Get.to(()=>DashboardNavBar());
           await AppConstant.sharedPreference.setBool(AppConstant.isVerify, true);
           Get.snackbar("Authentication",jsonDecode(value)["user"]["message"],
               backgroundGradient: LinearGradient(colors: [
                 Colors.red,
                 Colors.black26,
               ]),
               borderRadius: 2,
               icon: Icon(Icons.error)
           );
         }
       else
         {
           Get.snackbar("Authentication",jsonDecode(value)["user"]["message"],
               backgroundGradient: LinearGradient(colors: [
                 Colors.red,
                 Colors.black26,
               ]),
               borderRadius: 2,
               icon: Icon(Icons.error)
           );
         }
    });
  }
}
