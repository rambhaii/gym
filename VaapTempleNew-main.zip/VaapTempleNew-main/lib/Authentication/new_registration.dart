import 'dart:convert';

import 'package:aspgen_mobile/Authentication/Model/ClientInfoModel.dart';
import 'package:aspgen_mobile/Authentication/controller/auth_controller.dart';
import 'package:aspgen_mobile/Dashboard/dashboard.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:aspgen_mobile/Widget/EditextWidget.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';

import '../AppConstant/AppColors.dart';
import '../Dashboard/Model/dashboard_menu_item_data.dart';
import '../Widget/DropdownButtonWidget.dart';
import 'NewLoginPage.dart';


final elevatedStyle= ElevatedButton.styleFrom(
  backgroundColor: Colors.teal,

);
class RegistrationPage extends StatefulWidget {
  final int type;//type ==1 for registration and type == 2 for updation
  const RegistrationPage({Key? key, required this.type}) : super(key: key);

  @override
  _NewRegistrationState createState() => _NewRegistrationState();
}

class _NewRegistrationState extends State<RegistrationPage> {

  ClientInfoModel clientInfoModel = ClientInfoModel();
  AuthController authController = Get.put(AuthController());
  List<Map> organizationList = [];
  var selectedOrganization;
  String orgnizationVar = "";
  String orgnizationId = "";
  List<Map> productList = [];
  var selectedproduct;
  String productVar = "";
  String productId = "";
  List<Map> roleList = [{
    "name": "OWNER",
    "id": "1"
  },
    {
      "name": "ADMIN",
      "id": "2"
    },
    {
      "name": "DESIGN",
      "id": "3"
    }
  ];
  var selectedRole;
  String roleVar = "";
  String roleId = "";

  var s;

  final formGlobalKey = GlobalKey<FormState>();

  @override
  void initState() {
    // TODO: implement initState
    new Future.delayed(Duration.zero, () {
      widget.type==1?show_dailog():"";
    });

    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer);
    return Scaffold(

      appBar: AppBar(
        title: Text(
          "REGISTRATION",
        ),
        actions: [
          RawMaterialButton(onPressed: ()async{
            if (formGlobalKey.currentState!.validate()) {
              // DeterminePosition().then((value) async {
                String? token = await FirebaseMessaging.instance
                    .getToken();

                UtilMethods.signUp(
                    context,
                    authController.etusername.text,
                    authController.etpassword.text,
                    authController.etfirstname.text,
                    authController.etlastname.text,
                    authController.etemail.text,
                    authController.etphone.text,
                    authController.etaddress.text,
                    authController.etcity.text,
                    authController.etstate.text,
                    orgnizationVar,
                    authController.etUserZip.text,
                    roleVar,
                    orgnizationId,
                    roleId,
                    productVar,
                    productId,
                    token!.toString(),
                   "" + "," +
                        "",
                    authController.twoFactor.value,
                    authController.notification.value,
                    authController.newsletters.value,
                    authController.pinPasword.value,
                    authController.etPinPassword.text).then((value) {
                  if (jsonDecode(value)["statusCode"] == 1) {
                    Get.offAll(() => NewLoginPage());
                  }
                });

            }
          },
            child: Icon(Icons.save),
            fillColor: Colors.green,
            shape: CircleBorder(),
            constraints: BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          SizedBox(width: 8,)
        ],
      ),
      body: SingleChildScrollView(
        child: GetBuilder<AuthController>(
              builder: (authController) {
                return Padding(
                  padding: const EdgeInsets.only(left: 10,right: 10.0),
                  child: Column(
                    children: [
                      Form(
                        key: formGlobalKey,
                        child: Column(
                          children: [
                            Container(
                                margin: EdgeInsets.only(top:15),
                                decoration:decoration.copyWith(border: Border.all(color: (authController.isExpanded1==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                                child:ExpansionTileCard(
                                  finalPadding: EdgeInsets.only(left: 10,right: 10,bottom: 8),
                                  baseColor: Colors.transparent,
                                  elevation: 0,
                                  expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                                  key: authController.Group1Key,
                                  onExpansionChanged: ((value){
                                    authController.isExpanded1=!authController.isExpanded1;
                                    authController.Group2Key.currentState!.collapse();
                                    authController.update();
                                  }),
                                  title: Text("User Details"),

                                  children:[
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Username",
                                      controller:authController.etusername,
                                      hint: 'Enter user name ',

                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form username';
                                        }

                                        return null;
                                      },
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "First Name",
                                      controller: authController.etfirstname,
                                      hint: 'Enter first name',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form first name';
                                        }
                                        return null;
                                      },
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Last Name",
                                      controller: authController.etlastname,
                                      hint: 'Enter Last Name',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form last name';
                                        }
                                        return null;
                                      },
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    if(widget.type==1)  EditTextWidget(
                                      label: "Password",
                                      controller: authController.etpassword,
                                      hint: 'Enter Password',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form password';
                                        }
                                        return null;
                                      },
                                      maxLength: 20,
                                      maxline: 1,
                                      keyboardtype: TextInputType.visiblePassword,
                                      isPassword: true,
                                    ),
                                    if(widget.type==1)SizedBox(height: 10,),
                                    if(widget.type==1)    EditTextWidget(
                                      label: "Repeat Password",
                                      controller: authController.etrepassword,
                                      hint: 'Enter Repeat Password',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form repeat password';
                                        }
                                        if (value != authController.etpassword.text) {
                                          return 'Password Does Not Matchecd';
                                        }
                                        return null;
                                      },
                                      maxLength: 20,
                                      maxline: 1,
                                      keyboardtype: TextInputType.visiblePassword,
                                      isPassword: true,
                                    ),
                                    if(widget.type==1) SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Email",
                                      controller: authController.etemail,
                                      hint: 'Enter Email',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form email';
                                        }
                                        if (!isValidEmail(value)) {
                                          return 'Please Enter Valid email';
                                        }
                                        return null;
                                      },
                                      maxLength: 50,
                                      keyboardtype: TextInputType.emailAddress,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Phone",
                                      controller: authController.etphone,
                                      hint: 'Enter Phone ',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form phone ';
                                        }
                                        return null;
                                      },
                                      maxLength: 10,
                                      keyboardtype: TextInputType.phone,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Zip Code",
                                      controller: authController.etUserZip,
                                      hint: 'Enter Zip Code ',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please Enter Zip Code';
                                        }
                                        return null;
                                      },
                                      maxLength: 10,
                                      keyboardtype: TextInputType.phone,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Address",
                                      controller:authController.etaddress,
                                      hint: 'Enter address',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form address';
                                        }
                                        return null;
                                      },
                                      maxLength: 50,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "State",
                                      controller: authController.etstate,
                                      hint: 'Enter State',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form state';
                                        }
                                        return null;
                                      },
                                      maxLength: 50,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "City",
                                      controller: authController.etcity,
                                      hint: 'Enter city',

                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form city';
                                        }
                                        return null;
                                      },
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                  ]
                                ),
                            ),
                            Container(
                              margin: EdgeInsets.only(top:15),
                              decoration:decoration.copyWith(border: Border.all(color: (authController.isExpanded2==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                              child:ExpansionTileCard(
                                  baseColor: Colors.transparent,
                                  elevation: 0,
                                  expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                                  key: authController.Group2Key,
                                  onExpansionChanged: ((value){
                                    authController.Group1Key.currentState!.collapse();
                                    authController.isExpanded2=!authController.isExpanded2;
                                    authController.update();
                                  }),
                                  title: Text("User Preferences"),
                                  children:[
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        SizedBox(height: 8,),
                                        Card(
                                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                                          child: ListTile(
                                            title: Text("Two Factor Authentication ",style: Theme.of(context).textTheme.bodyText1,
                                            ) ,
                                            trailing:Obx(()=>CupertinoSwitch(onChanged: (bool value) {
                                              authController.changevalueTwofactorAut(value);
                                            }, value: authController.twoFactor.value,
                                            ),
                                            ),
                                          ),
                                        ),

                                        SizedBox(height: 5,),
                                        Card(
                                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                                          child: ListTile(
                                            title: Text("Notifications ",style: Theme.of(context).textTheme.bodyText1,
                                            ) ,
                                            trailing:Obx(()=>
                                                CupertinoSwitch(onChanged: (bool value) {
                                                authController.changevalueNotification(value);
                                                }, value:  authController.notification.value,),
                                            ),
                                          ),
                                        ),

                                        SizedBox(height: 5,),
                                        Card(
                                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                                          child: ListTile(
                                            title: Text("News letters ",style: Theme.of(context).textTheme.bodyText1,
                                            ) ,
                                            trailing:Obx(()=>
                                             CupertinoSwitch(onChanged: (bool value) {
                                              authController.newsletters(value);
                                              },
                                             value:  authController.newsletters.value,),
                                            ),
                                          ),
                                        ),
                                        SizedBox(height: 5,),
                                        Card(
                                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                                          child: ListTile(
                                            title: Text("Pin Password  ",style: Theme.of(context).textTheme.bodyText1,) ,
                                            trailing:Obx(()=>  CupertinoSwitch(onChanged: (bool value) {
                                              authController.changePinPassword(value);
                                            }, value:  authController.pinPasword.value,
                                            ),
                                            ),
                                          ),
                                        ),

                                        SizedBox(height: 15,),

                                        Obx(()=> authController.pinPasword.value? Row(
                                          children: [
                                            SizedBox(width: 15,),
                                            Expanded(
                                                flex: 3,
                                                child:EditTextWidget(
                                                  controller: authController.etPinPassword,
                                                  label: 'Enter Pin', maxLength: 6, keyboardtype: TextInputType.number, hint:  'Enter Pin', isPassword: false, validator: (value) {  },))
                                            , SizedBox(width: 15,),
                                          ],
                                        ):Container(),
                                        ),


                                      ],

                                    )
                                  ]
                              ),
                            ),

                          ],
                        ),
                      ),

                    ],
                  ),
                );
              }
            ),

      ),


    );
  }


  void show_dailog() {
    bool isgetbtn = true;
    bool isorgnization = false;
    bool isrole = false;
    bool isdonebtn = false;
    List<Product> pList = [];
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
            builder: (context, setState) {
              return WillPopScope(
                onWillPop: () async {
                  return false;
                },
                child: AlertDialog(
                  contentPadding: EdgeInsets.zero,
                  backgroundColor: Theme
                      .of(context)
                      .colorScheme
                      .secondary,
                  content: Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          height: 50,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.teal,
                                  Colors.teal.withOpacity(0.7),

                                ],
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                //stops: [1.0,1.0,],
                                tileMode: TileMode.clamp,
                              )),

                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Filtersss",
                                style: TextStyle(color: Colors.transparent),),
                              Text("Filter", style: TextStyle(
                                  color: Colors.white, fontSize: 20),),
                              IconButton(onPressed: () {
                                Navigator.pop(context);
                                Navigator.pop(context);
                              }, icon: Icon(Icons.clear), color: Colors.white,)

                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: EdgeInsets.all(10),
                          child: Column(

                            children: [
                              EditTextWidget(
                                label: "ZIP Code",
                                controller: authController.etZip,
                                onchanged: ((value) {
                                  setState(() {
                                    isgetbtn = true;
                                    isorgnization = false;
                                    isrole = false;
                                    isdonebtn = false;
                                  }
                                  );
                                }),
                                hint: 'Enter Zip',
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter ZIP Code';
                                  }
                                  return null;
                                },
                                maxLength: 6,
                                keyboardtype: TextInputType.number,
                                isPassword: false,
                              ),
                              SizedBox(height: 5,),
                              Visibility(
                                visible: isorgnization,
                                child: DropdownButtonWidget(
                                  change: (value) {
                                    productList.clear();
                                    selectedproduct = null;
                                    setState(() {
                                      selectedOrganization = value;
                                      orgnizationVar =
                                      selectedOrganization["name"];
                                      orgnizationId =
                                      selectedOrganization["id"];
                                      pList = selectedOrganization['plist'];
                                      pList.forEach((element1) {
                                        productList.add({
                                          "name": element1.name,
                                          "id": element1.productId
                                        });
                                      });
                                    });
                                    // getKioskPriestOrderData(statusupdate,4,"","",selectedService["name"]);
                                  },
                                  title: "Select Organization",
                                  list: organizationList,
                                  hint: "Select Organization",
                                  selectvalue: selectedOrganization,
                                  onPress: '',
                                ),
                              ),
                              Visibility(
                                visible: isdonebtn,
                                child: SizedBox(
                                  height: 12,
                                ),
                              ),
                              Visibility(
                                visible: isrole,
                                child: DropdownButtonWidget(
                                  change: (value) {
                                    setState(() {
                                      selectedproduct = value;
                                      productVar = selectedproduct['name'];
                                      productId = selectedproduct['id'];
                                    });
                                  },
                                  title: "Select Product",
                                  list: productList,
                                  hint: "Select Product",
                                  selectvalue: selectedproduct,
                                  onPress: '',
                                ),
                              ),
                              Visibility(
                                visible: isdonebtn,
                                child: SizedBox(
                                  height: 12,
                                ),
                              ),
                              Visibility(
                                visible: isrole,
                                child: GetBuilder<AuthController>(
                                  builder:(controller)=>DropdownButtonWidget(
                                    change: (value) {
                                      setState(() {
                                        selectedRole = value;
                                        roleVar = selectedRole['name'];
                                        roleId = selectedRole['id'];
                                      });
                                    },
                                    title: "Select Your Role",
                                    list: controller.roleList.value,
                                    hint: "Select Select Your Role",
                                    selectvalue: selectedRole,
                                    onPress: '',
                                  ),
                                ),
                              ),

                              Visibility(
                                visible: isgetbtn,
                                child: ElevatedButton(

                                  style: elevatedStyle,
                                  onPressed: () {
                                  UtilMethods.getClientInfoAPI(
                                      context, authController.etZip.text).then((value) {
                                    if (jsonDecode(value)["statusCode"] ==
                                        "-1") {
                                      organizationList.clear();
                                      productList.clear();
                                      Fluttertoast.showToast(
                                          msg: "Please Enter Valid Zip Code",
                                          backgroundColor: Colors.red);
                                    }
                                    else {
                                      organizationList.clear();
                                      productList.clear();
                                      setState(() {
                                        clientInfoModel =
                                            clientInfoModelFromJson(value);
                                        clientInfoModel.data!.forEach((
                                            element) {
                                          organizationList.add({
                                            "name": element.clientName,
                                            "id": element.clientCode,
                                            "plist": element.productId
                                          });
                                        });

                                        isgetbtn = false;
                                        isdonebtn = true;
                                        isorgnization = true;
                                        isrole = true;
                                      });
                                    }
                                  });
                                }
                                  ,
                                  child: Text(" GET ORGANIZATIONS ",
                                    style: TextStyle(
                                        fontSize: 16, color: Colors.white),),


                                ),
                              ),
                              SizedBox(height: 10,),
                              Visibility(
                                visible: isdonebtn,
                                child:
                                ElevatedButton(
                                  style: elevatedStyle,
                                  onPressed: () {
                                  if (orgnizationVar == "") {
                                    Fluttertoast.showToast(
                                        msg: "Please Select Orgnization");
                                  }
                                  else if (productVar == "") {
                                    Fluttertoast.showToast(
                                        msg: "Please Select Product");
                                  }
                                  else if (roleVar == "") {
                                    Fluttertoast.showToast(
                                        msg: "Please Select Role");
                                  }
                                  else {
                                    Get.back();
                                  }
                                }
                                  ,
                                  child: Text(" DONE ", style: TextStyle(
                                      fontSize: 16, color: Colors.white),),


                                ),
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                ),
              );
            }
        );
      },
    );
  }

}
