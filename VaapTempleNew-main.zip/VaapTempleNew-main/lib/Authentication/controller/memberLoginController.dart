import 'dart:convert';

import 'package:aspgen_mobile/Authentication/Menmberlogin.dart';
import 'package:aspgen_mobile/Authentication/NewLoginPage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../BottomBar/dashboard_nav.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/Utils.dart';
import '../../UtilMethods/base_client.dart';
import '../../flavors.dart';
import '../Model/AllClientInfoModel.dart';

class MemberLoginController extends GetxController{
  RxString path = "".obs;

  var allClientInfo=AllClientInfoModel().obs;
  @override
  void onInit() {

    getImageIcon();
    getAllClientInfo();
    // TODO: implement onInit
    super.onInit();
  }
  GetStorage storage=GetStorage();
 getCustomerInfo(String clientCode)async {
    var bodyJson = {
       "clientCode":clientCode
    };

    Get.context!.loaderOverlay.show();
    var response = await BaseClient().post(APIsConstant.getclientCodeInfo, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();

    print(response);
    if (response == null) return;
    if (jsonDecode(response)["statusCode"].toString() == "-1"){
      Get.snackbar("Alert!", jsonDecode(response)["message"].toString(),borderRadius: 2,icon: Icon(Icons.warning_amber),
          backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.amber,Colors.black12])
      );
    };
    storage.write(AppConstant.productId, jsonDecode(response)["data"][0]["productId"][0]["productId"].toString());
    storage.write(AppConstant.clientId, jsonDecode(response)["data"][0]["_id"].toString());
    Get.to(()=>NewLoginPage());
  }


//6306238262
 memberLogin(String mobile, String email)async {
   if(mobile.isEmpty && email.isEmpty)
   {
     Get.snackbar("Alert!", "Please Enter Email or Phone ",borderRadius: 2,icon: Icon(Icons.warning_amber),
         backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.amber,Colors.black12])
     );
     return;
   }
   var bodyJson = {
     "dataJson": {
       "email": email,
       "isMobile": mobile != "" ? true : false,
       "phone": mobile,
     },
     "componentConfig": {
       "productID": storage.read(AppConstant.productId),
       "clientID": storage.read(AppConstant.clientId),
       "moduleName": "Contacts"
     }
   };
   print("vhjxvhs");
   print(bodyJson);
   Get.context!.loaderOverlay.show();
   var response = await BaseClient().post(APIsConstant.memberLogin, bodyJson).catchError(BaseController().handleError);
   Get.context!.loaderOverlay.hide();
   print("shibsiukv");
   print(response);
   if (response == null) return;
   if (jsonDecode(response)["statusCode"].toString() == "-1"){
     Get.snackbar("Alert!", jsonDecode(response)["message"].toString(),borderRadius: 2,icon: Icon(Icons.warning_amber),
         backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.amber,Colors.black12])
     );
     return;
   }
   await AppConstant.sharedPreference.setString(AppConstant.token, json.decode(response)["data"][0]["token"]??"");
   await AppConstant.sharedPreference.setString(AppConstant.userEmail, json.decode(response)["data"][0]["email"]??"").toString();
   await AppConstant.sharedPreference.setString(AppConstant.userPhone, json.decode(response)["data"][0]["phone"]??"").toString();
   await AppConstant.sharedPreference.setString(AppConstant.memberId, json.decode(response)["data"][0]["_id"]??"").toString();
   await AppConstant.sharedPreference.setString(AppConstant.userName, json.decode(response)["data"][0]["refDataName"]??"").toString();
   await AppConstant.sharedPreference.setString(AppConstant.address, json.decode(response)["data"][0]["address"]??"").toString();
   await AppConstant.sharedPreference.setString(AppConstant.userName, json.decode(response)["data"][0]["refDataName"]??"").toString();
   storage.write(AppConstant.userName, json.decode(response)["data"][0]["refDataName"]??"");
   AppConstant.sharedPreference.setString(AppConstant.role, json.decode(response)["data"][0]["memberTypes"]??"").toString();
   await AppConstant.sharedPreference.setString(AppConstant.userAlldetails, json.encode(response)).toString();
   await  AppConstant.sharedPreference.setString(AppConstant.productId,storage.read(AppConstant.productId));
   await  AppConstant.sharedPreference.setString(AppConstant.clientId,storage.read(AppConstant.clientId));
   await AppConstant.sharedPreference.setBool(AppConstant.isVerify, true);
   await AppConstant.sharedPreference.setBool(AppConstant.isMember, true);
   Get.offAll(()=>DashboardNavBar());
 }


  getImageIcon() async {
    if (F.title == "Temple App") {
      path.value = "assets/images/templelogo.png";
    }
    else if (F.title == "Construction App") {
      path.value = "assets/images/constructionlogo.png";
    }
    else if (F.title == "Contractor App") {
      path.value = "assets/images/constructorlogo.png";
    } else if (F.title == "Sport App") {
      path.value = "assets/images/sportlogo.png";
    }
    else {
      path.value = "assets/images/templelogo.png";
    }

  }


  getAllClientInfo()async {
    var bodyJson =
      {"action": "get",
        "productId": [
          {
            "name": "TEMPLE",
            "productId": "62c807133d9ee4045ab78d4d"
          }
        ],
        "productName":[
          {
            "name": "TEMPLE",
            "productId": "62c807133d9ee4045ab78d4d"
          }
        ]


      };
    var response = await BaseClient().post(APIsConstant.clientinfo, bodyJson).catchError(BaseController().handleError);
    print(response);
    if (response == null) return;
    if (jsonDecode(response)["statusCode"].toString() == "-1"){
      Get.snackbar("Alert!", jsonDecode(response)["message"].toString(),borderRadius: 2,icon: Icon(Icons.warning_amber),
          backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.amber,Colors.black12])
      );
    };
    allClientInfo.value=allClientModelFromJson(response);
   print("jnvoshfvois");
   print(response);
  }
}