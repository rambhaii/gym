import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/Authentication/Model/UserDetailsData.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';

import '../../UtilMethods/Utils.dart';

class AuthController extends GetxController{
  TextEditingController etusername = new TextEditingController();
  TextEditingController etpassword = new TextEditingController();
  TextEditingController etrepassword = new TextEditingController();
  TextEditingController etZip = new TextEditingController();
  TextEditingController etfirstname = new TextEditingController();
  TextEditingController etlastname = new TextEditingController();
  TextEditingController etemail = new TextEditingController();
  TextEditingController etphone = new TextEditingController();
  TextEditingController etUserZip = new TextEditingController();
  TextEditingController etaddress = new TextEditingController();
  TextEditingController etcity = new TextEditingController();
  TextEditingController etstate = new TextEditingController();
  TextEditingController etPinPassword = new TextEditingController();

  final GlobalKey<ExpansionTileCardState> Group1Key = new GlobalKey();
  final GlobalKey<ExpansionTileCardState> Group2Key = new GlobalKey();
  final GlobalKey<ExpansionTileCardState> Group3Key = new GlobalKey();
  bool isExpanded1=false;
  bool isExpanded2=false;
  bool isExpanded3=false;
   final isReady=true.obs;
   final twoFactor=false.obs;
   final pageCount=0.obs;
   final notification=false.obs;
   final newsletters=false.obs;
   final pinPasword=false.obs;
   var userDetails=UserDetailsData().obs;

  RxList<Map> roleList= RxList<Map>();
  PageController pagecontroller = PageController(
    initialPage: 0,

  );

   changevalueTwofactorAut(bool val){

        twoFactor.value=val;
   }
   onPageViewChange(int page) {
      pageCount.value=page;
   }


   changevalueNotification(bool val){
     notification.value=val;
   }

   changevalueNewsLetters(bool val){
     newsletters.value=val;
   }

   changePinPassword(bool val){
     pinPasword.value=val;
   }
   @override
  void onInit() {
      getData();
      getRoleApi();
    super.onInit();
  }

  void getData() {
    AppConstant.sharedPreference.getString(AppConstant.userAlldetails)!=null?setData():"";
    update();
   }

  void setData() {
    userDetails.value=userDetailsDataFromJson(jsonDecode(AppConstant.sharedPreference.getString(AppConstant.userAlldetails).toString()));
    etusername.text=userDetails.value.user!.userName??"";
     etfirstname.text=userDetails.value.user!.firstName??"";
     etlastname.text=userDetails.value.user!.lastName??"";
     etemail.text=userDetails.value.user!.email??"";
     etphone.text=userDetails.value.user!.phone??"";
     etUserZip.text=userDetails.value.user!.zip??"";
     etaddress.text=userDetails.value.user!.address??"";
     etstate.text=userDetails.value.user!.state??"";
     etcity.text=userDetails.value.user!.city??"";
     twoFactor.value=userDetails.value.user!.userPrefrences!.twoFactorAuthentication!;
     notification.value=userDetails.value.user!.userPrefrences!.notification!;
     newsletters.value=userDetails.value.user!.userPrefrences!.newsletter!;
     pinPasword.value=userDetails.value.user!.userPrefrences!.pinPassword!;
     etPinPassword.text=userDetails.value.user!.userPrefrences!.pinPasswordCode!;
  }

  getRoleApi(){
    UtilMethods.getrole("62c807133d9ee4045ab78d4d").then((value) =>
    jsonDecode(value)["result"]["data"].forEach((element) {
      roleList.add({"id":element["_id"],"name":element["Role"]});
    })
    );
  }


}