import 'dart:convert';
import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/AppConstant/TextStyle.dart';
import 'package:aspgen_mobile/Authentication/new_registration.dart';
import 'package:aspgen_mobile/Dashboard/dashboard.dart';
import 'package:aspgen_mobile/Widget/primary_button.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../UtilMethods/GlobalApis.dart';
import '../UtilMethods/RemoteServices.dart';
import '../UtilMethods/Utils.dart';
class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool passwordVisible = false;
  bool loader = false;
  String path="";
  TextEditingController etuserName = new TextEditingController();
  TextEditingController etPasswordName = new TextEditingController();
  late SharedPreferences sp;

  @override
  void initState() {
    getImageIcon();
    CheckInternetConnection();
    // TODO: implement initState
    super.initState();

  }
  getImageIcon()async{
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    setState(() {
      if(packageInfo.appName=="Temple App")
      {
        path="assets/images/templelogo.png";
      }
      else  if(packageInfo.appName=="Construction App")
      {
        path="assets/images/constructionlogo.png";
      }
      else  if(packageInfo.appName=="Contractor App")
      {
        path="assets/images/constructorlogo.png";
      } else  if(packageInfo.appName=="Sport App")
      {
        path="assets/images/sportlogo.png";
      }
      else{
        path="assets/images/templelogo.png";
      }
    });

  }
  void togglePassword() {
    setState(() {
      passwordVisible = !passwordVisible;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
           padding: EdgeInsets.fromLTRB(10.0, 40.0, 10.0, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 10,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                       //AndroidInitializationSettings('@mipmap/ic_launcher');
                        Image.asset(
                          path,
                          width: 110,
                          height:110,
                        ),
                      ],
                    ),
                    SizedBox(height: 10,),
                    Center(
                      child: Text(
                        'Sign in',
                        style: heading7.copyWith(color: Theme.of(context).colorScheme.primary),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 48,
                ),
                Form(
                  child: AutofillGroup(
                    child: Column(
                      children: [
                        Container(
                          padding: EdgeInsets.only(left: 10,right: 10),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: AppColor.primaryBlue,
                            ),
                            borderRadius: BorderRadius.circular(14.0),
                          ),
                          child: TextFormField(
                            autofillHints: [AutofillHints.newUsername],
                           style: heading5.copyWith(color:  Theme.of(context).colorScheme.primary),
                            controller: etuserName,
                            decoration: InputDecoration(
                              hintText: 'Username',
                              hintStyle: heading5.copyWith(color:   Colors.grey),
                              border: OutlineInputBorder(
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 25,
                        ),
                        Container(
                          padding: EdgeInsets.only(left: 10),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: AppColor.primaryBlue,
                            ),
                            borderRadius: BorderRadius.circular(14.0),
                          ),
                          child: TextFormField(
                            style:heading5.copyWith(color:  Theme.of(context).colorScheme.primary),
                            obscureText: !passwordVisible,
                            controller: etPasswordName,
                            autofillHints: [AutofillHints.password],
                            decoration: InputDecoration(
                              hintText: 'Password',
                              hintStyle: heading5.copyWith(color: Colors.grey),
                              suffixIcon: IconButton(
                                color: Colors.grey,
                                splashRadius: 1,
                                icon: Icon(passwordVisible
                                    ? Icons.visibility_outlined
                                    : Icons.visibility_off_outlined),
                                onPressed: togglePassword,
                              ),
                              border: OutlineInputBorder(
                                borderSide: BorderSide.none,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                       // CustomCheckbox(),
                        SizedBox(
                          width: 12,
                        ),
                        Text('Remember me',
                            style: heading6.copyWith(color:  Theme.of(context).colorScheme.primary)),
                      ],
                    ),
                    TextButton(
                      onPressed: (){
                        // Navigator.push(
                        //     context,
                        //     MaterialPageRoute(
                        //         builder: (context) => ForgotPassword(title: "Forget password")));
                      },
                      child: Text(
                        "Forget password ?",
                        textAlign: TextAlign.right,
                        style: TextStyle(color: AppColor.primaryColor,fontSize: 15,
                          fontWeight: FontWeight.w600,),
                      ),
                    )
                  ],
                ),
                SizedBox(
                  height: 20,
                ),
                loader
                    ? Center(
                  child: CircularProgressIndicator(),
                )
                    :
                SizedBox(
                    height: 45,

                    child:CustomPrimaryButton(
                        buttonColor: AppColor.primaryColor,
                        textValue: 'Login',
                        textColor:  Theme.of(context).colorScheme.primary.withOpacity(0.8),
                        username: etuserName.text,
                        password: etPasswordName.text,
                        press: () {
                          if (etuserName.text != "" &&
                              etPasswordName.text != "blank") {
                            setState(() {
                              loader = true;
                            });
                            CheckInternetConnection().then((value) => value==true?signinApi(etuserName.text, etPasswordName.text, context):"");

                          } else {
                          
                          }
                        })),
                SizedBox(
                  height: 10,
                ),

                SizedBox(
                  height: 30,
                ),
                GestureDetector(
                  onTap: () {
                    // Navigator.push(context, MaterialPageRoute(builder: (context)=>BottomNavBar()));
                    // Navigator.canPop(context);
                  },
                  child: Center(
                    child:    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Don't have an account? ",
                          style: regular16pt.copyWith(color:Colors.grey),
                        ),
                        GestureDetector(
                          onTap: () {
                          },
                          child: InkWell(
                            onTap: (){
                              Get.to(()=>RegistrationPage(type: 1,));
                            },
                            child: Text(
                              'Register',
                              style: regular16pt.copyWith(color: AppColor.primaryBlue),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 30,
                ),
              ],
            ),
          ),
        ),
      ),
    );
    ;
  }

  void signinApi(
      String _username, String _password, BuildContext context) async {
    var urlLogin =
    Uri.parse(APIsConstant.Base_Url+'/user/services/productsignin');
    var url = Uri.parse(APIsConstant.Base_Url+'/user/services/findUserProductMobile');
    var response = await http.post(url, body: {
      'username': _username,
    });
    var res=jsonDecode(response.body);
    if (response.statusCode == 200) {
      print("jkkvbjk"+response.body);
      var responseLogin = await http.post(urlLogin, body: {
        'productName': json.decode(response.body)['productId'].toString(),
        'username': _username,
        'password': _password
      });
      print(responseLogin.body + _username + _password);
      if (responseLogin.statusCode == 200) {

      } else {
        setState(() {
          loader = false;
        });
        Fluttertoast.showToast(
            msg: "Invalid Credentials",
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.BOTTOM,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor:  Theme.of(context).colorScheme.primary,
            fontSize: 16.0);
      }
    }
  }

}
