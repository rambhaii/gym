import 'dart:convert';
import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/AppConstant/TextStyle.dart';
import 'package:aspgen_mobile/Authentication/new_registration.dart';
import 'package:aspgen_mobile/Dashboard/dashboard.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:aspgen_mobile/Widget/primary_button.dart';
import 'package:country_pickers/country.dart';
import 'package:country_pickers/country_picker_dropdown.dart';
import 'package:country_pickers/utils/utils.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';



import 'package:http/http.dart' as http;
import 'package:loader_overlay/loader_overlay.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../UtilMethods/GlobalApis.dart';
import '../UtilMethods/RemoteServices.dart';
import '../Widget/EditextWidget.dart';
import '../flavors.dart';
import 'Menmberlogin.dart';
import 'controller/memberLoginController.dart';
class NewLoginPage extends StatefulWidget {
  @override
  _NewLoginPageState createState() => _NewLoginPageState();
}

class _NewLoginPageState extends State<NewLoginPage> with SingleTickerProviderStateMixin {
  bool passwordVisible = false;
  bool loader = false;
  String path = "";
  String countryCode = "1";
  TextEditingController etuserName = new TextEditingController();
  TextEditingController etEmail = new TextEditingController();
  TextEditingController etPasswordName = new TextEditingController();
  TextEditingController etphone = new TextEditingController();
  late SharedPreferences sp;
  TabController  ?_tabController;
  MemberLoginController controller=Get.put(MemberLoginController());
  @override
  void initState() {
    getImageIcon();
    AppConstant.sharedPreference.clear();
    CheckInternetConnection();
    _tabController = TabController(length: 2,initialIndex: 0, vsync: this);
    // TODO: implement initState
    super.initState();
  }

  getImageIcon() async {
      if (F.title == "Temple App") {
        path = "assets/images/templelogo.png";
      }
      else if (F.title == "Construction App") {
        path = "assets/images/constructionlogo.png";
      }
      else if (F.title == "Contractor App") {
        path = "assets/images/constructorlogo.png";
      } else if (F.title == "Sport App") {
        path = "assets/images/sportlogo.png";
      }
      else {
        path = "assets/images/templelogo.png";
      }

  }

  void togglePassword() {
    setState(() {
      passwordVisible = !passwordVisible;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.fromLTRB(10.0, 30.0, 10.0, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        //AndroidInitializationSettings('@mipmap/ic_launcher');
                        Image.asset(
                          path,
                          width: 130,
                          height: 120,
                        ),
                      ],
                    ),

                    Center(
                      child: Text(
                        'Sign in',
                        style: heading7.copyWith(color: Theme
                            .of(context)
                            .colorScheme
                            .primary),
                      ),
                    ),
                  ],
                ),
                SizedBox(
                  height: 38,
                ),
                Container(
                  height: 40,
                  child: TabBar(
                      controller: _tabController,
                    indicator: BoxDecoration(
                      color: Colors.teal,

                        ),
                    labelStyle: const TextStyle(fontWeight: FontWeight.bold),
                    unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600,),
                    tabs: [
                      Tab(child:Text("ADMINISTRATOR")),
                      Tab(child:Text("DEVOTEE/PRIEST")),
                    ]
                  ),
                ),
                Container(
                  width: Get.width,
                  height: 260,
                  padding: EdgeInsets.only(left: 8,right: 8),
                  decoration: BoxDecoration(
                    border: Border.all(color:Colors.teal,width: 1)
                  ),
                  alignment: Alignment.center,
                  child: TabBarView(
                      controller: _tabController,
                      children:[
                        adminLogin(),
                        devoteeLogin(),
                      ]
                  ),
                ),
                loader
                    ? Center(
                  child: CircularProgressIndicator(),
                )
                    :
                Container(
                    height: 45,
                    margin: EdgeInsets.only(left:5 ,right: 5,top: 25),
                    child: CustomPrimaryButton(
                        buttonColor: AppColor.primaryColor,
                        textValue: 'Login',
                        textColor: Theme
                            .of(context)
                            .colorScheme
                            .primary
                            .withOpacity(0.9),
                        username: etuserName.text,
                        password: etPasswordName.text,
                        press: () {
                          CheckInternetConnection().then((value) =>
                          value == true
                              ?
                          _tabController!.index==0? signinApi(etuserName.text, etPasswordName.text, context):controller.memberLogin(etphone.text,etEmail.text)
                              : "");
                        }
                    )),


                SizedBox(
                  height: 30,
                ),
                GestureDetector(
                  onTap: () {
                    // Navigator.push(context, MaterialPageRoute(builder: (context)=>BottomNavBar()));
                    // Navigator.canPop(context);
                  },
                  child: Center(
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          "Don't have an account? ",
                          style: regular16pt.copyWith(color: Colors.grey),
                        ),
                        GestureDetector(
                          onTap: () {},
                          child: InkWell(
                            onTap: () {
                              Get.to(() => RegistrationPage(type: 1,));
                            },
                            child: Text(
                              'Register',
                              style: regular16pt.copyWith(
                                  color: AppColor.primaryBlue),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),

                SizedBox(
                  height: 30,
                ),
              ],
            ),
          ),
        ),
      ),
    );
    }
  Widget adminLogin(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AutofillGroup(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(left:5 ,right: 5),
                padding: EdgeInsets.only(left: 10, right: 10),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: AppColor.primaryBlue,
                  ),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: TextFormField(

                  autofillHints: [AutofillHints.newUsername],
                  onChanged: (value){
                    etphone.clear();
                  },

                  style: heading5.copyWith(color: Theme
                      .of(context)
                      .colorScheme
                      .primary),
                  controller: etuserName,
                  decoration: InputDecoration(
                    contentPadding:
                    EdgeInsets.only(left: 2, bottom: 17, top: 17, right: 2),
                    hintText: 'Username',
                    hintStyle: heading5.copyWith(color: Colors.grey),
                    border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 25,
              ),
              Container(
                margin: EdgeInsets.only(left:5 ,right: 5),
                padding: EdgeInsets.only(left: 10,right: 10),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: AppColor.primaryBlue,
                  ),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: TextFormField(
                  style: heading5.copyWith(color: Theme
                      .of(context)
                      .colorScheme
                      .primary),
                  onChanged: (value){
                    etphone.clear();
                  },
                  obscureText: !passwordVisible,
                  controller: etPasswordName,
                  autofillHints: [AutofillHints.password],
                  decoration: InputDecoration(
                    contentPadding:
                    EdgeInsets.only(left: 2, bottom: 17, top: 17, right: 2),
                    hintText: 'Password',
                    hintStyle: heading5.copyWith(color: Colors.grey),
                    suffixIcon: IconButton(
                      color: Colors.grey,
                      splashRadius: 1,
                      icon: Icon(passwordVisible
                          ? Icons.visibility_outlined
                          : Icons.visibility_off_outlined),
                      onPressed: togglePassword,
                    ),
                    border: OutlineInputBorder(
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 15,
              ),

            ],
          ),
        ),

        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            TextButton(
              onPressed: () {
                show_dailog_UserName();
              },
              child: Text(
                "Forget Username ?",
                textAlign: TextAlign.right,
                style: TextStyle(
                  color: AppColor.primaryColor, fontSize: 15,
                  fontWeight: FontWeight.w600,),
              ),
            ),
            TextButton(
              onPressed: () {
                show_dailog();
              },
              child: Text(
                "Forget password ?",
                textAlign: TextAlign.right,
                style: TextStyle(
                  color: AppColor.primaryColor, fontSize: 15,
                  fontWeight: FontWeight.w600,),
              ),
            )
          ],
        ),

      ],
    );
  }
  Widget devoteeLogin(){
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        AutofillGroup(
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(left:5 ,right: 5),
                padding: EdgeInsets.only(left: 10, right: 10),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: AppColor.primaryBlue,
                  ),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: TextFormField(
                  autofillHints: [AutofillHints.newUsername],
                  onChanged: (value){
                    etphone.clear();
                  }, style: heading5.copyWith(color: Theme.of(context).colorScheme.primary),
                  controller: etEmail,
                  decoration: InputDecoration(
                    contentPadding:
                    EdgeInsets.only(left: 2, bottom: 17, top: 17, right: 2),
                    hintText: 'Email Id',
                    hintStyle: heading5.copyWith(color: Colors.grey),
                    border: OutlineInputBorder(borderSide: BorderSide.none,),),),),
              SizedBox(
                height: 15,
              ),

              Text(" ------ OR ------ "),

              SizedBox(
                height: 15,
              ),


              Container(
                margin: EdgeInsets.only(left:5 ,right: 5),
                padding: EdgeInsets.only(left: 10,right: 10),
                decoration: BoxDecoration(
                  border: Border.all(
                    color: AppColor.primaryBlue,
                  ),
                  borderRadius: BorderRadius.circular(5.0),
                ),
                child: Row(
                  children: [
                    SizedBox(
                      width: MediaQuery
                          .of(context)
                          .size
                          .width * 0.3,
                      child: CountryPickerDropdown(
                        initialValue: 'US',
                        itemBuilder: _buildDropdownItem,
                        itemFilter: (c) =>
                            [
                              'US',
                              'IN',
                              'UK',
                              'CN',
                              'AU',
                              'UK',
                              "CA"
                            ].contains(c.isoCode),
                        dropdownColor: Theme.of(context).colorScheme.secondary,
                        priorityList: [
                          CountryPickerUtils.getCountryByIsoCode(
                              'US'),
                          CountryPickerUtils.getCountryByIsoCode(
                              'IN'),
                        ],
                        sortComparator: (Country a, Country b) =>
                            a.isoCode.compareTo(b.isoCode),
                        onValuePicked: (Country country) {
                          setState(() {
                            countryCode = country.phoneCode;
                          });
                          print("${country.phoneCode}");
                        },
                      ),
                    ),
                    Expanded(
                        child: SizedBox(
                            width:
                            MediaQuery
                                .of(context)
                                .size
                                .width / 3,
                            child: TextFormField(
                              inputFormatters: [maskFormatter],
                              style: heading5.copyWith(color: Theme
                                  .of(context)
                                  .colorScheme
                                  .primary),
                              onChanged: (value){
                                etuserName.clear();
                                etPasswordName.clear();
                              },
                              controller: etphone,
                              decoration: InputDecoration(
                                contentPadding:
                                EdgeInsets.only(left: 2, bottom: 17, top: 17, right: 2),
                                hintText: 'Mobile No',
                                hintStyle: heading5.copyWith(
                                    color: Colors.grey),
                                suffixIcon: IconButton(
                                  onPressed: () =>
                                      etPasswordName.clear(),
                                  icon: Icon(Icons.clear),
                                ),
                                border: OutlineInputBorder(
                                  borderSide: BorderSide.none,
                                ),
                              ),
                            ))),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
  var maskFormatter = new MaskTextInputFormatter(
      mask: '(###) ###-####',
      filter: {"#": RegExp(r'[0-9]')},
      type: MaskAutoCompletionType.lazy);

  Widget _buildDropdownItem(Country country) =>
      Container(

        child: Row(
          children: <Widget>[
            CountryPickerUtils.getDefaultFlagImage(country),
            SizedBox(
              width: 8.0,
            ),
            Text(
              "+${country.phoneCode}(${country.isoCode})",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12,
              ),
            ),
          ],
        ),
      );

  void signinApi(String _username, String _password, BuildContext context) async {

    if (etphone.text.isEmpty && etuserName.text.isNotEmpty && etPasswordName.text.isNotEmpty) {
      // DeterminePosition().then((value)async{
        String? token = await FirebaseMessaging.instance.getToken();
        String latlong=""+","+"";
        UtilMethods.SignIn(context, _username, _password,"phone",false,token!, latlong);
      // });

    }
    else if(etphone.text.isNotEmpty && etuserName.text.isEmpty && etPasswordName.text.isEmpty) {
      context.loaderOverlay.show();
      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber:"+"+countryCode+maskFormatter.getUnmaskedText(),
        timeout: Duration(seconds: 60),
        verificationCompleted: (PhoneAuthCredential credential) async {
          await FirebaseAuth.instance.signInWithCredential(credential);
        },
        verificationFailed: (FirebaseAuthException e) {
          context.loaderOverlay.hide();
          if (e.code == 'invalid-phone-number') {
            Fluttertoast.showToast(msg: "The provided phone number is not valid.",backgroundColor: Colors.red);
            print('The provided phone number is not valid.');
          }
          print(e.message);
        },
        codeSent: (String verificationId, int? resendToken) {
          context.loaderOverlay.hide();
          print(resendToken);
          Get.to(() => OtpVerification(VerificationId:verificationId ,MobileNo: "+"+countryCode+maskFormatter.getUnmaskedText(),onlyMobile:maskFormatter.getUnmaskedText() ,));
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          context.loaderOverlay.hide();
          print(verificationId);
        },);
    }
    else if( etuserName.text.isEmpty && etPasswordName.text.isEmpty)
          {
            Fluttertoast.showToast(msg: "Please Enter Userame And Password");
          }
    else if( etuserName.text.isEmpty )
          {
            Fluttertoast.showToast(msg: "Please Enter Userame ");
          }
    else if( etPasswordName.text.isEmpty )
        {
          Fluttertoast.showToast(msg: "Please Enter Password ");
        }
    else
        {
          Fluttertoast.showToast(msg: "Please Enter Field ");
        }
  }
  void show_dailog()
  {
    final _formKey = GlobalKey<FormState>();
    TextEditingController etUserName= TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
            builder: (context, setState) {
              return  WillPopScope(
                onWillPop:() async{
                  return false;
                },
                child: AlertDialog(
                  contentPadding: EdgeInsets.zero,
                  backgroundColor:Theme.of(context).colorScheme.onPrimaryContainer,
                  content: Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          height: 50,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.teal,
                                  Colors.teal.withOpacity(0.7),

                                ],
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                //stops: [1.0,1.0,],
                                tileMode: TileMode.clamp,
                              )),

                          child:Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Filtersss",style: TextStyle(color: Colors.transparent),),
                              Text("Forgot Password ",style: TextStyle(color: Colors.white,fontSize: 20),),
                              IconButton(onPressed: (){
                                Navigator.pop(context);
                              },icon: Icon(Icons.clear),color: Colors.white,)

                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: EdgeInsets.all(10),
                          child: Column(

                            children: [
                              Form(
                                key: _formKey,
                                child: EditTextWidget(
                                  label: "Username",
                                  controller: etUserName,
                                  onchanged:( (value){

                                  }),
                                  hint: 'Enter User Name',
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Username';
                                    }
                                    return null;
                                  },
                                  maxLength: 90,
                                  keyboardtype: TextInputType.text,
                                  isPassword: false,
                                ),
                              ),
                              SizedBox(height: 5,),

                              SizedBox(height: 10,),
                              ElevatedButton(onPressed: (){
                                if(_formKey.currentState!.validate())
                                  {
                                    UtilMethods.forgotPass(context, etUserName.text).then((value) {

                                      if(jsonDecode(value)["user"]["statusCode"]==1)
                                      {
                                        Fluttertoast.showToast(msg: jsonDecode(value)["user"]["message"],toastLength: Toast.LENGTH_LONG);
                                        Navigator.pop(context);
                                      }
                                      else{
                                        Fluttertoast.showToast(msg: jsonDecode(value)["user"]["message"],toastLength: Toast.LENGTH_LONG);
                                      }
                                    });
                                  }

                              },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal
                                )
                                ,child: Text("Submit",style: TextStyle( fontSize: 16,color: Colors.white),),


                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                ),
              );
            }
        );
      },
    );
  }
  void show_dailog_UserName()
  {
    final _formKey = GlobalKey<FormState>();
    TextEditingController etUserName= TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
            builder: (context, setState) {
              return  WillPopScope(
                onWillPop:() async{
                  return false;
                },
                child: AlertDialog(
                  contentPadding: EdgeInsets.zero,
                  backgroundColor:Theme.of(context).colorScheme.onPrimaryContainer,
                  content: Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          height: 50,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.teal,
                                  Colors.teal.withOpacity(0.7),

                                ],
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                //stops: [1.0,1.0,],
                                tileMode: TileMode.clamp,
                              )),

                          child:Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Filtersss",style: TextStyle(color: Colors.transparent),),
                              Text("Forgot Username ",style: TextStyle(color: Colors.white,fontSize: 20),),
                              IconButton(onPressed: (){
                                Navigator.pop(context);
                              },icon: Icon(Icons.clear),color: Colors.white,)

                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: EdgeInsets.all(10),
                          child: Column(

                            children: [
                              Form(
                                key: _formKey,
                                child: EditTextWidget(
                                  label: "Emial Id",
                                  controller: etUserName,
                                  onchanged:( (value){

                                  }),
                                  hint: 'Enter Email Id',
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please Enter Email Id';
                                    }
                                    if(!isValidEmail(value))
                                    {
                                      return 'Please Enter Valid Email';
                                    }
                                    return null;
                                  },
                                  maxLength: 90,
                                  keyboardtype: TextInputType.text,
                                  isPassword: false,
                                ),
                              ),
                              SizedBox(height: 5,),

                              SizedBox(height: 10,),
                              ElevatedButton(onPressed: (){

                                if(_formKey.currentState!.validate())
                                {
                                  UtilMethods.forgotUsername(context, etUserName.text).then((value) {

                                    if(jsonDecode(value)["user"]["statusCode"]==1)
                                    {
                                      Fluttertoast.showToast(msg: jsonDecode(value)["user"]["message"],toastLength: Toast.LENGTH_LONG);
                                      Navigator.pop(context);
                                    }
                                    else{
                                      Fluttertoast.showToast(msg: jsonDecode(value)["user"]["message"],toastLength: Toast.LENGTH_LONG);

                                    }
                                  });
                                }

                              },
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal
                                  )
                                ,child: Text("Submit",style: TextStyle( fontSize: 16,color: Colors.white),),


                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                ),
              );
            }
        );
      },
    );
  }
}
class OtpVerification extends StatefulWidget {
  final String VerificationId;
  final String MobileNo;
  final String onlyMobile;
   OtpVerification({Key? key, required this.VerificationId, required this.MobileNo, required this.onlyMobile}) : super(key: key);

  @override
  State<OtpVerification> createState() => _OtpVerificationState();
}

class _OtpVerificationState extends State<OtpVerification> {

  final _formKey = GlobalKey<FormState>();
  int _time = 60;
  String otp = "";
  String time = "00";
  bool resend = false;

  Future<void> startTime() async {
    if (_time >= 0) {
      resend = false;
      await Future.delayed(Duration(seconds: 1));
      setState(() {
        time = _time.toString();
      });
      _time--;
      startTime();
    }else{
      setState(() {
        resend = true;
      });
    }
  }
  @override
  void initState() {

    print(widget.onlyMobile.toString());
    startTime();
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    print("sdvbsvjsjk");
    return Scaffold(
      appBar: AppBar(title: Text("Verification") ,),
      body:Stack(
        children: [
          SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Center(
                child: Column(
                  children: [
                    SizedBox(
                      height: 20.0,
                    ),
                    Text( "You will get SMS with a confirmation\ncode to this number (${widget.MobileNo})",textAlign: TextAlign.center,style: Theme.of(context).textTheme.bodyText2!.copyWith(color: Colors.white),),
                    SizedBox(
                      height: 25.0,
                    ),
                    Text("Please input code below"),
                    Padding(
                      padding: const EdgeInsets.symmetric(
                          vertical: 40.0, horizontal: 35.0),
                      child: PinCodeTextField(
                        appContext: context,
                        length: 6,
                        validator: (value) {
                          if (value!.isEmpty || value.length < 6) {
                            return "Please Enter OTP";
                          }
                          return null;
                        },
                        onChanged: (value) {
                          otp = value;
                        },
                        keyboardType: TextInputType.number,
                        obscureText: false,
                        pinTheme: PinTheme(
                          inactiveColor: Colors.teal,
                          selectedColor: Colors.white70,
                          shape: PinCodeFieldShape.box,
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                      ),
                    ),
                    Text(time),
                    SizedBox(
                      height: 16.0,
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                      onPressed: (){

                        CheckInternetConnection().then((value) {
                              if(value==true)
                              {
                                signIn(otp);
                                // verifyOTP(context);
                              }
                            });
                        }
                      ,child: Text("Verify",style: TextStyle( fontSize: 16,color: Colors.white),),


                    ),

                    SizedBox(
                      height: 20.0,
                    ),
                    resend ? InkWell(onTap: () {
                      _time=120;
                      startTime();
                    }, child: Text("Resend Code",style: TextStyle(color:Colors.blue,fontWeight: FontWeight.bold,fontSize: 12),)) : Container(),
                  ],
                ),
              ),
            ),
          ),
        ],
      ) ,
    );
  }
  Future<void> signIn(String otp) async {
    context.loaderOverlay.show();
    FirebaseAuth auth =await FirebaseAuth.instance;
    PhoneAuthCredential credential =await PhoneAuthProvider.credential(verificationId: widget.VerificationId, smsCode: otp);
    try{
      context.loaderOverlay.hide();
        var authentication=await auth.signInWithCredential(credential);
        if(authentication!=null)
          {
            // DeterminePosition().then((value) async {
              String? token = await FirebaseMessaging.instance.getToken();
              String latlong=""+","+"";
              UtilMethods.SignIn(context, "_username", "_password",widget.onlyMobile,true,token!,latlong);
           // });

          }
        else
          {
            Fluttertoast.showToast(msg:"Wrong OTP");
          }
       }
    catch (e)
    {
      context.loaderOverlay.show();
      print(e.toString());

    }


  }



}
