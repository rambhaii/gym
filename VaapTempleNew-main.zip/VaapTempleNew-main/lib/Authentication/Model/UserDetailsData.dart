// To parse this JSON data, do
//
//     final userDetailsData = userDetailsDataFromJson(jsonString);

import 'dart:convert';

UserDetailsData userDetailsDataFromJson(String str) => UserDetailsData.fromJson(json.decode(str));

String userDetailsDataToJson(UserDetailsData data) => json.encode(data.toJson());

class UserDetailsData {
  UserDetailsData({
    this.user,
    this.token,
  });

  User? user;
  String ?token;

  factory UserDetailsData.fromJson(Map<String, dynamic> json) => UserDetailsData(
    user: User.fromJson(json["user"]??{}),
    token: json["token"],
  );

  Map<String, dynamic> toJson() => {
    "user": user!.toJson(),
    "token": token,
  };
}

class User {
  User({
    this.id,
    this.firstName,
    this.lastName,
    this.userName,
    this.email,
    this.phone,
    this.address,
    this.city,
    this.state,
    this.zip,
    this.organization,
    this.clientId,
    this.role,
    this.roleId,
    this.productName,
    this.productId,
    this.newUser,
    this.status,
    this.userPrefrences,

  });

  String ?id;
  String ?firstName;
  String ?lastName;
  String ?userName;
  String ?email;
  String ?phone;
  String ?address;
  String ?city;
  String ?state;
  String? zip;
  String ?organization;
  String? clientId;
  String ?role;
  String ?roleId;
  String ?productName;
  String ?productId;
  bool ?newUser;
  bool ?status;
  UserPrefrences? userPrefrences;


  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json["_id"]??"",
    firstName: json["firstName"]??"",
    lastName: json["lastName"]??"",
    userName: json["userName"]??"",
    email: json["email"]??"",
    phone: json["phone"]??"",
    address: json["address"]??"",
    city: json["city"]??"",
    state: json["state"]??"",
    zip: json["zip"]??"",
    organization: json["organization"]??"",
    clientId: json["clientId"]??"",
    role: json["role"]??"",
    roleId: json["roleId"]??"",
    productName: json["productName"]??"",
    productId: json["productId"]??"",
    newUser: json["newUser"]??"",
    status: json["status"]??"",
    userPrefrences: UserPrefrences.fromJson(json["userPrefrences"]??[]),

  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "firstName": firstName,
    "lastName": lastName,
    "userName": userName,
    "email": email,
    "phone": phone,
    "address": address,
    "city": city,
    "state": state,
    "zip": zip,
    "organization": organization,
    "clientId": clientId,
    "role": role,
    "roleId": roleId,
    "productName": productName,
    "productId": productId,
    "newUser": newUser,
    "status": status,
    "userPrefrences": userPrefrences!.toJson(),

  };
}

class UserPrefrences {
  UserPrefrences({
    this.twoFactorAuthentication,
    this.notification,
    this.newsletter,
    this.pinPassword,
    this.pinPasswordCode,
  });

  bool ?twoFactorAuthentication;
  bool ?notification;
  bool ?newsletter;
  bool ?pinPassword;
  String? pinPasswordCode;

  factory UserPrefrences.fromJson(Map<String, dynamic> json) => UserPrefrences(
    twoFactorAuthentication: json["twoFactorAuthentication"]??false,
    notification: json["notification"]??false,
    newsletter: json["newsletter"]??false,
    pinPassword: json["pinPassword"]??false,
    pinPasswordCode: json["pinPasswordCode"]??"",
  );

  Map<String, dynamic> toJson() => {
    "twoFactorAuthentication": twoFactorAuthentication,
    "notification": notification,
    "newsletter": newsletter,
    "pinPassword": pinPassword,
    "pinPasswordCode": pinPasswordCode,
  };
}
