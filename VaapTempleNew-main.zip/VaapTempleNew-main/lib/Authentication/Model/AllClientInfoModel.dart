// To parse this JSON data, do
//
//     final clientModel = clientModelFromJson(jsonString);

import 'dart:convert';

AllClientInfoModel allClientModelFromJson(String str) => AllClientInfoModel.fromJson(json.decode(str));

String allClientModelToJson(AllClientInfoModel data) => json.encode(data.toJson());

class AllClientInfoModel {
  AllClientInfoModel({
    this.result,
  });

  Result ?result;

  factory AllClientInfoModel.fromJson(Map<String, dynamic> json) => AllClientInfoModel(
    result: Result.fromJson(json["result"]),
  );

  Map<String, dynamic> toJson() => {
    "result": result!.toJson(),
  };
}

class Result {
  Result({
    this.statusCode,
    this.message,
    this.data,
  });

  int? statusCode;
  String? message;
  List<Datum> ?data;

  factory Result.fromJson(Map<String, dynamic> json) => Result(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.productId,
    this.productName,
    this.parentClient,
    this.clientCode,
    this.clientName,
    this.clientPhone,
    this.clientEmail,
    this.clientWebsite,
    this.clientTaxId,
    this.clientOwnerInfo,
    this.addressLineOne,
    this.addressLinetwo,
    this.state,
    this.city,
    this.zipCode,
    this.callbackUrl,
    this.clientLogoPath,
    this.bannerImg,
    this.businessDomain,
    this.unitType,
    this.description,
    this.aspectSource,
    this.aspectType,
    this.recCreBy,
    this.recModBy,
    this.recCreDate,
    this.recModDate,
    this.clientDb,
  });

  String? id;
  List<Product>? productId;
  List<Product>? productName;
  String? parentClient;
  String? clientCode;
  String? clientName;
  String? clientPhone;
  String? clientEmail;
  String? clientWebsite;
  String? clientTaxId;
  ClientOwnerInfo ?clientOwnerInfo;
  String? addressLineOne;
  String? addressLinetwo;
  String? state;
  String? city;
  String? zipCode;
  String? callbackUrl;
  String? clientLogoPath;
  String? bannerImg;
  String? businessDomain;
  String ?unitType;
  String ?description;
  String ?aspectSource;
  String ?aspectType;
  String ?recCreBy;
  String ?recModBy;
  String ?recCreDate;
  String?recModDate;
  String? clientDb;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"],
    productId: List<Product>.from((json["productId"]??[]).map((x) => Product.fromJson(x))),
    productName: List<Product>.from((json["productName"]??"").map((x) => Product.fromJson(x))),
    parentClient: json["parentClient"]??"",
    clientCode: json["clientCode"]??"",
    clientName: json["clientName"]??"",
    clientPhone: json["clientPhone"]??"",
    clientEmail: json["clientEmail"]??"",
    clientWebsite: json["clientWebsite"]??"",
    clientTaxId: json["clientTaxID"]??"",
    clientOwnerInfo: ClientOwnerInfo.fromJson(json["clientOwnerInfo"]??[]),
    addressLineOne: json["addressLineOne"]??"",
    addressLinetwo: json["addressLinetwo"]??"",
    state: json["state"]??"",
    city: json["city"]??"",
    zipCode: json["zipCode"]??"",
    callbackUrl: json["callbackURL"]??"",
    clientLogoPath: json["clientLogoPath"]??"",
    bannerImg: json["bannerImg"]??"",
    businessDomain: json["businessDomain"]??"",
    unitType: json["unitType"]??"",
    description: json["Description"]??"",
    aspectSource: json["aspectSource"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recModBy: json["recModBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModDate: json["recModDate"]??"",
    clientDb: json["clientDB"]??"",


  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "productId": List<dynamic>.from(productId!.map((x) => x.toJson())),
    "productName": List<dynamic>.from(productName!.map((x) => x.toJson())),
    "parentClient": parentClient,
    "clientCode": clientCode,
    "clientName": clientName,
    "clientPhone": clientPhone,
    "clientEmail": clientEmail,
    "clientWebsite": clientWebsite,
    "clientTaxID": clientTaxId,
    "clientOwnerInfo": clientOwnerInfo!.toJson(),
    "addressLineOne": addressLineOne,
    "addressLinetwo": addressLinetwo,
    "state": state,
    "city": city,
    "zipCode": zipCode,
    "callbackURL": callbackUrl,
    "clientLogoPath": clientLogoPath,
    "bannerImg": bannerImg,
    "businessDomain": businessDomain,
    "unitType": unitType,
    "Description": description,
    "aspectSource": aspectSource,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recModBy": recModBy,
    "recCreDate": recCreDate,
    "recModDate": recModDate,
    "clientDB": clientDb,

  };
}

class ClientOwnerInfo {
  ClientOwnerInfo({
    this.name,
    this.email,
    this.primaryPhone,
    this.secondryPhone,
    this.state,
    this.city,
    this.zip,
    this.address,
  });

  String ?name;
  String ?email;
  String ?primaryPhone;
  String ?secondryPhone;
  String ?state;
  String ?city;
  String ?zip;
  String ?address;

  factory ClientOwnerInfo.fromJson(Map<String, dynamic> json) => ClientOwnerInfo(
    name: json["name"],
    email: json["email"],
    primaryPhone: json["primaryPhone"],
    secondryPhone: json["secondryPhone"],
    state: json["state"],
    city: json["city"],
    zip: json["zip"],
    address: json["address"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "email": email,
    "primaryPhone": primaryPhone,
    "secondryPhone": secondryPhone,
    "state": state,
    "city": city,
    "zip": zip,
    "address": address,
  };
}

class Product {
  Product({
    this.name,
    this.productId,
  });

  var name;
  var productId;

  factory Product.fromJson(Map<String, dynamic> json) => Product(
    name: json["name"],
    productId: json["productId"],
  );

  Map<String, dynamic> toJson() => {
    "name":name,
    "productId": productId,
  };
}





