import 'dart:io';

import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/main.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flavors.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  AppConstant.sharedPreference=await SharedPreferences.getInstance();
  HttpOverrides.global = MyHttpOverrides();
  F.appFlavor = Flavor.SPORT;
  runApp(MyApp());
}
