import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/Dashboard/Catering/catering_page.dart';
import 'package:aspgen_mobile/Dashboard/Inquiry/view/InquiryCategory.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_remote_config/firebase_remote_config.dart';

import 'package:get_storage/get_storage.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../Analytics/view/AnalyticCategory.dart';
import '../../AppConfig/AppConfig.dart';
import '../../AppConstant/APIsConstant.dart';
import '../../Comunication/View/ComunicationPage.dart';
import '../../ConstructionModule/ProjectProfile/ProjectDetailsPage.dart';
import '../../ConstructionModule/projectPage.dart';
import '../../Notification/RecievedNotification/recieve_notification.dart';
import '../../Notification/page/NotificationPage.dart';
import '../../PriestDashboard/LeaveForm/view/leave_form.dart';
import '../../PriestDashboard/LeaveForm/view/leave_list.dart';
import '../../PriestDashboard/PoojaList/view/pooja_list.dart';
import '../../PriestDashboard/PriestAssignments/view/priest_assignment.dart';
import '../../PriestDashboard/Request/select_request_event.dart';
import '../../PriestDashboard/TimeCard/view/head_priest.dart';
import '../../PriestDashboard/TimeCard/view/timecard.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/Utils.dart';
import '../../UtilMethods/base_client.dart';
import '../../calendar/Booking/BookingCalender.dart';
import '../../calendar/PriestCalendar/PriestCalendar.dart';
import '../../calendar/calendar.dart';
import '../AssetsManagemant/assets_page.dart';
import '../Bookings/BookingPage.dart';
import '../Bookings/CampingPage.dart';
import '../Bookings/RentalPage.dart';
import '../Contact/ContactPage.dart';

import '../DailyMenu/prasadam_view.dart';
import '../DailyMenu/today_menu_page.dart';
import '../Devotee/DevoteePage.dart';
import '../Documents/document_page.dart';
import '../Expanses/expenses_page.dart';
import '../Inquiry/view/PaymentInqirey.dart';
import '../Inquiry/view/Booking_history.dart';
import '../Inquiry/view/rental_page.dart';
import '../Menu/Menu.dart';
import '../Model/DashGroupDataTitle.dart';
import '../Model/DashboardSubTitleData.dart';
import '../ProfilePage.dart';
import '../Purchase/purchase_page.dart';
import '../Request/view/select_request_event.dart';
import '../Services/View/ServiceCategoryTypePage.dart';
import '../inventory_page/InventoryList.dart';
import '../kitchen_orders.dart';

class DashboardController  extends GetxController
{
  GlobalKey<ExpansionTileCardState> groupkey=GlobalKey<ExpansionTileCardState>();
  GetStorage storage=GetStorage();
    final menuItemData= DashboardGroupTitleData().obs;
    RxList<GroupDatum> groupList= RxList();
    final dashboardSubTitleData= DashboardSubTitleData().obs;
    RxInt position=0.obs;
    var  request;
    var  request2;

    @override
  void onInit() {
      print("zdjvjhsv");
      print(AppConstant.sharedPreference.getString('role').toString());

      cacheData();
     setupRemoteConfig();
      request= {"componentConfig":
            {
            "moduleName": "Master Data Management",
            "aspectType": "mobileDashboardGroup",
            "productID": storage.read(AppConstant.productId),
            "clientID":  storage.read(AppConstant.clientId),
            "userName":  storage.read(AppConstant.userName),
            "query" :{"aspectType": "mobileDashboardGroup"},
            "skip": 0,
            "next": 500
             }
          };
      request2= {"componentConfig":
      {
        "moduleName": "Mobile Dashboard",
        "aspectType": "Mobile Dashboard",
        "productID": storage.read(AppConstant.productId),
        "clientID":  storage.read(AppConstant.clientId),
        "userName":  storage.read(AppConstant.userName),
        "query" :{"aspectType": "Mobile Dashboard"},
        "skip": 0,
        "next": 500
      }
      };
     getData();

    // TODO: implement onInit
    super.onInit();
  }

   getData()async{
     print("cdbhjdsbcds");
     print(request);
     var response=await BaseClient().post(APIsConstant.filterAPI, request).catchError(BaseController().handleError);
     Get.context!.loaderOverlay.hide();
     print("cdbhjdsbcds");
     print(response);
     if(response==null) return;
     if(jsonDecode(response)["statusCode"].toString()=="-1") return;
     else{
       groupList.value.clear();
       menuItemData.value=DashboardGroupTitleData.fromJson(jsonDecode(response));
       menuItemData.value.data!.forEach((element) {
         if(element.role!.contains(AppConstant.sharedPreference.getString('role').toString()))
         {
           groupList.value.add(element);
         }
       });
       storage.write("dashTitle", menuItemData.value);
       getSubData();
     }

   }
    getSubData()async{
      print("dvdvfdvd");
      print(request2);
      var response=await BaseClient().post(APIsConstant.filterAPI, request2).catchError(BaseController().handleError);
      Get.context!.loaderOverlay.hide();
      if(response==null) return;
      print("dvdvfdvd");
      print(response);
      if(jsonDecode(response)["statusCode"].toString()=="-1") return;
      dashboardSubTitleData.value.data=dashboardSubTitleDataFromJson(response).data;
      storage.write("dashSubTitle",response.toString());
      groupList.value.forEach((element1) {
        dashboardSubTitleData.value.data![0].childGrid!.forEach((element2) {
          if(element1.refDataName!.toLowerCase().trim()==element2.groupName!.toLowerCase().trim().toString() && element2.status=="ACTIVE")
          {
            element1.childGrid!.add(element2);
          }
        });
      });
      update();
    }
    cacheData(){
      if(storage.read("dashTitle")!=null &&storage.read("dashSubTitle")!=null){
         menuItemData.value.data=DashboardGroupTitleData.fromJson(jsonDecode(jsonEncode(storage.read("dashTitle")))).data!;
         menuItemData.value.data!.forEach((element) {
           if(element.role!.contains(AppConstant.sharedPreference.getString('role').toString()))
           {
             groupList.value.add(element);
           }
         });
        dashboardSubTitleData.value.data=dashboardSubTitleDataFromJson(storage.read("dashSubTitle")).data;
        groupList.value.forEach((element1) {
          dashboardSubTitleData.value.data![0].childGrid!.forEach((element2) {
            if(element1.refDataName!.toLowerCase().trim()==element2.groupName!.toLowerCase().trim().toString() &&   element2.status=="ACTIVE"
            )
            {
              element1.childGrid!.add(element2);
            }
          });
        });
        update();
      }
    }
    getRoute(String moduleName,String displayName){
      print("sjdbvjhds");
      print(moduleName);
      print(displayName);
      CheckInternetConnection().then((value) {
        if (value == true) {
        switch (moduleName.toLowerCase().trim()) {
        case "contacts" :
        Get.to(() => ContactPage(
        title: moduleName.toString()
        ,displayName: displayName,));
        break;
        case "temple calendar" :
        Get.to(() => EventCalendar(
          title: moduleName,displayName: displayName,));
        break;
        case "priestcalendar" :
        Get.to(() => PriestBookingCalendar(
          title: moduleName,displayName: displayName,));
        break;
        case "inventory" :
        Get.to(() => InventroyList(title: moduleName,displayName: displayName,));
        break;
        case "my profile" :
        Get.to(() => ProfilePage(
        title:moduleName.toString()));
        break;
        case "bookings" :
          Get.to(() => BookingCalendar(
            title: "Calendar",displayName: displayName,));
        break;
        case "donations" :
          Get.to(() => ServiceTypePage(title:"Donations", category: "DONATIONS", routType: 2,));
        break;
        case "inquiry" :
          Get.to(() => InquiryCategoryPage(title:moduleName));
        break;
        case "asset management" :
        Get.to(() => AssetPage(
        title: moduleName.toString(),));
        break;
        case "devoteeprofile" :
        Get.to(() => DevoteePage(
        title: moduleName.toString(), displayName: displayName,));
        break;
        case "purchase list" :
        Get.to(() => PurchasePage(
        title: moduleName.toString(),));
        break;
        case "bookings history" :
        Get.to(() => BookingHistoryPage(
          title: "Bookings", type: 1,));
        break;
        case "expenses" :
        Get.to(() => ExpansesPage(
        title: moduleName.toString(),));
        break;
        case "rentals" :
        Get.to(() => RentalBookingPage(
        title: moduleName.toString(), type: "3", displayName: displayName,));
        break;
        case "camping" :
        Get.to(() => CampingBookingPage(
        title: moduleName.toString(), type: "3", displayName: displayName,));
        break;
        case "documents" :
        Get.to(() => DocumentsPageTemp(
        title: moduleName.toString(),));
        break;
        case "timecard" :
        Get.to(() =>AppConstant.sharedPreference.getBool(AppConstant.isMember)==true? TimeCardPage(
          memberId: AppConstant.sharedPreference.getString(AppConstant.memberId).toString(),
        email:  AppConstant.sharedPreference.getString(AppConstant.userEmail).toString().trim(), type: 1,):AllPriestPage());
        break;
        case "assignments" :
        Get.to(() => PriestAssignmentPage(
        title: moduleName.toString(), displayName: displayName,));
        break;
        case "poojalist" :
        Get.to(() => PoojaListPage());
        break;
        case "leaveform" :
        Get.to(() => LeaveListPage(type: 1,));
        break;
        case "payments" :
        Get.to(() => PaymentInquiryPage(
        title: moduleName.toString(),type: 2,));
        break;
        case "devoteebookings" :
        Get.to(() => BookingHistoryPage(
        title: "Devotee Bookings", type: 2,));
        break;
        case "service request" :
        Get.to(() => BookingsPage(
        title: "Services", type: "1",displayName:displayName ,));
        break;
        // case "catering" :
        // Get.to(() => KitchenOrder(
        // title: moduleName.toString(),));
        // break;
        case "today's menu" :
        Get.to(() => TodyMenuPage(type: 1,
        title: "Today's Menu",));
        break;
        case "catering" :
        Get.to(() => CateringPage(type: 4,
        title: "Catering",));
        break;
        case "prasadam" :
        Get.to(() => PrasadamPage(title: displayName,));
        break;
        case "menu" :
        Get.to(() => MenuPage(
        title: moduleName.toString(), type: 1,));
        break;
        case "job orders" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "budgeting" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "estimator" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "contractors" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "checklist" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "check in/out" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "project profile" :
        Get.to(() => ProjectDetailPage(
        title: moduleName.toString(),));
        break;
        case "availability" :
        break;
        case "walk-through" :
        break;
        case "timelines" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "documents" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "notifications" :
        Get.to(() => RecieveNotificationPage(title: displayName,));
        break;
        case "punchlist" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "timecards" :
        break;
        case "nearby" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "consent" :
        Get.to(() => ProjectPage(
        title:moduleName.toString(),));
        break;
        case "invoices" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "project images" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;

        case "selections" :
        Get.to(() => ProjectPage(
        title: moduleName.toString(),));
        break;
        case "service setup" :
        Get.to(() => ServiceCategoryPage(
        title: moduleName.toString(),));
        break;
        case "app config" :
        Get.to(() => AppConfig());

        break;
        case "request" :
       AppConstant.sharedPreference.getBool(AppConstant.isMember)==true?Get.to(() => PriestServiceRequestPage()): Get.to(() => ServiceRequestPage());
        break;
        case "analytics" :
        Get.to(() => AnalyticCategoryPage(title: moduleName.toString(),));
        break;
        }
        }
        });

    }
  setupRemoteConfig() async {
    PackageInfo packageInfo = await PackageInfo.fromPlatform();
    String version = packageInfo.version;
    String buildNumber = packageInfo.buildNumber;

    final  remoteConfig = FirebaseRemoteConfig.instance;
    remoteConfig.setConfigSettings(
        RemoteConfigSettings(fetchTimeout: Duration(seconds: 10), minimumFetchInterval: Duration.zero)
    );
    await remoteConfig.fetch();
    await remoteConfig.activate();
    if(remoteConfig.getValue(AppConstant.vaapTempleUpdate).asBool())
    {

      if(version!=remoteConfig.getValue(AppConstant.vaapTempleVersion).asString() && remoteConfig.getValue(AppConstant.forceFully).asBool() )
      {
        _forceFullyupdate(remoteConfig.getString(AppConstant.vaapTempleUrl),remoteConfig.getString(AppConstant.vaapTempleMessage));
        return;
      }
      if(version!=remoteConfig.getValue(AppConstant.vaapTempleVersion).asString())
        {
          _update(remoteConfig.getString(AppConstant.vaapTempleUrl),remoteConfig.getString(AppConstant.vaapTempleMessage));
          return;
        }

    }

    //  print(remoteConfig.getValue('version').asString());

  }
  void _update(String url,String Message) {
    showCupertinoDialog(
        context: Get.context!,
        builder: (BuildContext ctx) {
          return CupertinoAlertDialog(
            title: const Text('Update ! '),
            content:  Text(Message),
            actions: [
              // The "Yes" button
              CupertinoDialogAction(
                onPressed: () {
                  Get.back();
                },
                child: const Text('May be later'),
                isDefaultAction: true,
                isDestructiveAction: true,
              ),
              // The "No" button
              CupertinoDialogAction(
                onPressed: () {
                  _lunchInBrowser(url);
                },
                child: const Text('Install'),
                isDefaultAction: false,
                isDestructiveAction: false,
              )
            ],
          );
        });
  }


  void _forceFullyupdate(String url,String Message) {
    showCupertinoDialog(
        context: Get.context!,
        barrierDismissible: true,
        builder: (BuildContext ctx) {
          return WillPopScope(onWillPop: ()async{
            return false;
          },
            child: CupertinoAlertDialog(
              insetAnimationCurve: Curves.easeInOutCubic,
              insetAnimationDuration:Duration(milliseconds: 600),
              title: const Text('Update required !',),
              content:  Text(Message),
              actions: [
                // The "Yes" button

                // The "No" button
                CupertinoDialogAction(
                  onPressed: () {
                    _lunchInBrowser(url);
                  },
                  child: const Text('Install'),
                  isDefaultAction: false,
                  isDestructiveAction: false,
                )
              ],
            ),
          );
        });
  }


  Future<void> _lunchInBrowser(String url) async
  {
    if(await canLaunch(url))
    {
      await launch(url,forceSafariVC: false,forceWebView: false,
          headers: <String,String>{"headesr_key":  "headers_value"}
      );

    }
    else{
      throw "url not lunched $url";
    }
  }
}