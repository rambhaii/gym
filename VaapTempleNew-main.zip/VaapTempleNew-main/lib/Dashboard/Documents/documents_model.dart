// To parse this JSON data, do
//
//     final documentData = documentDataFromJson(jsonString);

import 'dart:convert';

DocumentModel documentDataFromJson(String str) => DocumentModel.fromJson(json.decode(str));

String documentDataToJson(DocumentModel data) => json.encode(data.toJson());

class DocumentModel {
  DocumentModel({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String? message;
  List<Datum>? data;

  factory DocumentModel.fromJson(Map<String, dynamic> json) => DocumentModel(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.documentCode,
    this.documentCategory,
    this.documentType,
    this.documentName,
    this.documentDescription,
    this.documentImage,
    this.documentStatus,
    this.contactEmail,
    this.contactPhone,
    this.documentRemarks,
    this.documentVersionNumber,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.isChecked,
  });

  String ?id;
  String ?documentCode;
  String ?documentCategory;
  String ?documentType;
  String ?documentName;
  String ?documentDescription;
  String ?documentImage;
  String ?documentStatus;
  String ?contactEmail;
  String ?contactPhone;
  String? documentRemarks;
  String? documentVersionNumber;
  String? moduleName;
  String? clientId;
  String? productId;
  String? aspectType;
  String? recCreBy;
  String? recCreDate;
  String? recModBy;
  String? recModDate;
  bool? isChecked;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"],
    documentCode: json["documentCode"]??"",
    documentCategory: json["documentCategory"]??"",
    documentType: json["documentType"]??"",
    documentName: json["documentName"]??"",
    documentDescription: json["documentDescription"]??"",
    documentImage: json["documentImage"]??"",
    documentStatus: json["documentStatus"]??"",
    contactEmail: json["contactEmail"]??"",
    contactPhone: json["contactPhone"]??"",
    documentRemarks: json["documentRemarks"]??"",
    documentVersionNumber: json["documentVersionNumber"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    isChecked: false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "documentCode": documentCode,
    "documentCategory": documentCategory,
    "documentType": documentType,
    "documentName": documentName,
    "documentDescription": documentDescription,
    "documentImage": documentImage,
    "documentStatus": documentStatus,
    "contactEmail": contactEmail,
    "contactPhone": contactPhone,
    "documentRemarks": documentRemarks,
    "documentVersionNumber": documentVersionNumber,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "isChecked": isChecked,
  };
}
