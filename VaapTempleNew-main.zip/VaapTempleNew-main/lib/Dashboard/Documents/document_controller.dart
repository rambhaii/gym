import 'dart:convert';
import 'dart:io';

import 'package:aspgen_mobile/Dashboard/Documents/documents_model.dart';
import 'package:aspgen_mobile/Dashboard/inventory_page/InventoryList.dart';
import 'package:aspgen_mobile/Dashboard/inventory_page/model/InventoryData.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:path_provider/path_provider.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/base_client.dart';

class DocumentsController extends GetxController{
  DocumentsController(this.titile);
  final String titile;
  var datas= DocumentModel().obs;
  TextEditingController etSearch= new TextEditingController();
  var localpath=''.obs;
  var bodyJson={};
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":titile,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip":0,
      "next":40
    };
    fetchApi();
    // TODO: implement onInit
    super.onInit();
  }

  fetchApi()async{
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    print("dvds bvjksdb"+response);
    datas.value=documentDataFromJson(response);
    // UtilMethods.getGenericData(Get.context!, bodyJson).then((value) {
    //   inventoryData.value=inventoryDataFromJson(value);
    // });
  }
  fetchFilterApi(String text)async{
    var request={
      "text": text,
      "componentConfig": {
        "moduleName":titile,
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    datas.value=documentDataFromJson(response);
    // UtilMethods.getGenericFilterData(Get.context!,request).then((value)  {
    //   if(InventoryData.fromJson(jsonDecode(value)).data!.isEmpty)
    //     Fluttertoast.showToast(msg: "No Data Available");
    //   inventoryData.value=inventoryDataFromJson(value);
    // });
  }
  Future<String> getPath() async {
    Directory _path = await getApplicationDocumentsDirectory();
    String _localPath = _path.path + Platform.pathSeparator + 'Download';
    final savedDir = Directory(_localPath);
    bool hasExisted = await savedDir.exists();
    if (!hasExisted) {
      savedDir.create();
    }
    return _localPath;
  }
}