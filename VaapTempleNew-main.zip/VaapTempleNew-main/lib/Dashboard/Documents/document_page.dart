import 'dart:convert';
import 'dart:io';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/Dashboard/Documents/document_controller.dart';
import 'package:aspgen_mobile/Dashboard/Expanses/expenses_controller.dart';
import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../AppConstant/TextStyle.dart';
import '../../Templates/fieldPageNew.dart';
import '../../UtilMethods/RemoteServices.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListView.dart';
import '../../Widget/SearchBarWidget.dart';
import '../inventory_page/controller.dart';



class DocumentsPageTemp extends StatefulWidget {
  final String title;
  const DocumentsPageTemp({Key? key, required this.title}) : super(key: key);

  @override
  _DocumentsPageTempState createState() => _DocumentsPageTempState();
}

class _DocumentsPageTempState extends State<DocumentsPageTemp> {

  TextEditingController etsearch= new TextEditingController();
  late DocumentsController controller;
  DateTime?tempDate;
  @override
  void initState() {
    controller=Get.put(DocumentsController("Documents"));
    // TODO: implement initState

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
        ),
        actions: [  Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            CheckInternetConnection().then((value1) => value1==true? Get.to(()=>FieldPageNew(title:widget.title,type: 1,)):"");
          },child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        )],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),

        child: Column(
          children: [
            SizedBox(height: 10,),
            GetBuilder<DocumentsController>(
              builder: (controller)=>  SearchBarWidget(
                hint: "Search",
                controller: controller.etSearch,
                onchange: (value){
                  value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi():"";
                  controller.update();
                },
                onCancel: (){
                  controller.etSearch.clear();
                  controller.fetchApi();
                  controller.update();
                },
              ),
            ),
            SizedBox(height: 4,),
            Obx(() => controller.datas.value.data!=null?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {
                    controller.fetchApi();
                  });
                },
                child: ListView.builder(
                    itemCount:controller.datas.value.data!.length,
                    itemBuilder: (context,index)
                    {
                      final datum=controller.datas.value.data![index];
                      return CustomListWidget(
                        title: datum.documentName!,
                        subTitle: datum.documentCategory??"",
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              SizedBox(height: 2,),
                              GestureDetector(
                                onTap: (){
                                  UtilMethods.urlLuncher(APIsConstant.IP_Base_Url+datum.documentImage!);
                                },
                                child: Row(
                                  children: [
                                    Text("Document :    "),
                                    Icon(Icons.visibility_rounded,color: Colors.green,size: 18,),
                                    Text(" View",style: Theme.of(context).textTheme.bodyText1!.copyWith(color: Colors.green,decoration: TextDecoration.underline,fontSize: 14)),

                                  ],
                                ),
                              ),
                              SizedBox(height: 2,),
                              RichText(
                                text: TextSpan(
                                  text: 'Code :  ',
                                  style: Theme.of(context).textTheme.bodyText2,
                                  children: <TextSpan>[
                                    TextSpan(
                                        text:datum.documentCode,
                                        style: Theme.of(context).textTheme.bodyText1),
                                  ],
                                ),
                              ),
                              SizedBox(height: 2,),
                              RichText(
                                text: TextSpan(
                                  text: 'Notes :  ',
                                  style: Theme.of(context).textTheme.bodyText2,
                                  children: <TextSpan>[
                                    TextSpan(
                                        text:datum.documentRemarks,
                                        style: Theme.of(context).textTheme.bodyText1!.copyWith(fontWeight: FontWeight.normal,fontSize: 14)),
                                  ],
                                ),
                              )
                            ]),
                        isClicked: datum.isChecked??false,
                        onTapVieMore: (){
                          datum.isChecked=!datum.isChecked!;
                          controller.datas.refresh();
                        },
                        editOnTap: (){
                          CheckInternetConnection().then((value) {
                            if(value==true)
                            {
                              CheckInternetConnection().then((value1) => value1==true?Get.to(()=>FieldPageNew(title: "Expanses",type: 2,id: datum.id!),arguments: {"data": json.decode(json.encode(datum))}):"");
                            }
                          });
                        }, textEditingController: controller.etSearch,
                      );

                    }),
              ),
            ):Container(),
            )
          ],
        ),
      ),

    );
  }

}
