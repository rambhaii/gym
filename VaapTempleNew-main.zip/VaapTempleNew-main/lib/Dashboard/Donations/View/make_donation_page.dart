
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinbox/flutter_spinbox.dart';

import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../UtilMethods/Utils.dart';
import '../../../Widget/ButtonWidget.dart';
import '../../../Widget/CheckBoxCustomWidget.dart';
import '../../../Widget/EditextWidget.dart';
import '../../../Widget/SearchBarWidget.dart';
import '../Controller/DonationsController.dart';
import '../Model/make_donation.dart';



class MakeDonationPage extends StatefulWidget {
  final String title;
  final String displayName;
  final String type;
  const MakeDonationPage({Key? key, required this.title, required this.displayName, required this.type}) : super(key: key);

  @override
  _MakeDonationPageState createState() => _MakeDonationPageState();
}

class _MakeDonationPageState extends State<MakeDonationPage> {
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
late MakeDonationListController _controller;
  DateTime?tempDate;
  @override
  void initState() {
  _controller=  Get.put(MakeDonationListController(widget.title,widget.type));
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.type,
        ),
        actions: [
          Center(child: Obx(()=> Text("\$ "+_controller.totalAmount.value,style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color:Colors.amber),))),
          Padding(
            padding: const EdgeInsets.only(right: 8.0,left: 8),
            child: RawMaterialButton(onPressed: (){
              if(_controller.selectedData.value.isNotEmpty)
              {
                showDialog(context: context, builder: (context)=>showDailog(_controller.selectedData.value),
                    barrierDismissible:false
                );
               // showDialog(context: context, builder: (context)=>showDailog(context,));
              }
            }
              ,child: Icon(Icons.paypal),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          )
        ],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),

        child: Column(
          children: [
            SizedBox(height: 8,),
            GetBuilder<MakeDonationListController>(
              builder: (controller)=>  SearchBarWidget(
                hint: "Search",
                controller: controller.etSearch,
                onchange: (value){
                  //value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi(controller.bodyJson):"";
                  controller.update();
                },
                onCancel: (){
                  controller.etSearch.clear();
                  //controller.fetchApi(controller.bodyJson);
                  controller.update();
                },
              ),
            ),
            SizedBox(height: 8,),

            Obx(()=> _controller.servicedata.value!=null?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {

                  });
                  },
                child:

                ListView.builder(
                    itemCount:_controller.servicedata.value.length,
                    itemBuilder: (context,index)
                    {
                      final datum=_controller.servicedata.value[index];
                      return CheckboxCustomListWidget(title: _controller.servicedata.value[index].refDataName??"",
                        subTitle:amountParser(_controller.servicedata.value[index].serviceAmount!.toString()),
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                               SizedBox(height: 2,),
                               RichText(
                                text: TextSpan(
                                  text: 'Type : ',
                                  style: Theme.of(context).textTheme.bodyText2,
                                  children: <TextSpan>[
                                    TextSpan(text:_controller.servicedata.value[index].serviceTypes!,
                                        style: Theme.of(context).textTheme.bodyText1),
                                  ],
                                ),
                              ),
                               SizedBox(height: 2,),
                               RichText(
                                text: TextSpan(
                                  text: "Date/time:-   ",
                                  style: Theme.of(context).textTheme.bodyText2,
                                  children: <TextSpan>[
                                    TextSpan(text:_controller.servicedata.value[index].startDate!,
                                        style: Theme.of(context).textTheme.bodyText1),
                                    TextSpan(text:"  "+_controller.servicedata.value[index].startTime!,
                                        style: Theme.of(context).textTheme.bodyText1),
                                  ],
                                ),
                              )
                            ]),
                        textEditingController: _controller.etSearch,
                        isAdd:_controller.servicedata.value[index].isAdded!,
                        isClicked: _controller.servicedata.value[index].isChecked!??false,
                        onTapVieMore: (){
                          _controller.servicedata.value[index].isChecked=!_controller.servicedata.value[index].isChecked!;

                          _controller.servicedata.refresh();
                      },
                        icon: Icons.paypal_rounded,
                        iconColor: Colors.green,
                        onChange: (v){
                          _controller.servicedata.value[index].isAdded=v;
                          if(_controller.servicedata.value[index].isAdded!){

                              _controller.selectedData.value.add(datum);
                              _controller.totalAmount.value=(double.parse(_controller.totalAmount.value)+double.parse(datum.serviceAmount!.toString())).toStringAsFixed(2);

                          }
                          else{
                            _controller.selectedData.value.removeWhere((element) => element.id==datum.id);
                            _controller.totalAmount.value=(double.parse(_controller.totalAmount.value)-double.parse(datum.serviceAmount!.toString())).toStringAsFixed(2);

                          }
                          _controller.servicedata.refresh();


                        },);

                    }),
              ),
            ):Container(),
            )
          ],
        ),
      ),
    );
  }
  showDailog(List<MakeDonationsDatum> datum) {
    _controller.etEmail.text="";
    final  GlobalKey<FormState> formKey=GlobalKey<FormState>();
    return AlertDialog(
      elevation: 10,
      contentPadding: EdgeInsets.only(top: 20,bottom: 10,left: 8,right: 8),
      // backgroundColor: backgroundColor,
      title:Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Donate",
            style: Theme.of(context).textTheme.headline4!,
          ),
          // Icon(Icons.close,color: Colors.red,)
        ],

      ) ,
      actions: [
        ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
            onPressed: (){
              Get.back();
            }, child: Text("Cancel")),
        ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
            onPressed: (){
              if(formKey.currentState!.validate())
                {
                  _controller.alldata.clear();
                _controller.getDevoteeDetails().then((value) {
                  if(value==true)
                    {
                      Get.back();
                    //  _controller.totalAmount.value=double.parse(datum.serviceAmount!.toString()).toStringAsFixed(2);
                     datum.forEach((datum1) {
                       _controller.alldata.add( {
                         '_id': datum1.id,
                         'startDate': datum1.startDate,
                         "serviceName": datum1.refDataName,
                         "qty": 1,
                         "serviceAmount": datum1.serviceAmount,
                         "time": datum1.startTime,
                         "day": datum1.dayTypes
                       });
                     });

                      showDialog(context: context, builder: (context)=>showDailogPaymentmode(),
                          barrierDismissible:false
                      );
                    }
                }

                );

                }


            }, child: Text("Continue")),

      ],
      content: StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [

                Form(
                  key: formKey,
                  child: EditTextWidget(
                    maxLength: 200,
                    hint: "Enter Email",
                    isPassword: false,
                    keyboardtype: TextInputType.text,
                    label: "Devotee Email",
                    validator: (value) {

                      if (value == null || value.isEmpty) {
                          return 'Please Enter Email';
                        } if (!isValidEmail(value.toString())) {
                          return 'Please Enter Valid Email';
                        }
                      return null;
                    },
                    controller:_controller.etEmail,
                    maxline: 1,
                  ),
                ),
              SizedBox(height: 4,),

                Container(
                  height: 250,
                  child: ListView.builder(
                    itemCount: datum.length,
                    shrinkWrap: true,
                    itemBuilder:(ctx,index)=>Container(
                      color: Colors.grey.withOpacity(.2),
                      child: Card(
                        elevation: 5,
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        child: ListTile(
                          dense: true,

                          title: Text(
                                 datum[index].refDataName??"",
                            style: Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 13),
                          ) ,
                          trailing: Text(amountParser( datum[index].serviceAmount.toString()),
                     style: Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 13),
                          ),
                        ),
                      ),

                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  alignment: Alignment.bottomCenter,

                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        color: Colors.grey.withOpacity(.2),
                        padding: EdgeInsets.all(8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "  Total Amount ",
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText1!
                                  .copyWith(
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500),
                            ),
                            Text("\$ "+double.parse(_controller.totalAmount!.value.toString()).toStringAsFixed(2) ,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText1!
                                  .copyWith(
                                  fontSize: 17,
                                  fontWeight: FontWeight.w600,color: Colors.amber),
                            ),
                          ],
                        ),
                      ),

                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
  showDailogPaymentmode() {
    bool _value = false;
    int val = -1;
    String? _selectedmethod = "cash";
    return AlertDialog(
      // backgroundColor: backgroundColor,
      elevation: 10,
      content: Container(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Select Payment Method",
              style: Theme.of(context).textTheme.headline4,
            ),
            SizedBox(
              height: 15,
            ),
            Text(
              "Amount to Pay",
              style: Theme.of(context).textTheme.bodyText1!.copyWith(

                  fontSize: 16,
                  fontWeight: FontWeight.w500),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 15,
            ),
            Text(
           "\$ "+  double.parse(_controller.totalAmount.value).toStringAsFixed(2),
              style: Theme.of(context).textTheme.bodyText1!.copyWith(
                  color: Colors.amber,
                  fontSize: 20,
                  fontWeight: FontWeight.w500),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [


                  ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                      onPressed: (){
                     _controller.addServiceData("CASH");
                      }, child: Text(" CASH ")),
                  SizedBox(width: 10,),
                  ElevatedButton(
                      style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                      onPressed: (){
                       showDialog(context: context, builder: (context)=>showDailogCheck());
                      }, child: Text("CHECK")),



              ],
            ),
            ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                onPressed: (){
                  Get.snackbar("Alert!", "Credit Card Payment Method Comming Soon.",borderRadius: 2,backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.black12]));
                }, child: Text("CREDIT CARD")),
          ],
        ),
      ),
    );
  }
  showDailogCheck() {
    final GlobalKey<FormState> formKey=GlobalKey<FormState>();
    return AlertDialog(
        content: StatefulBuilder(
          builder: (BuildContext context, StateSetter setState) {
            return SingleChildScrollView(
                scrollDirection: Axis.vertical,
                child: Form(
                  key: formKey,
                  child: Column(
                    children: [
                      Text("Check Details",
                          style: Theme.of(context)
                              .textTheme
                              .headline4!),
                      SizedBox(
                        height: 20,
                      ),
                      EditTextWidget(
                            maxLength: 200,
                            hint: "Check Number",
                            isPassword: false,
                            keyboardtype: TextInputType.text,
                            label: "Check Number",
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please Enter Check Number';
                              }
                              return null;
                            },
                            controller: _controller.etCheckNo,
                            maxline: 1,
                          ),
                      EditTextWidget(
                        maxLength: 200,
                        hint: "Check Amount",
                        isPassword: false,
                        keyboardtype: TextInputType.number,
                        label: "Check Amount",
                        validator: (value) {

                          if (value == null || value.isEmpty) {
                            return 'Please Enter Amount';
                          }
                          return null;
                        },
                        controller: _controller.etAmount,
                        maxline: 1,
                      ),
                      EditTextWidget(
                        maxLength: 200,
                        hint: "Bank Detail",
                        isPassword: false,
                        keyboardtype: TextInputType.text,
                        label: "Bank Detail",
                        validator: (value) {

                          if (value == null || value.isEmpty) {
                            return 'Please Enter Bank Detail';
                          }
                          return null;
                        },
                        controller: _controller.etBankDetails,
                        maxline: 1,
                      ),





                      SizedBox(

                        child: InkWell(
                          onTap: () async {
                            final DateTime? picked= await  showDatePicker(
                                        context: context,
                                        initialDate:DateTime.now(),
                                        firstDate: DateTime(2015),
                                        lastDate: DateTime(2100),
                                        builder: (context, child) {
                                          return Theme(
                                            data: ThemeData.dark().copyWith(
                                                colorScheme: const ColorScheme.dark(
                                                    onPrimary: Colors.white,
                                                    // selected text color
                                                    onSurface: Colors.white,
                                                    // default text color
                                                    primary: Colors
                                                        .teal // circle color
                                                ),
                                                dialogBackgroundColor: Theme
                                                    .of(context)
                                                    .backgroundColor,

                                                textButtonTheme: TextButtonThemeData(
                                                    style: TextButton.styleFrom(
                                                        textStyle: const TextStyle(
                                                            color: Colors.white,
                                                            fontWeight: FontWeight
                                                                .normal,
                                                            fontSize: 12,
                                                            fontFamily: 'Quicksand'),
                                                        primary: Colors.white,
                                                        // color of button's letters
                                                        backgroundColor: Colors
                                                            .black54,
                                                        // Background color
                                                        shape: RoundedRectangleBorder(
                                                            side: const BorderSide(
                                                                color: Colors
                                                                    .transparent,
                                                                width: 1,
                                                                style: BorderStyle
                                                                    .solid),
                                                            borderRadius: BorderRadius
                                                                .circular(50))))),

                                            child: child!,
                                          );
                                        }

                                    );

                                    final String formatted = formatter.format(picked!);
                                    _controller.etDate.text=formatted;

                          },
                          child:  AbsorbPointer(
                            child: EditTextWidget(
                              maxLength: 200,
                              hint: "Date",
                              isPassword: false,
                              keyboardtype: TextInputType.text,
                              label: "Date",
                              validator: (value) {

                                if (value == null || value.isEmpty) {
                                  return 'Please Select Bank Date';
                                }
                                return null;
                              },
                              controller: _controller.etDate,
                              maxline: 1,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ButtonWidget(
                            btnName: 'Cancel',
                            onPress: () {
                              Navigator.of(context).pop();
                            },
                            minWidth: 100,
                          ),
                          ButtonWidget(
                            btnName: 'Proceed',
                            onPress: () {
                             if(formKey.currentState!.validate())
                               {
                                 _controller.addServiceData("CHECK");
                               }
                            },
                            minWidth: 100,
                          ),
                        ],
                      ),
                    ],
                  ),
                ));
          },
        ));
  }
}
