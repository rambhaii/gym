// To parse this JSON data, do
//
//     final makeDonationModel = makeDonationModelFromJson(jsonString);

import 'dart:convert';

MakeDonationModel makeDonationModelFromJson(String str) => MakeDonationModel.fromJson(json.decode(str));

String makeDonationModelToJson(MakeDonationModel data) => json.encode(data.toJson());

class MakeDonationModel {
  MakeDonationModel({
    this.statusCode,
    this.message,
    this.data,
  });

  String? statusCode;
  String? message;
  List<MakeDonationsDatum>? data;

  factory MakeDonationModel.fromJson(Map<String, dynamic> json) => MakeDonationModel(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<MakeDonationsDatum>.from(json["data"].map((x) => MakeDonationsDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class MakeDonationsDatum {
  MakeDonationsDatum({
    this.id,
    this.serviceCategoryTypes,
    this.serviceTypes,
    this.sourceTypes,
    this.refDataName,
    this.image,
    this.serviceAmount,
    this.startDate,
    this.endDate,
    this.startTime,
    this.endTime,
    this.sequenceId,
    this.qtyCounter,
    this.dayTypes,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.isChecked,
    this.isAdded,
  });

  String ?id;
  String ?serviceCategoryTypes;
  String ?serviceTypes;
  String ?sourceTypes;
  String ?refDataName;
  String ?image;
  var serviceAmount;
  String ?startDate;
  String ?endDate;
  String ?startTime;
  String ?endTime;
  String ?sequenceId;
  String ?qtyCounter;
  String ?dayTypes;
  String ?moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  bool ?isChecked;
  bool ?isAdded;

  factory MakeDonationsDatum.fromJson(Map<String, dynamic> json) => MakeDonationsDatum(
    id: json["_id"]??"",
    serviceCategoryTypes: json["serviceCategoryTypes"]??"",
    serviceTypes: json["serviceTypes"]??"",
    sourceTypes: json["sourceTypes"]??"",
    refDataName: json["refDataName"]??"",
    image: json["Image"]??"",
    serviceAmount: json["serviceAmount"]??"",
    startDate: json["startDate"]??"",
    endDate: json["endDate"]??"",
    startTime: json["startTime"]??"",
    endTime: json["endTime"]??"",
    sequenceId: json["sequenceId"]??"",
    qtyCounter: json["qtyCounter"]??"",
    dayTypes: json["dayTypes"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    isChecked: false,
    isAdded: false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "serviceCategoryTypes": serviceCategoryTypes,
    "serviceTypes": serviceTypes,
    "sourceTypes": sourceTypes,
    "refDataName": refDataName,
    "Image": image,
    "serviceAmount": serviceAmount,
    "startDate": startDate,
    "endDate": endDate,
    "startTime": startTime,
    "endTime": endTime,
    "sequenceId": sequenceId,
    "qtyCounter": qtyCounter,
    "dayTypes": dayTypes,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "isChecked": isChecked,
    "isAdded": isAdded,
  };
}
