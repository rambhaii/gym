
import 'dart:convert';

import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
import '../Model/make_donation.dart';

class MakeDonationListController extends GetxController{
  Rx<List<MakeDonationsDatum>> servicedata= Rx<List<MakeDonationsDatum>>([]);
  Rx<List<MakeDonationsDatum>> selectedData= Rx<List<MakeDonationsDatum>>([]);
  MakeDonationListController(this.title, this.Type);
  final String title;
  final String Type;

  var bodyJson={};
  TextEditingController etSearch= new TextEditingController();
  TextEditingController etEmail= new TextEditingController();

  TextEditingController etCheckNo= new TextEditingController();
  TextEditingController etAmount= new TextEditingController();
  TextEditingController etBankDetails= new TextEditingController();
  TextEditingController etDate= new TextEditingController();
  String memberName="";
  String memberId="";
  String memberEmail="";
  String memberPhone="";
  RxString totalAmount="0".obs;

  //Service Details Data
 List<Map> alldata = [];


  @override
  void onInit() {
    var query={"aspectType": "ServiceSetup","serviceCategoryTypes":"DONATIONS","serviceTypes":Type,"source":"Mobile"};
    fechApi(query);
    super.onInit();
  }
 fechApi(var query) async{
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, getRequestJson(query)).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1") "";
    if(jsonDecode(response)["data"]==null) "";
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No Data Available");
    };
    servicedata.value=MakeDonationModel.fromJson(jsonDecode(response)).data!;
  }
  getRequestJson(var query){
    bodyJson["componentConfig"] = {
      "moduleName":"Service Setup",
      "aspectType": "ServiceSetup",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": query,
      "skip": 0,
      "next": 100
    };
    return bodyJson;
  }

  Future<bool> getDevoteeDetails() async{
    var request={
    "dataJson":{
    "email":UtilMethods.encrypt(etEmail.text)
    },
    "componentConfig":{
    "moduleName": "Contacts",
    "productID":  AppConstant.sharedPreference.getString(AppConstant.productId),
    "clientID":AppConstant.sharedPreference.getString(AppConstant.clientId)
    }};
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getDevoteeDetais,request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();

    if(jsonDecode(response)["statusCode"].toString()=="-1") {
      Get.snackbar("Alert!", jsonDecode(response)["message"].toString(),borderRadius: 2,backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.black26]));

      return false;
    }
    if(jsonDecode(response)["data"]==null) return false;
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No Data Available");
      return false;
    };
      var datas=jsonDecode(response)["data"][0];
      memberId=datas["_id"];
      memberName=datas["refDataName"];
      memberEmail=datas["email"];
      memberPhone=datas["phone"];
      return true;
    }

    addServiceData(String paymentType){
    UtilMethods.addServiceCart(alldata, paymentType, etBankDetails.text, etCheckNo.text, etAmount.text, etDate.text, totalAmount.value, "", memberId, memberName, memberEmail, memberPhone, Get.context!);
  }

}