// To parse this JSON data, do
//
//     final settingModel = settingModelFromJson(jsonString);

import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/AppConstant.dart';

SettingModel settingModelFromJson(String str) => SettingModel.fromJson(json.decode(str));

String settingModelToJson(SettingModel data) => json.encode(data.toJson());

class SettingModel {
  SettingModel({
    this.result,
  });

  Result? result;

  factory SettingModel.fromJson(Map<String, dynamic> json) => SettingModel(
    result: Result.fromJson(json["result"]),
  );

  Map<String, dynamic> toJson() => {
    "result": result!.toJson(),
  };
}

class Result {
  Result({
    this.statusCode,
    this.message,
    this.data,
  });

  int ?statusCode;
  String? message;
  List<Datum>? data;

  factory Result.fromJson(Map<String, dynamic> json) => Result(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.privacySecurity,
    this.themeSettings,
    this.paymentGatewaySettings,
    this.productName,
    this.productId,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.clientId,
    this.clientName,
    this.aspectSource,
    this.aspectType,
    this.editHistory,
    this.v,
    this.languagesSettings,
  });

  String ?id;
  PrivacySecurity ?privacySecurity;
  List<ThemeSetting>? themeSettings;
  List<PaymentGatewaySetting>? paymentGatewaySettings;
  String ?productName;
  String ?productId;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  String ?clientId;
  String ?clientName;
  String ?aspectSource;
  String? aspectType;
  List<dynamic>? editHistory;
  int ?v;
  List<LanguagesSetting> ?languagesSettings;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"],
    privacySecurity: PrivacySecurity.fromJson(json["PrivacySecurity"]),
    themeSettings: List<ThemeSetting>.from(json["themeSettings"].map((x) => ThemeSetting.fromJson(x))),
    paymentGatewaySettings: List<PaymentGatewaySetting>.from(json["paymentGatewaySettings"].map((x) => PaymentGatewaySetting.fromJson(x))),
    productName: json["productName"],
    productId: json["productId"],
    recCreBy: json["recCreBy"],
    recCreDate: json["recCreDate"],
    recModBy: json["recModBy"],
    recModDate: json["recModDate"],
    clientId: json["clientId"],
    clientName: json["clientName"],
    aspectSource: json["aspectSource"],
    aspectType: json["aspectType"],
    editHistory: List<dynamic>.from(json["editHistory"].map((x) => x)),
    v: json["__v"],
    languagesSettings: List<LanguagesSetting>.from(json["languagesSettings"].map((x) => LanguagesSetting.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "PrivacySecurity": privacySecurity!.toJson(),
    "themeSettings": List<dynamic>.from(themeSettings!.map((x) => x.toJson())),
    "paymentGatewaySettings": List<dynamic>.from(paymentGatewaySettings!.map((x) => x.toJson())),
    "productName": productName,
    "productId": productId,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "clientId": clientId,
    "clientName": clientName,
    "aspectSource": aspectSource,
    "aspectType": aspectType,
    "editHistory": List<dynamic>.from(editHistory!.map((x) => x)),
    "__v": v,
    "languagesSettings": List<dynamic>.from(languagesSettings!.map((x) => x.toJson())),
  };
}

class LanguagesSetting {
  LanguagesSetting({
    this.language,
    this.platform,
  });

  List<String>? language;
  String ?platform;

  factory LanguagesSetting.fromJson(Map<String, dynamic> json) => LanguagesSetting(
    language: List<String>.from(json["language"].map((x) => x)),
    platform: json["platform"],
  );

  Map<String, dynamic> toJson() => {
    "language": List<dynamic>.from(language!.map((x) => x)),
    "platform": platform,
  };
}

class PaymentGatewaySetting {
  PaymentGatewaySetting({
    this.paymentGateway,
    this.platform,
  });

  List<String>? paymentGateway;
  String ?platform;

  factory PaymentGatewaySetting.fromJson(Map<String, dynamic> json) => PaymentGatewaySetting(
    paymentGateway: List<String>.from(json["paymentGateway"].map((x) => x)),
    platform: json["platform"],
  );

  Map<String, dynamic> toJson() => {
    "paymentGateway": List<dynamic>.from(paymentGateway!.map((x) => x)),
    "platform": platform,
  };
}

class PrivacySecurity {
  PrivacySecurity({
    this.activatePinPassword,
    this.activateTwoFactorAutentication,
    this.allowNotification,
    this.allowNewsletter,
    this.otpAuthentication,
    this.subscriptionReminder,
  });

  bool? activatePinPassword;
  bool? activateTwoFactorAutentication;
  bool? allowNotification;
  bool? allowNewsletter;
  List<String> ?otpAuthentication;
  List<String> ?subscriptionReminder;

  factory PrivacySecurity.fromJson(Map<String, dynamic> json) => PrivacySecurity(
    activatePinPassword: json["activatePinPassword"]??false,
    activateTwoFactorAutentication: json["activateTwoFactorAutentication"]??false,
    allowNotification: json["allowNotification"]??false,
    allowNewsletter: json["allowNewsletter"]??false,
    otpAuthentication:json["otpAuthentication"]!=null? List<String>.from(json["otpAuthentication"].map((x) => x)):[],
    subscriptionReminder: json["otpAuthentication"]!=null?List<String>.from(json["subscriptionReminder"].map((x) => x)):[],
  );

  Map<String, dynamic> toJson() => {
    "activatePinPassword": activatePinPassword,
    "activateTwoFactorAutentication": activateTwoFactorAutentication,
    "allowNotification": allowNotification,
    "allowNewsletter": allowNewsletter,
    "otpAuthentication": List<dynamic>.from(otpAuthentication!.map((x) => x)),
    "subscriptionReminder": List<dynamic>.from(subscriptionReminder!.map((x) => x)),
  };
}

class ThemeSetting {
  ThemeSetting({
    this.theme,
    this.platform,
    this.desc,
  });

  String? theme;
  String? platform;
  Desc? desc;

  factory ThemeSetting.fromJson(Map<String, dynamic> json) => ThemeSetting(
    theme: json["theme"]??"",
    platform: json["platform"]??"",
    desc:json["desc"]!=null? Desc.fromJson(json["desc"]):Desc(),
  );

  Map<String, dynamic> toJson() => {
    "theme": theme,
    "platform": platform,
    "desc": desc!.toJson(),
  };
}

class Desc {
  Desc({
    this.appbar,
    this.dailogColor,
    this.iconColor,
    this.primaryColor,
    this.secondryColor,
    this.fontColorTitle,
    this.fontColorSubtitle,
    this.fontColorHeading,
    this.backgroundColor,
    this.fontsizeHeading,
    this.fontsizeTitle,
    this.fontsizeSubTitle,

  });

  String? appbar;
  String? dailogColor;
  String? iconColor;
  String? primaryColor;
  String? secondryColor;
  String? fontColorTitle;
  String ?fontColorSubtitle;
  String ?fontColorHeading;
  String ?backgroundColor;
  double ?fontsizeHeading;
  double ?fontsizeTitle;
  double ?fontsizeSubTitle;


  factory Desc.fromJson(Map<String, dynamic> json) => Desc(
    appbar: json["Appbar"]??"",
    dailogColor: json["sideBar"]??"",
    iconColor: json["iconColor"]??"",
    primaryColor: json["primaryColor"]??"",
    secondryColor: json["secondryColor"]??"",
    fontColorTitle: json["fontColorTitle"]??"",
    fontColorSubtitle: json["fontColorSubtitle"]??"",
    fontColorHeading: json["fontColorHeading"]??"",
    backgroundColor: json["backgroundColor"]??"",
    fontsizeHeading:json["fontsizeHeading"]!=null? json["fontsizeHeading"].toDouble():20.0,
    fontsizeTitle:json["fontsizeTitle"]!=null? json["fontsizeTitle"].toDouble():16.0,
    fontsizeSubTitle:json["fontsizeSubTitle"]!=null? json["fontsizeSubTitle"].toDouble():14,
  );

  Map<String, dynamic> toJson() => {
    "Appbar": appbar,
    "dailogColor": dailogColor,
    "iconColor": iconColor,
    "primaryColor": primaryColor,
    "secondryColor": secondryColor,
    "fontColorTitle": fontColorTitle,
    "fontColorSubtitle": fontColorSubtitle,
    "fontColorHeading": fontColorHeading,
    "backgroundColor": backgroundColor,
    "fontsizeHeading": fontsizeHeading,
    "fontsizeTitle": fontsizeTitle,
    "fontsizeSubTitle": fontsizeSubTitle,

  };
}

