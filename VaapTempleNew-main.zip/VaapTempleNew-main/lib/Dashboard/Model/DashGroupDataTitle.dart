import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Model/DashboardSubTitleData.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/material.dart';
DashboardGroupTitleData dashboardGroupTitleDataFromJson(String str) => DashboardGroupTitleData.fromJson(json.decode(str));

String dashboardGroupTitleDataToJson(DashboardGroupTitleData data) => json.encode(data.toJson());
class DashboardGroupTitleData {
  String ?statusCode;
  String ?message;
  List<GroupDatum>? data;


  DashboardGroupTitleData({this.statusCode, this.message, this.data});

  DashboardGroupTitleData.fromJson(Map<String, dynamic> json) {
    statusCode = json['statusCode'];
    message = json['message'];
    if (json['data'] != null) {
      data =  [];
      json['data'].forEach((v) {
        data!.add(new GroupDatum.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['statusCode'] = this.statusCode;
    data['message'] = this.message;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class GroupDatum {
  String ?sId;
  String ?refDataName;
  String ?groupImage;
  String ?sequenceId;
  String ?code;
  String ?moduleName;
  String ?role;
  GlobalKey<ExpansionTileCardState>? group;
  bool? isExpanded;
  List<ChildGrid>? childGrid;

  GroupDatum(
      {this.sId,
        this.refDataName,
        this.groupImage,
        this.sequenceId,
        this.code,
        this.moduleName,
        this.group,
        this.role,
        this.childGrid,
       });

  GroupDatum.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    refDataName = json['refDataName'];
    groupImage = json['groupImage'];
    sequenceId = json['sequenceId'];
    code = json['code'];
    moduleName = json['moduleName'];
    group = json['group'];
    role=json['role'];
    childGrid=[];
    isExpanded=false;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['refDataName'] = this.refDataName;
    data['groupImage'] = this.groupImage;
    data['sequenceId'] = this.sequenceId;
    data['code'] = this.code;
    data['moduleName'] = this.moduleName;
    data['group'] = this.group;
    data['role'] = this.role;
    data['childGrid'] = this.childGrid;
    data['isExpanded'] = this.isExpanded;

    return data;
  }
}
