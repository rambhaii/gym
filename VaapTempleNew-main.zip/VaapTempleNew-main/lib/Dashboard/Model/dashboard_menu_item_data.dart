// To parse this JSON data, do
//
//     final dashBoardMenuItemData = dashBoardMenuItemDataFromJson(jsonString);

import 'dart:convert';

DashBoardMenuItemData dashBoardMenuItemDataFromJson(String str) => DashBoardMenuItemData.fromJson(json.decode(str));

String dashBoardMenuItemDataToJson(DashBoardMenuItemData data) => json.encode(data.toJson());

class DashBoardMenuItemData {
  DashBoardMenuItemData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<DashboardDatum>? data;

  factory DashBoardMenuItemData.fromJson(Map<String, dynamic> json) => DashBoardMenuItemData(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<DashboardDatum>.from(json["data"].map((x) => DashboardDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class DashboardDatum {
  DashboardDatum({
    this.id,
    this.refDataName,
    this.role,
    this.technicalChildData,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.aspectSource,
    this.aspectType,
    this.clientId,
    this.name,
    this.surname,
    this.moduleName,
    this.productId,
  });

  String? id;
  String? refDataName;
  String? role;
  List<TechnicalChildDatum> ?technicalChildData;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  String ?aspectSource;
  String ?aspectType;
  String ?clientId;
  String ?name;
  String ?surname;
  String ?moduleName;
  String ?productId;

  factory DashboardDatum.fromJson(Map<String, dynamic> json) => DashboardDatum(
    id: json["_id"],
    refDataName: json["refDataName"] == null ? null : json["refDataName"],
    role: json["role"] == null ? null : json["role"],
    technicalChildData: json["technicalChildData"] == null ? null : List<TechnicalChildDatum>.from(json["technicalChildData"].map((x) => TechnicalChildDatum.fromJson(x))),
    recCreBy: json["recCreBy"],
    recCreDate: json["recCreDate"],
    recModBy: json["recModBy"],
    recModDate: json["recModDate"],
    aspectSource: json["aspectSource"] == null ? null : json["aspectSource"],
    aspectType: json["aspectType"],
    clientId: json["clientID"],
    name: json["Name"] == null ? null : json["Name"],
    surname: json["Surname"] == null ? null : json["Surname"],
    moduleName: json["moduleName"] == null ? null : json["moduleName"],
    productId: json["productID"] == null ? null : json["productID"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "refDataName": refDataName == null ? null : refDataName,
    "role": role == null ? null : role,
    "technicalChildData": technicalChildData == null ? null : List<dynamic>.from(technicalChildData!.map((x) => x.toJson())),
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "aspectSource": aspectSource == null ? null : aspectSource,
    "aspectType": aspectType,
    "clientID": clientId,
    "Name": name == null ? null : name,
    "Surname": surname == null ? null : surname,
    "moduleName": moduleName == null ? null : moduleName,
    "productID": productId == null ? null : productId,
  };
}

class TechnicalChildDatum {
  TechnicalChildDatum({
    this.id,
    this.refDataName,
    this.status,
    this.icon,
    this.activePageName,
    this.predcessorPageName,
    this.successorPageName,
    this.statusName,
    this.editMode,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.technicalChildDatumId,
  });

  String ?id;
  String ?refDataName;
  String ?status;
  String ?icon;
  String ?activePageName;
  String ? predcessorPageName;
  String? successorPageName;
  String ?statusName;
  bool ?editMode;
  String? recCreBy;
  String? recCreDate;
  String? recModBy;
  String? recModDate;
  String? technicalChildDatumId;

  factory TechnicalChildDatum.fromJson(Map<String, dynamic> json) => TechnicalChildDatum(
    id: json["_id"],
    refDataName: json["refDataName"],
    status: json["status"],
    icon: json["icon"],
    activePageName: json["activePageName"],
    predcessorPageName: json["predcessorPageName"],
    successorPageName: json["successorPageName"],
    statusName: json["statusName"],
    editMode: json["editMode"],
    recCreBy: json["recCreBy"],
    recCreDate: json["recCreDate"],
    recModBy: json["recModBy"],
    recModDate: json["recModDate"],
    technicalChildDatumId: json["id"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "refDataName": refDataName,
    "status": status,
    "icon": icon,
    "activePageName": activePageName,
    "predcessorPageName": predcessorPageName,
    "successorPageName": successorPageName,
    "statusName": statusName,
    "editMode": editMode,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "id": technicalChildDatumId,
  };
}



