// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

SliderData sliderDataFromJson(String str) => SliderData.fromJson(json.decode(str));

String sliderDataToJson(SliderData data) => json.encode(data.toJson());

class SliderData {
  SliderData({
    this.success,
    this.data,
  });

  bool?success;
  List<Datum>?data;

  factory SliderData.fromJson(Map<String, dynamic> json) => SliderData(
    success: json["success"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.image,
    this.title,
    this.description,
  });

  String?image;
  String?title;
  String?description;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    image: json["image"],
    title: json["title"],
    description: json["description"],
  );

  Map<String, dynamic> toJson() => {
    "image": image,
    "title": title,
    "description": description,
  };
}
