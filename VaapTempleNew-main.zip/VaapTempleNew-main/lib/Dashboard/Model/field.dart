// To parse this JSON data, do
//
//     final fieldModel = fieldModelFromJson(jsonString);

import 'dart:convert';

import 'package:flutter/cupertino.dart';

FieldModel fieldModelFromJson(String str) => FieldModel.fromJson(json.decode(str));

String fieldModelToJson(FieldModel data) => json.encode(data.toJson());

class FieldModel {
  FieldModel({
    this.statusCode,
    this.message,
    this.data,
  });

  int? statusCode;
  String ?message;
  List<Datum> ?data;

  factory FieldModel.fromJson(Map<String, dynamic> json) => FieldModel(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.refDataName,
    this.date,
    this.moduleDescription,
    this.technicalChildData,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.clientId,
    this.productId,
    this.aspectSource,
    this.aspectType,
  });

  String? id;
  String? refDataName;
  String? date;
  String? moduleDescription;
  List<TechnicalChildDatum>? technicalChildData;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  String ?clientId;
  String ?productId;
  String ?aspectSource;
  String ?aspectType;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"],
    refDataName: json["refDataName"],
    date: json["date"],
    moduleDescription: json["moduleDescription"],
    technicalChildData: List<TechnicalChildDatum>.from(json["technicalChildData"].map((x) => TechnicalChildDatum.fromJson(x))),
    recCreBy: json["recCreBy"],
    recCreDate: json["recCreDate"],
    recModBy: json["recModBy"],
    recModDate: json["recModDate"],
    clientId: json["clientID"],
    productId: json["productID"],
    aspectSource: json["aspectSource"],
    aspectType: json["aspectType"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "refDataName": refDataName,
    "date": date,
    "moduleDescription": moduleDescription,
    "technicalChildData": List<dynamic>.from(technicalChildData!.map((x) => x.toJson())),
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "clientID": clientId,
    "productID": productId,
    "aspectSource": aspectSource,
    "aspectType": aspectType,
  };
}

class TechnicalChildDatum {
  TechnicalChildDatum({
    this.id,
    this.fieldType,
    this.fieldName,
    this.fieldLabel,
    this.mandatory,
    this.maxLength,
    this.listViewInd,
    this.technicalChildDatumId,
    this.textEditingController,
    this.selectedDropDownValue,
    this.image,
    this.dropDownList,
    this.dropDownValue,
    this.autoList,
    this.group,
    this.groupTitle,
    this.dropDownType,
    this.isReady,
    this.aspectType,
    this.checkBoxValue,

  });

  String ?id;
  String ?fieldType;
  String ?fieldName;
  String ?fieldLabel;
  String ?image;
  String ?dropDownType;
  String? mandatory;
  String ?maxLength;
  String? listViewInd;
  String? aspectType;
  bool? isReady;
  String ?technicalChildDatumId;
  TextEditingController?textEditingController;
  var selectedDropDownValue;
  List<Map>? dropDownList;
  List<String>? autoList;
  String?dropDownValue;
  String?group;
  bool?checkBoxValue;
  String?groupTitle;


  factory TechnicalChildDatum.fromJson(Map<String, dynamic> json) => TechnicalChildDatum(
    id: json["_id"]??"",
    fieldType: json["fieldType"]??"",
    fieldName: json["refDataName"]??"",
    fieldLabel: json["fieldLabelName"]??"",
    mandatory: json["mandatory"]??"",
    maxLength: json["maxLength"]??0,
    aspectType: json["aspectType"]??"",
    image: json["image"]??"",
    listViewInd: json["listViewInd"]??"",
    technicalChildDatumId: json["id"]??"",
    textEditingController: new TextEditingController(),
    dropDownValue: "",
    selectedDropDownValue: null,
    dropDownList:[],
    autoList:[],
    group:json["group"]??"",
    groupTitle:json["groupTitle"]??"",
    dropDownType:json["dropDownType"]??"",
    isReady:false,
    checkBoxValue:false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "fieldType": fieldType,
    "fieldName": fieldName,
    "fieldLabelName": fieldLabel,
    "mandatory": mandatory,
    "maxLength": maxLength,
    "listViewInd": listViewInd,
    "id": technicalChildDatumId,
    "aspectType": aspectType,
    "image": image,
    "dropDownValue": dropDownValue,
    "selectedDropDownValue": selectedDropDownValue,
    "dropDownList": dropDownList,
    "autoList": autoList,
    "groupTitle": groupTitle,
    "dropDownType": dropDownType,
    "isReady": isReady,
    "checkBoxValue": checkBoxValue,
  };
}




