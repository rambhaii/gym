// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';



KitchenOrderData kitchenOrderDataFromJson(String str) => KitchenOrderData.fromJson(json.decode(str));

String kitchenOrderDataToJson(KitchenOrderData data) => json.encode(data.toJson());

class KitchenOrderData {
  KitchenOrderData({
    this.success,
    this.name,
    this.email,
    this.phone,
    this.date,
    this.tithi,
    this.paksha,
    this.month,
    this.data,
  });

  bool?success;
  String?name;
  String?email;
  String?phone;
  String?date;
  String?tithi;
  String?paksha;
  String?month;
  List<Datum>?data;

  factory KitchenOrderData.fromJson(Map<String, dynamic> json) => KitchenOrderData(
    success: json["success"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    date: json["date"],
    tithi: json["tithi"],
    paksha: json["paksha"],
    month: json["month"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "name": name,
    "email": email,
    "phone": phone,
    "date": date,
    "tithi": tithi,
    "paksha": paksha,
    "month": month,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.datumId,
    this.tokenNo,
    this.customName,
    this.delivery,
    this.status,
    this.qty,
    this.itemName,
  });

  String?id;
  String?datumId;
  int?tokenNo;
  String?customName;
  String?delivery;
  String?status;
  String?qty;
  String?itemName;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"],
    datumId: json["id"],
    tokenNo: json["tokenNo"],
    customName: json["customName"],
    delivery: json["deliveryOption"],
    status: json["status"],
    qty: json["qty"],
    itemName: json["itemName"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "id": datumId,
    "tokenNo": tokenNo,
    "customName": customName,
    "delivery": delivery,
    "status": status,
    "qty": qty,
    "itemName": itemName,
  };
}
