// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString?);

import 'dart:convert';

CatOrderModel welcomeFromJson(String? str) => CatOrderModel.fromJson(json.decode(str!));

String? welcomeToJson(CatOrderModel data) => json.encode(data.toJson());

class CatOrderModel {
  CatOrderModel({
    this.success,
    this.name,
    this.email,
    this.phone,
    this.date,
    this.tithi,
    this.paksha,
    this.month,
    this.nakshatra,
    this.data,
  });

  bool? success;
  String? name;
  String? email;
  String? phone;
  String? date;
  String? tithi;
  String? paksha;
  String? month;
  String? nakshatra;
  List<Datum>? data;

  factory CatOrderModel.fromJson(Map<String?, dynamic> json) => CatOrderModel(
    success: json["success"],
    name: json["name"],
    email: json["email"],
    phone: json["phone"],
    date: json["date"],
    tithi: json["tithi"],
    paksha: json["paksha"],
    month: json["month"],
    nakshatra: json["nakshatra"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String?, dynamic> toJson() => {
    "success": success,
    "name": name,
    "email": email,
    "phone": phone,
    "date": date,
    "tithi": tithi,
    "paksha": paksha,
    "month": month,
    "nakshatra": nakshatra,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.datumId,
    this.date,
    this.tokenNo,
    this.customerName,
    this.status,
    this.deliveryOption,
    this.qty,
    this.itemName,
    this.image,
  });

  String? id;
  String? datumId;
  String? date;
  int? tokenNo;
  String? customerName;
  String? status;
  String? deliveryOption;
  String? qty;
  String? itemName;
  String? image;

  factory Datum.fromJson(Map<String?, dynamic> json) => Datum(
    id: json["_id"],
    datumId: json["id"],
    date: json["date"],
    tokenNo: json["tokenNo"],
    customerName: json["customerName"],
    status: json["status"],
    deliveryOption: json["deliveryOption"],
    qty: json["qty"],
    itemName: json["itemName"],
    image: json["image"],
  );

  Map<String?, dynamic> toJson() => {
    "_id": id,
    "id": datumId,
    "date": date,
    "tokenNo": tokenNo,
    "customerName": customerName,
    "status": status,
    "deliveryOption": deliveryOption,
    "qty": qty,
    "itemName": itemName,
    "image": image,
  };
}
