// To parse this JSON data, do
//
//     final dashboardSubTitleData = dashboardSubTitleDataFromJson(jsonString);

import 'dart:convert';

DashboardSubTitleData dashboardSubTitleDataFromJson(String str) => DashboardSubTitleData.fromJson(json.decode(str));

String dashboardSubTitleDataToJson(DashboardSubTitleData data) => json.encode(data.toJson());

class DashboardSubTitleData {
  DashboardSubTitleData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<Datum>? data;

  factory DashboardSubTitleData.fromJson(Map<String, dynamic> json) => DashboardSubTitleData(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.parent,
    this.childGrid,
    this.moduleName,

  });

  String ?id;
  Parent ?parent;
  List<ChildGrid>? childGrid;
  String ?moduleName;


  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"],
    parent: Parent.fromJson(json["Parent"]),
    childGrid: List<ChildGrid>.from(json["Child Grid"].map((x) => ChildGrid.fromJson(x))),
    moduleName: json["moduleName"],

  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "Parent": parent!.toJson(),
    "Child Grid": List<dynamic>.from(childGrid!.map((x) => x.toJson())),
    "moduleName": moduleName,
  };
}

class ChildGrid {
  ChildGrid({
    this.groupName,
    this.menuImage,
    this.refDataName,
    this.backendName,
    this.status,
    this.sequenceId,
  });

  String ?groupName;
  String ?menuImage;
  String ?refDataName;
  String ?backendName;
  String ?sequenceId;
  String ?status;

  factory ChildGrid.fromJson(Map<String, dynamic> json) => ChildGrid(
    groupName: json["Group Name"]??"",
    menuImage: json["Menu Image"]??"",
    refDataName: json["refDataName"]??"",
    backendName: json["backendName"]??"",
    sequenceId: json["sequenceId"]??"",
    status: json["status"]??"ACTIVE",
  );

  Map<String, dynamic> toJson() => {
    "Group Name": groupName,
    "Menu Image": menuImage,
    "refDataName": refDataName,
    "backendName": backendName,
    "status": status,
    "sequenceId": sequenceId,
  };
}

class Parent {
  Parent({
    this.refDataName,
    this.sequenceId,
  });

  String ?refDataName;
  String? sequenceId;

  factory Parent.fromJson(Map<String, dynamic> json) => Parent(
    refDataName: json["refDataName"],
    sequenceId: json["sequenceId"],
  );

  Map<String, dynamic> toJson() => {
    "refDataName": refDataName,
    "sequenceId": sequenceId,
  };
}
