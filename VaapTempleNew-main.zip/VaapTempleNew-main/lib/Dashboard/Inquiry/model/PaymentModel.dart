// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

PaymentModel paymentModelFromJson(String str) => PaymentModel.fromJson(json.decode(str));

String paymentModelToJson(PaymentModel data) => json.encode(data.toJson());

class PaymentModel {
  PaymentModel({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<PaymentDatum>? data;

  factory PaymentModel.fromJson(Map<String, dynamic> json) => PaymentModel(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<PaymentDatum>.from((json["data"]??"").map((x) => PaymentDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class PaymentDatum {
  PaymentDatum({
    this.id,
    this.memberId,
    this.memberName,
    this.prsnEmail,
    this.prsnPhone,
    this.paymentType,
    this.bankName,
    this.chequeNo,
    this.chequeAmount,
    this.chequeDate,
    this.totalAmount,
    this.transactionId,
    this.paymentStatus,
    this.recLinkIdDate,
    this.recLinkId,
    this.source,
    this.subjectArea,
    this.tokenNumber,
    this.batchNo,

    this.aspectType,
    this.transactionStatus,
    this.paymentsData,
    this.deliveryDate,
    this.delivery,
    this.etKitchenTIp,
    this.pickupTime,
    this.recCreDate,
    this.isChecked,
  });

  String? id;
  String? memberId;
  String? memberName;
  String? prsnEmail;
  String? prsnPhone;
  String? paymentType;
  String? bankName;
  String?chequeNo;
  String? chequeAmount;
  String? chequeDate;
  var  totalAmount;
  String? transactionId;
  String? paymentStatus;
  String? recLinkIdDate;
  String? recLinkId;
  bool? isChecked;
  String? recCreDate;
  String? source;
  String? subjectArea;
  var tokenNumber;
  var batchNo;

  String? aspectType;
  String? transactionStatus;
  List<PaymentsData>? paymentsData;
  String? deliveryDate;
  String? delivery;
  String? etKitchenTIp;
  String? pickupTime;

  factory PaymentDatum.fromJson(Map<String, dynamic> json) => PaymentDatum(
    id: json["_id"]??"",
    memberId: json["memberId"]??"",
    memberName: json["memberName"]??"",
    prsnEmail: json["prsnEmail"]??"",
    prsnPhone: json["prsnPhone"]??"",
    paymentType: json["paymentType"]??"",
    bankName: json["bankName"]??"",
    chequeNo: json["chequeNo"]??"",
    chequeAmount: json["chequeAmount"]??"",
    chequeDate: json["chequeDate"]??"",
    totalAmount: json["totalAmount"].toString(),
    transactionId: json["transactionId"]??"",
    paymentStatus: json["paymentStatus"]??"",
    recLinkIdDate: json["recLinkIdDate"]??"",
    recLinkId: json["recLinkId"]??"",
      recCreDate: json["recCreDate"]??"",
    source: json["source"]??"",
    subjectArea: json["subjectArea"]??"",
    tokenNumber: json["tokenNumber"]??"",
    batchNo: json["batchNo"]??"",

    aspectType: json["aspectType"]??"",
    transactionStatus: json["transactionStatus"]??"",
    paymentsData: List<PaymentsData>.from((json["paymentsData"]).map((x) => PaymentsData.fromJson(x))),
    deliveryDate: json["deliveryDate"]??"",
    delivery: json["delivery"]??"",
    etKitchenTIp: json["etKitchenTIp"]??"" ,
    pickupTime: json["pickupTime"]??"",
      isChecked: false
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "memberId": memberId,
    "memberName": memberName,
    "prsnEmail": prsnEmail,
    "prsnPhone": prsnPhone,
    "paymentType": paymentType,
    "bankName": bankName,
    "chequeNo": chequeNo,
    "chequeAmount": chequeAmount,
    "chequeDate": chequeDate,
    "totalAmount": totalAmount,
    "transactionId": transactionId,
    "paymentStatus": paymentStatus,
    "recLinkIdDate": recLinkIdDate,
    "recLinkId": recLinkId,
    "source": source == null ? null : source,
    "subjectArea": subjectArea,
    "tokenNumber": tokenNumber,
    "batchNo": batchNo,
    "aspectType": aspectType,
    "transactionStatus": transactionStatus,
    "paymentsData": List<dynamic>.from(paymentsData!.map((x) => x.toJson())),
    "deliveryDate": deliveryDate,
    "delivery": delivery ,
    "etKitchenTIp": etKitchenTIp ,
    "pickupTime": pickupTime,
    "recCreDate": recCreDate,
    "isChecked": isChecked
  };
}

class PaymentsData {
  PaymentsData({
    this.serviceDate,
    this.time,
    this.day,
    this.qty,
    this.serviceAmount,
    this.serviceName,
    this.statusName,
    this.tokenNumber,
    this.batchNo,
    this.id,
    this.bookingTime,
    this.source,
    this.isChecked,
  });

  String ?serviceDate;
  String ?time;
  String ?day;
  var qty;
  var serviceAmount;
  String ?serviceName;
  String? statusName;
  var tokenNumber;
  var batchNo;
  var id;
  bool? isChecked;
  var bookingTime;
  String? source;



  factory PaymentsData.fromJson(Map<String, dynamic> json) => PaymentsData(
    serviceDate: json["serviceDate"]??"",
    time: json["time"]??"",
    day:json["day"]??"",
    qty: json["qty"]??"",
    serviceAmount: json["serviceAmount"]??"",
    serviceName: json["serviceName"]??json["ServiceSetup"]??"",
    statusName: json["statusName"]??"",
    tokenNumber: json["tokenNumber"]??"",
    batchNo: json["batchNo"]??"",
    id: json["_id"]??"",
    bookingTime: json["bookingTime"]??"",
    source: json["source"]??"",
    isChecked: false,
   );

  Map<String, dynamic> toJson() => {
    "serviceDate": serviceDate,
    "time": time,
    "day": day,
    "qty": qty,
    "serviceAmount": serviceAmount,
    "serviceName": serviceName,
    "statusName": statusName,
    "tokenNumber": tokenNumber,
    "batchNo": batchNo,
    "_id": id,
    "bookingTime": bookingTime,
    "source": source,
    "isChecked": isChecked,

  };
}


