import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Inquiry/view/MenuInquiry.dart';
import 'package:aspgen_mobile/Dashboard/Inquiry/view/PaymentInqirey.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../UtilMethods/base_client.dart';
import '../../Contact/Model/AllContactDatas.dart';
import '../../Devotee/DevoteePage.dart';
import '../../Services/Model/ServiceData.dart';
import '../view/AssetsInquiery.dart';
import '../view/InventoryInquiry.dart';
import '../view/NewDevoteeInquiryPage.dart';
import '../view/Booking_history.dart';
import '../view/ServiceInquiry.dart';
class InquiryController extends GetxController with GetSingleTickerProviderStateMixin {
  InquiryController({required this.type});
  final int type;
  Rx<AllContactDatas> allContactDatas= AllContactDatas().obs;
  RxList<Map> map=RxList([]);
  Rx<List<ServiceDatum>> servicedata= Rx<List<ServiceDatum>>([]);
  Rx<List<ServiceDatum>> filterservicedata= Rx<List<ServiceDatum>>([]);
  DateTimeRange? pickedRangeDate;
  final DateFormat showDateformatter = DateFormat('EE, MMM dd');
  TextEditingController etSearch= new TextEditingController();
  TextEditingController etAmount= new TextEditingController();
   RxString rxCustomerName="".obs;
   RxString rxServiceDate="Select Date Range".obs;
  var selectedValue;
 var etsearch=new TextEditingController().obs;
  RxString date = "".obs;
  RxInt nextdate = 1.obs;
  RxInt previousdate = 1.obs;
  late TabController tabController;
  RxBool isSearchVisible=false.obs;
  RxBool isDateRangeVisible=false.obs;
  var rxCalFormate=CalendarFormat.week.obs;

  final DateFormat formatter = DateFormat('MM/dd/yyyy');
   String nextPreviousDate="";
  var selectedCategory="".obs;
  var setectedType="".obs;
  var message="".obs;
  RxList<String> caltegoryList=   RxList<String>([]);
  RxList<String> typeList= RxList<String>([]);
  var bodyJson={};
  @override
  void onInit() {
    pickedRangeDate=DateTimeRange(start: DateTime.now(), end: DateTime.now());
    // TODO: implement onInit
   // fetchApi();
    if(type==2)
      {
        //getFilterApiCu("DEVOTEE");
      }
    getDate();
    getServiceCategory(1);
    getInquieryData("");
    super.onInit();
  }
  getFilterApiCu(String membetType)async{
    var request={
      "text": membetType,
      "componentConfig": {
        "moduleName":"Contacts",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    allContactDatas.value=allContactDatasFromJson(response);
    if(allContactDatas.value.data!.isEmpty)
    {
      return;
      // Get.snackbar("No Data", "No Data Available",backgroundColor: Colors.amber.withOpacity(0.5),borderRadius: 5);
    }
    else{
      allContactDatas.value.data!.forEach((element) {
        map.add({"name":element.refDataName,"email":element.email,"phone":element.phone});
      });
    }
    map.refresh();
  }
  getInquieryData(String customerEmailPhone)async{
    bodyJson["componentConfig"]={
      "moduleName":"Calendar",
      "aspectType": "Service Schedules",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      if(!customerEmailPhone.contains("@") && _isNumeric(customerEmailPhone)==false  && type!=4)"text":customerEmailPhone,

      "query":(type==2 || type==3)?
      {
        if(type==2)"aspectType":"Service Schedules",
        if(type==3)"aspectType":"serviceBooking",
        if(type==3)"serviceCategory": "RENTAL",
        if(type==2 && customerEmailPhone.contains("@") && !_isNumeric(customerEmailPhone)) "customerEmail":UtilMethods.encrypt(customerEmailPhone),
        if(type==2 && !customerEmailPhone.contains("@")   && _isNumeric(customerEmailPhone)) "customerPhone":UtilMethods.encrypt(customerEmailPhone),
        if(type==2) if(pickedRangeDate != null)"serviceDate": {
      '\$lte': formatter.format(pickedRangeDate!.end),
      '\$gte':formatter.format(pickedRangeDate!.start)
      },
        if(type==3) if(pickedRangeDate != null)"recCreDate":{
          '\$lte': formatter.format(pickedRangeDate!.end),
          '\$gte':formatter.format(pickedRangeDate!.start)
        },
        if(selectedCategory.value.isNotEmpty)"serviceCategoryTypes":selectedCategory.value,
        if(setectedType.value.isNotEmpty)  "serviceTypes":setectedType.value,
        if(etAmount.text.isNotEmpty) "serviceAmount":etAmount.text.replaceAll("\$", "").replaceAll(",", "")
      }:{
        //,{"aspectType": "serviceBooking"},
        "\$or":[{"aspectType": "Service Schedules"}, {"serviceCategoryTypes": "IN-TEMPLE"}, {"serviceCategoryTypes": "AWAY-TEMPLE"},{"serviceCategoryTypes": "EVENTS"},
          {"serviceCategoryTypes": "SHARADAM"},
          {"serviceCategoryTypes": "RENTAL"}],

        if(pickedRangeDate != null)"recCreDate":{
          '\$lte': formatter.format(pickedRangeDate!.end),
          '\$gte':formatter.format(pickedRangeDate!.start)
        },
        if(customerEmailPhone.contains("@") && !_isNumeric(customerEmailPhone)) "customerEmail":UtilMethods.encrypt(customerEmailPhone),
        if(!customerEmailPhone.contains("@")   && _isNumeric(customerEmailPhone)) "customerPhone":UtilMethods.encrypt(customerEmailPhone),

        if(selectedCategory.value.isNotEmpty)"serviceCategoryTypes":selectedCategory.value,
        if(setectedType.value.isNotEmpty)  "serviceTypes":setectedType.value,

      },
      "skip":0,
      "next":500
    };
    //"aspectType":"Service Schedules",
    print("dsvhbjvds");
    print(bodyJson);
      Get.context!.loaderOverlay.show();
      var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
      Get.context!.loaderOverlay.hide();

      if(response==null) return;
      if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    servicedata.value=ServiceData.fromJson(jsonDecode(response)).data!;
    filterservicedata.value=ServiceData.fromJson(jsonDecode(response)).data!;
    print("dsvhbjvds");
    print(response);
    if(jsonDecode(response)["data"].isEmpty)
      {
        Fluttertoast.showToast(msg: "No Data Available");
      }
  }

  getRoute(String value){
     switch(value){
       case "Devotee":
         Get.to(()=>DevoteePage(title: value, displayName: value+" Inquiry",));
         break;
         case "Bookings":
           Get.to(()=>BookingHistoryPage(title: "Booking Inquiry",type: 1,));
         break;
         case "Payments":
           Get.to(()=>PaymentInquiryPage(title: "Payments Inquiry",type: 1,));
         break;
         case "Services":
           Get.to(()=>ServiceInquiryPage());
         break;
         case "Inventory":
           Get.to(()=>InventoryInquiry(title: 'Inventory Inquiry',));
         break;
         case "Assets":
           Get.to(()=>AssetInquieryPage(title: 'Assets Inquiry',));
         break;
         case "Menus":
           Get.to(()=>MenuInquiryPage(title: 'Menus Inquiry',));
         break;

     }
  }
  getServiceCategory(int type)async{
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "serviceCategoryTypes",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "serviceCategoryTypes"},
      "skip":0,
      "next":100
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      caltegoryList.value.add(element["refDataName"]);
    });
    tabController = TabController(length: caltegoryList.length, vsync: this);
    caltegoryList.refresh();
  }
  getServiceType(String refdata)async{
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "serviceTypes",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "serviceTypes","refDataCode":refdata},
      "skip":0,
      "next":100
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;

    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      typeList.value.add(element["refDataName"]);
    });
    typeList.refresh();
  }

    // filterData(String search){
    //   List<String> result=[];
    //   if(search.isEmpty)
    //   {
    //     result=filterList;
    //   }
    //   else{
    //     result=filterList.where((element) =>element.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    //   }
    //   inquiryList.value=result;
    // }
  bool _isNumeric(String str) {
    if(str == null) {
      return false;
    }
    return double.tryParse(str) != null;
  }



  getDate() {
    final String formatted = showDateformatter.format(DateTime.now());
    nextPreviousDate = formatter.format(DateTime.now());
    print("sdkjbjklbklds");
    print(nextPreviousDate);
    date.value = formatted;
  }

  getNextDate() {
    DateTime tempDate = new DateFormat('EE, MMM dd').parse(date.value);
    DateTime nextDate = new DateFormat('MM/dd/yyyy').parse(nextPreviousDate);
    final String formatted  = showDateformatter.format(tempDate.add(Duration(days: nextdate.value)));
    final String parseNextDate = formatter.format(nextDate.add(Duration(days: nextdate.value)));
    nextPreviousDate=parseNextDate;
    pickedRangeDate=DateTimeRange(start:formatter.parse(nextPreviousDate) ,end:formatter.parse(nextPreviousDate) );
    getInquieryData(etSearch.text);
    print("sbdvbsudovbods"+nextPreviousDate);
    date.value = formatted;
  }

  getPreviousDate() {
    DateTime tempDate = new DateFormat('EE, MMM dd').parse(date.value);
    DateTime previousDate = new DateFormat('MM/dd/yyyy').parse(nextPreviousDate);
    final String formatted = showDateformatter.format(tempDate.subtract(Duration(days: previousdate.value)));
    final String parsePrevDate = formatter.format(previousDate.subtract(Duration(days: previousdate.value)));
    nextPreviousDate=parsePrevDate;
    pickedRangeDate=DateTimeRange(start:formatter.parse(nextPreviousDate) ,end:formatter.parse(nextPreviousDate) );
    getInquieryData(etSearch.text);
    date.value = formatted;
  }
}