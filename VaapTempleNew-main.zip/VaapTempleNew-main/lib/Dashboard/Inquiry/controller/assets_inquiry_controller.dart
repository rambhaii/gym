import 'dart:convert';

import 'dart:io';

import 'package:aspgen_mobile/Dashboard/AssetsManagemant/Module/assets_mgmt_data.dart';
import 'package:aspgen_mobile/Dashboard/inventory_page/InventoryList.dart';
import 'package:aspgen_mobile/Dashboard/inventory_page/model/InventoryData.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:path_provider/path_provider.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
class AssetInquiryController extends GetxController{
  var datas= AssetData().obs;
  TextEditingController etSearch= new TextEditingController();
  TextEditingController etAmount= new TextEditingController();

  var bodyJson={};
  var selectedCategory="".obs;
  var setectedType="".obs;
  RxString rxServiceDate="Select Date Range".obs;
  var message="".obs;
  RxList<String> caltegoryList=   RxList<String>([]);
  RxList<String> typeList= RxList<String>([]);
  var pickedRangeDate;
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  @override
  void onInit() {
    getCategory();
    // TODO: implement onInit
    super.onInit();
  }

  fetchApi(String text)async{
    bodyJson["componentConfig"]={
      "moduleName":"Asset Management",
      "aspectType": "Asset Management",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      if(text.isNotEmpty)"text":text,
      "query":{
        "aspectType":"Asset Management",
        if(selectedCategory.value.isNotEmpty)"assetCategory":selectedCategory.value,
        if(setectedType.value.isNotEmpty) "assetType":setectedType.value,
        if(pickedRangeDate != null)"purchasedDate":{
          '\$lte': formatter.format(pickedRangeDate.end),
          '\$gte':formatter.format(pickedRangeDate.start)
        },
        if(etAmount.text.isNotEmpty) "purchasePrice":etAmount.text.replaceAll("\$", "").replaceAll(",", "")
       // if(rxServiceDate.value!="Select Date") "purchasedDate":rxServiceDate.value
      },
      "skip":0,
      "next":400
    };
    print("dfnkndond");
    print(bodyJson);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    print("dvds bvjksdb"+response);
    datas.value=assetDataFromJson(response);
    if(datas.value.data!.isEmpty){
      message.value="No Data Available!";
    }
  }
  fetchFilterApi(String text)async{
    var request={
      "text": text,
      "componentConfig": {
        "moduleName":"Asset Management",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    datas.value=assetDataFromJson(response);

  }
  getCategory()async{
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "assetCategory",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "assetCategory"},
      "skip":0,
      "next":100
    };
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      caltegoryList.value.add(element["refDataName"]);
    });
    caltegoryList.refresh();
  }
  getType(String refdata)async{
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "assetType",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "assetType","refDataCode":refdata},
      "skip":0,
      "next":100
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;

    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      typeList.value.add(element["refDataName"]);
    });
    typeList.refresh();
  }

}