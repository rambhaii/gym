import 'dart:convert';

import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
import '../../Contact/Model/AllContactDatas.dart';
import '../../Services/Model/ServiceData.dart';
import '../model/PaymentModel.dart';
class PaymentController extends GetxController{
  PaymentController({required this.type});
 final int type;
  Rx<AllContactDatas> allContactDatas= AllContactDatas().obs;
  RxList<Map> map=RxList([]);
  Rx<List<PaymentDatum>> servicedata= Rx<List<PaymentDatum>>([]);
  Rx<List<PaymentDatum>> paymentdata= Rx<List<PaymentDatum>>([]);
  var detailsdata= PaymentDatum().obs;
  RxBool isSearchVisible=false.obs;
  TextEditingController etSearch= new TextEditingController();
  TextEditingController etAmount= new TextEditingController();
  RxString rxCustomerName="".obs;
  RxString rxServiceDate="Select Date Range".obs;
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  var selectedValue;
  var selectedType="".obs;
  var selectedStatus="".obs;
  var message="".obs;
  List<String> paymentTypeList=['CHECK', 'CASH',"CREDIT CARD"];
  List<String> paymentStatusList=['INITIATED','COMPLETED', 'CANCEL'];
  DateTimeRange? pickedRangeDate;


  List inquiryList=[
    "Devotee Booking Inquiry",
    "Devotee Payment Inquiry",
    "Booking Inquiry",
    "Payment Inquiry",
    "Service Inquiry",
    "Inventory Inquiry"

  ];
  var bodyJson={};
  @override
  void onInit() {
    pickedRangeDate=DateTimeRange(start: DateTime.now(), end: DateTime.now());

    // TODO: implement onInit
    // fetchApi();

    super.onInit();
  }

  getFilterApiCu(String membetType)async{
    var request={
      "text": membetType,
      "componentConfig": {
        "moduleName":"Contacts",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    allContactDatas.value=allContactDatasFromJson(response);
    if(allContactDatas.value.data!.isEmpty)
    {
      return;
      // Get.snackbar("No Data", "No Data Available",backgroundColor: Colors.amber.withOpacity(0.5),borderRadius: 5);
    }
    else{
      allContactDatas.value.data!.forEach((element) {
        map.add({"name":element.refDataName,"email":element.email,"phone":element.phone});
      });
    }
    map.refresh();
  }
  getInquieryData(String customerName)async{
    bodyJson["componentConfig"]={
      "moduleName":"Payments",
      "aspectType": "Payments",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{"aspectType":"Payments","memberName":customerName},
      "skip":0,
      "next":100
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();

    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    if(jsonDecode(response)["data"].isEmpty)
    {
      Fluttertoast.showToast(msg: "No Data Available");
      message.value="No Data Available!";
    }
    servicedata.value=paymentModelFromJson(response).data!;

  }
  getPaymentData(String emailOrPhone)async{
    bodyJson["componentConfig"]={
      "moduleName":"Payments",
      "aspectType": "Payments",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      if(!emailOrPhone.contains("@") && _isNumeric(emailOrPhone)==false  && type!=4 && emailOrPhone.isNotEmpty)"text":emailOrPhone,
      "query":type==1?{"aspectType":"Payments",
        if(emailOrPhone.contains("@") &&
            !_isNumeric(emailOrPhone)) "prsnEmail": UtilMethods.encrypt(
            emailOrPhone),
        if(!emailOrPhone.contains("@") &&
            _isNumeric(emailOrPhone)) "prsnPhone": UtilMethods.encrypt(
            emailOrPhone),
        if(pickedRangeDate != null)'recCreDate': {
          '\$lte': formatter.format(pickedRangeDate!.end),
          '\$gte':formatter.format(pickedRangeDate!.start)
        },
      } :
      {"aspectType": "Payments",
        if(emailOrPhone.contains("@") &&
            !_isNumeric(emailOrPhone)) "prsnEmail": UtilMethods.encrypt(
            emailOrPhone),
        if(!emailOrPhone.contains("@") &&
            _isNumeric(emailOrPhone)) "prsnPhone": UtilMethods.encrypt(
            emailOrPhone),
        if(pickedRangeDate != null)'recCreDate': {
          '\$lte': formatter.format(pickedRangeDate!.end),
          '\$gte':formatter.format(pickedRangeDate!.start)
        },
      },
      "skip":0,
      "next":500
    };
    print("dvjskvbsjbvsd");
    print(bodyJson);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") {
      message.value=jsonDecode(response)["message"];
     return;
    }if(jsonDecode(response)["data"].isEmpty) {
      message.value="No Data Available!";

    }
    // print("hdsvjhsv");
    // print(response);
    paymentdata.value=paymentModelFromJson(response).data!;

  }
  bool _isNumeric(String str) {
    if(str == null) {
      return false;
    }
    return double.tryParse(str) != null;
  }
}