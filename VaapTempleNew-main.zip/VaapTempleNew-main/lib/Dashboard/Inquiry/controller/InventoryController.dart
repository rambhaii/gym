import 'dart:convert';
import 'package:aspgen_mobile/Dashboard/inventory_page/model/InventoryData.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';

class InventoryInquiryController extends GetxController{
  var inventoryData= InventoryData().obs;
  TextEditingController etSearch= new TextEditingController();
  var selectedCategory="".obs;
  var setectedType="".obs;
  var pickedRangeDate;
  RxString rxServiceDate="Select Date Range".obs;
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  TextEditingController etAmount= new TextEditingController();
  RxList<String> typeList= RxList<String>([]);

  var message="".obs;
  RxList<String> caltegoryList=   RxList<String>([]);
  var bodyJson={};
  @override
  void onInit() {

    fetchApi();
    getServiceCategory();
    // TODO: implement onInit
    super.onInit();
  }
  getServiceCategory() async {
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "itemCategory",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "itemCategory"},
      "skip":0,
      "next":200
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      caltegoryList.value.add(element["refDataName"]);
    });
    caltegoryList.refresh();
  }
  fetchApi() async {
    bodyJson["componentConfig"]={
      "moduleName":"Inventory",
      "aspectType": "inventory",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      if(etSearch.text.isNotEmpty)"text":etSearch.text,
      "query":{"aspectType":"inventory",
        if(selectedCategory.value.isNotEmpty)"itemCategory":selectedCategory.value
      },
      "skip":0,
      "next":100
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    inventoryData.value=inventoryDataFromJson(response);
    if(inventoryData.value.data!.isEmpty)
      {
        message.value="No Data Available! ";
      }
  }

}