import 'dart:convert';
import 'package:aspgen_mobile/Dashboard/Menu/Model/MenuData.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';
import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';

class MenuInquiryController extends GetxController{
  MenuInquiryController(this.titile);
  final String titile;
  var menuData= MenuData().obs;
  var selectedCategory="".obs;
  var setectedType="".obs;
  var message="".obs;
  RxList<String> caltegoryList=   RxList<String>([]);
  RxList<String> typeList= RxList<String>([]);
  TextEditingController etSearch= new TextEditingController();
  var bodyJson={};
  @override
  void onInit() {

    // TODO: implement onInit
    fetchApi("");
    getCategory();
    super.onInit();
  }
  fetchApi(String text)async{
    {
      bodyJson["componentConfig"]={
        "moduleName":"Menu",
        "aspectType": "menu",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
       if(text.isNotEmpty)"text":text,
        "query":{
          "aspectType":"menu",
          if(selectedCategory.value.isNotEmpty)"menuCategory":selectedCategory.value,
          if(setectedType.value.isNotEmpty) "menuType":setectedType.value

        },
        "skip":0,
        "next":400
      };
      print(bodyJson);
      Get.context!.loaderOverlay.show();
      var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
      Get.context!.loaderOverlay.hide();
      if(response==null) return;
      if(jsonDecode(response)["statusCode"].toString()=="-1") return;
      menuData.value=menuDataFromJson(response);
      if(menuData.value.data!.isEmpty)
        {
          message.value="No Data Available!";
        }
    }
  }
  fetchFilterApi(String text)async{
    var request={
      "text": text,
      "componentConfig": {
        "moduleName":titile,
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),

      }
    };
    print("vgjvgjvjgyju");
    print(request);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("dsjkvkjdsv");
    print(response);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    menuData.value=menuDataFromJson(response);
    if(menuData.value.data!.isEmpty)
    {
      message.value="No Data Available!";
    }
  }
  getCategory()async{
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "menuCategory",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "menuCategory"},
      "skip":0,
      "next":400
    };
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      caltegoryList.value.add(element["refDataName"]);
    });
    caltegoryList.refresh();
  }
  getType(String refdata)async{
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "menuType",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "menuType","refDataCode":refdata},
      "skip":0,
      "next":100
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;

    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      typeList.value.add(element["refDataName"]);
    });
    typeList.refresh();
  }

}