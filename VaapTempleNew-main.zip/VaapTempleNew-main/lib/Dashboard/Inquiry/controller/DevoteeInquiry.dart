
import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/UtilMethods/BaseController.dart';
import 'package:aspgen_mobile/UtilMethods/base_client.dart';
import 'package:dart_des/dart_des.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../UtilMethods/dailog_healper.dart';
import '../../Contact/Model/AllContactDatas.dart';

class DevoteeInquiryController extends GetxController {
  DevoteeInquiryController({required this.type});
  final int type;
  List<String> menuList=[
    "BOOKINGS",
    "PAYMENTS"
  ];
  RxList<ContactDatum> allContactDatas= RxList<ContactDatum>([]);
  // RxList<ContactDatum> filterContactDatas= RxList<ContactDatum>([]);
  RxList<ContactDatum> allFilterContactDatas= RxList<ContactDatum>([]);
  ScrollController controller = ScrollController();
  TextEditingController etSearch=new TextEditingController();
  TextEditingController etName=new TextEditingController();
  TextEditingController etPhone=new TextEditingController();
  TextEditingController etEmail=new TextEditingController();
  int skip=1;
  int next = 50;
  var bodyJson={};
  var bodyJson1={};
  RxBool isLoading=false.obs;
  RxBool isLoadMore=false.obs;
  RxBool isSerching=false.obs;
  // List<ContactDatum> get allContactData=>allContactDatas.value;
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":"Contacts",
      "aspectType": "Member Directory",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{"aspectType":"Member Directory","memberTypes":"DEVOTEE"},
      "skip":0,
      "next":200
    };
   fetchApi(bodyJson);
    super.onInit();
  }
  fetchApi(var bodyJson)async{
    print("bvdjbvjkbdsf");
    print(bodyJson);
    isLoadMore.value==false? Get.context!.loaderOverlay.show():"";
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    print("dsvcjhdsvcdshsj");
    print(response);
    if(AllContactDatas.fromJson(jsonDecode(response)).data!.isNotEmpty)
    {
      allContactDatas.value=allContactDatasFromJson(response).data!;
      allFilterContactDatas.value=allContactDatasFromJson(response).data!;
    }
    else{
      Fluttertoast.showToast(msg: "No data available");
    }
  }
  void filterData(String search){
    List<ContactDatum> result=[];
    if(search.isEmpty)
    {
      result=allFilterContactDatas.value;
    }
    else{
      result=allFilterContactDatas.value.where((element) =>element.refDataName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    allContactDatas.value=result;
  }
  fetchFilterApi(String filterData)async{
    allContactDatas.value=[];
    bodyJson1["componentConfig"]={
      "moduleName":"Contacts",
      "aspectType": "Member Directory",
      if(!filterData.contains("@") && _isNumeric(filterData)==false)"text":filterData,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":filterData.contains("@")?{"aspectType":"Member Directory","memberTypes":"DEVOTEE","email":UtilMethods.encrypt(filterData)}
          :{"aspectType":"Member Directory","memberTypes":"DEVOTEE",
        if(_isNumeric(filterData))"phone":UtilMethods.encrypt(filterData),

      },
      "skip":0,
      "next":200
    };
    isLoadMore.value==false? Get.context!.loaderOverlay.show():"";
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson1).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;

    if(AllContactDatas.fromJson(jsonDecode(response)).data!.isNotEmpty)
    {
      allContactDatas.value=allContactDatasFromJson(response).data!;
      allFilterContactDatas.value=allContactDatasFromJson(response).data!;
    }
    else{
      Fluttertoast.showToast(msg: "No more data");
    }
  }
  bool _isNumeric(String str) {
    if(str == null) {
      return false;
    }
    return double.tryParse(str) != null;
  }
}