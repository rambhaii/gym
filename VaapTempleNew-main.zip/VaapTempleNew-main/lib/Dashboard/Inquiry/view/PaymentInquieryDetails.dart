
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/LabaleListWidget.dart';
import '../controller/payment_controller.dart';



class DetailsPaymentInquiryPage extends StatefulWidget {
  final String title;
  const DetailsPaymentInquiryPage({Key? key, required this.title}) : super(key: key);

  @override
  _DetailsPaymentInquiryPageState createState() => _DetailsPaymentInquiryPageState();
}

class _DetailsPaymentInquiryPageState extends State<DetailsPaymentInquiryPage> {

  late PaymentController _controller;
  DateTime?tempDate;
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  @override
  void initState() {
    _controller=  Get.find();

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title+"'s Services",
        ),
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          children: [SizedBox(height: 8,),
            Obx(()=> _controller.detailsdata.value.paymentsData!.isNotEmpty?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {

                  });
                },
                child: ListView.builder(
                    itemCount:_controller.detailsdata.value.paymentsData!.length,
                    itemBuilder: (context,index)
                    {

                      final datas=_controller.detailsdata.value.paymentsData![index];
                      return LableListShowOnlyWidget(title: datas.serviceName??"",
                        subTitle:amountParser(datas.serviceAmount.toString()) ,
                       titlelable: "Service Name",
                       subTitleLable: "Amount",
                        subTitle3: datas.statusName.toString(),
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              if(datas.day!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datas.day!.isNotEmpty) viewMore("Day  ",datas.day.toString()??""),
                              if(datas.qty!.toString().isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.3),),
                              if(datas.qty!.toString().isNotEmpty) viewMore("Quantity ",datas.qty.toString()??""),
                            ]),
                        textEditingController: _controller.etSearch,isClicked: datas.isChecked!??false,
                        onTapVieMore: (){
                          datas.isChecked=!datas.isChecked!;
                          _controller.detailsdata.refresh();
                        },
                        editOnTap: (){

                        },
                      );

                    }),
              ),
            ):Container(),)

          ],
        ),
      ),
    );
  }

}
