
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../UtilMethods/Utils.dart';
import '../../../Widget/CustomListshowOnly.dart';
import '../../../Widget/DropdownButtonWidget.dart';
import '../../../Widget/SearchBarWidget.dart';
import '../../Services/Model/ServiceData.dart';
import '../controller/InquiryController.dart';



class RentalPage extends StatefulWidget {
  final String title;
  final int type;//1 for inquiery 2 for devotee  3 for rental
  const RentalPage({Key? key, required this.title, required this.type}) : super(key: key);

  @override
  _RentalPageState createState() => _RentalPageState();
}
class _RentalPageState extends State<RentalPage> {

  late InquiryController _controller;
  DateTime?tempDate;
  var format = new DateFormat('hh:mm a');
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  @override
  void initState() {
    _controller=  Get.put(InquiryController(type: widget.type));
    _controller.servicedata=Rx<List<ServiceDatum>>([]);
    widget.type==3?_controller.getInquieryData(""):"";
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
        ),
        actions: [
          PopupMenuButton<String>(
              child: Icon(Icons.filter_alt_outlined),
              color: Theme.of(context).colorScheme.onPrimaryContainer.withRed(3),
              offset: Offset(10, 40),
              elevation: 5,
              itemBuilder: (context) => [
                PopupMenuItem(
                  padding: EdgeInsets.only(left: 15,right: 6,),
                  child:Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [

                          InkWell(
                            onTap: (){
                              Get.back();
                            },
                            child: Icon(Icons.close),
                          ),
                          TextButton(child: Text("Clear All",style:TextStyle(fontSize: 14,decoration: TextDecoration.underline,color: Colors.blueAccent,fontWeight: FontWeight.bold),),
                            onPressed: (){
                              _controller.selectedCategory.value="";
                              _controller.setectedType.value="";
                              _controller.etAmount.clear();
                              _controller.rxServiceDate.value="Select Date";
                            },
                          )

                        ],
                      ),
                      Divider(thickness: 0.8,color: Colors.grey.withOpacity(0.5),)
                    ],
                  ),
                ),
                PopupMenuItem(
                  padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                  child:Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text("Date :                           ",style: Theme.of(context).textTheme.bodyText1),
                      SizedBox(height: 10,),
                      Obx(()=> Row(
                        children: [
                          Icon(Icons.date_range),
                          SizedBox(width: 10,),
                          TextButton(child: Text(_controller.rxServiceDate.value),onPressed: (){
                            dateTime();
                          },),
                        ],
                      )
                      ),
                    ],
                  ),
                  value:"My Profile",
                ),
                PopupMenuItem(
                  padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                  child:Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Text("Amount :                         ",style: Theme.of(context).textTheme.bodyText1),
                      TextFormField(
                        controller: _controller.etAmount,
                        decoration: InputDecoration(
                            hintStyle: TextStyle(color: Colors.grey),
                            hintText: "Enter Amount"
                        ),
                        inputFormatters: <TextInputFormatter>[
                          CurrencyTextInputFormatter(
                            locale: 'en',
                            decimalDigits: 2,
                            symbol: NumberFormat.compactSimpleCurrency(
                                locale:'en'
                            )
                                .currencySymbol,
                          ),
                        ],
                        keyboardType: TextInputType.number,

                      )
                    ],
                  ),
                  value:"My Profile",
                ),

                PopupMenuItem(
                  padding: EdgeInsets.only(left: 15,right: 15,top: 10),

                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      ElevatedButton(onPressed: (){
                        _controller.getInquieryData(_controller.rxCustomerName.value);
                        Get.back();
                      }, child: Text("    Apply    "),style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),),
                    ],
                  )

                  , value:"My Profile",
                ),


              ]
          ),
          SizedBox(width: 15,)
        ],

      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          children: [SizedBox(height: 8,),
            // Obx(()=> Text("Date "+_controller.rxServiceDate.value,style: TextStyle(color: Colors.tealAccent,fontWeight: FontWeight.bold,fontSize: 15),)),
            if(widget.type==2) Padding(
              padding: EdgeInsets.only(left: 12,right: 12,top: 8),
              child: Obx(()=>_controller.map.value!=null? Autocomplete<Map>(
                optionsBuilder: (TextEditingValue textEditingValue) {
                  return _controller.map.value.where((Map county) => county["name"].toLowerCase().startsWith(textEditingValue.text.toLowerCase())
                  ).toList();
                },
                displayStringForOption: (Map option) => option["name"],
                fieldViewBuilder: (
                    BuildContext context,
                    TextEditingController fieldTextEditingController,
                    FocusNode fieldFocusNode,
                    VoidCallback onFieldSubmitted
                    ) {
                  return TextField(
                    controller: fieldTextEditingController,
                    focusNode: fieldFocusNode,
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.7),width: 0.8)
                      ),
                      focusedBorder:  OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey)
                      ),
                      errorBorder:   OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.red)
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey)
                      ),
                      counter: Offstage(),
                      hintText: "Search",
                      alignLabelWithHint: true,
                      hintStyle:Theme.of(context).textTheme.bodyText2,
                      labelText:"Search",
                      // prefixIcon: Icon(icon,color:  Theme.of(context).colorScheme.primary,),
                      // icon: Icon(Icons.person),
                      contentPadding: const EdgeInsets.all(12.0),
                      labelStyle: Theme.of(context).textTheme.bodyText2,
                    ),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  );
                },
                onSelected: (Map selection) {
                  _controller.rxCustomerName.value=selection["name"];
                  _controller.getInquieryData(_controller.rxCustomerName.value);
                },
                optionsViewBuilder: (
                    BuildContext context,
                    AutocompleteOnSelected<Map> onSelected,
                    Iterable<Map> options
                    ) {
                  return Align(
                    alignment: Alignment.topLeft,
                    child: Material(
                      child: Container(
                        width: w*0.92,
                        decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.onPrimaryContainer,
                            border: Border.all(color: Colors.grey.withOpacity(0.8),width: 0.8)),

                        child: Row(
                          children: [
                            Expanded(
                              child: ListView.builder(
                                padding: EdgeInsets.only(bottom: 10,right: 10,top: 8),
                                itemCount: options.length,
                                shrinkWrap: true,
                                itemBuilder: (BuildContext context, int index) {
                                  final Map option = options.elementAt(index);
                                  return GestureDetector(
                                    onTap: () {
                                      onSelected(option);
                                    },
                                    child: ListTile(
                                      title: Text(option["name"], style: Theme.of(context).textTheme.bodyText1),
                                      subtitle: Text(option["email"]+"\n"+option["phone"], style: Theme.of(context).textTheme.bodyText2),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ):Container(),
              ),
            ),

            Obx(()=> _controller.servicedata.value!=null?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {

                  });
                },
                child: ListView.builder(
                    itemCount:_controller.servicedata.value.length,
                    itemBuilder: (context,index)
                    {
                      var date = new DateTime.fromMicrosecondsSinceEpoch( _controller.servicedata.value[index].bookingTime);
                      String strDate=format.format(date);
                      return CustomListShowOnlyWidget(title: _controller.servicedata.value[index].memberName??"",
                        subTitle: (_controller.servicedata.value[index].serviceName??""),
                        imgUrl:_controller.servicedata.value[index].image??"" ,
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              viewMore("Amount  ","\$ "+(_controller.servicedata.value[index].serviceAmount??"")),
                              Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              viewMore("Status  ",_controller.servicedata.value[index].statusName??""),
                              Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.3),),
                              viewMore("Date/time",_controller.servicedata.value[index].recCreDate!+" "+strDate),
                            ]),
                        textEditingController: _controller.etSearch,isClicked: _controller.servicedata.value[index].isChecked!??false,
                        onTapVieMore: (){
                          _controller.servicedata.value[index].isChecked=!_controller.servicedata.value[index].isChecked!;
                          _controller.servicedata.refresh();
                        },
                        editOnTap: (){

                        },
                      );

                    }),
              ),
            ):Container(),)

          ],
        ),
      ),
    );
  }
  dateTime()async{
    final DateTime? picked= await  showDatePicker(
        context: context,
        initialDate:DateTime.now(),
        firstDate: DateTime(2015),
        lastDate: DateTime(2100),
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
                colorScheme: const ColorScheme.dark(
                    onPrimary: Colors.white,
                    // selected text color
                    onSurface: Colors.white,
                    // default text color
                    primary: Colors
                        .teal // circle color
                ),
                dialogBackgroundColor: Theme
                    .of(context)
                    .backgroundColor,

                textButtonTheme: TextButtonThemeData(
                    style: TextButton.styleFrom(
                        textStyle: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight
                                .normal,
                            fontSize: 12,
                            fontFamily: 'Quicksand'),
                        primary: Colors.white,
                        // color of button's letters
                        backgroundColor: Colors
                            .black54,
                        // Background color
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                color: Colors
                                    .transparent,
                                width: 1,
                                style: BorderStyle
                                    .solid),
                            borderRadius: BorderRadius
                                .circular(50))))),

            child: child!,
          );
        }

    );

    final String formatted = formatter.format(picked!);
    _controller.rxServiceDate.value=formatted;
  }
}
