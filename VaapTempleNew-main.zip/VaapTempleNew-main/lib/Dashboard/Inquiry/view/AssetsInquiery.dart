
import 'package:aspgen_mobile/Dashboard/AssetsManagemant/asset_controller.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'package:intl/intl.dart';
import '../../../Widget/CustomListshowOnly.dart';
import '../../../Widget/SearchBarWidget.dart';
import '../controller/assets_inquiry_controller.dart';



class AssetInquieryPage extends StatefulWidget {
  final String title;
  const AssetInquieryPage({Key? key, required this.title}) : super(key: key);

  @override
  _AssetInquieryPageState createState() => _AssetInquieryPageState();
}

class _AssetInquieryPageState extends State<AssetInquieryPage> {
  final DateFormat formatter = DateFormat('MM/dd/yyyy');

  TextEditingController etsearch= new TextEditingController();
  late AssetInquiryController _controller;
  DateTime?tempDate;
  @override
  void initState() {
    _controller=Get.put(AssetInquiryController());
    // TODO: implement initState

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
        ),
        actions: [
          IconButton(onPressed: (){
            FocusManager.instance.primaryFocus?.unfocus();
            showCustomDialog(context);}, icon: Icon(Icons.filter_alt_outlined))
        ],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),

        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            SizedBox(height: 10,),

            GetBuilder<AssetInquiryController>(
                builder: (controller)=> Row(
                  children: [
                    Expanded(
                      flex: 13,
                      child: Container(
                          margin: EdgeInsets.only(left: 10,right: 5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            border: Border(
                                top: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                bottom: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                right: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                left: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                            color:Color(0xff6d8d8c).withOpacity(0.3),
                          ),
                          child: TextField(
                            autofocus: false,
                            style: Theme.of(context).textTheme.bodyText1,
                            controller:_controller.etSearch,
                            onChanged:((value){
                              _controller.update();
                            }),
                            decoration: new InputDecoration(
                              fillColor: Colors.teal,
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              contentPadding:
                              EdgeInsets.only(left: 10, top: 15, right: 2),
                              hintText: "Search",
                              hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.4)),
                              suffixIcon: _controller.etSearch.text.isNotEmpty?InkWell(
                                onTap: (){
                                  _controller.etSearch.clear();
                                },
                                child: Icon(
                                  Icons.clear,
                                  color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                                ),
                              ):Icon(
                                Icons.clear,
                                color: Colors.transparent,
                              ),
                            ),
                          )
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Container(
                        margin: EdgeInsets.only(right: 4),
                        child: RawMaterialButton(onPressed: (){
                         _controller.fetchApi(controller.etSearch.text);
                        }
                          ,child: Icon(Icons.search),fillColor: Colors.green.withOpacity(0.5),shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 44.0, minHeight: 44.0),),
                      ),
                    ),

                  ],
                )
            ),
            SizedBox(height: 8,),
            Obx(() => (_controller.datas.value.data!=null && _controller.datas.value.data!.isNotEmpty )?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {
                    _controller.fetchApi("");
                  });
                },
                child: ListView.builder(
                    itemCount:_controller.datas.value.data!.length,
                    itemBuilder: (context,index)
                    {

                      final datum=_controller.datas.value.data![index];
                      return CustomListShowOnlyWidget(title: datum.assetName??"",
                        subTitle: "\$ "+double.parse(datum.purchasePrice!.isNotEmpty?datum.purchasePrice!:"0.0").toStringAsFixed(2),

                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              if(datum.status!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.status!.isNotEmpty) viewMore("Status  ",datum.status??""),
                              if(datum.modelNo!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.modelNo!.isNotEmpty) viewMore("Model No  ",datum.modelNo??""),
                              if(datum.purchasedDate!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.3),),
                              if(datum.purchasedDate!.isNotEmpty)  viewMore("Purchase Date",datum.purchasedDate??""),
                            ]),
                        textEditingController: _controller.etSearch,isClicked: datum.isChecked??false,
                        onTapVieMore: (){
                          datum.isChecked=!datum.isChecked!;
                          _controller.datas.refresh();
                        },
                        editOnTap: (){
                        //  Get.to(()=>FieldPageNew(title: widget.title,type: 2,id: datum.id,),arguments: {"data": json.decode(json.encode(datum))});

                        },
                      );


                    }),
              ),
            ):
            Center(child:
                  Text(_controller.message.value,style: Theme.of(context).textTheme.bodyText2,)
              ,),
            )
          ],
        ),
      ),

    );
  }

  void showCustomDialog(BuildContext context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (BuildContext cxt) {
        return Align(
          alignment: Alignment.center,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Material(
              color:Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              child:GlassmorphicContainer(
                borderRadius: 5,
                blur: 10,
                alignment: Alignment.topLeft,
                border: 0.6,
                linearGradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFFffffff).withOpacity(0.1),
                      Color(0xFFFFFFFF).withOpacity(0.05),
                    ],
                    stops: [
                      0.1,
                      1,
                    ]),
                borderGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFFffffff).withOpacity(0.5),
                    Color((0xFFFFFFFF)).withOpacity(0.5),
                  ],
                ),
                width: 600,
                height: 500,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 12,right: 12,top: 4),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                InkWell(
                                  onTap: (){
                                    Get.back();
                                  },
                                  child: Icon(Icons.close),
                                ),
                                TextButton(child: Text("Clear All",style:TextStyle(fontSize: 14,decoration: TextDecoration.underline,color: Colors.blueAccent,fontWeight: FontWeight.bold),),
                                  onPressed: (){
                                    _controller.selectedCategory.value="";
                                    _controller.setectedType.value="";
                                    _controller.etAmount.clear();
                                    _controller.rxServiceDate.value="Select Date Range";
                                  },
                                )

                              ],
                            ),
                          ),
                          Divider(thickness: 0.8,color: Colors.grey.withOpacity(0.5),)
                        ],
                      ),
                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Text("Category :                                     ",style: Theme.of(context).textTheme.bodyText1),
                            Obx(()=>DropdownButton<String>(
                              isExpanded:true,
                              value: _controller.selectedCategory.value==""?null:_controller.selectedCategory.value,
                              hint: Text("Select Category "),
                              items: _controller.caltegoryList.value
                                  .map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(
                                    value,
                                    style: TextStyle(fontSize: 15),
                                  ),
                                );
                              }).toList(),
                              // Step 5.
                              onChanged: (String? newValue) {
                                _controller.selectedCategory.value=newValue!;
                                _controller.typeList.clear();
                                _controller.setectedType.value="";
                                _controller.getType(newValue);
                              },
                            ),
                            ),
                          ],
                        ),
                      ),
                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Type :                         ",style: Theme.of(context).textTheme.bodyText1),
                            Obx(()=> DropdownButton<String>(
                              isExpanded:true,
                              value: _controller.setectedType.value==""?null:_controller.setectedType.value,
                              hint: Text("Select Type"),
                              items: _controller.typeList.value.map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(
                                    value??"",
                                    style: TextStyle(fontSize: 15),
                                  ),
                                );
                              }).toList(),
                              // Step 5.
                              onChanged: (String? newValue) {
                                _controller.setectedType.value=newValue!;
                              },
                            ),
                            ),
                          ],
                        ),
                        value:"My Profile",
                      ),
                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Date :                           ",style: Theme.of(context).textTheme.bodyText1),
                            SizedBox(height: 10,),
                            Obx(()=> Row(
                              children: [
                                Icon(Icons.date_range),
                                SizedBox(width: 10,),
                                TextButton(child: Text(_controller.rxServiceDate.value,style: TextStyle(fontSize: 16,height: 1.3),),onPressed: (){
                                  dateTime();
                                },),
                              ],
                            )
                            ),
                          ],
                        ),
                        value:"My Profile",
                      ),
                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Text("Amount :                         ",style: Theme.of(context).textTheme.bodyText1),
                            TextFormField(
                              controller: _controller.etAmount,
                              decoration: InputDecoration(
                                  hintStyle: TextStyle(color: Colors.grey),
                                  hintText: "Enter Amount"
                              ),
                              inputFormatters: <TextInputFormatter>[
                                CurrencyTextInputFormatter(
                                  locale: 'en',
                                  decimalDigits: 2,
                                  symbol: NumberFormat.compactSimpleCurrency(
                                      locale:'en'
                                  )
                                      .currencySymbol,
                                ),
                              ],
                              keyboardType: TextInputType.number,

                            )
                          ],
                        ),
                        value:"My Profile",
                      ),

                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 20,bottom: 20),

                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ElevatedButton(onPressed: (){
                              _controller.fetchApi(_controller.etSearch.text);
                              Get.back();
                            }, child: Text("    Apply    "),style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),),
                          ],
                        )

                        , value:"My Profile",
                      ),
                    ],
                  ),
                ),
              ),

            ),
          ),
        );
      },
    );
  }
  dateTime()async{
    DateTimeRange? picked= await  showDateRangePicker(
        context: context,
        firstDate:DateTime(DateTime.now().year-1),
        lastDate: DateTime(DateTime.now().year+2),
        initialDateRange:_controller.pickedRangeDate??  DateTimeRange(
          start: DateTime.now(),
          end:DateTime.now().add(Duration(hours: 24*1)),
        ),
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
                colorScheme: const ColorScheme.dark(
                    onPrimary: Colors.white,
                    // selected text color
                    onSurface: Colors.white,
                    // default text color
                    primary: Colors
                        .teal // circle color
                ),
                dialogBackgroundColor: Theme
                    .of(context)
                    .backgroundColor,

                textButtonTheme: TextButtonThemeData(
                    style: TextButton.styleFrom(
                        textStyle: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight
                                .normal,
                            fontSize: 12,
                            fontFamily: 'Quicksand'),
                        primary: Colors.white,
                        // color of button's letters
                        backgroundColor: Colors
                            .black54,
                        // Background color
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                color: Colors
                                    .transparent,
                                width: 1,
                                style: BorderStyle
                                    .solid),
                            borderRadius: BorderRadius
                                .circular(50))))),

            child: child!,
          );
        }

    );
    if(picked!=null)
    {
      _controller.pickedRangeDate=picked;
      final String start = "Start Date : "+formatter.format(picked!.start)+ "\nEnd Date   : "+formatter.format(picked!.end);
      _controller.rxServiceDate.value=start;
    }



  }
}
