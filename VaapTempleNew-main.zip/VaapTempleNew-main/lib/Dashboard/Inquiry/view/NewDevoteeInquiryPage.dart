// import 'dart:convert';
// import 'dart:math';
// import 'package:aspgen_mobile/AppConstant/config.dart';
// import 'package:aspgen_mobile/Dashboard/Contact/Controller/contact_controller.dart';
// import 'package:aspgen_mobile/Templates/Model/ListingData.dart';
// import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
// import 'package:aspgen_mobile/UtilMethods/Utils.dart';
// import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
// import 'package:aspgen_mobile/Widget/SearchBarWidget.dart';
// import 'package:cached_network_image/cached_network_image.dart';
// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:url_launcher/url_launcher.dart';
//
// import '../../../AppConstant/APIsConstant.dart';
// import '../../../Templates/fieldPageNew.dart';
// import '../../../Widget/EditextWidget.dart';
// import '../../../Widget/FullScreenImageWidget.dart';
// import '../../../Widget/LoadMore.dart';
//
// import '../../Contact/Model/AllContactDatas.dart';
// import '../controller/DevoteeInquiry.dart';
// class DevoteeInquieryNewPage extends StatefulWidget {
//   final String title;
//   final String displayName;
//   final int type;  //type 1 for inquiry and type 2 for devotee Module
//   const DevoteeInquieryNewPage({Key? key,required this.title, required this.displayName, required this.type}) : super(key: key);
//   @override
//   State<DevoteeInquieryNewPage> createState() => _DevoteeInquieryNewPageState();
// }
//
// class _DevoteeInquieryNewPageState extends State<DevoteeInquieryNewPage> {
// late  DevoteeInquiryController _controller;
//   final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
//
//   var bodyJson={};
//   @override
//   void initState() {
//     _controller= Get.put(DevoteeInquiryController(type: widget.type));
//     super.initState();
//   }
//
//   makingPhoneCall(String phone) async {
//     var url = 'tel:'+phone;
//     if (await canLaunch(url)) {
//       await launch(url);
//     } else {
//       throw 'Could not launch $url';
//     }
//   }
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       key: _scaffoldKey,
//       appBar: AppBar(
//         title: Text(widget.displayName),
//         actions: [
//           Padding(
//             padding: const EdgeInsets.only(right: 8.0),
//             child: RawMaterialButton(onPressed: (){
//               _scaffoldKey.currentState!.openEndDrawer();
//             }
//               ,child: Icon(Icons.filter_alt_outlined),fillColor: Colors.green.shade900,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
//           )
//         ],
//       ),
//       endDrawer: Container(
//         alignment: Alignment.topRight,
//         padding: EdgeInsets.only(left: 15,top: 15,right: 10),
//         width: Get.width*0.8,
//          height: Get.height*0.6,
//          color: Theme.of(context).colorScheme.onPrimaryContainer,
//         child: Column(
//           mainAxisAlignment:MainAxisAlignment.start,
//           children: [
//             Text("Filter Data",style: Theme.of(context).textTheme.headline4),
//             Divider(thickness: 0.5,color: Colors.grey.withOpacity(0.5),),
//             Row(
//              mainAxisAlignment: MainAxisAlignment.center,
//              children: [
//                Icon(Icons.calendar_today),
//                TextButton(child:Text("Select Date"),onPressed: (){
//                  },)
//              ],
//            ),
//             SizedBox(height: 20,),
//
//             EditTextWidget(
//               maxLength: 200,
//               hint: "Enter Name ",
//               isPassword: false,
//               keyboardtype:  TextInputType.text,
//               label: "Enter name",
//               validator: (value) {
//                 return null;
//               },
//               controller: _controller.etName,
//               maxline: 1,
//             ),
//             SizedBox(height: 10,),
//
//             EditTextWidget(
//               maxLength: 200,
//               hint: "Enter Phone ",
//               isPassword: false,
//               keyboardtype:  TextInputType.phone,
//               label: "Enter Phone",
//               validator: (value) {
//
//                 return null;
//               },
//               controller: _controller.etPhone,
//               maxline: 1,
//             ),
//
//             ElevatedButton(
//                 style: ElevatedButton.styleFrom(backgroundColor: Colors.teal,
//                 padding: EdgeInsets.all(5),
//
//                 ),
//                 onPressed: (){}, child:Row(
//               mainAxisAlignment: MainAxisAlignment.center,
//                   children: [
//                     CircleAvatar(
//                       radius: 15,
//                       child:Icon(Icons.search),
//                     ),
//                     Text("     Apply"),
//                   ],
//                 ) )
//           ],
//         ),
//       ),
//
//       body: Column(
//         mainAxisSize: MainAxisSize.max,
//         children: [
//           SizedBox(height: 10,),
//           GetBuilder<DevoteeInquiryController>(
//             builder: (controller)=>  SearchBarWidget(
//               hint: "Search",
//               controller: controller.etSearch,
//               onchange: (value){
//                 controller.filterData(value);
//                 // value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi(controller.bodyJson):"";
//                 controller.update();
//               },
//               onCancel: (){
//                 controller.etSearch.clear();
//                 controller.update();
//               },
//             ),
//           ),
//           SizedBox(height: 8,),
//          Obx(()=>_controller.allContactDatas.value.isNotEmpty? Expanded(
//
//               child: RefreshIndicator(
//                 semanticsLabel: "Refresh",
//                 onRefresh: (){
//                   return Future.delayed(Duration.zero, () {
//                     _controller.fetchApi(_controller.bodyJson);
//                   });
//                 },
//                 child: ListView.builder(
//                     controller: _controller.controller,
//                     itemCount:  _controller.allContactDatas.value.length,
//                     physics: const AlwaysScrollableScrollPhysics(),
//                     itemBuilder: (context,index){
//                       final data=_controller.allContactDatas.value[index];
//                       return Card(
//                         color: Theme.of(context).colorScheme.onPrimaryContainer,
//                         elevation: 6,
//                         child:
//                         Column(
//                           children: [
//                             Divider(
//                               height: 0.5,
//                               thickness: 0.5,
//                               color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
//                             ),
//                             SizedBox(height: 10),
//                             Row(
//                               children: [
//                                 Container(
//                                   width: MediaQuery.of(context).size.width * 0.2,
//                                   padding: EdgeInsets.only(left: 5),
//                                   child: Stack(
//                                     children: [
//                                       data.image==""?  CircleAvatar(
//                                         backgroundColor: Color(Random().nextInt(0xffffffff)),
//                                         child: Text(
//                                             data.refDataName.toString().toUpperCase() ==
//                                                 "" ? "" : data.refDataName![0].toString().toUpperCase(),
//                                             style: Theme.of(context).textTheme.headline4
//                                         ),
//                                         maxRadius: 27,
//                                       ):
//                                       ClipOval(
//                                         child: GestureDetector(
//                                           onTap: (){
//                                             Get.to(()=>FullScreenImageWidget(path: APIsConstant.IP_Base_Url+data.image.toString(),),fullscreenDialog: true);
//                                           },
//                                           child: Hero(
//                                             tag:"img", child: CachedNetworkImage(
//                                             fit: BoxFit.cover,
//                                             imageUrl:APIsConstant.IP_Base_Url+data.image.toString(),
//                                             height: 55,
//                                             width: 55,
//                                             placeholder: (context,url)=>const CircularProgressIndicator(),
//                                             errorWidget: (context,url,error)=>const Icon(Icons.error),
//                                           ),
//                                           ),
//                                         ),
//                                       ),
//                                       Positioned(
//                                           left:0,
//                                           bottom:0,
//                                           child: GestureDetector(
//                                             onTap: (){
//                                               CheckInternetConnection().then((value1) => value1==true?Get.to(()=>FieldPageNew(title: "Contacts",type: 2,id: _controller.allContactDatas.value[index].id!),arguments: {"data": json.decode(json.encode(data))}):"");
//                                             },
//                                             child: CircleAvatar(
//                                               radius: 11,
//                                               backgroundColor: Colors.white,
//                                               child: CircleAvatar(
//                                                 backgroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
//                                                 radius: 10,
//                                                 child: Icon(Icons.edit,color:Colors.amber,size: 12,),
//                                               ),
//                                             ),
//                                           )
//                                       )
//
//                                     ],
//                                   ),
//                                 ),
//                                 Container(
//                                   width: MediaQuery.of(context).size.width * 0.6,
//                                   child: Column(
//                                     mainAxisAlignment: MainAxisAlignment.start,
//                                     crossAxisAlignment: CrossAxisAlignment.start,
//                                     children: [
//                                       HigliteText(textData: data.refDataName!, query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle),
//                                       SizedBox(
//                                         height: 9,
//                                       ),
//                                       HigliteText(textData:  data.memberTypes!, query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(
//                                           color:  data.memberTypes!.toString() == "PRIEST"
//                                               ? Colors.amber
//                                               :  data.memberTypes!.toString()== "DEVOTEE"
//                                               ? Colors.green:
//                                           data.memberTypes!.toString()== "GUEST"?Colors.purple  : Colors.lightBlue,
//                                           fontSize: 11,fontWeight: FontWeight.w400
//                                       )
//                                       ),
//                                       SizedBox(
//                                         height: 3,
//                                       ),
//                                       InkWell(onTap: (){
//                                         data.isCheckList!?data.isCheckList=false:data.isCheckList=true;
//                                         _controller.update();
//                                       },
//                                           child: Row(
//                                             children: [
//                                               Expanded(
//                                                   flex:3,
//                                                   child: Text(data.isCheckList!=true?"View More  ":"Hide ",style:TextStyle(fontSize: 12,color:Colors.white54, decoration: TextDecoration.underline,))),
//                                               Expanded(
//                                                   flex:6,
//                                                   child:Icon(data.isCheckList!=true?Icons.expand_more:Icons.expand_less,size: 20,color:Colors.white54)),
//                                             ],
//                                           )
//                                       ),
//                                       if(data.isCheckList!)   SizedBox(
//                                         height: 8,
//                                       ),
//                                       if(data.isCheckList!) Row(
//                                         children: [
//                                           Icon(Icons.phone,size: 16,),
//                                           SizedBox(width: 8,),
//                                           HigliteText(textData:  data.phone!, query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle),
//                                         ],
//                                       ),
//
//                                     ],
//                                   ),
//                                 ),
//                                 Container(
//                                   alignment: Alignment.topRight,
//
//                                   width: MediaQuery.of(context).size.width * 0.175,
//                                   child: Container(
//
//                                     alignment: Alignment.center,
//                                     decoration: BoxDecoration(
//                                         border: Border.all(color:Colors.green.withOpacity(0.24),width: 1 ),
//                                         shape:BoxShape.circle
//                                     ),
//                                     child: IconButton(
//                                       splashRadius: 20,
//                                       padding: EdgeInsets.all(8),
//                                       constraints:BoxConstraints(maxWidth:35,maxHeight: 35 ),
//                                       onPressed: (){
//                                         makingPhoneCall(data.phone!);
//                                       },
//                                       icon: Icon(Icons.call,
//                                           color: Colors.green,
//                                           size: 18),
//                                     ),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             Container(
//                               margin: EdgeInsets.only(left: Get.width*0.2,right: 8),
//                               child: Column(children: [
//                                 if(data.isCheckList!)  SizedBox(
//                                   height: 4,
//                                 ),
//                                 if(data.isCheckList!) Row(
//                                   children: [
//                                     Icon(Icons.email,size: 16,),
//                                     SizedBox(width: 8,),
//                                     Expanded(child: HigliteText(textData:data.email!, query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle)),
//                                   ],
//                                 ),
//                               ],),
//                             ),
//                             SizedBox(height: 10),
//                             Divider(
//                               height: 0.5,
//                               thickness: 0.5,
//                               color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
//                             )
//                           ],
//                         ),
//                       );
//                     }),
//               ),
//             ): Expanded(child: Center(child: Text(_controller.isSerching.value?"We couldn't find any contact\nmatching '${_controller.etSearch.text}'  ":"",
//               style: Theme.of(context).textTheme.bodyText1,
//               textAlign: TextAlign.center,),
//
//             ),
//             ),
//           ),
//           Obx(() => _controller.isLoadMore.value?LoadMoreData():Container())
//         ],
//       ),
//     );
//   }
//
// }
