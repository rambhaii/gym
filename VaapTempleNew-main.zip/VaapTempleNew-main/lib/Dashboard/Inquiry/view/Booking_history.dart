
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../../Widget/CircleTabIndicatorWidget.dart';
import '../../../Widget/LabaleListWidget.dart';
import '../../Services/Model/ServiceData.dart';
import '../controller/InquiryController.dart';



class BookingHistoryPage extends StatefulWidget {
  final String title;
  final int type;//1 for inquiery 2 for devotee
  const BookingHistoryPage({Key? key, required this.title, required this.type}) : super(key: key);

  @override
  _BookingHistoryPageState createState() => _BookingHistoryPageState();
}
class _BookingHistoryPageState extends State<BookingHistoryPage> {

  CalendarFormat _calendarFormat = CalendarFormat.week;
  RangeSelectionMode _rangeSelectionMode = RangeSelectionMode
      .toggledOn; // Can be toggled on/off by longpressing a date
  DateTime _focusedDay =  DateTime.now();
  DateTime? _selectedDay;
  DateTime? _rangeStart;
  DateTime? _rangeEnd;

  late InquiryController _controller;
  DateTime?tempDate;
  final DateFormat formatter = DateFormat('MMM dd , yyyy');

  @override
  void initState() {
    _controller=  Get.put(InquiryController(type: widget.type));
    _controller.servicedata=Rx<List<ServiceDatum>>([]);
    _controller.etSearch.clear();
    _controller.rxCustomerName.value="";
    if(widget.type==4)
      {
        _controller.getInquieryData(Get.arguments['data']);
        _controller.etSearch.text=Get.arguments['data'];
        _controller.rxCustomerName.value=Get.arguments['data'];
      }

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 6,
      child: Scaffold(
        appBar: AppBar(
          title: Text(widget.title),
          actions: [
       if(widget.type!=4)   IconButton(onPressed: (){
            _controller.isSearchVisible.value=!_controller.isSearchVisible.value;
          }, icon: Icon(Icons.search)),
        ],),
        body:  SingleChildScrollView(
          child: Container(
            margin: EdgeInsets.only(top: 0),
            child: Column(
              children: [
                SizedBox(height: 6,),
                if(widget.type!=4)  Obx(() => _controller.isSearchVisible.value? GetBuilder<InquiryController>(
                    builder: (controller)=> Row(
                      children: [
                        Expanded(
                          flex: 13,
                          child: Container(
                              margin: EdgeInsets.only(left: 10,right: 5),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                border: Border(
                                    top: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                    bottom: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                    right: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                    left: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                                color:Color(0xff6d8d8c).withOpacity(0.3),
                                // borderRadius:  BorderRadius.circular(32),
                              ),
                              child: TextField(
                                autofocus: false,
                                style: Theme.of(context).textTheme.bodyText1,
                                controller:_controller.etSearch,
                                onChanged:((value){
                                  _controller.update();
                                }),
                                decoration: new InputDecoration(
                                  fillColor: Colors.teal,
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  errorBorder: InputBorder.none,
                                  disabledBorder: InputBorder.none,
                                  contentPadding:
                                  EdgeInsets.only(left: 10, top: 15, right: 2),
                                  hintText:"Search Name / Email / Phone ",
                                  hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.4)),
                                  suffixIcon: _controller.etSearch.text.isNotEmpty?InkWell(
                                    onTap: (){
                                      _controller.etSearch.clear();
                                    },
                                    child: Icon(
                                      Icons.clear,
                                      color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                                    ),
                                  ):Icon(
                                    Icons.clear,
                                    color: Colors.transparent,
                                  ),
                                ),
                              )
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Container(
                            margin: EdgeInsets.only(right: 4),
                            child: RawMaterialButton(onPressed: (){
                              if(_controller.etSearch.text.isNotEmpty)
                              {
                                _controller.rxCustomerName.value=_controller.etSearch.text;
                                _controller.getInquieryData(_controller.etSearch.text);
                              }
                              else{
                                Fluttertoast.showToast(msg: "Please enter email or phone in search field");
                              }
                            }
                              ,child: Icon(Icons.search),fillColor: Colors.green.withOpacity(0.5),shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 44.0, minHeight: 44.0),),
                          ),
                        ),
                      ],
                    )
                )
                    :Container(),
                ),
                TableCalendar(
                  firstDay: DateTime.utc(2010, 10, 16),
                  lastDay: DateTime.utc(2030, 3, 14),
                  focusedDay: _focusedDay,
                  availableGestures:AvailableGestures.horizontalSwipe,
                  selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                  rangeStartDay: _rangeStart,
                  rangeEndDay: _rangeEnd,
                  calendarFormat: _calendarFormat,
                  availableCalendarFormats: {
                    CalendarFormat.month: 'Week',
                    CalendarFormat.week: 'Month',
               },
                  rangeSelectionMode: _rangeSelectionMode,
                  onDaySelected: (selectedDay, focusedDay) {
                    if (!isSameDay(_selectedDay, selectedDay)) {
                      setState(() {
                        _selectedDay = selectedDay;
                        _focusedDay = focusedDay;
                        _rangeStart = null; // Important to clean those
                        _rangeEnd = null;
                        _rangeSelectionMode = RangeSelectionMode.toggledOff;



                      });
                    }
                  },
                  onRangeSelected: (start, end, focusedDay) {
                    setState(() {
                      _selectedDay = null;
                      _focusedDay = focusedDay;
                      _rangeStart = start;
                      _rangeEnd = end;
                      _rangeSelectionMode = RangeSelectionMode.toggledOn;
                    });
                    print("vdsbvjsdkbv");
                    if(_rangeStart!=null&&_rangeEnd==null)
                    {
                      _controller.pickedRangeDate=DateTimeRange(start:_rangeStart! ,end:_rangeStart!);
                      _controller.getInquieryData(_controller.etSearch.text);
                    }
                    if(_rangeStart!=null&&_rangeEnd!=null)
                      {
                        _controller.pickedRangeDate=DateTimeRange(start:_rangeStart! ,end:_rangeEnd!);
                               _controller.getInquieryData(_controller.etSearch.text);
                      }

                  },
                  onFormatChanged: (format) {
                    if (_calendarFormat != format) {
                      setState(() {
                        _calendarFormat = format;
                      });
                      if(_calendarFormat==CalendarFormat.week)
                      {
                        _controller.pickedRangeDate=DateTimeRange(start:_focusedDay ,end:_focusedDay.add(Duration(days: 7)) );
                      }
                      if(_calendarFormat==CalendarFormat.month)
                      {
                        var noOfMonth =  DateTime(_focusedDay.year, _focusedDay.month+1, 0);
                        DateTimeRange date=DateTimeRange(start:DateTime(_focusedDay.year, _focusedDay.month , 1), end:DateTime(_focusedDay.year, _focusedDay.month ,noOfMonth.day));
                        _controller.pickedRangeDate=date;
                        //_controller.pickedRangeDate=DateTimeRange(start:_focusedDay ,end:_focusedDay.add(Duration(days: 30)) );
                      }
                      _controller.getInquieryData(_controller.etSearch.text);
                    }
                    print("_controller.pickedRangeDate");
                    print(_controller.pickedRangeDate);
                  },
                  onPageChanged: (focusedDay) {
                    _focusedDay = focusedDay;
                     if(_calendarFormat==CalendarFormat.week)
                       {
                         _controller.pickedRangeDate=DateTimeRange(start:_focusedDay ,end:_focusedDay.add(Duration(days: 7)) );

                      }
                     if(_calendarFormat==CalendarFormat.month)
                       {
                         var noOfMonth =  DateTime(_focusedDay.year, _focusedDay.month+1, 0);
                         DateTimeRange date=DateTimeRange(start:DateTime(_focusedDay.year, _focusedDay.month , 1), end:DateTime(_focusedDay.year, _focusedDay.month ,noOfMonth.day));
                         _controller.pickedRangeDate=date;

                         // _controller.pickedRangeDate=DateTimeRange(start:_focusedDay ,end:_focusedDay.add(Duration(days: 30)) );
                       }
                    print("_controller.pickedRangeDate");
                    print(_controller.pickedRangeDate);
                     _controller.getInquieryData(_controller.etSearch.text);
                  },
                    headerStyle: HeaderStyle(
                    formatButtonTextStyle:
                    TextStyle().copyWith(
                    color: Colors.white,
                    fontSize: 15.0,
                    ),
                    formatButtonDecoration: BoxDecoration(
                    color: Colors.teal,
                    borderRadius: BorderRadius.circular(2.0),
                    ),
                    ),

    // Operating
                  calendarStyle: CalendarStyle(
                 rangeHighlightColor: Colors.tealAccent.withOpacity(0.35),

                    selectedDecoration: BoxDecoration(
                      color: Colors.tealAccent
                    ),
                    markerDecoration: BoxDecoration(
                        color: Colors.tealAccent
                    ) ,
                    defaultTextStyle: TextStyle(color:Colors.white.withOpacity(0.8)) ,
                    withinRangeTextStyle:TextStyle(color:Colors.white) ,
                    rangeEndTextStyle: TextStyle(color:Colors.black,fontWeight: FontWeight.bold),
                    rangeStartTextStyle: TextStyle(color:Colors.black,fontWeight: FontWeight.bold),
                    rangeEndDecoration: BoxDecoration(
                              color: Colors.tealAccent,
                           shape: BoxShape.circle

                              ) ,  rangeStartDecoration: BoxDecoration(
                              color: Colors.tealAccent,
                           shape: BoxShape.circle

                              ) ,
                    outsideDaysVisible: false,
                  ),

                ),

               Obx(()=> _controller.servicedata.value!=null?
               RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {

                  });
               },
               child: ListView.builder(
                   itemCount:_controller.servicedata.value.length,
                   physics: NeverScrollableScrollPhysics(),
                   shrinkWrap: true,
                   itemBuilder: (context,index)
                   {
                     return LableListShowOnlyWidget(
                       title: _controller.servicedata.value[index].ServiceSetup??"",
                       titlelable: "Service Name",
                       subTitleLable: "Category",
                       subTitle2Lable: "Booking Date",
                       subTitle3: _controller.servicedata.value[index].statusName.toString(),
                       subTitle: (_controller.servicedata.value[index].serviceCategoryTypes??""),
                       imgUrl:_controller.servicedata.value[index].image??"" ,
                       subTitle2: dateParser(_controller.servicedata.value[index].recCreDate.toString())  ,
                       viewMoreWidget: Column(
                           crossAxisAlignment: CrossAxisAlignment.start,
                           children:[
                             Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                             viewMore("Devotee Name  ",_controller.servicedata.value[index].memberName??""),
                             Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                             Row(
                               children: [
                                 Expanded(
                                     flex:2,
                                     child: viewMore("Amount  ",amountParser(_controller.servicedata.value[index].serviceAmount.toString()))),
                                 Expanded(
                                     flex:2,
                                     child:  viewMore("Service  Date",dateParser(_controller.servicedata.value[index].serviceDate.toString().isNotEmpty?_controller.servicedata.value[index].serviceDate.toString():_controller.servicedata.value[index].recCreDate.toString()))),
                               ],
                             ),
                             Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                             viewMore("Type  ",_controller.servicedata.value[index].serviceTypes!??""),
                                         ]),
                                   textEditingController: _controller.etSearch,isClicked: _controller.servicedata.value[index].isChecked!??false,
                                onTapVieMore: (){
                                 _controller.servicedata.value[index].isChecked=!_controller.servicedata.value[index].isChecked!;
                                 _controller.servicedata.refresh();
                               },
                       editOnTap: (){
                       },
                     );

                   }),
              ):Container(),)

              ],
            ),
          ),
        ),
      ),
    );
  }
  dateTime()async{
    DateTimeRange? picked= await  showDateRangePicker(
        context: context,
        initialEntryMode:DatePickerEntryMode.input,

        firstDate:DateTime(DateTime.now().year-1),
        lastDate: DateTime(DateTime.now().year+2),
        initialDateRange:_controller.pickedRangeDate??  DateTimeRange(
          start: DateTime.now(), end:DateTime.now().add(Duration(hours: 24*1)),
        ),
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
                colorScheme: const ColorScheme.dark(
                    onPrimary: Colors.white,
                    // selected text color
                    onSurface: Colors.white,
                    // default text color
                    primary: Colors
                        .teal // circle color
                ),
                dialogBackgroundColor: Theme
                    .of(context)
                    .backgroundColor,

                textButtonTheme: TextButtonThemeData(
                    style: TextButton.styleFrom(
                        textStyle: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight
                                .normal,
                            fontSize: 12,
                            fontFamily: 'Quicksand'),
                        primary: Colors.white,
                        // color of button's letters
                        backgroundColor: Colors
                            .black54,
                        // Background color
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                color: Colors
                                    .transparent,
                                width: 1,
                                style: BorderStyle
                                    .solid),
                            borderRadius: BorderRadius
                                .circular(50))))),

            child: child!,
          );
        }

    );
    if(picked!=null)
    {
      final DateFormat showDateformatter = DateFormat('dd, MMM yy');
      _controller.pickedRangeDate=picked;
      print("sdcbsvsdjhvb");
      print(picked.start);
      final String start =showDateformatter.format(picked.start)+" - "+showDateformatter.format(picked.end);
      _controller.rxServiceDate.value=start;
      _controller.isDateRangeVisible.value=true;
      _controller.getInquieryData(_controller.etSearch.text);
    }



  }
}
