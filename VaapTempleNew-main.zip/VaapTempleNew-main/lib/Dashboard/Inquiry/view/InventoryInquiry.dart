import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'package:intl/intl.dart';

import '../../../UtilMethods/RemoteServices.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/CustomListshowOnly.dart';
import '../../../Widget/SearchBarWidget.dart';
import '../controller/InventoryController.dart';
class InventoryInquiry extends StatelessWidget {
  final String title;
  final DateFormat formatter = DateFormat('MMM dd , yyyy');
  InventoryInquiryController controller=Get.put(InventoryInquiryController());
  InventoryInquiry({Key? key, required this.title}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          title,
        ),

        actions: [
          IconButton(onPressed: (){
            FocusManager.instance.primaryFocus?.unfocus();
            showCustomDialog(context);}, icon: Icon(Icons.filter_alt_outlined))
        ],

      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          children: [
            SizedBox(height: 10,),
            GetBuilder<InventoryInquiryController>(
                builder: (controller)=> Row(
                  children: [
                    Expanded(
                      flex: 13,
                      child: Container(
                          margin: EdgeInsets.only(left: 10,right: 5),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(5),
                            border: Border(
                                top: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                bottom: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                right: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                left: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                            color:Color(0xff6d8d8c).withOpacity(0.3),
                            // borderRadius:  BorderRadius.circular(32),
                          ),
                          child: TextField(
                            autofocus: false,
                            style: Theme.of(context).textTheme.bodyText1,
                            controller:controller.etSearch,
                            onChanged:((value){
                              controller.update();
                            }),
                            decoration: new InputDecoration(
                              fillColor: Colors.teal,
                              border: InputBorder.none,
                              focusedBorder: InputBorder.none,
                              enabledBorder: InputBorder.none,
                              errorBorder: InputBorder.none,
                              disabledBorder: InputBorder.none,
                              contentPadding:
                              EdgeInsets.only(left: 10, top: 15, right: 2),
                              hintText: "Search",
                              hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.4)),
                              suffixIcon: controller.etSearch.text.isNotEmpty?InkWell(
                                onTap: (){
                                  controller.etSearch.clear();
                                },
                                child: Icon(
                                  Icons.clear,
                                  color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                                ),
                              ):Icon(
                                Icons.clear,
                                color: Colors.transparent,
                              ),
                            ),
                          )
                      ),
                    ),
                    Expanded(
                      flex: 2,
                      child: Container(
                        margin: EdgeInsets.only(right: 4),
                        child: RawMaterialButton(onPressed: (){
                          controller.fetchApi();
                        }
                          ,child: Icon(Icons.search),fillColor: Colors.green.withOpacity(0.5),shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 44.0, minHeight: 44.0),),
                      ),
                    ),

                  ],
                )
            ),
            SizedBox(height: 8,),
            Obx(() => controller.inventoryData.value.data!=null?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {
                    controller.fetchApi();
                  });
                },
                child:controller.inventoryData.value.data!.isNotEmpty? ListView.builder(
                    itemCount:controller.inventoryData.value.data!.length,
                    itemBuilder: (context,index)
                    {
                      final datum=controller.inventoryData.value.data![index];
                      return  CustomListShowOnlyWidget(title: datum.refDataName??"",
                        subTitle: datum.itemCategory??"",
                        imgUrl:datum.image ,
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              if(datum.rackNo!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.rackNo!.isNotEmpty) viewMore("Rack No  ",datum.rackNo??""),
                              if(datum.quantityOnHand!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.quantityOnHand!.isNotEmpty) viewMore("Qty On Hand  ", datum.quantityOnHand??""),
                              if(datum.quantityOnOrder!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.quantityOnOrder!.isNotEmpty) viewMore("Qty  On Stock  ", datum.quantityOnOrder??""),
                            ]),
                        textEditingController: controller.etSearch,isClicked:datum.isChecked!??false,
                        onTapVieMore: (){
                          datum.isChecked=!datum.isChecked!;
                          controller.inventoryData.refresh();
                        },
                        editOnTap: (){
                          CheckInternetConnection().then((value) {
                            if(value==true)
                            {
                            }
                          });
                        },
                      );

                    }):
                Center(
                 child: Text(controller.message.value,style: Theme.of(context).textTheme.bodyText2,),
                ),
              ),
            ):Container(),
            )
          ],
        ),
      ),

    );
  }
  dateTime(BuildContext context)async{
    DateTimeRange? picked= await  showDateRangePicker(
        context: context,
        firstDate:DateTime(DateTime.now().year-1),
        lastDate: DateTime(DateTime.now().year+2),
        initialDateRange:controller.pickedRangeDate??  DateTimeRange(
          start: DateTime.now(),
          end:DateTime.now().add(Duration(hours: 24*1)),
        ),
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
                colorScheme: const ColorScheme.dark(
                    onPrimary: Colors.white,
                    // selected text color
                    onSurface: Colors.white,
                    // default text color
                    primary: Colors
                        .teal // circle color
                ),
                dialogBackgroundColor: Theme
                    .of(context)
                    .backgroundColor,

                textButtonTheme: TextButtonThemeData(
                    style: TextButton.styleFrom(
                        textStyle: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight
                                .normal,
                            fontSize: 12,
                            fontFamily: 'Quicksand'),
                        primary: Colors.white,
                        // color of button's letters
                        backgroundColor: Colors
                            .black54,
                        // Background color
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                color: Colors
                                    .transparent,
                                width: 1,
                                style: BorderStyle
                                    .solid),
                            borderRadius: BorderRadius
                                .circular(50))))),

            child: child!,
          );
        }

    );
    if(picked!=null)
    {
      controller.pickedRangeDate=picked;
      final String start = "Start Date : "+formatter.format(picked!.start)+ "\nEnd Date   : "+formatter.format(picked!.end);
      controller.rxServiceDate.value=start;
    }



  }
  void showCustomDialog(BuildContext context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (BuildContext cxt) {
        return Align(
          alignment: Alignment.center,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Material(
              color:Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              child:GlassmorphicContainer(
                borderRadius: 5,
                blur: 10,
                alignment: Alignment.topLeft,
                border: 0.6,
                linearGradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFFffffff).withOpacity(0.1),
                      Color(0xFFFFFFFF).withOpacity(0.05),
                    ],
                    stops: [
                      0.1,
                      1,
                    ]),
                borderGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFFffffff).withOpacity(0.5),
                    Color((0xFFFFFFFF)).withOpacity(0.5),
                  ],
                ),
                width: 600,
                height: 250,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 12,right: 12,top: 4),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                InkWell(
                                  onTap: (){
                                    Get.back();
                                  },
                                  child: Icon(Icons.close),
                                ),
                                TextButton(child: Text("Clear All",style:TextStyle(fontSize: 14,decoration: TextDecoration.underline,color: Colors.blueAccent,fontWeight: FontWeight.bold),),
                                  onPressed: (){
                                    controller.selectedCategory.value="";
                                    controller.setectedType.value="";
                                    // controller.etAmount.clear();
                                    controller.rxServiceDate.value="Select Date Range";
                                  },
                                )

                              ],
                            ),
                          ),
                          Divider(thickness: 0.8,color: Colors.grey.withOpacity(0.5),)
                        ],
                      ),
                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Text("Category :                                     ",style: Theme.of(context).textTheme.bodyText1),
                            Obx(()=>DropdownButton<String>(
                              isExpanded:true,
                              value: controller.selectedCategory.value==""?null:controller.selectedCategory.value,
                              hint: Text("Select Category "),
                              items: controller.caltegoryList.value
                                  .map<DropdownMenuItem<String>>((String value) {
                                return DropdownMenuItem<String>(
                                  value: value,
                                  child: Text(
                                    value,
                                    style: TextStyle(fontSize: 15),
                                  ),
                                );
                              }).toList(),
                              // Step 5.
                              onChanged: (String? newValue) {
                                controller.selectedCategory.value=newValue!;
                                //controller.typeList.clear();
                                //controller.getServiceType(newValue);
                              },
                            ),
                            ),
                          ],
                        ),
                      ),

                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 20,bottom: 20),

                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ElevatedButton(onPressed: (){
                            controller.fetchApi();
                              Get.back();
                            }, child: Text("    Apply    "),style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),),
                          ],
                        ), value:"My Profile",
                      ),
                    ],
                  ),
                ),
              ),

            ),
          ),
        );
      },
    );
  }
}
