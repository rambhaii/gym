import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/TextStyle.dart';
import 'package:aspgen_mobile/Dashboard/Inquiry/controller/InquiryController.dart';
import 'package:aspgen_mobile/Dashboard/Inquiry/view/AssetsInquiery.dart';
import 'package:aspgen_mobile/Dashboard/Inquiry/view/DevoteePaymentInquery.dart';
import 'package:aspgen_mobile/Dashboard/Inquiry/view/MenuInquiry.dart';
import 'package:aspgen_mobile/Dashboard/Inquiry/view/PaymentInqirey.dart';
import 'package:aspgen_mobile/Dashboard/Inquiry/view/Booking_history.dart';
import 'package:aspgen_mobile/Dashboard/Inquiry/view/ServiceInquiry.dart';
import 'package:aspgen_mobile/Dashboard/Services/Controller/ServiceController.dart';
import 'package:aspgen_mobile/Dashboard/Services/View/ServicePage.dart';
import 'package:aspgen_mobile/Widget/SelectionTypeWidget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../Widget/SearchBarWidget.dart';
import '../../Devotee/DevoteePage.dart';
import '../../Donations/View/make_donation_page.dart';
import 'InventoryInquiry.dart';
class InquiryCategoryPage extends StatelessWidget {
  final String title;
   InquiryCategoryPage({Key? key,required this.title}) : super(key: key);
  RxList<String> inquiryList=[
    "Devotee",
    "Bookings",
    "Payments" ,
    "Services"  ,
    "Inventory",
    "Assets",
    "Menus"
  ].obs;

  List<String> filterList=[
    "Devotee",
    "Bookings",
    "Payments" ,
    "Services"  ,
    "Inventory",
    "Assets",
    "Menus"
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Select "+title +" Types"),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top:8.0),
        child: Column(
          children: [
            SizedBox(height: 6,),
           Obx(() => inquiryList.value!=null?Expanded(
                child: ListView.builder(
                    itemCount:inquiryList.value.length,
                    itemBuilder: (context,index)
                    {
                      return SelectionTypeWidget(
                          title: inquiryList.value[index]??"",
                          onTap: (){
                        getRoute( inquiryList.value[index]);
                      });
                    }),
              ):Container(),
            )
              ,

          ],
        ),
      ),
    );
  }
  getRoute(String value){
    switch(value){
      case "Devotee":
        Get.to(()=>DevoteePage(title: value, displayName: value+" Inquiry",));
        break;
      case "Bookings":
        Get.to(()=>BookingHistoryPage(title: "Booking Inquiry",type: 1,));
        break;
      case "Payments":
        Get.to(()=>PaymentInquiryPage(title: "Payments Inquiry",type: 1,));
        break;
      case "Services":
        Get.to(()=>ServiceInquiryPage());
        break;
      case "Inventory":
        Get.to(()=>InventoryInquiry(title: 'Inventory Inquiry',));
        break;
      case "Assets":
        Get.to(()=>AssetInquieryPage(title: 'Assets Inquiry',));
        break;
      case "Menus":
        Get.to(()=>MenuInquiryPage(title: 'Menus Inquiry',));
        break;

    }
  }
}

