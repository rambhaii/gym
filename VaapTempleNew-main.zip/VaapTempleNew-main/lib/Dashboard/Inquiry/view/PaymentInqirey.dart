import 'dart:ui';

import 'package:currency_text_input_formatter/currency_text_input_formatter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/LableListActionWidget.dart';
import '../controller/payment_controller.dart';
import 'PaymentInquieryDetails.dart';



class PaymentInquiryPage extends StatefulWidget {
  final String title;
  final int type;// Type 1 for payment Inquiry and 2 for devotee Inquiry
  const PaymentInquiryPage({Key? key, required this.title, required this.type}) : super(key: key);

  @override
  _PaymentInquiryPageState createState() => _PaymentInquiryPageState();
}

class _PaymentInquiryPageState extends State<PaymentInquiryPage> {

  late PaymentController _controller;
  DateTime?tempDate;
  final DateFormat formatter = DateFormat('MMM dd , yyyy');
  CalendarFormat _calendarFormat = CalendarFormat.week;
  RangeSelectionMode _rangeSelectionMode = RangeSelectionMode
      .toggledOn; // Can be toggled on/off by longpressing a date

  DateTime _focusedDay =  DateTime.now();
  DateTime? _selectedDay;
  DateTime? _rangeStart;
  DateTime? _rangeEnd;
  @override
  void initState() {
    _controller=  Get.put(PaymentController(type: widget.type));
    _controller.etSearch.clear();
    if(widget.type==3)
      {
        _controller.getPaymentData(Get.arguments['data']);
        _controller.etSearch.text=Get.arguments['data'];
        _controller.rxCustomerName.value=Get.arguments['data'];
      }
    _controller.getPaymentData("");
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
        ),
        actions: [
          if(widget.type!=3)      IconButton(onPressed: (){
            _controller.isSearchVisible.value=!_controller.isSearchVisible.value;
          }, icon: Icon(Icons.search)),

        ],
      ),
      body:  SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 0),
          child: Column(
            children: [
              SizedBox(height: 6,),
            if(widget.type!=3) Obx(() =>_controller.isSearchVisible.value?  GetBuilder<PaymentController>(
                    builder: (controller)=> Row(
                      children: [
                        Expanded(
                          flex: 13,
                          child: Container(
                              margin: EdgeInsets.only(left: 10,right: 5),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                border: Border(
                                    top: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                    bottom: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                    right: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                    left: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                                color:Color(0xff6d8d8c).withOpacity(0.3),
                              ),
                              child: TextField(
                                autofocus: false,
                                style: Theme.of(context).textTheme.bodyText1,
                                controller:_controller.etSearch,
                                onChanged:((value){
                                  _controller.update();
                                }),
                                decoration: new InputDecoration(
                                  fillColor: Colors.teal,
                                  border: InputBorder.none,
                                  focusedBorder: InputBorder.none,
                                  enabledBorder: InputBorder.none,
                                  errorBorder: InputBorder.none,
                                  disabledBorder: InputBorder.none,
                                  contentPadding:
                                  EdgeInsets.only(left: 10, top: 15, right: 4),
                                  hintText: "Search Email / Phone / Name",
                                  hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.4)),
                                  suffixIcon: _controller.etSearch.text.isNotEmpty?InkWell(
                                    onTap: (){
                                      _controller.etSearch.clear();
                                      _controller.paymentdata.value.clear();
                                      _controller.paymentdata.refresh();
                                    },
                                    child: Icon(
                                      Icons.clear,
                                      color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                                    ),
                                  ):Icon(
                                    Icons.clear,
                                    color: Colors.transparent,
                                  ),
                                ),
                              )
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Container(
                            margin: EdgeInsets.only(right: 4),
                            child: RawMaterialButton(onPressed: (){
                              if(_controller.etSearch.text.isNotEmpty)
                                {
                                  _controller.getPaymentData(_controller.etSearch.text);
                                }
                             else{
                                Fluttertoast.showToast(msg: "Please enter email or phone in search field");
                              }
                            }
                              ,child: Icon(Icons.search),fillColor: Colors.green.withOpacity(0.5),shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 44.0, minHeight: 44.0),),
                          ),
                        ),

                      ],
                    )
                ):Container(),
            ),
              TableCalendar(
                firstDay: DateTime.utc(2010, 10, 16),
                lastDay: DateTime.utc(2030, 3, 14),
                focusedDay: _focusedDay,
                availableGestures:AvailableGestures.horizontalSwipe,
                selectedDayPredicate: (day) => isSameDay(_selectedDay, day),
                rangeStartDay: _rangeStart,
                rangeEndDay: _rangeEnd,
                calendarFormat: _calendarFormat,
                availableCalendarFormats: {
                  CalendarFormat.month: 'Week',
                  CalendarFormat.week: 'Month',
                },
                rangeSelectionMode: _rangeSelectionMode,
                onDaySelected: (selectedDay, focusedDay) {
                  if (!isSameDay(_selectedDay, selectedDay)) {
                    setState(() {
                      _selectedDay = selectedDay;
                      _focusedDay = focusedDay;
                      _rangeStart = null; // Important to clean those
                      _rangeEnd = null;
                      _rangeSelectionMode = RangeSelectionMode.toggledOff;
                      _controller.pickedRangeDate=DateTimeRange(start:_selectedDay! ,end:_selectedDay!);
                      _controller.getPaymentData(_controller.etSearch.text);
                    });
                  }
                },
                onRangeSelected: (start, end, focusedDay) {
                  setState(() {
                    _selectedDay = null;
                    _focusedDay = focusedDay;
                    _rangeStart = start;
                    _rangeEnd = end;
                    _rangeSelectionMode = RangeSelectionMode.toggledOn;
                  });
                  print("vdsbvjsdkbv");
                  if(_rangeStart!=null&&_rangeEnd==null)
                  {
                    _controller.pickedRangeDate=DateTimeRange(start:_rangeStart! ,end:_rangeStart!);
                    _controller.getPaymentData(_controller.etSearch.text);
                  }
                  if(_rangeStart!=null&&_rangeEnd!=null)
                  {
                    _controller.pickedRangeDate=DateTimeRange(start:_rangeStart! ,end:_rangeEnd!);
                    _controller.getPaymentData(_controller.etSearch.text);
                  }
                },
                onFormatChanged: (format) {
                  if (_calendarFormat != format) {
                    setState(() {
                      _calendarFormat = format;
                    });
                  }
                  if(_calendarFormat==CalendarFormat.week)
                  {
                    _controller.pickedRangeDate=DateTimeRange(start:_focusedDay ,end:_focusedDay.add(Duration(days: 7)) );
                  }

                  if(_calendarFormat==CalendarFormat.month)
                  {
                    var noOfMonth =  DateTime(_focusedDay.year, _focusedDay.month+1, 0);
                    DateTimeRange date=DateTimeRange(start:DateTime(_focusedDay.year, _focusedDay.month , 1), end:DateTime(_focusedDay.year, _focusedDay.month ,noOfMonth.day));
                    _controller.pickedRangeDate=date;
                  }
                  _controller.getPaymentData(_controller.etSearch.text);
                },
                onPageChanged: (focusedDay) {
                  _focusedDay = focusedDay;
                  if(_calendarFormat==CalendarFormat.week)
                  {
                    _controller.pickedRangeDate=DateTimeRange(start:_focusedDay ,end:_focusedDay.add(Duration(days: 7)) );
                  }
                  if(_calendarFormat==CalendarFormat.month)
                  {
                    var noOfMonth =  DateTime(_focusedDay.year, _focusedDay.month+1, 0);
                    DateTimeRange date=DateTimeRange(start:DateTime(_focusedDay.year, _focusedDay.month , 1), end:DateTime(_focusedDay.year, _focusedDay.month ,noOfMonth.day));
                    _controller.pickedRangeDate=date;
                  }
                  _controller.getPaymentData(_controller.etSearch.text);
                },
                headerStyle: HeaderStyle(
                  formatButtonTextStyle:
                  TextStyle().copyWith(
                    color: Colors.white,
                    fontSize: 15.0,
                  ),
                  formatButtonDecoration: BoxDecoration(
                    color: Colors.teal,
                    borderRadius: BorderRadius.circular(2.0),
                  ),
                ),

                // Operating
                calendarStyle: CalendarStyle(
                  rangeHighlightColor: Colors.tealAccent.withOpacity(0.35),

                  selectedDecoration: BoxDecoration(
                      color: Colors.tealAccent
                  ),
                  markerDecoration: BoxDecoration(
                      color: Colors.tealAccent
                  ) ,
                  defaultTextStyle: TextStyle(color:Colors.white.withOpacity(0.8)) ,
                  withinRangeTextStyle:TextStyle(color:Colors.white) ,
                  rangeEndTextStyle: TextStyle(color:Colors.black,fontWeight: FontWeight.bold),
                  rangeStartTextStyle: TextStyle(color:Colors.black,fontWeight: FontWeight.bold),
                  rangeEndDecoration: BoxDecoration(
                      color: Colors.tealAccent,
                      shape: BoxShape.circle

                  ) ,  rangeStartDecoration: BoxDecoration(
                    color: Colors.tealAccent,
                    shape: BoxShape.circle

                ) ,
                  outsideDaysVisible: false,
                ),
              ),
              SizedBox(height: 8,),
              Obx(()=> _controller.paymentdata.value.isNotEmpty?RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {

                  });
                },
                child: ListView.builder(
                    itemCount:_controller.paymentdata.value.length,
                    physics: NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context,index)
                    {
                      final datas=_controller.paymentdata.value[index];
                      return LableListWidget(
                        title: datas.memberName??"",
                        titlelable: "Name",  subTitleLable: "Payment Type",  subTitle2Lable: "Payment Date",
                        subTitle:(datas.paymentType.toString()) ,
                        subTitle2: dateParser(datas.recCreDate.toString()),
                        subTitle3: datas.paymentStatus.toString()??"",
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              if(datas.totalAmount!.isNotEmpty)  Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                Row(
                                  children: [
                                    Expanded(flex:2,child: viewMore("Amount  ", amountParser(datas.totalAmount.toString())),),
                                    Expanded(flex:2,child: viewMore("Token #  ", datas.tokenNumber.toString()),),
                                  ],
                                ),
                              if(datas.transactionId!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.3),),
                              if(datas.transactionId!.isNotEmpty) viewMore("Transaction Id ",datas.transactionId.toString()??""),
                            ]),
                        textEditingController: _controller.etSearch,isClicked: datas.isChecked!??false,
                        onTapVieMore: (){
                          datas.isChecked=!datas.isChecked!;
                          _controller.paymentdata.refresh();
                        },
                        icon: Icons.arrow_forward,
                        iconColor: Theme.of(context).colorScheme.primary,
                        editOnTap: (){
                         _controller.detailsdata.value=datas;
                         Get.to(()=>DetailsPaymentInquiryPage(title: datas.memberName.toString(),));
                        },
                      );

                    }),
              ):Center(child: Text(_controller.message.value,style: Theme.of(context).textTheme.bodyText2,),),)

            ],
          ),
        ),
      ),
    );
  }
  dateTime()async{
    DateTimeRange? picked= await  showDateRangePicker(
        context: context,
        firstDate:DateTime(DateTime.now().year-1),
        lastDate: DateTime(DateTime.now().year+2),
        initialDateRange:_controller.pickedRangeDate??  DateTimeRange(
          start: DateTime.now(),
          end:DateTime.now().add(Duration(hours: 24*1)),
        ),
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
                colorScheme: const ColorScheme.dark(
                    onPrimary: Colors.white,
                    // selected text color
                    onSurface: Colors.white,
                    // default text color
                    primary: Colors
                        .teal // circle color
                ),
                dialogBackgroundColor: Theme
                    .of(context)
                    .backgroundColor,

                textButtonTheme: TextButtonThemeData(
                    style: TextButton.styleFrom(
                        textStyle: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight
                                .normal,
                            fontSize: 12,
                            fontFamily: 'Quicksand'),
                        primary: Colors.white,
                        // color of button's letters
                        backgroundColor: Colors
                            .black54,
                        // Background color
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                color: Colors
                                    .transparent,
                                width: 1,
                                style: BorderStyle
                                    .solid),
                            borderRadius: BorderRadius
                                .circular(50))))),

            child: child!,
          );
        }

    );
if(picked!=null)
  {
    _controller.pickedRangeDate=picked;
    final String start = "Start Date : "+formatter.format(picked!.start)+ "\nEnd Date   : "+formatter.format(picked!.end);
    _controller.rxServiceDate.value=start;
  }



  }
  void showCustomDialog(BuildContext context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (BuildContext cxt) {
        return Align(
          alignment: Alignment.center,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Material(
              color:Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
                child:GlassmorphicContainer(
                  borderRadius: 5,
                  blur: 10,
                  alignment: Alignment.topLeft,
                  border: 0.6,
                  linearGradient: LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [
                        Color(0xFFffffff).withOpacity(0.1),
                        Color(0xFFFFFFFF).withOpacity(0.05),
                      ],
                      stops: [
                        0.1,
                        1,
                      ]),
                  borderGradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFFffffff).withOpacity(0.5),
                      Color((0xFFFFFFFF)).withOpacity(0.5),
                    ],
                  ),
                  width: 600,
                  height: 500,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                            Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 12,right: 12,top: 4),
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [

                                      InkWell(
                                        onTap: (){
                                          Get.back();
                                        },
                                        child: Icon(Icons.close),
                                      ),
                                      TextButton(child: Text("Clear All",style:TextStyle(fontSize: 14,decoration: TextDecoration.underline,color: Colors.blueAccent,fontWeight: FontWeight.bold),),
                                      onPressed: (){
                                       _controller.selectedType.value="";
                                       _controller.selectedStatus.value="";
                                       _controller.pickedRangeDate=null;
                                       _controller.rxServiceDate.value="Select Date Range";

                                      },
                                      )

                                    ],
                                  ),
                                ),
                               Divider(thickness: 0.8,color: Colors.grey.withOpacity(0.5),)
                              ],
                            ),
                            PopupMenuItem(
                              enabled: false,
                              padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                              child:Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("Payment Type :                         ",style: Theme.of(context).textTheme.bodyText1),
                                  Obx(()=>DropdownButton<String>(
                                      isExpanded:true,
                                      value: _controller.selectedType.value==""?null:_controller.selectedType.value,
                                      hint: Text("Select Type"),
                                      items: _controller.paymentTypeList
                                          .map<DropdownMenuItem<String>>((String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(
                                            value,
                                            style: TextStyle(fontSize: 15),
                                          ),
                                        );
                                      }).toList(),
                                      // Step 5.
                                      onChanged: (String? newValue) {
                                       _controller.selectedType.value=newValue!;
                                      },
                                    ),
                                  ),
                                ],
                              ),
                              value:"My Profile",
                            ),
                            PopupMenuItem(
                              enabled: false,
                              padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                              child:Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("Payment Status :                         ",style: Theme.of(context).textTheme.bodyText1),
                                  Obx(()=> DropdownButton<String>(
                                      isExpanded:true,
                                      value: _controller.selectedStatus.value==""?null:_controller.selectedStatus.value,
                                      hint: Text("Select status"),
                                      items: _controller.paymentStatusList
                                          .map<DropdownMenuItem<String>>((String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(
                                            value,
                                            style: TextStyle(fontSize: 15),
                                          ),
                                        );
                                      }).toList(),
                                      // Step 5.
                                      onChanged: (String? newValue) {
                                            _controller.selectedStatus.value=newValue!;
                                      },
                                    ),
                                  ),
                                ],
                              ),
                              value:"My Profile",
                            ),
                            PopupMenuItem(
                              enabled: false,
                              padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                              child:Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("Date Range :                           ",style: Theme.of(context).textTheme.bodyText1),
                                  SizedBox(height: 10,),
                                  Obx(()=> Row(
                                    children: [
                                      Icon(Icons.date_range),
                                      SizedBox(width: 10,),
                                      TextButton(child: Text(_controller.rxServiceDate.value,style: TextStyle(fontSize: 16,height: 1.3),),onPressed: (){
                                        dateTime();
                                      },),
                                    ],
                                  )
                                  ),
                                ],
                              ),
                              value:"My Profile",
                            ),
                            PopupMenuItem(
                            enabled: false,
                              padding: EdgeInsets.only(left: 15,right: 15,top: 20,bottom: 20),

                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  ElevatedButton(onPressed: (){
                                    print("evdjnvjefv");
                                    print(widget.type);
                                    if(widget.type==1 || widget.type==3 )
                                      {
                                        _controller.getPaymentData(_controller.etSearch.text);
                                        Get.back();
                                        return;
                                      }
                                    if(_controller.etSearch.text.isNotEmpty)
                                    {
                                      _controller.getPaymentData(_controller.etSearch.text);
                                      Get.back();
                                    }
                                    else{
                                      Fluttertoast.showToast(msg: "Please enter email or phnoe in search field");
                                    }


                                  }, child: Text("    Apply    "),style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),),
                                ],
                              )

                           , value:"My Profile",
                            ),
                      ],
                    ),
                  ),
                ),

            ),
          ),
        );
      },
    );
  }

}

