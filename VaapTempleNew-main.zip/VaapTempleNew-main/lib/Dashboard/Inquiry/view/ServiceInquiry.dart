import 'package:aspgen_mobile/Dashboard/Request/conroller/controller.dart';
import 'package:aspgen_mobile/Widget/LableListActionWidget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/SearchBarWidget.dart';
class ServiceInquiryPage extends StatelessWidget {
  ServiceInquiryPage({Key? key}) : super(key: key);
  ServiceRequestController _controller=Get.put(ServiceRequestController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Services Inquiry"),
        actions: [
          Obx(() =>  PopupMenuButton<String>(
                child: Icon(Icons.filter_alt_outlined),
                color: Theme.of(context).colorScheme.onPrimaryContainer.withRed(3),
                offset: Offset(10, 50),
                elevation: 5,
                itemBuilder:(context) =>
                    List.generate(_controller.statusList.length,(int index)=>
                    PopupMenuItem<String>(
                      value: _controller.statusList[index],
                      child:Text(_controller.statusList[index])

                )

            ),
              initialValue: _controller.rxStatus.value,
        enabled: true,
        onSelected: (value) {
             _controller.rxStatus.value=value;
             _controller.fetchApi();
        },

      ),

          ),

        SizedBox(width: 10, )
        ]),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              SizedBox(height: 10,),
              GetBuilder<ServiceRequestController>(
                builder: (controller)=>  SearchBarWidget(
                  hint: "Search",
                  controller: controller.etSearch,
                  onchange: (value){
                    controller.update();
                    controller.filterData(value);
                  },
                  onCancel: (){
                    controller.etSearch.clear();
                    controller.filterData(controller.etSearch.text);
                    controller.update();
                  },
                ),
              ),
              SizedBox(height: 8,),
              Obx(() =>(_controller.datas.value.data!=null &&_controller.datas.value.data!.isNotEmpty)? ListView.builder(
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemCount: _controller.datas.value.data!.length,
                  itemBuilder: (context,index){
                    final datum=_controller.datas.value.data![index];
                    return  LableListWidget(title: datum.serviceName??"",
                      titlelable: "Service Name",subTitleLable:"Location",subTitle2Lable: "Service Date",
                      subTitle: datum.serviceLocationName??"",
                      subTitle2: dateParser(datum.serviceDate!),
                      viewMoreWidget: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children:[
                            if(datum.comments!.contactName!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                            if(datum.comments!.contactName!.isNotEmpty) viewMore("Devotee Details  ",datum.comments!.contactName??""),
                            SizedBox(height: 5,),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(Icons.phone,color: Colors.green,),SizedBox(width: 6,),
                                Expanded(child: Text(phoneFormatter(datum.prsnPhone.toString()),style: Theme.of(Get.context!).textTheme.bodyText1!)),
                              ],
                            ),
                            SizedBox(height: 5,),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(Icons.email,color: Colors.amber,),SizedBox(width: 6,),
                                Expanded(child: Text(UtilMethods.decrypt(datum.prsnEmail.toString()),style: Theme.of(Get.context!).textTheme.bodyText1!)),
                              ],
                            ),

                            if(datum.comments!.contactName!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                            if(datum.comments!.contactName!.isNotEmpty) viewMore("Requested Priest Details  ",datum.requestForPriestName??""),
                            SizedBox(height: 5,),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(Icons.phone,color: Colors.green,),SizedBox(width: 6,),
                                Expanded(child: Text(phoneFormatter(datum.priestPhone.toString()),style: Theme.of(Get.context!).textTheme.bodyText1!)),
                              ],
                            ),
                            SizedBox(height: 5,),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(Icons.email,color: Colors.amber,),SizedBox(width: 6,),
                                Expanded(child: Text(UtilMethods.decrypt(datum.priestEmail.toString()),style: Theme.of(Get.context!).textTheme.bodyText1!)),
                              ],
                            ),
                            // if(datum.comments!.contactName!.isNotEmpty) viewMore("Devotee Email  ",datum.prsnEmail??""),
                            // if(datum.comments!.contactName!.isNotEmpty) viewMore("Devotee Name  ",datum.comments!.contactName??""),
                            // if(datum.comments!.contactName!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                            // if(datum.comments!.contactName!.isNotEmpty) viewMore("Devotee Name  ",datum.comments!.contactName??""),


                          ]),
                      textEditingController:_controller.etSearch,
                      onTapVieMore: (){
                        datum.isChecked=!datum.isChecked!;
                        _controller.datas.refresh();
                      },
                      icon: Icons.arrow_forward,
                      iconColor: Colors.white,
                      editOnTap: (){
                        CheckInternetConnection().then((value) {
                          if(value==true)
                          {
                            _controller.sendData(datum);
                            // Get.to(()=>ServiceRequestDetailsPage());
                          }
                        });
                      }, isClicked: datum.isChecked!,
                    );
                  })

                  :Center(
                child: Text("No Data Available!"),
              ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
