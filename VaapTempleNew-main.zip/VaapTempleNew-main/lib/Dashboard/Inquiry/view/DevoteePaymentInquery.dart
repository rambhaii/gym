
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../../Widget/CustomListshowOnly.dart';
import '../controller/payment_controller.dart';



class DevoteePaymentInquiryPage extends StatefulWidget {
  final String title;
  const DevoteePaymentInquiryPage({Key? key, required this.title}) : super(key: key);

  @override
  _DevoteePaymentInquiryPageState createState() => _DevoteePaymentInquiryPageState();
}

class _DevoteePaymentInquiryPageState extends State<DevoteePaymentInquiryPage> {

  late PaymentController _controller;
  DateTime?tempDate;
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  @override
  void initState() {
    _controller= Get.put(PaymentController(type: 1));
    _controller.getFilterApiCu("DEVOTEE");
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
        ),

      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          children: [SizedBox(height: 8,),
            //Obx(()=> Text("Date "+_controller.rxServiceDate.value,style: TextStyle(color: Colors.tealAccent,fontWeight: FontWeight.bold,fontSize: 15),)),
            Padding(
              padding: EdgeInsets.only(left: 12,right: 12,top: 8),
              child: Obx(()=>_controller.map.value!=null?
              Autocomplete<Map>(
                optionsBuilder: (TextEditingValue textEditingValue) {
                  return _controller.map.value.where((Map county) => county["name"].toLowerCase().startsWith(textEditingValue.text.toLowerCase())
                  ).toList();
                },
                displayStringForOption: (Map option) => option["name"],
                fieldViewBuilder: (
                    BuildContext context,
                    TextEditingController fieldTextEditingController,
                    FocusNode fieldFocusNode,
                    VoidCallback onFieldSubmitted
                    ) {
                  return TextField(
                    controller: fieldTextEditingController,
                    focusNode: fieldFocusNode,
                    decoration: InputDecoration(
                      enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey.withOpacity(0.7),width: 0.8)
                      ),
                      focusedBorder:  OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey)
                      ),
                      errorBorder:   OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.red)
                      ),
                      focusedErrorBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.grey)
                      ),
                      counter: Offstage(),
                      hintText: "Search",
                      alignLabelWithHint: true,
                      hintStyle:Theme.of(context).textTheme.bodyText2,
                      labelText:"Search",
                      contentPadding: const EdgeInsets.all(12.0),
                      labelStyle: Theme.of(context).textTheme.bodyText2,
                    ),
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  );
                },
                onSelected: (Map selection) {
                  _controller.rxCustomerName.value=selection["name"];
                 _controller.getInquieryData(selection["name"]);
                },
                optionsViewBuilder: (
                    BuildContext context,
                    AutocompleteOnSelected<Map> onSelected,
                    Iterable<Map> options
                    ) {
                  return Align(
                    alignment: Alignment.topLeft,
                    child: Material(
                      child: Container(
                        width: w*0.92,
                        decoration: BoxDecoration(
                            color: Theme.of(context).colorScheme.onPrimaryContainer,
                            border: Border.all(color: Colors.grey.withOpacity(0.8),width: 0.8)),

                        child: Row(
                          children: [
                            Expanded(
                              child: ListView.builder(
                                padding: EdgeInsets.only(bottom: 10,right: 10,top: 8),
                                itemCount: options.length,
                                shrinkWrap: true,
                                itemBuilder: (BuildContext context, int index) {
                                  final Map option = options.elementAt(index);
                                  return GestureDetector(
                                    onTap: () {
                                      onSelected(option);
                                    },
                                    child: ListTile(
                                      title: Text(option["name"], style: Theme.of(context).textTheme.bodyText1),
                                      subtitle: Text(option["email"]+"\n"+option["phone"], style: Theme.of(context).textTheme.bodyText2),
                                    ),
                                  );
                                },
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ):Container(),
              ),
            ),

            Obx(()=> _controller.servicedata.value.isNotEmpty?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {

                  });
                },
                child: ListView.builder(
                    itemCount:_controller.servicedata.value[0].paymentsData!.length,
                    itemBuilder: (context,index)
                    {
                      final datas=_controller.servicedata.value[0].paymentsData![index];
                      return CustomListShowOnlyWidget(title: datas.serviceName??"",
                        subTitle:(datas.serviceDate??"")+"  "+(datas.time??"") ,
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[

                              RichText(
                                text: TextSpan(
                                  text: 'Amount : ',
                                  style: Theme.of(context).textTheme.bodyText2,
                                  children: <TextSpan>[
                                    TextSpan(
                                        text:  "\$ "+datas.serviceAmount.toString(),
                                        style: Theme.of(context).textTheme.bodyText1),
                                  ],
                                ),
                              ),
                              SizedBox(height: 2,),

                              RichText(
                                text: TextSpan(
                                  text: "Day:-   ",
                                  style: Theme.of(context).textTheme.bodyText2,
                                  children: <TextSpan>[
                                    TextSpan(text:datas.day.toString(),
                                        style: Theme.of(context).textTheme.bodyText1),
                                  ],
                                ),
                              )
                            ]),
                        textEditingController: _controller.etSearch,isClicked: datas.isChecked!??false,
                        onTapVieMore: (){
                          datas.isChecked=!datas.isChecked!;
                          _controller.servicedata.refresh();
                        },
                        editOnTap: (){

                        },
                      );

                    }),
              ),
            ):Container(),)

          ],
        ),
      ),
    );
  }

}
