import 'dart:math';


import 'package:aspgen_mobile/Dashboard/Request/view/ChatUi.dart';
import 'package:aspgen_mobile/Dashboard/Request/view/ReScheduledPage.dart';
import 'package:aspgen_mobile/Dashboard/Request/view/service_request_details_page.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppColors.dart';
import '../../../PriestDashboard/PoojaList/controller/controller.dart';
import '../../../PriestDashboard/PoojaList/view/ViewPoojaListPage.dart';
import '../../../PriestDashboard/PoojaList/view/pooja_list.dart';
import '../../../Widget/FullScreenImageWidget.dart';
import '../../../Widget/HiglitTextWidget.dart';
import '../conroller/controller.dart';
import '../../../Widget/CustomListFourTitleWidget.dart';
import '../../../Widget/EditextWidget.dart';
import '../../../AppConstant/AppConstant.dart';
import 'CancelationPage.dart';
class ServiceActionPage extends StatefulWidget {

   ServiceActionPage({Key? key}) : super(key: key);

  @override
  State<ServiceActionPage> createState() => _ServiceActionPageState();
}

class _ServiceActionPageState extends State<ServiceActionPage> with SingleTickerProviderStateMixin {
  ServiceRequestController _controller=Get.find();
  late final tabController = TabController(length: 4, vsync: this);
  PoojaListController _poojaListController=Get.put(PoojaListController());

  @override
  Widget build(BuildContext context) {
    _controller.isExpendAction.value=false;
    TextStyle subTitle=Theme.of(context).textTheme.bodyText2!;
    TextStyle title=Theme.of(context).textTheme.bodyText1!;
    final datum=_controller.datum.value;
    var dateTime="";

    try{
      dateTime=_controller.formatter.format(_controller.formatter1.parse(datum.serviceDate!));
    }
    catch(e){

    }
    TextEditingController etsearch=new TextEditingController();
    return Scaffold(
      appBar: AppBar(title: Text(_controller.datum.value.serviceName!),
        actions: [

        ],
      ),
      body: Column(
        children: [

          Card(
         color: AppColor.getColorByServiceCategory(datum.serviceCategoryTypes!).withOpacity(0.35),
         elevation: 6,

         child:
         Column(
           children: [
             Divider(
               height: 0.5,
               thickness: 0.5,
               color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
             ),
             SizedBox(height: 6),
             Padding(
               padding: const EdgeInsets.all(8.0),
               child: Row(
                 mainAxisAlignment: MainAxisAlignment.spaceBetween,
                 children: [
                   HigliteText(textData:  dateTime + " " +datum.serviceTime!, query: etsearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle),
                   HigliteText(textData: datum.serviceStatus.toString(), query: etsearch.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 15,color: AppColor.getColorByStatus(datum.serviceStatus!) ) as TextStyle),
                 ],
               ),
             ),
             SizedBox(
               height: 8,
             ),
             Row(
               crossAxisAlignment:CrossAxisAlignment.start,

               children: [
                 Spacer(flex: 1,),
                 Expanded(
                   flex: 5,
                   child: Stack(
                     children: [
                       datum.serviceImage!.isEmpty?  CircleAvatar(
                         backgroundColor: Color(Random().nextInt(0xffffffff)),
                         child: Text(
                             datum.serviceName!.trim().toString().toUpperCase() ==
                                 "" ? "" : datum.serviceName!.trim()[0].toString().toUpperCase(),
                             style: Theme.of(context).textTheme.headline4
                         ),
                         maxRadius: 27,
                       )
                           :GestureDetector(
                         onTap: (){
                           Get.to(()=>FullScreenImageWidget(path: APIsConstant.IP_Base_Url+datum.serviceImage!,),fullscreenDialog: true);
                         },
                         child: ClipOval(
                           child: CachedNetworkImage(
                             fit: BoxFit.cover,
                             imageUrl:APIsConstant.IP_Base_Url+datum.serviceImage!,
                             height: 50,
                             width: 50,
                             placeholder: (context,url)=>const CircularProgressIndicator(),
                             errorWidget: (context,url,error)=>const Icon(Icons.error),
                           ),
                         ),
                       ),
                     ],
                   ),
                 ),
                 Spacer(flex: 1,),
                 Expanded(
                   flex: 20,
                   child: Column(
                     mainAxisAlignment: MainAxisAlignment.start,
                     crossAxisAlignment: CrossAxisAlignment.start,
                     children: [
                       HigliteText(textData: datum.serviceName??"", query:etsearch.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(
                           color:  subTitle.toString() == "PRIEST"
                               ? Colors.amber
                               :  subTitle.toString()== "DEVOTEE"
                               ? Colors.green:
                           subTitle.toString()== "GUEST"?Colors.purple  : Colors.amber,
                           fontSize: 18,fontWeight: FontWeight.w400
                       )
                       ),
                       SizedBox(
                         height: 8,
                       ),
                      HigliteText(textData:datum.comments!.contactName!, query: etsearch.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 15) as TextStyle),
                       SizedBox(
                         height: 8,
                       ),
                       Padding(
                         padding: const EdgeInsets.only(right: 10.0),
                         child: Row(
                           mainAxisAlignment: MainAxisAlignment.end,
                           children: [
                             HigliteText(textData: datum.serviceCategoryTypes.toString(), query: etsearch.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 15 ) as TextStyle),
                           ],
                         ),
                       ),
                       SizedBox(
                         height: 5,
                       ),

                     ],
                   ),
                 ),
               ],
             ),
             SizedBox(
               height: 10,
             ),
             Row(
               mainAxisAlignment: MainAxisAlignment.spaceAround,
               children: [
                 customBtn("Book Service",Colors.green,()
                 {_controller.pagecontroller.animateToPage(0, duration: Duration(milliseconds: 500), curve: Curves.easeIn);
                   },Icons.bookmark_border_sharp),
                 customBtn("Reschedule",Colors.purpleAccent,(){
                   _controller.pagecontroller.animateToPage(1, duration: Duration(milliseconds: 500), curve: Curves.easeIn);
                 },Icons.refresh),
                 Expanded(
                   flex: 1,
                   child: InkWell(
                     onTap: (){
                       _controller.pagecontroller.animateToPage(2, duration: Duration(milliseconds: 500), curve: Curves.easeIn);
                        _poojaListController.sendData(_controller.datum.value);
                       _poojaListController.sendPoojaList(datum.poojaList!);
                     },
                     child: Container(
                       padding: EdgeInsets.only(left: 3,right: 3,bottom: 3,top: 3),
                       margin: EdgeInsets.all(3),
                       decoration: BoxDecoration(
                           color: Colors.pinkAccent,
                           borderRadius: BorderRadius.circular(2)
                       ),
                       child: Image.asset("assets/images/poojaListicon.png",height: 31,width: 31),
                     ) ,
                   ),
                 ),
                 customBtn("Messages",Colors.amber,(){
                   _controller.pagecontroller.animateToPage(3, duration: Duration(milliseconds: 500), curve: Curves.easeIn);
                   }, Icons.message),

                 // customBtn("Pooja List",Colors.amber,(){
                 //   _controller.pagecontroller.animateToPage(2, duration: Duration(milliseconds: 500), curve: Curves.easeIn);
                 //   }, Icons.message),
                 customBtn("Reject",Colors.red,(){
                   _controller.pagecontroller.animateToPage(4, duration: Duration(milliseconds: 500), curve: Curves.easeIn);
                   },Icons.cancel),


               ],
             ),
             SizedBox(height: 10),
             Divider(
               height: 0.5,
               thickness: 0.5,
               color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
             ),

           ],
         ),
       ),

          Expanded(
            child: PageView(
            physics: NeverScrollableScrollPhysics(),
            onPageChanged: ((value) {
            //  _tabController.index=value;
            }),
            controller: _controller.pagecontroller,
            children: [
            ServiceRequestDetailsPage(),
            RescheduledPage(),
           ViewPoojaListPage(type: 2,),
              ChatUiPage(),

              CancelationPage(),
            ],
            ),
          ),
        ],
      ),
    );
  }

   Widget customBtn(String title,Color color,VoidCallback onPress,IconData iconData){
    return Expanded(
      flex: 1,
      child: InkWell(
        onTap: onPress,
        child: Container(
          padding: EdgeInsets.only(left: 3,right: 3,bottom: 6,top: 6),
          margin: EdgeInsets.all(3),
          decoration: BoxDecoration(
              color: color.withOpacity(.7),
            borderRadius: BorderRadius.circular(2)
          ),
          child: Icon(iconData,size: 25,),
        ) ,
      ),
    );
      
      

   }
}