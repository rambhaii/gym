import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Request/conroller/RequestFormController.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/DropdownButtonWidget.dart';
import '../../../Widget/EditextWidget.dart';
import '../conroller/controller.dart';

class RequestFormPage extends StatefulWidget {

  RequestFormPage({Key? key}) : super(key: key);

  @override
  State<RequestFormPage> createState() => _RequestFormPageState();
}

class _RequestFormPageState extends State<RequestFormPage> {
  RequestFormController _controller=Get.put(RequestFormController());

  final GlobalKey expansionTile = new GlobalKey();

  @override
  void initState() {

    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    TextStyle title=Theme.of(context).textTheme.bodyText1!;
    TextStyle subTitle=Theme.of(context).textTheme.bodyText2!;
    BoxDecoration decoration=BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.1),width: 0.4)),
        color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.3));
    return Scaffold(
    appBar:  AppBar(
        automaticallyImplyLeading: false,
        title: Text("Add Event"),
        actions: [
          RawMaterialButton(
            onPressed: () {
              if(_controller.etemail.text.isEmpty)
                {
                  Fluttertoast.showToast(msg: "Please Search Devotee");
                  return;
                }
              if(_controller.etserviceName.text.isEmpty)
              {
                Fluttertoast.showToast(msg: "Please Enter Service Name");
                return;
              }
              if(_controller.etdate.text.isEmpty)
              {
                Fluttertoast.showToast(msg: "Please Select Service Date");
                return;
              }
              if(_controller.ettime.text.isEmpty)
              {
                Fluttertoast.showToast(msg: "Please Select Service Time");
                return;
              }
              if(_controller.etServiceLocation.text.isEmpty)
              {
                Fluttertoast.showToast(msg: "Please Select Service Location");
                return;
              }  if(_controller.etchildren.text.isEmpty)
              {
                Fluttertoast.showToast(msg: "Please Enter No. of  Childen");
                return;
              }  if(_controller.etadult.text.isEmpty)
              {
                Fluttertoast.showToast(msg: "Please Enter No. of Adult ");
                return;
              }
              if(_controller.etPriestName.text.isEmpty)
              {
                Fluttertoast.showToast(msg: "Please Select Priest ");
                return;
              }
           _controller. addServiceRequest();

            },
            child: Image.asset("assets/images/diskbold.png",height: 22,width: 22,color: Colors.white,),
            fillColor: Colors.green,
            shape: CircleBorder(),
            elevation: 5,
            constraints: BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        SizedBox(width: 8,)
      ],
      ),
      body: SingleChildScrollView(
        child: Container(

          child: Obx(()=> ListView(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              key: Key('builder ${_controller.isSelected.value.toString()}'),
              children:[SizedBox(height: 8,),
                Obx(()=>Container(
                  margin: EdgeInsets.only(top:15,left: 5,right: 5),
                  decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend1.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                  child: ListTileTheme(
                    dense: true,
                    horizontalTitleGap: 15.0,
                    minLeadingWidth: 0,
                    child: ExpansionTile(
                        key: Key("0"),
                        collapsedTextColor: Colors.tealAccent,
                        textColor: Colors.tealAccent,
                        childrenPadding: EdgeInsets.only(left: 10,right: 10),
                        onExpansionChanged: (value){
                          _controller.isExpend1.value=value;
                          _controller.isExpend2.value=false;
                          _controller.isExpend3.value=false;
                          _controller.isSelected.value=0;
                        },
                        initiallyExpanded: _controller.isExpend1.value,
                        title: Text("Devotee Info",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                        children:<Widget>
                        [
                          Column(
                            children: [
                              GetBuilder<RequestFormController>(
                                  builder: (controller)=> Row(
                                    children: [
                                      Expanded(
                                        flex: 13,
                                        child: Container(
                                            margin: EdgeInsets.only(left: 0,right: 5),
                                            decoration: BoxDecoration(
                                              borderRadius: BorderRadius.circular(5),
                                              border: Border(
                                                  top: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                                  bottom: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                                  right: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                                  left: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                                              color:Color(0xff6d8d8c).withOpacity(0.3),
                                            ),
                                            child: TextField(
                                              autofocus: false,
                                              style: Theme.of(context).textTheme.bodyText1,
                                              controller:_controller.etSearchDevotee,
                                              onChanged:((value){
                                                _controller.update();
                                              }),
                                              decoration: new InputDecoration(
                                                fillColor: Colors.teal,
                                                border: InputBorder.none,
                                                focusedBorder: InputBorder.none,
                                                enabledBorder: InputBorder.none,
                                                errorBorder: InputBorder.none,
                                                disabledBorder: InputBorder.none,
                                                contentPadding:
                                                EdgeInsets.only(left: 10, top: 15, right: 2),
                                                hintText: "Search Email / Phone",
                                                hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.4)),
                                                suffixIcon: _controller.etSearchDevotee.text.isNotEmpty?InkWell(
                                                  onTap: (){
                                                    _controller.etSearchDevotee.clear();
                                                  },
                                                  child: Icon(
                                                    Icons.clear,
                                                    color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                                                  ),
                                                ):Icon(
                                                  Icons.clear,
                                                  color: Colors.transparent,
                                                ),
                                              ),
                                            )
                                        ),
                                      ),
                                      Expanded(
                                        flex: 2,
                                        child: Container(
                                          margin: EdgeInsets.only(right: 4),
                                          child: RawMaterialButton(onPressed: (){
                                            if(_controller.etSearchDevotee.text.isNotEmpty)
                                            {
                                               _controller.fetchFilterApi(_controller.etSearchDevotee.text);
                                            }
                                            else{
                                              Fluttertoast.showToast(msg: "Please enter email or phone in search field");
                                            }
                                          }
                                            ,child: Icon(Icons.search),fillColor: Colors.green.withOpacity(0.5),shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 44.0, minHeight: 44.0),),
                                        ),
                                      ),

                                    ],
                                  )
                              ),
                               SizedBox(height: 12,),
                              SizedBox(height: 6,),
                              EditTextWidget(
                                maxLength: 200,
                                hint: "Enter Email",
                                isPassword: false,
                                isRead: true,
                                keyboardtype: TextInputType.text,
                                label:"Enter Email",
                                formatter:[],
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter email';
                                  }

                                  return null;
                                },
                                controller: _controller.etemail,
                                maxline: 1,
                              ),


                              SizedBox(height: 6,),

                              EditTextWidget(
                                maxLength: 200,
                                hint: "Enter Devotee Phone",
                                isPassword: false,
                                keyboardtype: TextInputType.text,
                                label:"Devotee Phone  ",
                                formatter:[],
                                isRead: true,
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter Devotee Phone  ';
                                  }

                                  return null;
                                },
                                controller: _controller.etphone,
                                maxline: 1,
                              ),
                              SizedBox(height: 6,),







                              Row(
                                children: [
                                  Expanded(
                                    flex: 4,
                                    child:       EditTextWidget(
                                      maxLength: 200,
                                      hint: "Enter State",
                                      isPassword: false,
                                      keyboardtype: TextInputType.text,
                                      label:"State",
                                      formatter:[],
                                      isRead: true,
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please Enter State';
                                        }

                                        return null;
                                      },
                                      controller: _controller.etstate,
                                      maxline: 1,
                                    ),
                                  ),


                                  SizedBox(width: 10,),
                                  Expanded(
                                    flex: 4,
                                    child:  EditTextWidget(
                                      maxLength: 6,
                                      hint: "Enter Zip",
                                      isPassword: false,
                                      keyboardtype: TextInputType.number,
                                      label:"Zip",
                                      isRead: true,
                                      formatter:[],
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please Enter Zip';
                                        }

                                        return null;
                                      },
                                      controller: _controller.etzip,
                                      maxline: 1,
                                    ),
                                  ),


                                ],
                              ),

                              SizedBox(height: 6,),
                              EditTextWidget(
                                maxLength: 200,
                                hint: "Enter City",
                                isPassword: false,
                                isRead: true,
                                keyboardtype: TextInputType.text,
                                label:"City",
                                formatter:[],
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter City';
                                  }

                                  return null;
                                },
                                controller: _controller.etcity,
                                maxline: 1,
                              ),
                              SizedBox(height: 6,),
                              EditTextWidget(
                                maxLength: 2000,
                                hint: "Enter Address",
                                isPassword: false,
                                isRead: true,
                                keyboardtype: TextInputType.text,
                                label:"Address",
                                formatter:[],
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter Address';
                                  }

                                  return null;
                                },
                                controller: _controller.etaddress,
                                maxline: 1,
                              ),

                            ],
                          ),

                          SizedBox(height: 6,),

                        ]
                    ),
                  ),
                ),
                ),



                Obx(()=> Container(
                  margin: EdgeInsets.only(top:15,left: 5,right: 5),
                  decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend2.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Color(0xEBFF448D),)),
                  child: ListTileTheme(
                    dense: true,
                    horizontalTitleGap: 15.0,
                    minLeadingWidth: 0,
                    child: ExpansionTile(
                        maintainState: true,
                        collapsedTextColor: Color(0xEBFF448D),
                        textColor:Color(0xEBFF448D),
                        childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                        onExpansionChanged: (value){
                          _controller.isExpend2.value=value;
                          _controller.isExpend1.value=false;
                          _controller.isExpend3.value=false;
                          _controller.isExpend4.value=false;
                          _controller.isSelected.value=1;
                        },
                        initiallyExpanded: _controller.isExpend2.value,
                        key: Key("1"),
                        title: Text("Service Request Details",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                        children:<Widget>
                        [
                          Column(
                            children: [

                             SizedBox(height: 4,),
                              Obx(()=> _controller.rxServiceCategoryList.isNotEmpty?
                              Container(
                                height: 50,
                                width: Get.width,
                                child:  DropdownButtonWidget(
                                  change: (value) {
                                    _controller.selectedServiceCategoryValue=value;
                                    _controller.etserviceCategory.text=_controller.selectedServiceCategoryValue["name"];
                                    _controller.rxServiceCategoryList.refresh();
                                    _controller.selectedServiceValue=null;
                                    _controller.rxServiceNameList.clear();
                                    _controller.rxServiceNameList.refresh();
                                    _controller.getServicesDetails(_controller.selectedServiceCategoryValue["name"]);
                                  },
                                  title: "Select Categort Type",
                                  list:_controller.rxServiceCategoryList.value,
                                  hint: "Select Category Type",
                                  selectvalue: _controller.selectedServiceCategoryValue,
                                  onPress: '',
                                ),

                              ):Container()
                                ,),
                              SizedBox(height:12,),
                              Obx(()=> _controller.rxServiceNameList.isNotEmpty?
                              Container(
                                height: 50,
                                width: Get.width,
                                child:  DropdownButtonWidget(
                                  change: (value) {
                                    _controller.selectedServiceValue=value;
                                    _controller.etserviceName.text=_controller.selectedServiceValue["name"];
                                    _controller.etserviceType.text=_controller.selectedServiceValue["serviceType"];
                                    _controller.rxServiceNameList.refresh();
                                  },
                                  title: "Select Service",
                                  list:_controller.rxServiceNameList.value,
                                  hint: "Select Service",
                                  selectvalue: _controller.selectedServiceValue,
                                  onPress: '',
                                ),

                              ):Container()
                                ,),
                              SizedBox(height:12,),
                              // EditTextWidget(
                              //   maxLength: 2000,
                              //   hint: "Enter Service Category",
                              //   isPassword: false,
                              //   keyboardtype: TextInputType.text,
                              //   label:"Service Category",
                              //   formatter:[],
                              //   validator: (value) {
                              //     if (value == null || value.isEmpty) {
                              //       return 'Please Enter Service Category';
                              //     }
                              //
                              //     return null;
                              //   },
                              //   controller: _controller.etserviceCategory,
                              //   maxline: 1,
                              // ),


                              // EditTextWidget(
                              //   maxLength: 2000,
                              //   hint: "Enter Service Name",
                              //   isPassword: false,
                              //   keyboardtype: TextInputType.text,
                              //   label:"Service Name",
                              //   formatter:[],
                              //   validator: (value) {
                              //     if (value == null || value.isEmpty) {
                              //       return 'Please Enter Service Name';
                              //     }
                              //
                              //     return null;
                              //   },
                              //   controller: _controller.etserviceName,
                              //   maxline: 1,
                              // ),

                              SizedBox(height:6,),
                              Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: GestureDetector(
                                      onTap: ()async{
                                        var date =await showDatePicker(
                                            context: context,
                                            initialDate:DateTime.now(),
                                            firstDate: DateTime(1900),
                                            lastDate: DateTime(2100),
                                            builder: (context, child) {
                                              return Theme(
                                                data: ThemeData.dark().copyWith(
                                                    colorScheme: const ColorScheme.dark(
                                                        onPrimary: Colors.white,
                                                        // selected text color
                                                        onSurface: Colors.white,
                                                        // default text color
                                                        primary: Colors
                                                            .teal // circle color
                                                    ),
                                                    dialogBackgroundColor: Theme
                                                        .of(context)
                                                        .backgroundColor,
                                                    textButtonTheme: TextButtonThemeData(
                                                        style: TextButton.styleFrom(
                                                            textStyle: const TextStyle(
                                                                color: Colors.white,
                                                                fontWeight: FontWeight
                                                                    .normal,
                                                                fontSize: 12,
                                                                fontFamily: 'Quicksand'),
                                                            primary: Colors.white,
                                                            // color of button's letters
                                                            backgroundColor: Colors
                                                                .black54,
                                                            // Background color
                                                            shape: RoundedRectangleBorder(
                                                                side: const BorderSide(
                                                                    color: Colors
                                                                        .transparent,
                                                                    width: 1,
                                                                    style: BorderStyle
                                                                        .solid),
                                                                borderRadius: BorderRadius
                                                                    .circular(50))))),
                                                child: child!,
                                              );
                                            });

                                        final DateFormat formatter = DateFormat('MM/dd/yyyy');
                                        final String formatted = formatter.format(date!);
                                        _controller.etdate.text = formatted;
                                      },
                                      child: AbsorbPointer(
                                        child: EditTextWidget(
                                          maxLength: 2000,
                                          hint: "Enter Date",
                                          isPassword: false,
                                          keyboardtype: TextInputType.text,
                                          label:" Date",
                                          formatter:[],
                                          validator: (value) {
                                            if (value == null || value.isEmpty) {
                                              return 'Please Enter Service Date';
                                            }

                                            return null;
                                          },
                                          controller: _controller.etdate,
                                          maxline: 1,
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(width:12,),

                                  Expanded(
                                    flex:2,
                                    child: GestureDetector(
                                      onTap: ()async{
                                        TimeOfDay? time = await showTimePicker(
                                            context: context,
                                            initialTime: TimeOfDay.now(),
                                            builder: (context, child) {
                                              return Theme(
                                                data: ThemeData.dark().copyWith(
                                                    colorScheme: const ColorScheme.dark(
                                                        onPrimary: Colors.white,
                                                        onSurface: Colors.white,
                                                        primary: Colors.teal // circle color
                                                    ),
                                                    dialogBackgroundColor: Theme
                                                        .of(context)
                                                        .backgroundColor,

                                                    textButtonTheme: TextButtonThemeData(
                                                        style: TextButton.styleFrom(
                                                            textStyle: const TextStyle(
                                                                color: Colors.white,
                                                                fontWeight: FontWeight
                                                                    .normal,
                                                                fontSize: 12,
                                                                fontFamily: 'Quicksand'),
                                                            primary: Colors.white,
// color of button's letters
                                                            backgroundColor: Colors
                                                                .black54,
// Background color
                                                            shape: RoundedRectangleBorder(
                                                                side: const BorderSide(
                                                                    color: Colors
                                                                        .transparent,
                                                                    width: 1,
                                                                    style: BorderStyle
                                                                        .solid),
                                                                borderRadius: BorderRadius
                                                                    .circular(50))))),
                                                child: child!,
                                              );
                                            }

                                        );
                                         if(time!=null){
                                           _controller.ettime.text = formatTimeOfDay(time!);
                                         }

                                      },
                                      child: AbsorbPointer(
                                        child: EditTextWidget(
                                          maxLength: 2000,
                                          hint: "Enter Time",
                                          isPassword: false,
                                          keyboardtype: TextInputType.text,
                                          label:" Time",
                                          formatter:[],
                                          validator: (value) {
                                            if (value == null || value.isEmpty) {
                                              return 'Please Enter  Time';
                                            }
                                            return null;
                                          },
                                          controller: _controller.ettime,
                                          maxline: 1,
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),

                              SizedBox(height:6,),
                              Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child:
                                    EditTextWidget(
                                      maxLength: 3,
                                      hint: "Enter No. of Adults",
                                      isPassword: false,
                                      keyboardtype: TextInputType.number,
                                      label:"Adults",
                                      formatter:[],
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please Enter Adults';
                                        }

                                        return null;
                                      },
                                      controller: _controller.etadult,
                                      maxline: 1,

                                    ),
                                  ),
                                  SizedBox(width:12,),

                                  Expanded(
                                    flex:2,
                                    child:  EditTextWidget(
                                      maxLength: 3,
                                      hint: "Enter No. of Children",
                                      isPassword: false,
                                      keyboardtype: TextInputType.number,
                                      label:"Children",
                                      formatter:[],
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please Enter Children';
                                        }

                                        return null;
                                      },
                                      controller: _controller.etchildren,
                                      maxline: 1,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height:6,),
                              Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child:      Obx(()=>
                                        Container(
                                          height: 48,
                                          width: Get.width,
                                          margin: EdgeInsets.only(bottom: 8),

                                          child:  DropdownButtonWidget(
                                            change: (value) {
                                              _controller.locationValue=value;
                                              _controller.etServiceLocation.text=_controller.locationValue["name"];
                                              _controller.rxLocation.refresh();
                                            },
                                            title: "Select Location ",
                                            list:_controller.rxLocation.value,
                                            hint: "Select Location",
                                            selectvalue: _controller.locationValue,
                                            onPress: '',
                                          ),

                                        )
                                      ,),
                                    // EditTextWidget(
                                    //   maxLength: 2000,
                                    //   hint: "Enter Service Location",
                                    //   isPassword: false,
                                    //   keyboardtype: TextInputType.text,
                                    //   label:"Service Location",
                                    //   formatter:[],
                                    //   validator: (value) {
                                    //     if (value == null || value.isEmpty) {
                                    //       return 'Please Enter Service Location';
                                    //     }
                                    //
                                    //     return null;
                                    //   },
                                    //   controller: _controller.etServiceLocation,
                                    //   maxline: 1,
                                    // ),
                                  ),
                                  SizedBox(width:12,),

                                  Expanded(
                                    flex:2,
                                    child:  EditTextWidget(
                                      maxLength: 2000,
                                      hint: "Enter Service Amount",
                                      isPassword: false,
                                      keyboardtype: TextInputType.text,
                                      label:"Service Amount",
                                      formatter:[],
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please Enter Service Amount';
                                        }

                                        return null;
                                      },
                                      controller: _controller.etServiceAmount,
                                      maxline: 1,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height:6,),
                              Obx(()=>
                              Container(
                                height: 50,
                                width: Get.width,
                                child:  DropdownButtonWidget(
                                  change: (value) {
                                    _controller.languageValue=value;
                                    _controller.etLanguage.text=_controller.languageValue["name"];
                                    _controller.rxLanguage.refresh();
                                  },
                                  title: "Select Language ",
                                  list:_controller.rxLanguage.value,
                                  hint: "Select Language",
                                  selectvalue: _controller.languageValue,
                                  onPress: '',
                                ),

                              )
                                ,),
                              // EditTextWidget(
                              //   maxLength: 2000,
                              //   hint: "Enter Language",
                              //   isPassword: false,
                              //   keyboardtype: TextInputType.text,
                              //   label:" Language",
                              //   formatter:[],
                              //   validator: (value) {
                              //     if (value == null || value.isEmpty) {
                              //       return 'Please Enter Service Language';
                              //     }
                              //
                              //     return null;
                              //   },
                              //   controller: _controller.etLanguage,
                              //   maxline: 1,
                              // ),
                              SizedBox(height:12,),
                              EditTextWidget(
                                maxLength: 2000,
                                hint: "Enter Address",
                                isPassword: false,
                                keyboardtype: TextInputType.text,
                                label:"Service Address",
                                formatter:[],
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter Address';
                                  }

                                  return null;
                                },
                                controller: _controller.etaddress,
                                maxline: 1,
                              ),

                              SizedBox(height:6,),
                              EditTextWidget(
                                maxLength: 2000,
                                hint: "Enter Notes",
                                isPassword: false,
                                keyboardtype: TextInputType.text,
                                label:"Service Notes",
                                formatter:[],
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter Notes';
                                  }

                                  return null;
                                },
                                isCounter: true,
                                controller: _controller.etnotes,
                                maxline: 5,
                              ),

                              SizedBox(height:6,),

                            ],
                          ),


                        ]
                    ),
                  ),
                ),
                ),

                Obx(() => Container(
                  margin: EdgeInsets.only(top:15,left: 5,right: 5),
                  decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend3.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.amber)),
                  child: ListTileTheme(
                    dense: true,
                    horizontalTitleGap: 15.0,
                    minLeadingWidth: 0,
                    child: ExpansionTile(

                        collapsedTextColor: Colors.amber,
                        textColor: Colors.amber,
                        childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                        onExpansionChanged: (value){
                          _controller.isExpend3.value=value;
                          _controller.isExpend2.value=false;
                          _controller.isExpend1.value=false;
                          _controller.isExpend4.value=false;
                          _controller.isSelected.value=2;
                        },
                        maintainState: true,
                        initiallyExpanded: _controller.isExpend3.value,
                        key: Key("2"),
                        title: Text("Priest Request",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                        children:<Widget>
                        [
                          Column(
                            children: [
                              SizedBox(height: 4,),

                              Obx(()=> _controller.map.isNotEmpty?
                              Container(
                                height: 50,
                                width: Get.width,

                                child:  DropdownButtonWidget(
                                  change: (value) {
                                      _controller.selectedPriestValue=value;
                                      _controller.etPriestName.text=_controller.selectedPriestValue["email"];
                                      _controller.etPriestEmail.text=UtilMethods.decrypt(_controller.selectedPriestValue["email"]);
                                      _controller.etPriestPhone.text=phoneFormatter(_controller.selectedPriestValue["phone"]);
                                      _controller.map.refresh();
                                  },
                                  title: "Select Member Type",
                                  list:_controller.map.value,
                                  hint: "Select Member Type",
                                  selectvalue: _controller.selectedPriestValue,
                                  onPress: '',
                                ),

                              ):Container()
                                ,),
                              SizedBox(height:12,), EditTextWidget(
                                maxLength: 2000,
                                hint: "Enter Priest Phone",
                                isPassword: false,
                                keyboardtype: TextInputType.text,
                                label:"Enter Priest Phone",
                                formatter:[],
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter Priest Phone';
                                  }
                                  return null;
                                },

                                controller: _controller.etPriestPhone,
                                maxline: 1,
                              ),

                              SizedBox(height:6,), EditTextWidget(
                                maxLength: 2000,
                                hint: "Enter Priest Email",
                                isPassword: false,
                                keyboardtype: TextInputType.text,
                                label:" Priest Email",
                                formatter:[],
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter Priest Email';
                                  }

                                  return null;
                                },
                                controller: _controller.etPriestEmail,
                                maxline: 1,
                              ),

                              SizedBox(height:6,),
                              EditTextWidget(
                                maxLength: 2000,
                                hint: "Enter Additional Priest",
                                isPassword: false,
                                keyboardtype: TextInputType.text,
                                label:"Enter Additional Priest",
                                formatter:[],
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter Additional Priest';
                                  }

                                  return null;
                                },
                                controller: _controller.etAdditionalPriest,
                                maxline: 1,
                              ),

                              SizedBox(height:6,),




                            ],
                          ),

                          SizedBox(height: 15,),

                        ]
                    ),
                  ),
                ),
                ),

                SizedBox(height: 15,),
              ]
          ),
          ),
        ),
      ),
    );
  }
  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
    final format = DateFormat.jm(); // YOUR DATE GOES HERE
    return format.format(dt);
  }
}
