import 'package:aspgen_mobile/Dashboard/Request/view/ChatUi.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../Widget/EditextWidget.dart';
import '../conroller/controller.dart';
class CancelationPage extends StatefulWidget {

  CancelationPage({Key? key}) : super(key: key);

  @override
  State<CancelationPage> createState() => _CancelationPageState();
}

class _CancelationPageState extends State<CancelationPage> {
  ServiceRequestController _controller=Get.find();
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.1),width: 0.4)),
        color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.3));
    _controller.isExpendAction.value=false;
    TextStyle subTitle=Theme.of(context).textTheme.bodyText2!;
    TextStyle title=Theme.of(context).textTheme.bodyText1!;
    final datum=_controller.datum.value;
    var dateTime="";

    try{
      dateTime=_controller.formatter.format(_controller.formatter1.parse(datum.serviceDate!));
    }
    catch(e){

    }
    TextEditingController etsearch=new TextEditingController();
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 45,
        automaticallyImplyLeading: false,
        backgroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
        title: Text("Cancel",style: TextStyle(fontSize: 18),),

        actions: [
          Padding(
              padding: const EdgeInsets.only(right: 6,left: 0,top: 0,bottom: 0),
              child:
              RawMaterialButton(

                  constraints: BoxConstraints(minHeight: 38,minWidth: 38),
                  onPressed: (){
                    _controller.approveDatum={
                      "_id":_controller.datum.value.id,
                      "customerName":_controller.datum.value.comments!.contactName,
                      "customerEmail":_controller.datum.value.comments!.email,
                      "customerPhone":_controller.datum.value.comments!.phone,
                      "customerState":_controller.datum.value.comments!.state,
                      "customerCity":_controller.datum.value.comments!.city,
                      "customerAddress":_controller.datum.value.comments!.address,
                      "customerZip":_controller.datum.value.comments!.zip,
                      "countryCode":_controller.datum.value.comments!.countryCode,
                      "date":_controller.datum.value.date,
                      "serviceName":_controller.datum.value.serviceName,
                      "serviceDate":_controller.datum.value.serviceDate,
                      "serviceTime":_controller.datum.value.serviceTime,
                      "locationTypes":_controller.datum.value.serviceLocationName,
                      "languageTypes":_controller.datum.value.languagePreferenceName,
                      "addtionalPriest":"",
                      "serviceCategoryTypes":_controller.datum.value.serviceCategoryTypes,
                      "serviceTypes":_controller.datum.value.serviceTypes,
                      "description":_controller.datum.value.notes,
                      "foodType":_controller.datum.value.foodType,
                      "extraFood":_controller.datum.value.extraFood,
                      "adults":_controller.datum.value.adults,
                      "children":_controller.datum.value.children,
                      "serviceAddress":_controller.datum.value.serviceAddress,
                      "moduleName": "Calendar",
                      "clientID":  AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
                      "productID":  AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
                      "aspectType": "Service Schedules",
                      "priestEmail":_controller.datum.value.priestEmail,
                      "priestName":_controller.datum.value.requestForPriestName,
                      "priestPhone":_controller.datum.value.priestPhone,
                      "serviceAmount":_controller.datum.value.serviceAmount.toString().isNotEmpty?   double.parse(_controller.datum.value.serviceAmount.toString().replaceAll("\$", "").replaceAll(",", "")).toStringAsFixed(2):"0.00",
                      "serviceStatus":"REJECTED",
                      "priestMessage":_controller.etResion.text,
                      "isChecked":false,
                    };
                    _controller.cancelApprove(context, _controller.datum.value.id!,  _controller.approveDatum);

                  },
                  shape: CircleBorder(),
                  fillColor: Colors.green,
                  child: Icon(Icons.check)
              )),
        ],


      ),
      body: SingleChildScrollView(
        child: Column(
          children: [

            SizedBox(height: 15,),
            Obx(() => Container(
              margin: EdgeInsets.only(top:15,left: 5,right: 5),
              decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpendReService.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
              child: ListTileTheme(
                dense: true,
                horizontalTitleGap: 15.0,
                minLeadingWidth: 0,
                child: ExpansionTile(
                    collapsedTextColor: Colors.white,
                    textColor: Colors.tealAccent,
                    childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                    onExpansionChanged: (value){
                      _controller.isExpendReService.value=value;
                    },
                    maintainState: true,
                    initiallyExpanded:_controller.isExpendReService.value,
                    title: Text("Cancel Form",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                    children:<Widget>
                    [
                      SizedBox(height: 10,),
                      EditTextWidget(
                        maxLength: 2000,
                        hint: "Enter Resion",
                        isPassword: false,
                        keyboardtype: TextInputType.text,
                        label: "Resion",
                        validator: (value) {

                            if (value == null || value.isEmpty) {


                              return 'Please Enter ' + "Resion";
                            }

                          return null;
                        },
                        controller: _controller.etResion,
                        isCounter: true,
                        maxline: 12,
                      ),


                    ]
                ),
              ),
            ),
            ),
            SizedBox(height: 15,),

          ],
        ),
      ),
    );
  }
  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
    final format = DateFormat.jm(); // YOUR DATE GOES HERE
    return format.format(dt);
  }
}