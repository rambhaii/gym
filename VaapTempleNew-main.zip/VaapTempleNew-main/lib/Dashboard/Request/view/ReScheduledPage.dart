import 'package:aspgen_mobile/Dashboard/Request/view/ChatUi.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import '../../../Widget/DropdownButtonWidget.dart';
import '../conroller/controller.dart';
import '../../../Widget/CustomListFourTitleWidget.dart';
import '../../../Widget/EditextWidget.dart';
import '../../../AppConstant/AppConstant.dart';
class RescheduledPage extends StatefulWidget {

  RescheduledPage({Key? key}) : super(key: key);

  @override
  State<RescheduledPage> createState() => _RescheduledPageState();
}

class _RescheduledPageState extends State<RescheduledPage> {
  ServiceRequestController _controller=Get.find();
  @override
  void initState() {
    _controller.getFilterApi("PRIEST");
    // TODO: implement initState
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    _controller.etAddress.text=_controller.datum.value.serviceLocationName!;
    BoxDecoration decoration=BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.1),width: 0.4)),
        color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.3));
    _controller.isExpendAction.value=false;
    TextStyle subTitle=Theme.of(context).textTheme.bodyText2!;
    TextStyle title=Theme.of(context).textTheme.bodyText1!;
    final datum=_controller.datum.value;
    var dateTime="";

    try{
      dateTime=_controller.formatter.format(_controller.formatter1.parse(datum.serviceDate!));
    }
    catch(e){

    }
    TextEditingController etsearch=new TextEditingController();
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 45,
        automaticallyImplyLeading: false,
        backgroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
        title: Text("Re-Schedule",style: TextStyle(fontSize: 18),),

      actions: [
      Padding(
      padding: const EdgeInsets.only(right: 6,left: 0,top: 0,bottom: 0),
        child:
        RawMaterialButton(

            constraints: BoxConstraints(minHeight: 38,minWidth: 38),
            onPressed: (){
              if(_controller.email.value.isNotEmpty && _controller.etAddress.text.isNotEmpty)
              {
                _controller.approveDatum={
                  "_id":_controller.datum.value.id,
                  "customerName":_controller.datum.value.comments!.contactName,
                  "customerEmail":_controller.datum.value.comments!.email,
                  "customerPhone":_controller.datum.value.comments!.phone,
                  "customerState":_controller.datum.value.comments!.state,
                  "customerCity":_controller.datum.value.comments!.city,
                  "customerAddress":_controller.datum.value.comments!.address,
                  "customerZip":_controller.datum.value.comments!.zip,
                  "countryCode":_controller.datum.value.comments!.countryCode,
                  "date":_controller.datum.value.date,
                  "serviceName":_controller.datum.value.serviceName,
                  "serviceDate":_controller.datum.value.serviceDate,
                  "serviceTime":_controller.datum.value.serviceTime,
                  "locationTypes":_controller.datum.value.serviceLocationName,
                  "languageTypes":_controller.datum.value.languagePreferenceName,
                  "addtionalPriest":"",
                  "serviceCategoryTypes":_controller.datum.value.serviceCategoryTypes,
                  "serviceTypes":_controller.datum.value.serviceTypes,
                  "description":_controller.datum.value.notes,
                  "foodType":_controller.datum.value.foodType,
                  "extraFood":_controller.datum.value.extraFood,
                  "adults":_controller.datum.value.adults,
                  "children":_controller.datum.value.children,
                  "serviceAddress":_controller.datum.value.serviceAddress,
                  "priestName":_controller.name.value,
                  "moduleName": "Calendar",
                  "clientID":  AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
                  "productID":  AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
                  "aspectType": "Service Schedules",
                  "priestEmail":UtilMethods.encrypt(_controller.email.value),
                  "priestPhone":UtilMethods.encrypt(_controller.phone.value),
                  "serviceAmount":_controller.datum.value.serviceAmount.toString().isNotEmpty?   double.parse(_controller.datum.value.serviceAmount.toString().replaceAll("\$", "").replaceAll(",", "")).toStringAsFixed(2):"0.00",
                  "serviceStatus":"RESCHEDULED",
                  "priestMessage":"",
                  "isChecked":false,
                };
                _controller.reScheduled(context,datum.id!,_controller.approveDatum);
              }
              else{
                Get.snackbar("Alert", "Please Select Priest or Select Address",borderRadius: 2,icon: Icon(Icons.warning_amber),backgroundGradient: LinearGradient(colors: [
                  Colors.amberAccent,Colors.black12
                ]));
              }
              },
            shape: CircleBorder(),
            fillColor: Colors.green,
            child: Icon(Icons.check)
        )),
    ],


      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            // SizedBox(height: 10,),
            // Obx(()=> CustomListFourWidget(title: dateTime + "  at " +datum.serviceTime!,
            //   subTitle: datum.serviceName??"",
            //   subTitle2: (datum.serviceLocationName??""),
            //   subTitle3: datum.comments!.contactName??"",
            //   status: datum.serviceStatus??"",
            //   viewMoreWidget: Column(
            //       crossAxisAlignment: CrossAxisAlignment.start,
            //       children:[
            //         if(datum.prsnPhone!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
            //         if(datum.prsnPhone!.isNotEmpty) viewMore("Phone  ",phoneFormatter(datum.prsnPhone!)),
            //         if(datum.prsnEmail!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
            //         if(datum.prsnEmail!.isNotEmpty) viewMore("Email  ", UtilMethods.decrypt(datum.prsnEmail!)),
            //         if(datum.serviceStatus!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
            //         if(datum.notes!.isNotEmpty) viewMore("Notes ",datum.notes??""),
            //       ]),
            //   textEditingController:_controller.etSearch,
            //   onTapVieMore: (){
            //     _controller.isExpendAction.value=!_controller.isExpendAction.value;
            //   },
            //   icon: Icons.more_vert_outlined,
            //   iconColor: Colors.white,
            //   editOnTap: (){
            //     CheckInternetConnection().then((value) {
            //       if(value==true)
            //       {
            //         Get.to(()=>ServiceRequestDetailsPage());
            //
            //
            //       }
            //     });
            //   }, isClicked: _controller.isExpendAction.value,
            // ),
            // ),
            SizedBox(height: 15,),
            Obx(() => Container(
              margin: EdgeInsets.only(top:15,left: 5,right: 5),
              decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpendReService.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
              child: ListTileTheme(
                dense: true,
                horizontalTitleGap: 15.0,
                minLeadingWidth: 0,
                child: ExpansionTile(
                    collapsedTextColor: Colors.white,
                    textColor: Colors.tealAccent,
                    childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                    onExpansionChanged: (value){
                      _controller.isExpendReService.value=value;
                      },
                    maintainState: true,
                    initiallyExpanded:_controller.isExpendReService.value,
                    title: Text("Edit Service info",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                    children:<Widget>
                    [
                      Form(
                        child: Column(
                          children: [
                            SizedBox(height: 12,),
                            EditTextWidget(
                              maxLength: 2000,
                              hint: "Enter Service Address",
                              isPassword: false,
                              keyboardtype: TextInputType.text,
                              label: "Service Location",
                              validator: (value) {

                                if (value == null || value.isEmpty) {
                                  return 'Please Enter ' + "Resion";
                                }

                                return null;
                              },
                              controller: _controller.etAddress,
                              maxline: 1,
                            ),


                            SizedBox(height: 12,),
                            Row(
                              children: [
                                Expanded(
                                  flex: 4,
                                  child: GestureDetector(
                                    onTap: ()async{
                                      final DateTime? date=await showDatePicker(
                                          context: context,
                                          initialDate:DateTime.now(),
                                          firstDate: DateTime(1900),
                                          lastDate: DateTime(2100),
                                          builder: (context, child) {
                                            return Theme(
                                              data: ThemeData.dark().copyWith(
                                                  colorScheme: const ColorScheme.dark(
                                                      onPrimary: Colors.white,
                                                      // selected text color
                                                      onSurface: Colors.white,
                                                      // default text color
                                                      primary: Colors
                                                          .teal // circle color
                                                  ),
                                                  dialogBackgroundColor: Theme
                                                      .of(context)
                                                      .backgroundColor,
                                                  textButtonTheme: TextButtonThemeData(
                                                      style: TextButton.styleFrom(
                                                          textStyle: const TextStyle(
                                                              color: Colors.white,
                                                              fontWeight: FontWeight
                                                                  .normal,
                                                              fontSize: 12,
                                                              fontFamily: 'Quicksand'),
                                                          primary: Colors.white,
                                                          // color of button's letters
                                                          backgroundColor: Colors
                                                              .black54,
                                                          // Background color
                                                          shape: RoundedRectangleBorder(
                                                              side: const BorderSide(
                                                                  color: Colors
                                                                      .transparent,
                                                                  width: 1,
                                                                  style: BorderStyle
                                                                      .solid),
                                                              borderRadius: BorderRadius
                                                                  .circular(50))))),
                                              child: child!,
                                            );
                                          });
                                      if(date!=null)
                                      {
                                        _controller.datum.value.serviceDate=_controller.formatter1.format(date!);

                                        setState(() {

                                        });


                                      }

                                    },
                                    child: InputDecorator(decoration: InputDecoration(
                                      labelText:"Service Date  ",
                                      labelStyle: subTitle,
                                      contentPadding: EdgeInsets.only(left: 15,right: 15),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(2.0),
                                        borderSide: const BorderSide(
                                            color: Colors.white70, width: 0.0),
                                      ),
                                      border: const OutlineInputBorder(),
                                    ),
                                      child: Text(datum.serviceDate??"",style: title,)
                                      ,
                                    ),
                                  ),
                                ),
                                SizedBox(width: 12,),
                                Expanded(
                                  flex: 4,
                                  child: GestureDetector(
                                    onTap: ()async{
                                      TimeOfDay? time = await showTimePicker(
                                          context: context,
                                          initialTime: TimeOfDay.now(),
                                          builder: (context, child) {
                                            return Theme(
                                              data: ThemeData.dark().copyWith(
                                                  colorScheme: const ColorScheme.dark(
                                                      onPrimary: Colors.white,
                                                      onSurface: Colors.white,
                                                      primary: Colors.teal // circle color
                                                  ),
                                                  dialogBackgroundColor: Theme
                                                      .of(context)
                                                      .backgroundColor,

                                                  textButtonTheme: TextButtonThemeData(
                                                      style: TextButton.styleFrom(
                                                          textStyle: const TextStyle(
                                                              color: Colors.white,
                                                              fontWeight: FontWeight
                                                                  .normal,
                                                              fontSize: 12,
                                                              fontFamily: 'Quicksand'),
                                                          primary: Colors.white,
// color of button's letters
                                                          backgroundColor: Colors
                                                              .black54,
// Background color
                                                          shape: RoundedRectangleBorder(
                                                              side: const BorderSide(
                                                                  color: Colors
                                                                      .transparent,
                                                                  width: 1,
                                                                  style: BorderStyle
                                                                      .solid),
                                                              borderRadius: BorderRadius
                                                                  .circular(50))))),
                                              child: child!,
                                            );
                                          }

                                      );
                                      if(time!=null)
                                      {
                                        _controller.datum.value.serviceTime= formatTimeOfDay(time) ;
                                        setState(() {

                                        });
                                      }
                                    },
                                    child: InputDecorator(decoration: InputDecoration(
                                      labelText:"Service Time  ",
                                      labelStyle: subTitle,
                                      contentPadding: EdgeInsets.only(left: 15,right: 15),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(2.0),
                                        borderSide: const BorderSide(
                                            color: Colors.white70, width: 0.0),
                                      ),
                                      border: const OutlineInputBorder(),
                                    ),
                                      child: Text(datum.serviceTime??"",style: title,)
                                      ,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 12),
                            Obx(()=> _controller.map.isNotEmpty?
                            Container(
                              height: 50,
                              width: Get.width,

                              child:  DropdownButtonWidget(
                                change: (value) {
                                  setState(() {
                                    _controller.selectedValue=value;
                                    _controller.email.value=_controller.selectedValue["email"];
                                    _controller.name.value=_controller.selectedValue["name"];
                                    _controller.phone.value=_controller.selectedValue["phone"];
                                  });
                                  // controller.selectedValue=value;
                                  // controller.update();
                                },
                                title: "Select Member Type",
                                list:_controller.map.value,
                                hint: "Select Member Type",
                                selectvalue: _controller.selectedValue,
                                onPress: '',
                              ),

                            ):Container()
                              ,),
                            SizedBox(height: 14,),
                            InputDecorator(decoration: InputDecoration(
                              labelText:"Priest Email",
                              labelStyle: subTitle,
                              contentPadding: EdgeInsets.only(left: 15,right: 15),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(2.0),
                                borderSide: const BorderSide(
                                    color: Colors.white70, width: 0.0),
                              ),
                              border: const OutlineInputBorder(),
                            ),
                              child: Text(_controller.email.value,style: title,)
                              ,
                            ),
                            SizedBox(height: 12,),  InputDecorator(decoration: InputDecoration(
                              labelText:"Priest Phone ",
                              labelStyle: subTitle,
                              contentPadding: EdgeInsets.only(left: 15,right: 15),
                              enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(2.0),
                                borderSide: const BorderSide(
                                    color: Colors.white70, width: 0.0),
                              ),
                              border: const OutlineInputBorder(),
                            ),
                              child: Text( MaskTextInputFormatter(
                                  initialText:_controller.phone.value, mask: '(###) ###-####',
                                  filter: {"#": RegExp(r'[0-9]')},
                                  type: MaskAutoCompletionType.lazy ).getMaskedText(),style: title,)
                              ,
                            ),
                            SizedBox(height: 4,),
                          ],
                        ),
                      ),


                    ]
                ),
              ),
            ),
            ),
            SizedBox(height: 15,),

          ],
        ),
      ),
    );
  }
  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
    final format = DateFormat.jm(); // YOUR DATE GOES HERE
    return format.format(dt);
  }

}