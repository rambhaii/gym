import 'package:aspgen_mobile/Dashboard/Request/conroller/ChatController.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../conroller/controller.dart';
import '../../../Widget/CustomListFourTitleWidget.dart';
import '../../../Widget/EditextWidget.dart';
import '../../../AppConstant/AppConstant.dart';
class ChatUiPage extends StatelessWidget {
  ChatUiPage({Key? key}) : super(key: key);
  ChatController chatController=Get.put(ChatController());
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 45,
        automaticallyImplyLeading: false,
        backgroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
        title: Text("Messages",style: TextStyle(fontSize: 18),),
        actions: [
        ],
      ),
      body:RefreshIndicator(
        onRefresh: (){
          return Future.delayed(Duration.zero, () {
            chatController.getMessage();
          });
        },
        child: Obx(() =>chatController.chatDatas.value.data!=null?
        ListView.builder(
            itemCount:chatController.chatDatas.value.data!.length,
            shrinkWrap: true,
            padding: EdgeInsets.only(top: 10,bottom: 10),
            itemBuilder: (context, index){
              final datum=chatController.chatDatas.value.data![index];
              return Container(
                padding: EdgeInsets.only(left: 14,right: 14,top: 10,bottom: 10),
                child: Align(
                  alignment: (datum.priestId.toString()=="0"?Alignment.topLeft:Alignment.topRight),
                  child: Column(
                    mainAxisAlignment:datum.priestId.toString()=="0"?MainAxisAlignment.start: MainAxisAlignment.end,
                    crossAxisAlignment:datum.priestId.toString()=="0"?CrossAxisAlignment.start: CrossAxisAlignment.end,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          color: (datum.priestId.toString()=="0" ?Colors.grey.withOpacity(0.7):Colors.tealAccent.withOpacity(0.4)),
                        ),
                        padding: EdgeInsets.all(10),
                        child: Text(chatController.chatDatas.value.data![index].message??"", style: TextStyle(fontSize: 15,color: Theme.of(context).colorScheme.primary),),
                      ),
                      Container(
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                         // color: (datum.priestId.toString()=="0" ?Theme.of(context).colorScheme.onPrimaryContainer:Colors.tealAccent.withOpacity(0.4)),
                        ),
                        padding: EdgeInsets.only(top: 6),
                        child: Text(datum.priestId.toString()=="0"?datum.memberName!.isEmpty?chatController.controller.datum.value.comments!.contactName!:datum.memberName!:datum.priestName!, style: TextStyle(fontSize: 12,color: Colors.white),),
                      ),
                    ],
                  ),
                ),
              );
            },
          )
            :Container(),
        ),
      ),
      bottomNavigationBar:  Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
        child: Container(
          padding: EdgeInsets.only(left: 10,bottom: 10,top: 10),
          height: 60,
          width: double.infinity,
          color: Theme.of(context).colorScheme.onPrimaryContainer,
          child: Row(
            children: <Widget>[
              SizedBox(width: 15,),
              Expanded(
                child: Form(
                  key: chatController.formKey,
                  child: TextFormField(
                    controller: chatController.etMessage,
                    decoration: InputDecoration(
                        hintText: "Write message...",
                        hintStyle: TextStyle(color: Colors.white),
                        border: InputBorder.none
                    ),
                    validator: (value){
                      if(value.toString().isEmpty)
                        {
                          return "Please Enter mesaages....";
                        }

                    },
                  ),
                ),
              ),
              SizedBox(width: 15,),
              FloatingActionButton(
                onPressed: (){
                  if(chatController.formKey.currentState!.validate())
                    {
                      FocusManager.instance.primaryFocus?.unfocus();
                      chatController.sendMessage();
                    }
                  },
                child: Icon(Icons.send,color: Colors.white,size: 18,),
                backgroundColor: Colors.teal,
                elevation: 0,
              ),
            ],

          ),
        ),
      ),
    );
  }
}