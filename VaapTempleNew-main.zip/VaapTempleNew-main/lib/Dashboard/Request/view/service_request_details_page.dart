import 'dart:convert';

import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/DropdownButtonWidget.dart';
import '../conroller/controller.dart';

class ServiceRequestDetailsPage extends StatefulWidget {

   ServiceRequestDetailsPage({Key? key}) : super(key: key);

  @override
  State<ServiceRequestDetailsPage> createState() => _ServiceRequestDetailsPageState();
}

class _ServiceRequestDetailsPageState extends State<ServiceRequestDetailsPage> {
   ServiceRequestController _controller=Get.find();

   final GlobalKey expansionTile = new GlobalKey();


   final GlobalKey<ExpansionTileCardState> expensionPriestKey =  GlobalKey();

   final GlobalKey<ExpansionTileCardState> expensionMemberKey =  GlobalKey();



   @override
   void initState() {
     _controller.getFilterApi("PRIEST");
     super.initState();
   }

  @override
  Widget build(BuildContext context) {
     final datum=_controller.datum.value;
    final devoteedatum=_controller.datum.value.comments!;
    TextStyle title=Theme.of(context).textTheme.bodyText1!;
    TextStyle subTitle=Theme.of(context).textTheme.bodyText2!;
    BoxDecoration decoration=BoxDecoration(
      borderRadius: BorderRadius.circular(5),
        border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.1),width: 0.4)),
        color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.3));
    return Scaffold(
      appBar: AppBar(
      toolbarHeight: 45,
      automaticallyImplyLeading: false,
      backgroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
      title: Text("Request Details",style: TextStyle(fontSize: 18),),
      actions: [
        Padding(
            padding: const EdgeInsets.only(right: 6,left: 0,top: 0,bottom: 0),
            child:
            RawMaterialButton(

                constraints: BoxConstraints(minHeight: 38,minWidth: 38),
                onPressed: (){
                  if(_controller.email.value.isNotEmpty)
              {

                print(_controller.datum.value.serviceAmount.toString());
                _controller.approveDatum={
                  "_id":_controller.datum.value.id,
                  "customerName":_controller.datum.value.comments!.contactName,
                  "customerEmail":_controller.datum.value.comments!.email,
                  "customerPhone":_controller.datum.value.comments!.phone,
                  "customerState":_controller.datum.value.comments!.state,
                  "customerCity":_controller.datum.value.comments!.city,
                  "customerAddress":_controller.datum.value.comments!.address,
                  "customerZip":_controller.datum.value.comments!.zip,
                  "countryCode":_controller.datum.value.comments!.countryCode,
                  "date":_controller.datum.value.date,
                  "serviceName":_controller.datum.value.serviceName,
                  "serviceDate":_controller.datum.value.serviceDate,
                  "serviceTime":_controller.datum.value.serviceTime,
                  "locationTypes":_controller.datum.value.serviceLocationName,
                  "languageTypes":_controller.datum.value.languagePreferenceName,
                  "addtionalPriest":"",
                  "serviceCategoryTypes":_controller.datum.value.serviceCategoryTypes,
                  "serviceTypes":_controller.datum.value.serviceTypes,
                  "description":_controller.datum.value.notes,
                  "foodType":_controller.datum.value.foodType,
                  "extraFood":_controller.datum.value.extraFood,
                  "adults":_controller.datum.value.adults,
                  "children":_controller.datum.value.children,
                  "serviceAddress":_controller.datum.value.serviceAddress,
                  "moduleName": "Calendar",
                  "clientID":  AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
                  "productID":  AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
                  "aspectType": "Service Schedules",
                  "priestEmail":_controller.datum.value.priestEmail,
                  "priestName":_controller.datum.value.requestForPriestName,
                  "priestPhone":_controller.datum.value.priestPhone,
                  "serviceAmount":_controller.datum.value.serviceAmount.toString().isNotEmpty?   double.parse(_controller.datum.value.serviceAmount.toString().replaceAll("\$", "").replaceAll(",", "")).toStringAsFixed(2):"0.00",
                  "serviceStatus":"SCHEDULED",
                  "priestMessage":"Test",
                  "isChecked":false,
                };
                _controller.showDialogApprove(context, _controller.datum.value.id!,  _controller.approveDatum);
              }
              else{
                Get.snackbar("Alert", "Please Select Priest",borderRadius: 2,icon: Icon(Icons.warning_amber),backgroundGradient: LinearGradient(colors: [
                  Colors.amberAccent,Colors.black12
                ]));
                _controller.isExpend3.value=true;
              }

            },
                shape: CircleBorder(),
                fillColor: Colors.green,
                child: Icon(Icons.check)
            )),
      ],
    ),

      body: SingleChildScrollView(
        child: Container(

          child: Obx(()=> ListView(
            shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                key: Key('builder ${_controller.isSelected.value.toString()}'),
              children:[SizedBox(height: 8,),
            Obx(()=>Container(
                  margin: EdgeInsets.only(top:15,left: 5,right: 5),
                  decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend1.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                  child: ListTileTheme(
                    dense: true,
                    horizontalTitleGap: 15.0,
                    minLeadingWidth: 0,
                    child: ExpansionTile(
                        key: Key("0"),
                       collapsedTextColor: Colors.tealAccent,
                       textColor: Colors.tealAccent,
                      childrenPadding: EdgeInsets.only(left: 10,right: 10),
                      onExpansionChanged: (value){
                        _controller.isExpend1.value=value;
                        _controller.isExpend2.value=false;
                        _controller.isExpend3.value=false;
                        _controller.isSelected.value=0;
                      },
                        initiallyExpanded: _controller.isExpend1.value,
                        title: Text("Devotee Info",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                        children:<Widget>
                        [
                          Column(
                            children: [
                              SizedBox(height: 4,),
                              SizedBox(height: 12,),  InputDecorator(decoration: InputDecoration(
                                labelText:"Devotee Name  ",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(devoteedatum.contactName!,style: title,)
                                ,
                              ),


                              SizedBox(height: 12,),
                              InputDecorator(decoration: InputDecoration(
                                labelText:"Gotra",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(devoteedatum.gotraName??"",style: title,)
                                ,
                              ),

                              SizedBox(height: 12,),
                              Row(
                                children: [

                                  Expanded(
                                    flex: 4,
                                    child: InputDecorator(decoration: InputDecoration(
                                      labelText:"Nakshatra ",
                                      labelStyle: subTitle,
                                      contentPadding: EdgeInsets.only(left: 15,right: 15),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(2.0),
                                        borderSide: const BorderSide(
                                            color: Colors.white70, width: 0.0),
                                      ),
                                      border: const OutlineInputBorder(),
                                    ),
                                      child: Text(devoteedatum.nakshatraName??"",style: title,)
                                      ,
                                    ),
                                  ),
                                  SizedBox(width: 12,),
                                  Expanded(
                                    flex: 4,
                                    child: InputDecorator(decoration: InputDecoration(
                                      labelText:"Rashi",
                                      labelStyle: subTitle,
                                      contentPadding: EdgeInsets.only(left: 15,right: 15),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(2.0),
                                        borderSide: const BorderSide(
                                            color: Colors.white70, width: 0.0),
                                      ),
                                      border: const OutlineInputBorder(),
                                    ),
                                      child: Text(devoteedatum.rashiName??"",style: title,)
                                      ,
                                    ),
                                  ),
                                ],
                              ),
                              SizedBox(height: 12,), InputDecorator(decoration: InputDecoration(
                                labelText:"Date Of Birth",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(devoteedatum.dob??"",style: title,)
                                ,
                              ),
                              SizedBox(height: 12,),  InputDecorator(decoration: InputDecoration(
                                labelText:"Devotee Email  ",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(UtilMethods.decrypt(devoteedatum.email!),style: title,),
                              ),


                              SizedBox(height: 12,),  InputDecorator(decoration: InputDecoration(
                                labelText:"Devotee Phone  ",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(phoneFormatter(devoteedatum.phone!),style: title,)
                                ,
                              ),





                              SizedBox(height: 12,),
                              Row(
                                children: [
                                  Expanded(
                                    flex: 4,
                                    child: InputDecorator(decoration: InputDecoration(
                                      labelText:"State",
                                      labelStyle: subTitle,
                                      contentPadding: EdgeInsets.only(left: 15,right: 15),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(2.0),
                                        borderSide: const BorderSide(
                                            color: Colors.white70, width: 0.0),
                                      ),
                                      border: const OutlineInputBorder(),
                                    ),
                                      child: Text(devoteedatum.state??"",style: title,)
                                      ,
                                    ),
                                  ),


                                  SizedBox(width: 12,),
                                  Expanded(
                                    flex: 4,
                                    child: InputDecorator(decoration: InputDecoration(
                                      labelText:"Zip ",
                                      labelStyle: subTitle,
                                      contentPadding: EdgeInsets.only(left: 15,right: 15),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(2.0),
                                        borderSide: const BorderSide(
                                            color: Colors.white70, width: 0.0),
                                      ),
                                      border: const OutlineInputBorder(),
                                    ),
                                      child: Text(devoteedatum.zip??"",style: title,)
                                      ,
                                    ),
                                  ),
                                ],
                              ),

                              SizedBox(height: 12,),
                              InputDecorator(decoration: InputDecoration(
                                labelText:"City ",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(devoteedatum.city??"",style: title,)
                                ,
                              ),
                              SizedBox(height: 12,),

                              InputDecorator(decoration: InputDecoration(
                                labelText:"Address  ",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(devoteedatum.address??"",style: title,),),
                            ],
                          ),

                          SizedBox(height: 12,),

                        ]
                    ),
                  ),
                ),
              ),
                Obx(()=>Container(
                  margin: EdgeInsets.only(top:15,left: 5,right: 5),
                  decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend4.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.lightBlueAccent)),
                  child: ListTileTheme(
                    dense: true,
                    horizontalTitleGap: 15.0,
                    minLeadingWidth: 0,
                    child: ExpansionTile(
                        key: Key("3"),
                        collapsedTextColor: Colors.lightBlueAccent,
                        textColor: Colors.lightBlueAccent,
                        childrenPadding: EdgeInsets.only(left: 10,right: 10),
                        onExpansionChanged: (value){
                          _controller.isExpend1.value=false;
                          _controller.isExpend4.value=value;
                          _controller.isExpend2.value=false;
                          _controller.isExpend3.value=false;
                          _controller.isSelected.value=3;
                        },
                        initiallyExpanded: _controller.isExpend4.value,
                        title: Text("Sankalpam  Info",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                        children:<Widget>
                        [
                          Column(
                            children: [

                              Column(children: List.generate(devoteedatum.memberDetail!.length, (index) =>Container(
                                padding: EdgeInsets.only(left: 10,right: 10),
                                decoration: BoxDecoration(
                                    color:Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.6),
                                    border: Border.all(color:Colors.tealAccent.withOpacity(0.3),width: 0.5)

                                ),
                                child: Column(
                                  children: [
                                    SizedBox(height:12,),

                                    InputDecorator(decoration: InputDecoration(
                                      labelText:"Member Name "+(index+1).toString(),
                                      labelStyle: subTitle,
                                      contentPadding: EdgeInsets.only(left: 15,right: 15),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(2.0),
                                        borderSide: const BorderSide(
                                            color: Colors.white70, width: 0.0),
                                      ),
                                      border: const OutlineInputBorder(),
                                    ),
                                      child: Text(devoteedatum.memberDetail![index].memberName!,style: title,)
                                      ,
                                    ),
                                    SizedBox(height: 12,),
                                    Row(
                                      children: [
                                        Expanded(
                                          flex: 4,
                                          child: InputDecorator(decoration: InputDecoration(
                                            labelText:"Nakshatra",
                                            labelStyle: subTitle,
                                            contentPadding: EdgeInsets.only(left: 15,right: 15),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.circular(2.0),
                                              borderSide: const BorderSide(
                                                  color: Colors.white70, width: 0.0),
                                            ),
                                            border: const OutlineInputBorder(),
                                          ),
                                            child: Text(devoteedatum.memberDetail![index].nakshatra!,style: title,)
                                            ,
                                          ),
                                        ),
                                        SizedBox(width: 12,),
                                        Expanded(
                                          flex: 4,
                                          child: InputDecorator(decoration: InputDecoration(
                                            labelText:"Rashi ",
                                            labelStyle: subTitle,
                                            contentPadding: EdgeInsets.only(left: 15,right: 15),
                                            enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.circular(2.0),
                                              borderSide: const BorderSide(
                                                  color: Colors.white70, width: 0.0),
                                            ),
                                            border: const OutlineInputBorder(),
                                          ),
                                            child: Text(devoteedatum.memberDetail![index].rashi!,style: title,)
                                            ,
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: 12,),
                                  ],
                                ),
                              ),growable: true),),
                              SizedBox(height: 12,),
                            ],
                          ),


                        ]
                    ),
                  ),
                ),
                ),




                  Obx(()=> Container(
                    margin: EdgeInsets.only(top:15,left: 5,right: 5),
                    decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend2.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Color(
                        0xEBFF448D),)),
                    child: ListTileTheme(
                    dense: true,
                    horizontalTitleGap: 15.0,
                    minLeadingWidth: 0,
                    child: ExpansionTile(
                        maintainState: true,
                        collapsedTextColor: Color(0xEBFF448D),
                        textColor:Color(0xEBFF448D),
                        childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                        onExpansionChanged: (value){
                          _controller.isExpend2.value=value;
                          _controller.isExpend1.value=false;
                          _controller.isExpend3.value=false;
                          _controller.isExpend4.value=false;
                          _controller.isSelected.value=1;
                        },
                        initiallyExpanded: _controller.isExpend2.value,
                     key: Key("1"),
                        title: Text("Service Request Details",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                        children:<Widget>
                        [
                    Column(
                      children: [

                        SizedBox(height: 4,),
                        InputDecorator(decoration: InputDecoration(
                          labelText:"Service Name  ",
                          labelStyle: subTitle,
                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(2.0),
                            borderSide: const BorderSide(
                                color: Colors.white70, width: 0.0),
                          ),
                          border: const OutlineInputBorder(),
                        ),
                          child: Text(datum.serviceName??"",style: title,),
                        ),

                        SizedBox(height: 12,),
                        InputDecorator(decoration: InputDecoration(
                          labelText:"Service Category  ",
                          labelStyle: subTitle,
                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(2.0),
                            borderSide: const BorderSide(
                                color: Colors.white70, width: 0.0),
                          ),
                          border: const OutlineInputBorder(),
                        ),
                          child: Text(datum.serviceCategoryTypes??"",style: title,),
                        ),

                        SizedBox(height: 12,),
                        InputDecorator(decoration: InputDecoration(
                          labelText:"Service Type  ",
                          labelStyle: subTitle,
                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(2.0),
                            borderSide: const BorderSide(
                                color: Colors.white70, width: 0.0),
                          ),
                          border: const OutlineInputBorder(),
                        ),
                          child: Text(datum.serviceTypes??"",style: title,),
                        ),

                        SizedBox(height: 12,),
                        Row(
                          children: [
                            Expanded(
                              flex: 4,
                              child: InputDecorator(decoration: InputDecoration(
                                labelText:"Service Date  ",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(datum.serviceDate??"",style: title,)
                                ,
                              ),
                            ),
                            SizedBox(width: 12,),
                            Expanded(
                              flex: 4,
                              child: InputDecorator(decoration: InputDecoration(
                                labelText:"Service Time  ",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(datum.serviceTime??"",style: title,)
                                ,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 12,),
                        Row(
                          children: [
                            Expanded(
                              flex: 4,
                              child: InputDecorator(decoration: InputDecoration(
                                labelText:"Location",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(datum.serviceLocationName??"",style: title,)
                                ,
                              ),
                            ),
                            SizedBox(width: 12,),
                            Expanded(
                              flex: 4,
                              child: InputDecorator(decoration: InputDecoration(
                                labelText:"Service Amount  ",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(amountParser(datum.serviceAmount.toString()),style: title,)
                                ,
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: 12,),
                        InputDecorator(decoration: InputDecoration(
                          labelText:"Language",
                          labelStyle: subTitle,
                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(2.0),
                            borderSide: const BorderSide(
                                color: Colors.white70, width: 0.0),
                          ),
                          border: const OutlineInputBorder(),
                        ),
                          child: Text(datum.languagePreferenceName??"",style: title,)
                          ,
                        ), SizedBox(height: 12,),
                        InputDecorator(decoration: InputDecoration(
                          labelText:"Address",
                          labelStyle: subTitle,
                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(2.0),
                            borderSide: const BorderSide(
                                color: Colors.white70, width: 0.0),
                          ),
                          border: const OutlineInputBorder(),
                        ),
                          child: Text(datum.serviceAddress??"",style: title,)
                          ,
                        ), SizedBox(height: 12,),
                        InputDecorator(decoration: InputDecoration(
                          labelText:"Notes",
                          labelStyle: subTitle,
                          contentPadding: EdgeInsets.only(left: 15,right: 15),
                          enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(2.0),
                            borderSide: const BorderSide(
                                color: Colors.white70, width: 0.0),
                          ),
                          border: const OutlineInputBorder(),
                        ),
                          child: Text(datum.notes??"",style: title,)
                          ,
                        ),
                        SizedBox(height: 4,),
                      ],
                    ),


                        ]
                    ),
              ),
                  ),
                ),

              Obx(() => Container(
              margin: EdgeInsets.only(top:15,left: 5,right: 5),
              decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend3.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.amber)),
              child: ListTileTheme(
                    dense: true,
                    horizontalTitleGap: 15.0,
                    minLeadingWidth: 0,
                    child: ExpansionTile(
                        collapsedTextColor: Colors.amber,
                        textColor: Colors.amber,
                        childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                        onExpansionChanged: (value){
                          _controller.isExpend3.value=value;
                          _controller.isExpend2.value=false;
                          _controller.isExpend1.value=false;
                          _controller.isExpend4.value=false;
                          _controller.isSelected.value=2;
                        },
                        maintainState: true,
                        initiallyExpanded: _controller.isExpend3.value,
                        key: Key("2"),
                        title: Text("Priest Request",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                        children:<Widget>
                        [
                          Column(
                            children: [
                              SizedBox(height: 4,),
                              Obx(()=> _controller.map.isNotEmpty?
                              Container(
                                height: 50,
                                width: Get.width,

                                child:  DropdownButtonWidget(
                                  change: (value) {
                                      setState(() {
                                          _controller.selectedValue=value;
                                          _controller.email.value=_controller.selectedValue["email"];
                                          _controller.name.value=_controller.selectedValue["name"];
                                          _controller.phone.value=_controller.selectedValue["phone"];
                                      });
                                    // controller.selectedValue=value;
                                   // controller.update();
                                  },
                                  title: "Select Member Type",
                                  list:_controller.map.value,
                                  hint: "Select Member Type",
                                  selectvalue: _controller.selectedValue,
                                  onPress: '',
                                ),

                              ):Container()
                                ,),
                             SizedBox(height: 14,),
                              InputDecorator(decoration: InputDecoration(
                                labelText:"Priest Email",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text(_controller.email.value,style: title,)
                                ,
                              ),
                              SizedBox(height: 12,),  InputDecorator(decoration: InputDecoration(
                                labelText:"Priest Phone ",
                                labelStyle: subTitle,
                                contentPadding: EdgeInsets.only(left: 15,right: 15),
                                enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(2.0),
                                  borderSide: const BorderSide(
                                      color: Colors.white70, width: 0.0),
                                ),
                                border: const OutlineInputBorder(),
                              ),
                                child: Text( MaskTextInputFormatter(
                                    initialText:_controller.phone.value, mask: '(###) ###-####',
                                    filter: {"#": RegExp(r'[0-9]')},
                                    type: MaskAutoCompletionType.lazy ).getMaskedText(),style: title,)
                                ,
                              ),
                              SizedBox(height: 4,),
                            ],
                          ),

                          SizedBox(height: 15,),

                        ]
                    ),
                  ),
              ),
              ),

                SizedBox(height: 15,),
              ]
            ),
          ),
        ),
      ),
    );
  }

}
