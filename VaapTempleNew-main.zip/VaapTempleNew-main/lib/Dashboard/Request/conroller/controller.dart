import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Request/model/service_model.dart';
import 'package:aspgen_mobile/Templates/Model/CategoryData.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
import '../../../calendar/Booking/BookingCalender.dart';
import '../../Contact/Model/AllContactDatas.dart';

class ServiceRequestController extends GetxController{
  var bodyJson={};
  var bodyJson2={};
  var email="".obs;
  var name="".obs;
  var phone="".obs;
  var selectedValue;
   RxBool isPriestAvl=false.obs;
   RxInt isSelected=0.obs;
  RxBool isExpend1=false.obs;
  RxBool isExpend2=false.obs;
  RxBool isExpend3=false.obs;
  RxBool isExpendReService=true.obs;
  RxBool isExpend4=false.obs;
  RxBool isExpendAction=false.obs;
  final DateFormat formatter = DateFormat('MMM dd, yyyy');
  final DateFormat formatter1 = DateFormat('MM/dd/yyyy');
  var datas=ServiceRequestData().obs;
  var filterdatas=ServiceRequestData().obs;


  List<String> statusList=[
    "NEW",
    "SCHEDULED",
    "COMPLETED",
    "CANCEL"
  ];
  var approveDatum={};
  TextEditingController etSearch= new TextEditingController();
  TextEditingController etResion= new TextEditingController();
  TextEditingController etAddress= new TextEditingController();
  Rx<ServiceRequestDatum> datum=ServiceRequestDatum().obs;
  Rx<AllContactDatas> allContactDatas= AllContactDatas().obs;
 RxList<Map> map=RxList([]);
 RxList<Map> rxServiceCategory=RxList([]);
 RxString rxStatus="ALL".obs;


  PageController pagecontroller = PageController(
    initialPage: 0,

  );


  var maskFormatter = new MaskTextInputFormatter(
      mask: '(###) ###-####',
      filter: {"#": RegExp(r'[0-9]')},
      type: MaskAutoCompletionType.lazy);


 RxString rxMessage="".obs;
  @override
  void onInit() {
    print("sdbvhjdsbjkv");
    print(AppConstant.sharedPreference.getString(AppConstant.memberId));
    fetchApi();
    //fetchApi2();
    super.onInit();
  }
  fetchApi()async{
    bodyJson={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
      "username": AppConstant.sharedPreference.getString(AppConstant.userName).toString().trim(),
      "query": {"serviceStatus":rxStatus.value}
    };
    print("dsvbhvkdjsv");
    print(jsonEncode(bodyJson));
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getServiceRequest, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("dsvbhvkdjsv");
    print(response);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    datas.value=ServiceRequestData.fromJson(jsonDecode(response));

    filterdatas.value=ServiceRequestData.fromJson(jsonDecode(response));
    if(datas.value.data!.isEmpty)
    {
      rxMessage.value="No Service Available";
    }

  }

  sendData(ServiceRequestDatum data){
    datum.value=data;
    email.value="";
    phone.value="";
  }



  approveApi(String id,var datas,int type)async{
    //type 1 for scheduled ,2 for Rescheduled 3 for canceled
    var bodyrequest={};
    bodyrequest={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
      "memberId":"0",
      "priestName": AppConstant.sharedPreference.getString(AppConstant.firstName).toString().trim()+" "+AppConstant.sharedPreference.getString(AppConstant.lastName).toString().trim(),
      "priestId":AppConstant.sharedPreference.getString(AppConstant.memberId).toString().trim(),
       "_id":id,
      "data":datas
    };
  print(json.encode(bodyrequest));
      Get.context!.loaderOverlay.show();
      var response=await BaseClient().post(APIsConstant.approveServiceRequest, bodyrequest).catchError(BaseController().handleError);
      Get.context!.loaderOverlay.hide();
      if(response==null) return;
      if(jsonDecode(response)["statusCode"].toString()=="1"){
        Get.back();
        if(type==1)
          {
            Get.snackbar("Success", "Your Service has been approve",borderRadius: 2,icon: Icon(Icons.check_rounded),backgroundGradient: LinearGradient(colors: [
              Colors.green,Colors.black12
            ]));
            Get.to(()=>BookingCalendar(title: "Calendar",displayName: "Bookings",));
          }
        if(type==2)
          {
            Get.snackbar("Success", "Your Service has been re-schedule",borderRadius: 2,icon: Icon(Icons.check_rounded),backgroundGradient: LinearGradient(colors: [
              Colors.green,Colors.black12
            ]));
          }
        if(type==3)
          {
            Get.snackbar("Success", "Your Service has been cancel",borderRadius: 2,icon: Icon(Icons.check_rounded),backgroundGradient: LinearGradient(colors: [
              Colors.green,Colors.black12
            ]));
          }

         fetchApi();
      };

    }


  // Container(
  // height: 500,
  // width: Get.width,
  // child: PageView(
  // onPageChanged: ((value) {
  // //  _tabController.index=value;
  // }),
  // controller: _controller.pagecontroller,
  // children: [
  // ServiceRequestDetailsPage(),
  // RescheduledPage()
  // ],
  // ),
  // ),
  getFilterApi(String membetType)async{
    var request={
      "serviceDate":datum.value.serviceDate,
      "startTime": datum.value.serviceTime,
      "endTime": datum.value.serviceTime,
      "memberType": membetType,
      "componentConfig": {
        "moduleName":"Contacts",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    print("dsvhbvkd");
    print(jsonEncode(request));
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getpriestAvailbility, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    map.clear();
    selectedValue=null;
    jsonDecode(response)["data"].forEach((element) {
      map.add({"name":element["refDataName"],"email":UtilMethods.decrypt(element["email"]),"phone":UtilMethods.decrypt(element["phone"])});
    });
    print( datum.value.priestEmail!.toString());
    int index = map.indexWhere((element1) => element1['email'] == UtilMethods.decrypt(datum.value.priestEmail!.toString()));

    if (index > -1) {
      isPriestAvl.value=true;
      selectedValue = map[index];
      email.value=selectedValue["email"];
      name.value=selectedValue["name"];
      phone.value=selectedValue["phone"];
    }
    else{
      isPriestAvl.value=false;
    }
    if( jsonDecode(response)["data"].isEmpty)
    {
      Get.snackbar("Alert!", "No Priest Available",backgroundColor: Colors.amber.withOpacity(0.5),borderRadius: 5);
    }
    map.refresh();
    update();
    return isPriestAvl.value;
  }


  void filterData(String search){
    List<ServiceRequestDatum> result=[];
    if(search.isEmpty)
    {
      result=filterdatas.value.data!;
    }
    else{
      result=filterdatas.value.data!.where((element) =>element.serviceName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    datas.value.data=result;
    datas.refresh();
  }

  void showDialogApprove(BuildContext  context,String id,var datas)
  {
    showCupertinoDialog(
      context: context,
      builder: (context) {
        return CupertinoAlertDialog(
          title: Text("Approve"),
          content: Text("Are you sure you want to approve the Service?"),
          actions: [
            CupertinoDialogAction(
                child: Text("Cancel"),
                isDefaultAction: true,
                isDestructiveAction: true,
                onPressed: ()
                {
                  Navigator.of(context).pop();
                }
            ),
            CupertinoDialogAction(
              child: Text("Approve?",style: TextStyle(color:Colors.green.shade800),),
              isDefaultAction: true,
              onPressed: (){
                approveApi(id,datas,1);
                Navigator.of(context).pop();
              }
              ,
            )
          ],
        );
      },
    );
  }

  void reScheduled(BuildContext  context,String id,var datas)
  {
    showCupertinoDialog(
      context: context,
      builder: (context) {
        return CupertinoAlertDialog(
          title: Text("RE-SCHEDULE"),
          content: Text("Are you sure you want to Reschedule the Service?"),
          actions: [
            CupertinoDialogAction(
                child: Text("No"),
                isDefaultAction: true,
                isDestructiveAction: true,
                onPressed: ()
                {
                  Navigator.of(context).pop();
                }
            ),
            CupertinoDialogAction(
              child: Text("Yes",style: TextStyle(color:Colors.green.shade800)),
              isDefaultAction: true,
              onPressed: (){
                approveApi(id,datas,2);
                Navigator.of(context).pop();
              }
              ,
            )
          ],
        );
      },
    );
  }


  void cancelApprove(BuildContext  context,String id,var datas)
  {
    showCupertinoDialog(
      context: context,
      builder: (context) {
        return CupertinoAlertDialog(
          title: Text("REJECT !"),
          content: Text("Are you sure you want to Rejecte the Service?"),

          actions: [
            CupertinoDialogAction(
                child: Text("No",style: TextStyle(color:Colors.black)),
                isDefaultAction: true,
                onPressed: ()
                {
                  Navigator.of(context).pop();
                }
            ),
            CupertinoDialogAction(
              child: Text("Yes?",style: TextStyle(color:Colors.red.shade800)),

              isDefaultAction: true,
              isDestructiveAction: true,
              onPressed: (){
                approveApi(id,datas,3);
                Navigator.of(context).pop();
              }
              ,
            )
          ],
        );
      },
    );
  }


}