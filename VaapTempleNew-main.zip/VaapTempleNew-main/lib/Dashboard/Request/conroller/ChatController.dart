import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Request/model/chatModel.dart';
import 'package:aspgen_mobile/Dashboard/Request/conroller/controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
class ChatController extends GetxController{
  TextEditingController etMessage=new TextEditingController();
  ServiceRequestController controller=Get.find();
  final GlobalKey<FormState> formKey=GlobalKey<FormState>();
  ScrollController scrollController = ScrollController();


  var chatDatas=ChatModel().obs;
  @override
  void onInit() {
    getMessage();
    super.onInit();
  }
  getMessage()async{
    var   bodyJson2=
      {
        "serviceId": controller.datum.value.id,
        "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "productId": AppConstant.sharedPreference.getString(AppConstant.productId)
      }
    ;
    print("hbsbjdkvs");
    print(bodyJson2);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getServiceCommunicationByServiceID, bodyJson2).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("hbsbjdkvs");
    print(response);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1") {
      chatDatas.value=chatModelFromJson(response);

    };
  }
  sendMessage()async{

    controller.approveDatum={
      "_id":controller.datum.value.id,
      "customerName":controller.datum.value.comments!.contactName,
      "customerEmail":controller.datum.value.comments!.email,
      "customerPhone":controller.datum.value.comments!.phone,
      "customerState":controller.datum.value.comments!.state,
      "customerCity":controller.datum.value.comments!.city,
      "customerAddress":controller.datum.value.comments!.address,
      "customerZip":controller.datum.value.comments!.zip,
      "countryCode":controller.datum.value.comments!.countryCode,
      "date":controller.datum.value.date,
      "serviceName":controller.datum.value.serviceName,
      "serviceDate":controller.datum.value.serviceDate,
      "serviceTime":controller.datum.value.serviceTime,
      "locationTypes":controller.datum.value.serviceLocationName,
      "languageTypes":controller.datum.value.languagePreferenceName,
      "addtionalPriest":"",
      "serviceCategoryTypes":controller.datum.value.serviceCategoryTypes,
      "serviceTypes":controller.datum.value.serviceTypes,
      "description":controller.datum.value.notes,
      "foodType":controller.datum.value.foodType,
      "extraFood":controller.datum.value.extraFood,
      "adults":controller.datum.value.adults,
      "children":controller.datum.value.children,
      "serviceAddress":controller.datum.value.serviceAddress,
      "moduleName": "Calendar",
      "clientID":  AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "productID":  AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "aspectType": "Service Schedules",
      "priestEmail":controller.datum.value.priestEmail,
      "priestName":controller.datum.value.requestForPriestName,
      "priestPhone":controller.datum.value.priestPhone,
      "serviceAmount":controller.datum.value.serviceAmount.toString().isNotEmpty?   double.parse(controller.datum.value.serviceAmount.toString().replaceAll("\$", "").replaceAll(",", "")).toStringAsFixed(2):"0.00",
      "serviceStatus":"PROCESSING",
      "priestMessage":etMessage.text,
      "isChecked":false,
    };
    var bodyrequest={};
    bodyrequest={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId).toString().trim(),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId).toString().trim(),
      "memberId":"0",
      "priestName": AppConstant.sharedPreference.getString(AppConstant.firstName).toString().trim()+" "+AppConstant.sharedPreference.getString(AppConstant.lastName).toString().trim(),
      "priestId":AppConstant.sharedPreference.getString(AppConstant.memberId).toString().trim(),
      "_id":controller.datum.value.id,
      "data":controller.approveDatum
    };

    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.approveServiceRequest, bodyrequest).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    etMessage.clear();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1"){
      getMessage();
    };

  }


}