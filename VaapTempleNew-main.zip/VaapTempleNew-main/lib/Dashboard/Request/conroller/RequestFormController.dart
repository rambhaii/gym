import 'dart:convert';

import 'package:aspgen_mobile/BottomBar/dashboard_nav.dart';
import 'package:aspgen_mobile/Dashboard/Request/model/service_model.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:rflutter_alert/rflutter_alert.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../Templates/Model/CategoryData.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
import '../../../calendar/Booking/BookingCalender.dart';
import '../../Contact/Model/AllContactDatas.dart';

class RequestFormController extends GetxController{
  var bodyJson={};
  RxList<Map> rxServiceCategoryList=RxList([]);
  var selectedPriestValue;
  RxList<Map> rxServiceNameList=RxList([]);
  // RxList<Map> rxServiceNameList=RxList([]);
  var selectedServiceValue;
  var selectedServiceCategoryValue;
  RxList<Map> map=RxList([]);
  RxInt isSelected=0.obs;
  RxBool isExpend1=false.obs;
  RxBool isExpend2=false.obs;
  RxBool isExpend3=false.obs;
  RxBool isExpendReService=true.obs;
  RxBool isExpend4=false.obs;
  String id="";
  String encryptedEmail="";
  String encryptecPhone="";
  TextEditingController etfirstname = new TextEditingController();
  TextEditingController etSearchDevotee = new TextEditingController();
  TextEditingController etmember1 = new TextEditingController();
  TextEditingController etmember2 = new TextEditingController();
  TextEditingController etmember3 = new TextEditingController();
  TextEditingController etmember4 = new TextEditingController();
  TextEditingController etmember5 = new TextEditingController();
  TextEditingController etmember6 = new TextEditingController();
  TextEditingController etlastname = new TextEditingController();
  TextEditingController etLanguage = new TextEditingController();
  TextEditingController etpledgeday = new TextEditingController();
  TextEditingController etemail = new TextEditingController();
  TextEditingController etphone = new TextEditingController();
  TextEditingController etPriestPhone = new TextEditingController();
  TextEditingController etPriestName = new TextEditingController();
  TextEditingController etPriestEmail = new TextEditingController();
  TextEditingController etAdditionalPriest = new TextEditingController();
  TextEditingController etlifetime = new TextEditingController();
  TextEditingController etpledgeDate = new TextEditingController();
  TextEditingController ettime = new TextEditingController();
  TextEditingController etRequestDate = new TextEditingController();
  TextEditingController etstreetaddress = new TextEditingController();
  TextEditingController etserviceCategory = new TextEditingController();
  TextEditingController etServiceLocation = new TextEditingController();
  TextEditingController etserviceName = new TextEditingController();
  TextEditingController etserviceType = new TextEditingController();

  TextEditingController etnoofsqfootforPledge = new TextEditingController();
  TextEditingController etpledgefor = new TextEditingController();
  TextEditingController etPledgeAmount = new TextEditingController();
  TextEditingController etpledgeamount = new TextEditingController();
  TextEditingController etgothram = new TextEditingController();
  TextEditingController etstar = new TextEditingController();
  TextEditingController etrasi = new TextEditingController();
  TextEditingController etdob = new TextEditingController();
  TextEditingController etgothram1 = new TextEditingController();
  TextEditingController etstar1 = new TextEditingController();
  TextEditingController etrasi1 = new TextEditingController();
  TextEditingController etgothram2 = new TextEditingController();
  TextEditingController etstar2 = new TextEditingController();
  TextEditingController etrasi2 = new TextEditingController();
  TextEditingController etgothram3 = new TextEditingController();
  TextEditingController etstar3 = new TextEditingController();
  TextEditingController etrasi3 = new TextEditingController();
  TextEditingController etgothram4 = new TextEditingController();
  TextEditingController etstar4 = new TextEditingController();
  TextEditingController etrasi4 = new TextEditingController();
  TextEditingController etstar5 = new TextEditingController();
  TextEditingController etrasi5 = new TextEditingController();
  TextEditingController etstar6 = new TextEditingController();
  TextEditingController etrasi6 = new TextEditingController();
  TextEditingController eteventType = new TextEditingController();
  TextEditingController etaddress = new TextEditingController();
  TextEditingController etnotes = new TextEditingController();

  TextEditingController etstate = new TextEditingController();
  TextEditingController etcity = new TextEditingController();
  TextEditingController etzip = new TextEditingController();

  TextEditingController etchecknumber = new TextEditingController();
  TextEditingController etbankname = new TextEditingController();
  TextEditingController etamount = new TextEditingController();
  TextEditingController etdate = new TextEditingController();

  TextEditingController etCeditCardnumber = new TextEditingController();
  TextEditingController etCeditCardname = new TextEditingController();
  TextEditingController etexpirydate = new TextEditingController();
  TextEditingController etCVVNo = new TextEditingController();
  TextEditingController etcardZipCode = new TextEditingController();

  TextEditingController etbankName = new TextEditingController();
  TextEditingController etroutingNo = new TextEditingController();
  TextEditingController etpayeeName = new TextEditingController();
  TextEditingController etServiceAmount = new TextEditingController();
  TextEditingController etaccName = new TextEditingController();
  TextEditingController etaccNo = new TextEditingController();

  TextEditingController etadult = new TextEditingController();
  TextEditingController etchildren = new TextEditingController();
  TextEditingController etfoodType = new TextEditingController();
  TextEditingController etpackage = new TextEditingController();
  TextEditingController etextraFood = new TextEditingController();
  TextEditingController etShraadhamFor = new TextEditingController();
  TextEditingController ettithiDetail = new TextEditingController();

  Rx<AllContactDatas> allContactDatas= AllContactDatas().obs;
  Rx<AllContactDatas> allPriestDatas= AllContactDatas().obs;

  List<String> statusList=["NEW", "SCHEDULED", "COMPLETED", "CANCEL"];

RxList<Map> rxLocation=[
{"name":"IN-TEMPLE"},
{"name":"AWAY-TEMPLE"}
].obs;

  var locationValue;
RxList<Map> rxLanguage=[
{"name":"ENGLISH"},
{"name":"SPANISH"},
{"name":"HINDI"}].obs;

  var languageValue;


var maskFormatter = new MaskTextInputFormatter(
  mask: '(###) ###-####',
  filter: {"#": RegExp(r'[0-9]')},
  type: MaskAutoCompletionType.lazy);


  RxString rxMessage="".obs;
  @override
  void onInit() {
    getAllPriest();
    getServiceCategory();
    super.onInit();
  }

  fetchFilterApi(String filterData)async{
    bodyJson["componentConfig"]={
      "moduleName":"Contacts",
      "aspectType": "Member Directory",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":filterData.contains("@")?{"aspectType":"Member Directory","memberTypes":"DEVOTEE","email":UtilMethods.encrypt(filterData)}
          :{"aspectType":"Member Directory","memberTypes":"DEVOTEE",
        if(_isNumeric(filterData))"phone":UtilMethods.encrypt(filterData),
      },
      "skip":0,
      "next":200
    };
    print("bcffbchgc");
    print(bodyJson);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;

    if(AllContactDatas.fromJson(jsonDecode(response)).data!.isNotEmpty)
    {
      allContactDatas.value.data=allContactDatasFromJson(response).data!;
      final datum= allContactDatas.value.data![0];
      etfirstname.text=datum.refDataName!;
      id=datum.id!;
      etemail.text=UtilMethods.decrypt(datum.email!);
      encryptedEmail=datum.email!;
      encryptecPhone=datum.phone!;
      etemail.text=UtilMethods.decrypt(datum.email!);
      etphone.text=phoneFormatter(datum.phone!);
      etstate.text=datum.stateTypes!;
      etcity.text=datum.cityTypes!;
      etaddress.text=datum.address!;

    }
    else{
      Fluttertoast.showToast(msg: "Devotee Not Register");
    }
  }
  bool _isNumeric(String str) {
    if(str == null) {
      return false;
    }
    return double.tryParse(str) != null;
  }


  getAllPriest()async {
  bodyJson["componentConfig"] = {
    "moduleName": "Contacts",
    "aspectType": "Member Directory",
    "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
    "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
    "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
    "query": {
      "aspectType": "Member Directory",
      "memberTypes": "PRIEST",
    },
    "skip": 0,
    "next": 400
  };

    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;

    if(AllContactDatas.fromJson(jsonDecode(response)).data!.isNotEmpty)
    {
      allPriestDatas.value.data=allContactDatasFromJson(response).data!;
      map.clear();
      selectedPriestValue=null;
      allPriestDatas.value.data!.forEach((element) {
        map.add({"name":element.refDataName,"email":element.email,"phone":element.phone});
      });
    }
    else{
      Fluttertoast.showToast(msg: "Priest Not Available");
    }

  }

  getServiceCategory()async{
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "serviceCategoryTypes",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{"aspectType":"serviceCategoryTypes"},
      "skip":0,
      "next":500
    };
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    CategoryData.fromJson(jsonDecode(response)).data!.forEach((element) {
      rxServiceCategoryList.value.add({"name":element.refDataName??""});
    });
    // categoryDataFromJson(response);

  }


  getServicesDetails(String category) async{
    var bodyJson2={};
    bodyJson2["componentConfig"] = {
      "moduleName":"Service Setup",
      "aspectType": "ServiceSetup",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": {"aspectType":"ServiceSetup","serviceCategoryTypes":category,"source":"MOBILE"},
      "skip": 0,
      "next": 400
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson2).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("resdsjnvjds"+response);
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1") "";
    if(jsonDecode(response)["data"]==null) "";
    // if(jsonDecode(response)["data"].isEmpty){
    //   Fluttertoast.showToast(msg: "No Data Available");
    // };
    jsonDecode(response)["data"].forEach((element) {
      rxServiceNameList.value.add({"name":element["refDataName"]??"","serviceType":element["serviceTypes"]??""});
    });
    rxServiceNameList.refresh();
  }
  getServicesNameDetails(String category,String type) async{
    var bodyJson2={};
    bodyJson2["componentConfig"] = {
      "moduleName":"Service Setup",
      "aspectType": "ServiceSetup",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": {"aspectType":"ServiceSetup","serviceCategoryTypes":category,"serviceTypes":type,"source":"MOBILE"},
      "skip": 0,
      "next": 400
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson2).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("resdsjnvjds"+response);
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1") "";
    if(jsonDecode(response)["data"]==null) "";
    // if(jsonDecode(response)["data"].isEmpty){
    //   Fluttertoast.showToast(msg: "No Data Available");
    // };
    jsonDecode(response)["data"].forEach((element) {
      rxServiceNameList.value.add({"name":element["refDataName"]??""});
    });
    rxServiceNameList.refresh();
  }

 addServiceRequest() async {
    var bodyJson = {
      "memberId":id,
      "serviceRequestName": etfirstname.text,
      "serviceAmount": etServiceAmount.text,
      "prsnEmail":encryptedEmail,
      "prsnPhone":encryptecPhone,
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "serviceDate": etdate.text,
      "serviceTime": ettime.text,
      "serviceLocationName": etServiceLocation.text,
      "adults":etadult.text,
      "children": etchildren.text,
      "serviceAddress": etaddress.text,
      "foodType": "",
      "package": "",
      "extraFood": "",
      "serviceName": etserviceName.text,
      "serviceCategoryTypes": etserviceCategory.text,
      "serviceTypes": etserviceType.text,
      "notes": etnotes.text,
      "languagePreferenceName": etLanguage.text,
      "requestForPriestName": selectedPriestValue["name"],
      "priestEmail": selectedPriestValue["email"],
      "priestPhone": selectedPriestValue["phone"],
      "etShraadhamFor": "",
      "ettithiDetail": "",
      "source": "MOBILE",
      "notificationEmailName": "YES",
    };
    print("bkjvbjkervbrbv");
    print(jsonEncode(bodyJson));
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.addServiceRequest, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("bkjvbjkervbrbv");
    print(response);
    if (json.decode(response)['statusCode'] == "-1") {
     Fluttertoast.showToast(
         msg: json.decode(response)['message'],
         toastLength: Toast.LENGTH_SHORT,
         gravity: ToastGravity.CENTER,
         timeInSecForIosWeb: 1,
         backgroundColor: Colors.red,
         textColor: Colors.white,
         fontSize: 16.0);
   } else {
     Alert(
       context: Get.context!,
       type: AlertType.success,
       style: AlertStyle(
         backgroundColor: Colors.black,
         titleStyle: Theme.of(Get.context!)
             .textTheme
             .bodyText1!
             .copyWith(color: Colors.white, fontSize: 24),
         descStyle: Theme.of(Get.context!)
             .textTheme
             .bodyText1!
             .copyWith(color: Colors.white, fontSize: 15),
       ),
       title: "Success",
       desc: json.decode(response)['message'],
       buttons: [
         DialogButton(
           color: Color(0xFF005d4b),
           child: Text(
             "OK",
             style: Theme.of(Get.context!)
                 .textTheme
                 .bodyText1!
                 .copyWith(color: Colors.white, fontSize: 15),
           ),
           onPressed: () => {Get.offAll(() => DashboardNavBar())},
         )
       ],
     ).show();
    }
  }
}