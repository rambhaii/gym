
import 'dart:convert';

ServiceRequestData serviceRequestDataFromJson(String str) => ServiceRequestData.fromJson(json.decode(str));

String serviceRequestDataToJson(ServiceRequestData data) => json.encode(data.toJson());

class ServiceRequestData {
  ServiceRequestData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<ServiceRequestDatum> ?data;

  factory ServiceRequestData.fromJson(Map<String, dynamic> json) => ServiceRequestData(
    statusCode: json["statusCode"]??"",
    message: json["message"]??"",
    data: List<ServiceRequestDatum>.from((json["data"]??[]).map((x) => ServiceRequestDatum.fromJson(x))),
  );
  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class ServiceRequestDatum {
  ServiceRequestDatum({
    this.id,
    this.memberId,
    this.prsnEmail,
    this.prsnPhone,
    this.serviceDate,
    this.requestDate,
    this.serviceTime,
    this.serviceLocationName,
    this.serviceName,
    this.serviceAmount,
    this.notes,
    this.languagePreferenceName,
    this.requestForPriestName,
    this.notificationEmailName,
    this.serviceStatus,
    this.date,
    this.priestMessage,
    this.clientmessage,
    this.comments,
    this.isChecked,
    this.priestEmail,
    this.priestPhone,
    this.serviceTypes,
    this.serviceCategoryTypes,
    this.foodType,
    this.package,
    this.extraFood,
    this.adults,
    this.children,
    this.serviceAddress,
    this.priestID,
    this.dob,
    this.serviceImage,
    this.serviceId,
    this.priestDetail,
    this.poojaList,
  });

  String ?id;
  String ?memberId;
  String ?prsnEmail;
  String ?prsnPhone;
  String ?serviceDate;
  String ?requestDate;
  String ?serviceTime;
  String ?serviceLocationName;
  String ?serviceName;
  String ?serviceTypes;
  String ?serviceCategoryTypes;
  var serviceAmount;
  String ?notes;
  String ?clientmessage;
  String ?priestMessage;
  String ?languagePreferenceName;
  String ?requestForPriestName;
  String ?notificationEmailName;
  String ?serviceStatus;
  String ?date;
  String ?priestEmail;
  String ?priestPhone;

  String ?foodType;
  String ?package;
  String ?extraFood;
  String ?adults;
  String ?children;
  String ?serviceAddress;
  String ?priestID;
  String ?serviceImage;
  String ?serviceId;
  Comments? comments;
  PriestDetail? priestDetail;
  List<PoojaList>? poojaList;
  String? dob;
  bool? isChecked;
  factory ServiceRequestDatum.fromJson(Map<String, dynamic> json) => ServiceRequestDatum(
    id: json["_id"]??"",
    memberId: json["memberId"]??"",
    prsnEmail: json["prsnEmail"]??"",
    prsnPhone: json["prsnPhone"]??"",
    serviceDate: json["serviceDate"]??"",
    requestDate: json["requestDate"]??"",
    serviceTime: json["serviceTime"]??"",
    serviceLocationName: json["serviceLocationName"]??"",
    serviceName: json["serviceName"]??json["ServiceSetup"]??"",
    serviceAmount: json["serviceAmount"]??"",
    notes: json["notes"]??"",
    dob: json["dob"]??"",
    clientmessage: json["clientmessage"]??"",
    priestMessage: json["priestMessage"]??"",
    languagePreferenceName: json["languagePreferenceName"]??"",
    requestForPriestName: json["priestName"]??"",
    notificationEmailName: json["notificationEmailName"]??"",
    serviceStatus: json["serviceStatus"]??["status"]??["statusName"],
    date: json["date"]??"",
    serviceTypes: json["serviceTypes"]??"",
    serviceCategoryTypes: json["serviceCategoryTypes"]??"",
    priestPhone: json["priestPhone"]??"",
    priestEmail: json["priestEmail"]??"", foodType: json["foodType"]??"",
    package: json["package"]??"",
    extraFood: json["extraFood"]??"",
    children: json["children"]??"",
    serviceAddress: json["serviceAddress"]??"",
    priestID: json["priestID"]??"",
    serviceImage: json["serviceImage"]!=null?json["serviceImage"]["Image"]??"":"",
    serviceId: json["serviceImage"]!=null?json["serviceImage"]["_id"]??"":"",
    comments: Comments.fromJson(json["comments"]??[]),
    priestDetail: PriestDetail.fromJson(json["priestDetail"]??[]),
     poojaList: List<PoojaList>.from( (json["serviceImage"]!=null?json["serviceImage"]["poojaList"].toString().isEmpty?[]:json["serviceImage"]["poojaList"]:[]).map((x) => PoojaList.fromJson(x))),
    isChecked: false,

  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "memberId": memberId,
    "prsnEmail": prsnEmail,
    "prsnPhone": prsnPhone,
    "serviceDate": serviceDate,
    "requestDate": requestDate,
    "serviceTime": serviceTime,
    "serviceLocationName": serviceLocationName,
    "serviceName": serviceName,
    "serviceAmount": serviceAmount,
    "notes": notes,
    "clientmessage": clientmessage,
    "priestMessage": priestMessage,
    "languagePreferenceName": languagePreferenceName,
    "requestForPriestName": requestForPriestName,
    "notificationEmailName": notificationEmailName,
    "serviceStatus": serviceStatus,
    "date": date,
    "foodType": foodType,
    "package": package,
    "extraFood": extraFood,
    "serviceImage": serviceImage,
    "children": children,
    "serviceAddress": serviceAddress,
    "priestID": priestID,
    "isChecked": isChecked,
    "dob": dob,
    "serviceId": serviceId,
    "comments": comments!.toJson(),
    "priestDetail": priestDetail!.toJson(),
    "poojaList": List<dynamic>.from(poojaList!.map((x) => x.toJson())),
    "priestPhone": priestPhone,
    "priestEmail": priestEmail,
    "serviceCategoryTypes": serviceCategoryTypes,
    "serviceTypes": serviceTypes,

  };
}

class Comments {
  Comments({
    this.id,
    this.contactName,
    this.email,
    this.phone,
    this.moduleName,
    this.memberTypes,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.address,
    this.city,
    this.companyEmail,
    this.companyName,
    this.companyPhone,
    this.emailSubscriptionName,
    this.gotraName,
    this.memberDetail,
    this.nakshatraName,
    this.phoneSubscriptionName,
    this.rashiName,
    this.state,
    this.dob,

    this.website,
    this.countryCode,

    this.zip,
  });

  String ?id;
  String ?contactName;
  String ?email;
  String ?phone;
  String ?moduleName;
  String ?memberTypes;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  dynamic recCreBy;
  String ?recCreDate;
  dynamic recModBy;
  String ?recModDate;
  String ?address;
  String ?city;
  String ?companyEmail;
  String ?companyName;
  String ?companyPhone;
  String ?emailSubscriptionName;
  String ?gotraName;
  String ?dob;
  List<MemberDetail> ?memberDetail;
  String? nakshatraName;
  String ?phoneSubscriptionName;
  String ?rashiName;
  String ?state;
  String ?website;
  String ?zip;
  String ?countryCode;

  factory Comments.fromJson(Map<String, dynamic> json) => Comments(
    id: json["_id"]??"",
    contactName: json["refDataName"]??"",
    email: json["email"]??"",
    phone: json["phone"]??"",
    moduleName: json["moduleName"]??"",
    memberTypes: json["memberTypes"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    dob: json["dob"]??"",
    address: json["address"]??"",
    city: json["city"]??"",
    companyEmail: json["companyEmail"]??"",
    companyName: json["companyName"]??"",
    companyPhone: json["companyPhone"]??"",
    emailSubscriptionName: json["emailSubscriptionName"]??"",
    gotraName: json["gotraName"]??"",
    memberDetail: List<MemberDetail>.from((json["memberDetail"]??[]).map((x) => MemberDetail.fromJson(x))),
    nakshatraName: json["nakshatraName"]??"",
    phoneSubscriptionName: json["phoneSubscriptionName"]??"",
    rashiName: json["rashiName"]??"",
    state: json["state"]??"",

    website: json["website"]??"",
    zip: json["zip"]??"",
    countryCode: json["countryCode"]??"",

  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "contactName": contactName,
    "email": email,
    "phone": phone,
    "dob": dob,
    "moduleName": moduleName,
    "memberTypes": memberTypes,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "address": address,
    "city": city,
    "companyEmail": companyEmail,
    "companyName": companyName,
    "companyPhone": companyPhone,
    "emailSubscriptionName": emailSubscriptionName,
    "gotraName": gotraName,
    "memberDetail": List<dynamic>.from(memberDetail!.map((x) => x.toJson())),
    "nakshatraName": nakshatraName,
    "phoneSubscriptionName": phoneSubscriptionName,
    "rashiName": rashiName,
    "state": state,
    "website": website,
    "zip": zip,
    "countryCode": countryCode,

  };
}

class PriestDetail {
  PriestDetail({
    this.id,
    this.contactName,
    this.priestImage,
  });

  String ?id;
  String ?contactName;
  String ?priestImage;


  factory PriestDetail.fromJson(Map<String, dynamic> json) => PriestDetail(
    id: json["_id"]??"",
    contactName: json["refDataName"]??"",
    priestImage: json["image"]??"",


  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "contactName": contactName,
    "image": priestImage,

  };
}
class PoojaList {
  PoojaList({
    this.name,
    this.qty,
    this.uom,
  });

  String ?name;
  String ?qty;
  String ?uom;


  factory PoojaList.fromJson(Map<String, dynamic> json) => PoojaList(
    name: json["name"]??"",
    qty: json["qty"]??"",
    uom: json["uom"]??"",


  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "qty": qty,
    "uom": uom,

  };
}
class MemberDetail {
  MemberDetail({
    this.memberName,
    this.nakshatra,
    this.rashi,
  });

  String ?memberName;
  String ?nakshatra;
  String ?rashi;

  factory MemberDetail.fromJson(Map<String, dynamic> json) => MemberDetail(
    memberName: json["memberName"]??"",
    nakshatra: json["nakshatra"]??"",
    rashi: json["rashi"]??"",
  );

  Map<String, dynamic> toJson() => {
    "memberName": memberName,
    "nakshatra": nakshatra,
    "rashi": rashi,
  };
}
