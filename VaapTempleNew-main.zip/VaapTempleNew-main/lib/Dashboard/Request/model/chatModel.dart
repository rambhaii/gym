// To parse this JSON data, do
//
//     final chatModel = chatModelFromJson(jsonString);

import 'dart:convert';

ChatModel chatModelFromJson(String str) => ChatModel.fromJson(json.decode(str));

String chatModelToJson(ChatModel data) => json.encode(data.toJson());

class ChatModel {
  ChatModel({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<ChatDatum>? data;

  factory ChatModel.fromJson(Map<String, dynamic> json) => ChatModel(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<ChatDatum>.from(json["data"].map((x) => ChatDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class ChatDatum {
  ChatDatum({
    this.id,
    this.serviceId,
    this.message,
    this.productId,
    this.memberId,
    this.priestId,
    this.isMember,
    this.clientId,
    this.memberName,
    this.priestName,
    this.recCreDate,
  });

  String ?id;
  String ?serviceId;
  String ?message;
  String ?productId;
  String ?memberId;
  String ?memberName;
  String ?priestId;
  String ?priestName;
  var isMember;
  String ?clientId;
  String? recCreDate;

  factory ChatDatum.fromJson(Map<String, dynamic> json) => ChatDatum(
    id: json["_id"],
    serviceId: json["serviceId"]??"",
    message: json["message"]??"",
    productId: json["productId"]??"",
    memberId: json["memberId"]??"",
    memberName: json["memberName"]??"",
    priestName: json["priestName"]??"fsdfsdf",
    priestId: json["priestId"]??"",
    isMember: json["isMember"]??"",
    clientId: json["clientId"]??"",
    recCreDate:json["recCreDate"]??"",
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "serviceId": serviceId,
    "message": message,
    "productId": productId,
    "memberId": memberId,
    "memberName": memberName,
    "priestName": priestName,
    "priestId": priestId,
    "isMember": isMember,
    "clientId": clientId,
    "recCreDate": recCreDate,
  };
}
