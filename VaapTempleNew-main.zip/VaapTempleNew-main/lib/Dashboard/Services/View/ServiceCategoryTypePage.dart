import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/TextStyle.dart';
import 'package:aspgen_mobile/Dashboard/Services/Controller/ServiceController.dart';
import 'package:aspgen_mobile/Dashboard/Services/View/ServicePage.dart';
import 'package:aspgen_mobile/Widget/SelectionTypeWidget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../Widget/SearchBarWidget.dart';
import '../../Donations/View/make_donation_page.dart';
class ServiceCategoryPage extends StatelessWidget {
  final String title;
  const ServiceCategoryPage({Key? key,required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    ServiceController serviceController=Get.put(ServiceController());
    TextEditingController etsearch=new TextEditingController();
    return Scaffold(
      appBar: AppBar(
        title: Text("Select "+title),
      ),
  body: Padding(
    padding: const EdgeInsets.only(top:8.0),
    child: Column(

      children: [
        SearchBarWidget(
          hint: "Search ",
          controller: etsearch,
          onchange: (value){
            serviceController.filterData(value);
          },
          onCancel: (){
            etsearch.clear();
            serviceController.filterData(etsearch.text);
          },
        ),
        SizedBox(height: 6,),
        Obx(()=> serviceController.category.value!=null?Expanded(
          child: ListView.builder(
              itemCount:serviceController.category.value.length,
              itemBuilder: (context,index)
              {
                return SelectionTypeWidget(title: serviceController.category.value[index].refDataName??"", onTap: (){
                  Get.to(()=>
                      ServiceTypePage(title:title, category: serviceController.category.value[index].refDataName??"",routType: 1,));
                });


              }),
        ):Container()
          ,
        ),
      ],
    ),
  ),
    );
  }
}


class ServiceTypePage extends StatelessWidget {
  final String category;
  final String title;
  final int routType;//1  for service and 2 for Donations
  const ServiceTypePage({Key? key,required this.category,required this.title, required this.routType}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    ServiceTypeController serviceController=Get.put(ServiceTypeController(category));
    TextEditingController etsearch=new TextEditingController();
   // ServiceTypeController
    return Scaffold(
      appBar: AppBar(
        title:routType==1? Text(category+"'s "+title): Text(title),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top:8.0),
        child: Column(
          children: [
            SearchBarWidget(
              hint: "Search ",
              controller: etsearch,
              onchange: (value){
                serviceController.filterData(value);
              },
              onCancel: (){
                etsearch.clear();
                serviceController.filterData(etsearch.text);
              },
            ),
            SizedBox(height: 8,),
            Obx(()=> serviceController.serviceType.value!=null?Expanded(
              child: ListView.builder(
                  itemCount:serviceController.serviceType.value.length,
                  itemBuilder: (context,index)
                  {
                    return SelectionTypeWidget(title: serviceController.serviceType.value[index].refDataName??"", onTap: (){
                      if(routType==1)
                        {
                          Get.to(()=>ServicePage(category: category, title: title, type: serviceController.serviceType.value[index].refDataName??"",));
                        }
                      else{
                        Get.to(() => MakeDonationPage(
                          title: "Service Setup",
                          displayName: "Donations",
                          type: serviceController.serviceType.value[index].refDataName!,
                        ));
                      }
                    });
                  }),
            ):Container()
              ,
            ),
          ],
        ),
      ),
    );
  }
}
