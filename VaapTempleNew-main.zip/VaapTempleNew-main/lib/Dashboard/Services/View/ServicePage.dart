import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/Dashboard/Services/Controller/ServiceController.dart';
import 'package:aspgen_mobile/Templates/fieldPageNew.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../../AppConstant/TextStyle.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/CustomListView.dart';
import '../../../Widget/SearchBarWidget.dart';



class ServicePage extends StatefulWidget {
  final String title;
  final String category;
  final String type;
  const ServicePage({Key? key, required this.title,required this.category,required this.type}) : super(key: key);

  @override
  _ServicePageState createState() => _ServicePageState();
}

class _ServicePageState extends State<ServicePage> {
  final DateFormat formatter = DateFormat.yMMMd('en_US');
late ServiceListController _controller;
  DateTime?tempDate;
  @override
  void initState() {
  _controller=  Get.put(ServiceListController(widget.title,widget.category,widget.type));
  // print("dvbsjbjkdsvk"+widget.category +"  "+widget.type);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
        ),
        actions: [  Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            CheckInternetConnection().then((value1) => value1==true? Get.to(()=>FieldPageNew(title: widget.title,type: 1,)):"");
          }
            ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        )],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),

        child: Column(
          children: [
            SizedBox(height: 8,),
            GetBuilder<ServiceListController>(
              builder: (controller)=>  SearchBarWidget(
                hint: "Search",
                controller: controller.etSearch,
                onchange: (value){
                  controller.filterData(value.toString());
                  //value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi(controller.bodyJson):"";
                  controller.update();
                },
                onCancel: (){
                  controller.etSearch.clear();
                  //controller.fetchApi(controller.bodyJson);
                  controller.update();
                },
              ),
            ),
            SizedBox(height: 8,),
            // FittedBox(
            //     child:Text(widget.category+ " || "+widget.type,style: Theme.of(context).textTheme.bodyText1!.copyWith(color: Colors.greenAccent,fontSize: 18),)
            // ),
            // SizedBox(height: 8,),
            Obx(()=> _controller.servicedata.value!=null?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {

                  });
                  },
                child:

                ListView.builder(
                    itemCount:_controller.servicedata.value.length,
                    itemBuilder: (context,index)
                    {
                      final datum=_controller.servicedata.value[index];
                      print("dfnjbfbndfnb");
                      print(jsonEncode(datum));
                      return CustomListWidget(title: _controller.servicedata.value[index].refDataName??"",
                        subTitle: _controller.servicedata.value[index].serviceCategoryTypes??"",
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              if(datum.serviceAmount!.toString().isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.serviceAmount!.toString().isNotEmpty) viewMore("Amount  ",  amountParser(datum.serviceAmount.toString())),
                              if(datum.serviceTypes!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.serviceTypes!.isNotEmpty) viewMore("Type  ",datum.serviceTypes??""),
                              if(datum.startDate!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.3),),
                              if(datum.startDate!.isNotEmpty)  viewMore("Date/Time",(datum.startDate??"")+" "+(datum.startTime??"")),
                            ]),
                        textEditingController: _controller.etSearch,isClicked: _controller.servicedata.value[index].isChecked!??false,
                        onTapVieMore: (){
                          _controller.servicedata.value[index].isChecked=!_controller.servicedata.value[index].isChecked!;
                          _controller.servicedata.refresh();
                      },
                           editOnTap: (){
                           CheckInternetConnection().then((value) {
                                if(value==true)
                                {
                                  Get.to(()=>FieldPageNew(title: widget.title, type: 2,id:_controller.servicedata.value[index].id!,),arguments: {'data':json.decode(json.encode(_controller.servicedata.value[index]))});
                                }
                              });
                        },
                      );


                    }),
              ),
            ):Container(),
            )
          ],
        ),
      ),
    );
  }

}
