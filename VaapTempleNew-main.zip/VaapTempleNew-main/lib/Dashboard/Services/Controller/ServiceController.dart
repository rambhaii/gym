import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Services/Model/ServiceCategoryTypeData.dart';
import 'package:aspgen_mobile/Dashboard/Services/Model/ServiceData.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../Templates/Model/CategoryData.dart';
import '../../../Templates/Model/RequestData.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';

class ServiceController extends GetxController{
  RequestData _requestData=RequestData();
  CategoryData categoryData=CategoryData();
  RxList<CategoryDatum> category= RxList<CategoryDatum>([]);
  RxList<CategoryDatum> filtercategory= RxList<CategoryDatum>([]);

  var bodyJson={};
  @override
  void onInit() {
    // TODO: implement onInit
    fetchApi();
    super.onInit();
  }
  fetchApi()async{
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "serviceCategoryTypes",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{"aspectType":"serviceCategoryTypes"},
      "skip":0,
      "next":100
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
      if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    categoryData=categoryDataFromJson(response);
    category.value=categoryData.data!;
    filtercategory.value=categoryData.data!;
  }
  void filterData(String search){
    List<CategoryDatum> result=[];
       if(search.isEmpty)
         {
           result=filtercategory.value;
         }
       else{
         result=filtercategory.value.where((element) =>element.refDataName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
       }
       category.value=result;
  }
}
class ServiceTypeController extends GetxController{
  CategoryData categoryData=CategoryData();
  RxList<CategoryDatum> serviceType= RxList<CategoryDatum>([]);
  RxList<CategoryDatum> filtercategory= RxList<CategoryDatum>([]);
  final String categoryType;
   ServiceTypeController(this.categoryType);
  // RxList serviceType =  [].obs;
  // RxList filtercategory =  [].obs;
  var bodyJson={};
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "serviceTypes",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{"aspectType":"serviceTypes","refDataCode":categoryType},
      "skip":0,
      "next":300
    };
    fetchApis();
    super.onInit();
  }
  fetchApis()async{
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    categoryData=categoryDataFromJson(response);
      if(categoryData.data!.isNotEmpty) {
        serviceType.value = categoryData.data!;
        filtercategory.value = categoryData.data!;
      }
      else{
        Get.snackbar("No Data!!","No Data Available",snackPosition: SnackPosition.BOTTOM);
      }


  }

  void filterData(String search){
    List<CategoryDatum> result=[];
    if(search.isEmpty)
    {
      result=filtercategory.value;
    }
    else{
      result=filtercategory.value.where((element) =>element.refDataName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    serviceType.value=result;
  }

}
class ServiceListController extends GetxController{
  Rx<List<ServiceDatum>> servicedata= Rx<List<ServiceDatum>>([]);
  Rx<List<ServiceDatum>> filterservicedata= Rx<List<ServiceDatum>>([]);
  ServiceListController(this.title, this.category, this.Type,);
  final String title;
  final String category;
  final String Type;
  var bodyJson={};
  TextEditingController etSearch= new TextEditingController();

  @override
  void onInit() {
    var query={"aspectType":"ServiceSetup","serviceCategoryTypes":category,"serviceTypes":Type,"sourceTypes":"MOBILE"};
    fechApi(query).then((value){
      servicedata.value=ServiceData.fromJson(jsonDecode(value)).data!;
      filterservicedata.value=ServiceData.fromJson(jsonDecode(value)).data!;
    });
    super.onInit();
  }
  Future<String> fechApi(var query) async{
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, getRequestJson(query)).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("vfjfnvjfv");
    print(response);
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1") "";
    if(jsonDecode(response)["data"]==null) "";
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No Data Available");
    };

    return response;
  }
  getRequestJson(var query){
    bodyJson["componentConfig"] = {
      "moduleName":"Service Setup",
      "aspectType": "ServiceSetup",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": query,
      "skip": 0,
      "next": 100
    };
    return bodyJson;
  }
  void filterData(String search){
    List<ServiceDatum> result=[];
    if(search.isEmpty)
    {
      result=filterservicedata.value;
    }
    else{
      result=filterservicedata.value.where((element) =>element.refDataName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    servicedata.value=result;
  }
}