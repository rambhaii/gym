// To parse this JSON data, do
//
//     final serviceCategoryTypeData = serviceCategoryTypeDataFromJson(jsonString);

import 'dart:convert';

ServiceCategoryTypeData serviceCategoryTypeDataFromJson(String str) => ServiceCategoryTypeData.fromJson(json.decode(str));

String serviceCategoryTypeDataToJson(ServiceCategoryTypeData data) => json.encode(data.toJson());

class ServiceCategoryTypeData {
  ServiceCategoryTypeData({
    this.data,
    this.success,
  });

  List<ServiceCategoryTypeDatum>?data;
  bool ?success;

  factory ServiceCategoryTypeData.fromJson(Map<String, dynamic> json) => ServiceCategoryTypeData(
    data: List<ServiceCategoryTypeDatum>.from(json["data"].map((x) => ServiceCategoryTypeDatum.fromJson(x))),
    success: json["success"],
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
    "success": success,
  };
}

class ServiceCategoryTypeDatum {
  ServiceCategoryTypeDatum({
    this.serviceType,
    this.category,
  });

  String?serviceType;
  String?category;

  factory ServiceCategoryTypeDatum.fromJson(Map<String, dynamic> json) => ServiceCategoryTypeDatum(
    serviceType: json["serviceType"]??"",
    category: json["category"]??"",
  );

  Map<String, dynamic> toJson() => {
    "serviceType": serviceType,
    "category": category,
  };
}
