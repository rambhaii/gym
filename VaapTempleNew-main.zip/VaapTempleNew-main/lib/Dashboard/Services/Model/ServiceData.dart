// To parse this JSON data, do
//
//     final serviceData = serviceDataFromJson(jsonString);

import 'dart:convert';

import 'package:get/get.dart';

ServiceData serviceDataFromJson(String str) => ServiceData.fromJson(json.decode(str));

String serviceDataToJson(ServiceData data) => json.encode(data.toJson());

class ServiceData {
  ServiceData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<ServiceDatum> ?data;

  factory ServiceData.fromJson(Map<String, dynamic> json) => ServiceData(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<ServiceDatum>.from(json["data"].map((x) => ServiceDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class ServiceDatum {
  ServiceDatum({
    this.id,
    this.serviceCategoryTypes,
    this.serviceTypes,
    this.sourceTypes,
    this.refDataName,
    this.dayTypes,
    this.startDate,
    this.serviceDate,
    this.endDate,
    this.startTime,
    this.endTime,
    this.deity,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.day,
    this.qtyCounter,
    this.memberName,
    this.sequenceId,
    this.serviceAmount,
    this.isChecked,
    this.serviceName,
    this.statusName,
    this.bookingTime,
    this.image,
    this.ServiceSetup,
    this.unitTypes,
    this.costPerUnitType,
    this.description,
    this.facility,
    this.campingAmount,
    this.rentalCategory,
    this.isAdd,
    this.totalServiceAmount,
    this.campingEndDate,
    this.campingStartDate,

  });

  String? id;
  String? serviceCategoryTypes;
  String? rentalCategory;
  String? serviceTypes;
  String? sourceTypes;
  String? refDataName;
  String? serviceDate;
  String? dayTypes;
  String? startDate;
  String? endDate;
  String? memberName;
  String? startTime;
  String? endTime;
  String? deity;
  String? moduleName;
  String? clientId;
  String? productId;
  String? aspectType;
  String? serviceName;
  var bookingTime;
  String? statusName;
  String? recCreBy;
  String? recCreDate;
  String? campingStartDate;
  String? campingEndDate;
  dynamic? recModBy;
  String ?recModDate;
  String ?day;
  String ?qtyCounter;
  String ?sequenceId;
  String ?description;
  bool ?isChecked;
  bool ?isAdd;
  var serviceAmount;
  var totalServiceAmount;
  var costPerUnitType;
  var campingAmount;
  String ?image;
  String ?ServiceSetup;
  String ?unitTypes;
  String ?facility;

  factory ServiceDatum.fromJson(Map<String, dynamic> json) => ServiceDatum(
    id: json["_id"]??"",
    serviceCategoryTypes: json["serviceCategoryTypes"]??"",
    ServiceSetup: json["ServiceSetup"]??"",
    facility: json["facility"]??"",
    description: json["description"]??"",
    serviceTypes: json["serviceTypes"]??"",
    sourceTypes: json["sourceTypes"]??"",
    refDataName: json["refDataName"]??"",
    dayTypes: json["dayTypes"]??"",
    serviceDate: json["serviceDate"]??json["campingStartDate"]??"",
    startDate: json["startDate"]??"",
    endDate: json["endDate"]??"",
    campingAmount: json["campingAmount"]??"",
    startTime: json["startTime"]??"",
    endTime: json["endTime"]??"",
    deity: json["deity"]??"",
    unitTypes: json["unitTypes"]??"",
    rentalCategory: json["rentalCategory"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    campingStartDate: json["campingStartDate"]??"",
    campingEndDate: json["campingEndDate"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    costPerUnitType: json["costPerUnitType"]??"",
    day: json["day"]??"",
    qtyCounter: json["qtyCounter"]??"",
    sequenceId: json["sequenceId"]??"",
    bookingTime: json["bookingTime"]??"",
    image: json["image"]??"",
    memberName: json["memberName"]??json["customerName"]??"",
    serviceName: json["serviceName"]??"",
    statusName: json["statusName"]??"",
    serviceAmount: json["serviceAmount"]??"",
    totalServiceAmount: "",
    isChecked: false,
    isAdd: false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "serviceCategoryTypes": serviceCategoryTypes,
    "ServiceSetup": ServiceSetup,
    "serviceTypes": serviceTypes,
    "serviceDate": serviceDate,
    "sourceTypes": sourceTypes,
    "refDataName": refDataName,
    "campingStartDate": campingStartDate,
    "campingEndDate": campingEndDate,
    "dayTypes": dayTypes,
    "startDate": startDate,
    "unitTypes": unitTypes,
    "endDate": endDate,
    "startTime": startTime,
    "endTime": endTime,
    "deity": deity,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "description": description,
    "facility": facility,
    "day": day,
    "qtyCounter": qtyCounter,
    "sequenceId": sequenceId,
    "campingAmount": campingAmount,
    "image": image,
    "memberName": memberName,
    "serviceName": serviceName,
    "bookingTime": bookingTime,
    "statusName": statusName,
    "serviceAmount": serviceAmount,
    "isChecked": isChecked,
    "rentalCategory": rentalCategory,
    "costPerUnitType": costPerUnitType,
    "totalServiceAmount": totalServiceAmount,
    "isAdd": isAdd,
  };
}
