import 'dart:convert';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/Authentication/controller/auth_controller.dart';
import 'package:aspgen_mobile/Authentication/new_registration.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:aspgen_mobile/Widget/EditextWidget.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import "package:http/http.dart" as http;

import '../Authentication/NewLoginPage.dart';
import '../UtilMethods/Utils.dart';

class ProfilePage extends StatelessWidget {
  final String title;
   ProfilePage({Key? key, required this.title}) : super(key: key);
  AuthController authController=Get.put(AuthController());
  final formGlobalKey = GlobalKey<FormState>();

  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer);
    return Scaffold(
        appBar: AppBar(
          title: Text(
           title,
          ),
          actions: [
            RawMaterialButton(onPressed: (){
              if (formGlobalKey.currentState!.validate()) {
                // DeterminePosition().then((value) async {
                //   String? token = await FirebaseMessaging.instance
                //       .getToken();
                //
                //   // UtilMethods.signUp(
                //   //     context,
                //   //     authController.etusername.text,
                //   //     authController.etpassword.text,
                //   //     authController.etfirstname.text,
                //   //     authController.etlastname.text,
                //   //     authController.etemail.text,
                //   //     authController.etphone.text,
                //   //     authController.etaddress.text,
                //   //     authController.etcity.text,
                //   //     authController.etstate.text,
                //   //     "",
                //   //     authController.etUserZip.text,
                //   //     "",
                //   //     "",
                //   //     "",
                //   //     "",
                //   //     "",
                //   //     token!.toString(),
                //   //     value.latitude.toString() + "," +
                //   //         value.longitude.toString(),
                //   //     authController.twoFactor.value,
                //   //     authController.notification.value,
                //   //     authController.newsletters.value,
                //   //     authController.pinPasword.value,
                //   //     authController.etPinPassword.text).then((value) {
                //   //   if (jsonDecode(value)["statusCode"] == 1) {
                //   //     Get.offAll(() => NewLoginPage());
                //   //   }
                //   // });
                // });
              }
            },
              child: Icon(Icons.save),
              fillColor: Colors.green,
              shape: CircleBorder(),
              constraints: BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
            SizedBox(width: 8,)
          ],
        ),
        body:SingleChildScrollView(
          child: GetBuilder<AuthController>(
              builder: (authController) {
                return Padding(
                  padding: const EdgeInsets.only(left: 10,right: 10.0),
                  child: Column(
                    children: [
                      Form(
                        key: formGlobalKey,
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(top:15),
                              decoration:decoration.copyWith(border: Border.all(color: (authController.isExpanded1==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                              child:ExpansionTileCard(
                                  finalPadding: EdgeInsets.only(left: 10,right: 10,bottom: 8),
                                  baseColor: Colors.transparent,
                                  elevation: 0,
                                  expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                                  key: authController.Group1Key,
                                  onExpansionChanged: ((value){
                                    authController.isExpanded1=!authController.isExpanded1;
                                    authController.Group2Key.currentState!.collapse();
                                    authController.update();
                                  }),
                                  title: Text("User Details"),

                                  children:[
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Username",
                                      controller:authController.etusername,
                                      hint: 'Enter user name ',

                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form username';
                                        }

                                        return null;
                                      },
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "First Name",
                                      controller: authController.etfirstname,
                                      hint: 'Enter first name',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form first name';
                                        }
                                        return null;
                                      },
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Last Name",
                                      controller: authController.etlastname,
                                      hint: 'Enter Last Name',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form last name';
                                        }
                                        return null;
                                      },
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),


                                    EditTextWidget(
                                      label: "Email",
                                      controller: authController.etemail,
                                      hint: 'Enter Email',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form email';
                                        }
                                        if (!isValidEmail(value)) {
                                          return 'Please Enter Valid email';
                                        }
                                        return null;
                                      },
                                      maxLength: 50,
                                      keyboardtype: TextInputType.emailAddress,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Phone",
                                      controller: authController.etphone,
                                      hint: 'Enter Phone ',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form phone ';
                                        }
                                        return null;
                                      },
                                      maxLength: 10,
                                      keyboardtype: TextInputType.phone,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Zip Code",
                                      controller: authController.etUserZip,
                                      hint: 'Enter Zip Code ',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please Enter Zip Code';
                                        }
                                        return null;
                                      },
                                      maxLength: 10,
                                      keyboardtype: TextInputType.phone,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Address",
                                      controller:authController.etaddress,
                                      hint: 'Enter address',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form address';
                                        }
                                        return null;
                                      },
                                      maxLength: 50,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "State",
                                      controller: authController.etstate,
                                      hint: 'Enter State',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form state';
                                        }
                                        return null;
                                      },
                                      maxLength: 50,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "City",
                                      controller: authController.etcity,
                                      hint: 'Enter city',

                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form city';
                                        }
                                        return null;
                                      },
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                  ]
                              ),
                            ),
                            Container(
                              margin: EdgeInsets.only(top:15),
                              decoration:decoration.copyWith(border: Border.all(color: (authController.isExpanded2==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                              child:ExpansionTileCard(
                                  baseColor: Colors.transparent,
                                  elevation: 0,
                                  expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                                  key: authController.Group2Key,
                                  onExpansionChanged: ((value){
                                    authController.Group1Key.currentState!.collapse();
                                    authController.Group3Key.currentState!.collapse();
                                    authController.isExpanded2=!authController.isExpanded2;
                                    authController.update();
                                  }),
                                  title: Text("User Preferences"),
                                  children:[
                                    Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        SizedBox(height: 8,),
                                        Card(
                                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                                          child: ListTile(
                                            title: Text("Two Factor Authentication ",style: Theme.of(context).textTheme.bodyText1,
                                            ) ,
                                            trailing:Obx(()=>CupertinoSwitch(onChanged: (bool value) {
                                              authController.changevalueTwofactorAut(value);
                                            }, value: authController.twoFactor.value,
                                            ),
                                            ),
                                          ),
                                        ),

                                        SizedBox(height: 5,),
                                        Card(
                                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                                          child: ListTile(
                                            title: Text("Notifications ",style: Theme.of(context).textTheme.bodyText1,
                                            ) ,
                                            trailing:Obx(()=> CupertinoSwitch(onChanged: (bool value) {
                                              authController.changevalueNotification(value);
                                            }, value:  authController.notification.value,
                                            ),
                                            ),
                                          ),
                                        ),


                                        SizedBox(height: 5,),
                                        Card(
                                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                                          child: ListTile(
                                            title: Text("Newsletters ",style: Theme.of(context).textTheme.bodyText1,
                                            ) ,
                                            trailing:Obx(()=> CupertinoSwitch(onChanged: (bool value) {
                                              authController.newsletters(value);
                                            }, value:  authController.newsletters.value,
                                            ),
                                            ),
                                          ),
                                        ),
                                        SizedBox(height: 5,),
                                        Card(
                                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                                          child: ListTile(
                                            title: Text("Pin Password  ",style: Theme.of(context).textTheme.bodyText1,
                                            ) ,
                                            trailing:Obx(()=>  CupertinoSwitch(onChanged: (bool value) {
                                              authController.changePinPassword(value);
                                            }, value:  authController.pinPasword.value,
                                            ),
                                            ),
                                          ),
                                        ),

                                        SizedBox(height: 15,),

                                        Obx(()=> authController.pinPasword.value? Row(
                                          children: [
                                            SizedBox(width: 15,),
                                            Expanded(
                                                flex: 3,
                                                child:EditTextWidget(
                                                  controller: authController.etPinPassword,
                                                  label: 'Enter Pin', maxLength: 6, keyboardtype: TextInputType.number, hint:  'Enter Pin', isPassword: false, validator: (value) {  },))
                                            , SizedBox(width: 15,),
                                          ],
                                        ):Container(),
                                        ),


                                      ],

                                    )
                                  ]
                              ),
                            ),
                          //   Container(
                          //     margin: EdgeInsets.only(top:15),
                          //     decoration:decoration.copyWith(border: Border.all(color: (authController.isExpanded3==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                          //     child:ExpansionTileCard(
                          //         baseColor: Colors.transparent,
                          //         elevation: 0,
                          //         finalPadding: EdgeInsets.only(left: 10,right: 10,bottom: 8),
                          //
                          //         expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                          //         key: authController.Group3Key,
                          //         onExpansionChanged: ((value){
                          //           authController.Group1Key.currentState!.collapse();
                          //           authController.Group2Key.currentState!.collapse();
                          //           authController.isExpanded3=!authController.isExpanded3;
                          //           authController.update();
                          //         }),
                          //         title: Text("Change Password"),
                          //         children:[
                          //           Column(
                          //             crossAxisAlignment: CrossAxisAlignment.center,
                          //             children: [
                          //               SizedBox(height: 8,),
                          //       EditTextWidget(
                          //         controller: authController.etPinPassword,
                          //         label: 'Old Password', maxLength: 6, keyboardtype: TextInputType.text, hint:  'Enter Old Password', isPassword: false, validator: (value) {  },),
                          //               SizedBox(height: 10,),
                          //       EditTextWidget(
                          //         controller: authController.etPinPassword,
                          //         label: 'New Password', maxLength: 6, keyboardtype: TextInputType.text, hint:  'Enter New Password', isPassword: false, validator: (value) {  },),
                          //               SizedBox(height:10,),
                          //        EditTextWidget(
                          //         controller: authController.etPinPassword,
                          //         label: 'Confirm Password', maxLength: 6, keyboardtype: TextInputType.text, hint:  'Enter Confirm Password', isPassword: false, validator: (value) {  },),
                          //
                          //
                          //
                          // ],
                          //
                          //           )
                          //         ]
                          //     ),
                          //   ),
                            SizedBox(height: 60,)
                          ],
                        ),
                      ),

                    ],
                  ),
                );
              }
          ),

        ) // This trailing comma makes auto-formatting nicer for build methods.
        );
   }



}
