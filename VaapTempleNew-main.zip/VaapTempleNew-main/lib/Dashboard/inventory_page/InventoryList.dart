import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../AppConstant/TextStyle.dart';
import '../../Templates/fieldPageNew.dart';
import '../../UtilMethods/RemoteServices.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListView.dart';
import '../../Widget/SearchBarWidget.dart';
import 'controller.dart';


class InventroyList extends StatefulWidget {
  final String title;
  final String displayName;
  const InventroyList({Key? key, required this.title, required this.displayName}) : super(key: key);

  @override
  _InventroyListState createState() => _InventroyListState();
}

class _InventroyListState extends State<InventroyList> {

  TextEditingController etsearch= new TextEditingController();
  late InventoryController inventoryController;
  DateTime?tempDate;
  @override
  void initState() {
    inventoryController=Get.put(InventoryController(widget.title));

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.displayName,
        ),
        actions: [  Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            CheckInternetConnection().then((value1) => value1==true? Get.to(()=>FieldPageNew(title: widget.title,type: 1,)):"");
          }
            ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        )],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),

        child: Column(
          children: [
            SizedBox(height: 10,),
        GetBuilder<InventoryController>(
          builder: (controller)=>  SearchBarWidget(
            hint: "Search",
            controller: controller.etSearch,
            onchange: (value){
              value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi():"";
              controller.update();
            },
            onCancel: (){
              controller.etSearch.clear();
              controller.fetchApi();
              controller.update();
            },
          ),
        ),
            SizedBox(height: 8,),
           Obx(() => inventoryController.inventoryData.value.data!=null?Expanded(
                child: RefreshIndicator(
                  semanticsLabel: "Refresh",
                  onRefresh: (){
                    return Future.delayed(Duration.zero, () {
                     inventoryController.fetchApi();
                    });
                 },
                  child: ListView.builder(
                      itemCount:inventoryController.inventoryData.value.data!.length,
                      itemBuilder: (context,index)
                      {
                        final datum=inventoryController.inventoryData.value.data![index];
                        print(jsonEncode(datum));
                        return  CustomListWidget(title: datum.refDataName??"",
                          subTitle: datum.itemCategory??"",
                          imgUrl: datum.image,
                          viewMoreWidget: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children:[
                                if(datum.rackNo!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                if(datum.rackNo!.isNotEmpty) viewMore("Rack No  ",datum.rackNo??""),
                                if(datum.quantityOnHand!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                if(datum.quantityOnHand!.isNotEmpty) viewMore("Qty On Hand  ", datum.quantityOnHand??""),
                                if(datum.quantityOnOrder!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                if(datum.quantityOnOrder!.isNotEmpty) viewMore("Qty  On Stock  ", datum.quantityOnOrder??""),
                              ]),
                          textEditingController: inventoryController.etSearch,isClicked:datum.isChecked!??false,
                          onTapVieMore: (){
                            datum.isChecked=!datum.isChecked!;
                            inventoryController.inventoryData.refresh();
                          },
                          editOnTap: (){
                            CheckInternetConnection().then((value) {
                              if(value==true)
                              {
                                Get.to(()=>FieldPageNew(title: widget.title,type: 2,id: datum.id,),arguments: {"data": json.decode(json.encode(datum))});
                              }
                            });
                          },
                        );

                      }),
                ),
              ):Container(),
            )
          ],
        ),
      ),

    );
  }

}
