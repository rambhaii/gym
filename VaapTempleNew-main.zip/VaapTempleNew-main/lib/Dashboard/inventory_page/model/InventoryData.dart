// To parse this JSON data, do
//
//     final inventoryData = inventoryDataFromJson(jsonString);

import 'dart:convert';

InventoryData inventoryDataFromJson(String str) => InventoryData.fromJson(json.decode(str));

String inventoryDataToJson(InventoryData data) => json.encode(data.toJson());

class InventoryData {
  InventoryData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<Datum> ?data;

  factory InventoryData.fromJson(Map<String, dynamic> json) => InventoryData(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.itemCategory,
    this.refDataName,
    this.laneNo,
    this.rackNo,
    this.binNo,
    this.status,
    this.brand,
    this.displayName,
    this.productCode,
    this.quantityOnHand,
    this.quantityTrigger,
    this.triggerCondition,
    this.quantityOnOrder,
    this.description,
    this.date,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.isChecked,
    this.refDataCode,
    this.image,
    this.thresholdQuantity,
  });

  String ?id;
  String ?itemCategory;
  String ?refDataCode;
  String ?refDataName;
  String ?laneNo;
  String ?image;
  String ?rackNo;
  String ?binNo;
  String ?status;
  String ?brand;
  String ?displayName;
  String ?productCode;
  String ?quantityOnHand;
  String ?quantityTrigger;
  String ?triggerCondition;
  String ?quantityOnOrder;
  String ?description;
  String ?thresholdQuantity;
  String ?date;
  String ?moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  bool ?isChecked;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"]??"",
    itemCategory: json["itemCategory"]??"",
    refDataName: json["refDataName"]??"",
    laneNo: json["laneNo"]??"",
    rackNo: json["rackNo"]??"",
    binNo: json["binNo"]??"",
    image: json["image"]??"",
    status: json["status"]??"",
    thresholdQuantity: json["thresholdQuantity"]??"",
    brand: json["brand"]??"",
    displayName: json["displayName"]??"",
    productCode: json["productCode"]??"",
    quantityOnHand: json["quantityOnHand"]??"",
    quantityTrigger: json["quantityTrigger"]??"",
    triggerCondition: json["triggerCondition"]??"",
    quantityOnOrder: json["quantityOnOrder"]??"",
    description: json["desc"]??"",
    date: json["date"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    refDataCode: json["refDataCode"]??"",
    isChecked: false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "itemCategory": itemCategory,
    "refDataName": refDataName,
    "laneNo": laneNo,
    "rackNo": rackNo,
    "binNo": binNo,
    "status": status,
    "brand": brand,
    "displayName": displayName,
    "productCode": productCode,
    "quantityOnHand": quantityOnHand,
    "quantityTrigger": quantityTrigger,
    "triggerCondition": triggerCondition,
    "quantityOnOrder": quantityOnOrder,
    "desc": description,
    "date": date,
    "moduleName": moduleName,
    "image": image,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "isChecked": isChecked,
    "refDataCode": refDataCode,
    "thresholdQuantity": thresholdQuantity,
  };
}
