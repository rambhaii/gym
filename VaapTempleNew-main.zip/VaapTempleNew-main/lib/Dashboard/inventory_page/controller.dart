import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/inventory_page/InventoryList.dart';
import 'package:aspgen_mobile/Dashboard/inventory_page/model/InventoryData.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/base_client.dart';

class InventoryController extends GetxController{
  InventoryController(this.titile);
  final String titile;
  var inventoryData= InventoryData().obs;
  TextEditingController etSearch= new TextEditingController();

  var bodyJson={};
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":titile,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip":0,
      "next":500
    };
    fetchApi();
    // TODO: implement onInit
    super.onInit();
  }

  fetchApi()async{

    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    inventoryData.value=inventoryDataFromJson(response);
  }
  fetchFilterApi(String text)async{
    var request={
      "text": text,
      "componentConfig": {
        "moduleName":titile,
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    inventoryData.value=inventoryDataFromJson(response);
  }
}