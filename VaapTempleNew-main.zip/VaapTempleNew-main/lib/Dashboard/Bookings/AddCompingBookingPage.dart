import 'package:aspgen_mobile/Dashboard/Bookings/controller/controller.dart';
import 'package:aspgen_mobile/Dashboard/Menu/Menu.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinbox/flutter_spinbox.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../AppConstant/AppColors.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/ButtonWidget.dart';
import '../../Widget/CircleTabIndicatorWidget.dart';
import '../../Widget/CustomListView.dart';
import '../../Widget/EditextWidget.dart';
import '../../Widget/HiglitTextWidget.dart';
import '../../Widget/SearchBarWidget.dart';
import '../Menu/Model/MenuData.dart';

import '../Services/Model/ServiceData.dart';
import 'controller/DevoteeController.dart';
import 'controller/camping_controller.dart';
import 'controller/rental_controller.dart';

class AddCompingBookingPage extends StatefulWidget {
  final String title;
  AddCompingBookingPage({Key? key, required this.title}) : super(key: key);

  @override
  State<AddCompingBookingPage> createState() => _AddCompingBookingPageState();
}

class _AddCompingBookingPageState extends State<AddCompingBookingPage> {
  TextEditingController etdate = new TextEditingController();

  final DateFormat formatter = DateFormat('MM/dd/yyyy');

  final formGlobalKey = GlobalKey<FormState>();

  DateTime? tempDate;
  DevoteeController devoteecontroller = Get.find();
  CompingController controller = Get.find();
  @override
  void initState() {
    print("bzvjkbzb");
    controller.alldata.clear();
    controller.rxTtlAmount.value = "0";
    controller.getServicesApi();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Book Camp",
          textAlign: TextAlign.center,
        ),
        actions: [
          Center(
              child: Obx(() => Text(
                    amountParser(controller.rxTtlAmount.value),
                    style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: Colors.amber),
                  ))),
          Padding(
            padding: const EdgeInsets.only(right: 8.0, left: 8),
            child: RawMaterialButton(
              onPressed: () {
                if (controller.alldata.isNotEmpty) {
                  showDialog(
                      context: context,
                      builder: (context) => showDailog(
                            context,
                          ));
                }
              },
              child: Icon(Icons.paypal),
              fillColor: Colors.green,
              shape: CircleBorder(),
              constraints: BoxConstraints(minWidth: 38.0, minHeight: 38.0),
            ),
          )
        ],
      ),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
              SizedBox(
                height: 8,
              ),
              GetBuilder<CompingController>(
                builder: (controller) => SearchBarWidget(
                  hint: "Search ",
                  controller: controller.etSearchAddBooking,
                  onchange: (value) {
                    controller.filterData(controller.etSearchAddBooking.text);
                    //value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi(controller.bodyJson):"";
                    controller.update();
                  },
                  onCancel: () {
                    controller.etSearchAddBooking.clear();
                    controller.filterData(controller.etSearchAddBooking.text);
                    controller.update();
                  },
                ),
              ),
              SizedBox(
                height: 4,
              ),
              // Obx(() => controller.caltegoryList.value.isNotEmpty? TabBar(
              //   onTap: (value){
              //     controller.filterData( controller.caltegoryList.value[value]);
              //   },
              //     controller: controller.tabController,
              //     isScrollable: true,
              //     labelColor: Colors.amber,
              //     unselectedLabelColor: Colors.white70,
              //     labelStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.bold),
              //     indicator: CircleTabIndicator(color: Colors.amber,radius: 4),
              //     tabs: List.generate(controller.caltegoryList.value.length, (index) => Tab(
              //     text: controller.caltegoryList.value[index],
              //   ))):Container(),
              // ),
              Obx(() => controller.servicedata.value != null
                  ? controller.servicedata.value.isNotEmpty
                      ? RefreshIndicator(
                          onRefresh: () {
                            return Future.delayed(Duration.zero, () {
                              // controller.servicedata();
                            });
                          },
                          child: ListView.builder(
                              itemCount: controller.servicedata.value.length,
                              shrinkWrap: true,
                              physics: NeverScrollableScrollPhysics(),
                              itemBuilder: (context, index) {
                                final datum =
                                    controller.servicedata.value[index];
                                return Card(
                                  shape: const RoundedRectangleBorder(
                                      borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(0.0),
                                          topRight: Radius.circular(0.0),
                                          bottomLeft: Radius.circular(0.0),
                                          bottomRight: Radius.circular(0.0))),
                                  color: AppColor.getColorByServiceCategory("")
                                      .withOpacity(0.35),
                                  elevation: 6,
                                  child: Column(
                                    children: [
                                      Divider(
                                        height: 0.5,
                                        thickness: 0.5,
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary
                                            .withOpacity(0.24),
                                      ),
                                      SizedBox(height: 10),
                                      Row(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Spacer(
                                            flex: 1,
                                          ),
                                          Expanded(
                                            flex: 25,
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.start,
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    Row(
                                                      children: [
                                                        Expanded(
                                                            flex: 2,
                                                            child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text(
                                                                      "Camp Name",
                                                                      style: Theme.of(
                                                                              Get.context!)
                                                                          .textTheme
                                                                          .bodyText2),
                                                                  SizedBox(
                                                                    height: 6,
                                                                  ),
                                                                  Text(
                                                                      datum
                                                                          .refDataName!,
                                                                      style: Theme.of(
                                                                              Get.context!)
                                                                          .textTheme
                                                                          .bodyText1)
                                                                ])),
                                                        Expanded(
                                                            flex: 1,
                                                            child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text("Amount",
                                                                      style: Theme.of(
                                                                              Get.context!)
                                                                          .textTheme
                                                                          .bodyText2),
                                                                  SizedBox(
                                                                    height: 6,
                                                                  ),
                                                                  Text(
                                                                      amountParser(datum
                                                                          .campingAmount
                                                                          .toString()),
                                                                      style: Theme.of(Get
                                                                              .context!)
                                                                          .textTheme
                                                                          .bodyText1!
                                                                          .copyWith(
                                                                              color: Colors.amber))
                                                                ])),
                                                      ],
                                                    ),
                                                    SizedBox(height: 8),
                                                    Divider(
                                                      height: 0.5,
                                                      thickness: 0.5,
                                                      color: Theme.of(context)
                                                          .colorScheme
                                                          .primary
                                                          .withOpacity(0.24),
                                                    ),
                                                    SizedBox(height: 8),
                                                    Row(
                                                      children: [
                                                        Expanded(
                                                            flex: 3,
                                                            child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text(
                                                                      "Start Date",
                                                                      style: Theme.of(
                                                                              Get.context!)
                                                                          .textTheme
                                                                          .bodyText2),
                                                                  SizedBox(
                                                                    height: 6,
                                                                  ),
                                                                  Row(
                                                                    children: [
                                                                      Icon(Icons
                                                                          .calendar_month),
                                                                      Text(
                                                                          datum
                                                                              .campingStartDate
                                                                              .toString(),
                                                                          style: Theme.of(Get.context!)
                                                                              .textTheme
                                                                              .bodyText1),
                                                                    ],
                                                                  )
                                                                ])),
                                                        Expanded(
                                                            flex: 3,
                                                            child: Column(
                                                                crossAxisAlignment:
                                                                    CrossAxisAlignment
                                                                        .start,
                                                                children: [
                                                                  Text(
                                                                      "End Date",
                                                                      style: Theme.of(
                                                                              Get.context!)
                                                                          .textTheme
                                                                          .bodyText2),
                                                                  SizedBox(
                                                                    height: 6,
                                                                  ),
                                                                  Row(
                                                                    children: [
                                                                      Icon(Icons
                                                                          .calendar_month),
                                                                      Text(
                                                                          datum
                                                                              .campingEndDate
                                                                              .toString(),
                                                                          style: Theme.of(Get.context!)
                                                                              .textTheme
                                                                              .bodyText1),
                                                                    ],
                                                                  )
                                                                ])),
                                                      ],
                                                    ),
                                                    SizedBox(height: 6),
                                                  ],
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 5,
                                            child: Column(
                                              children: [
                                                Container(
                                                  margin: EdgeInsets.only(
                                                      left: 6, right: 2),
                                                  alignment: Alignment.center,
                                                  decoration: BoxDecoration(
                                                      border: Border.all(
                                                          color: datum.isAdd!
                                                              ? Colors.white
                                                                  .withOpacity(
                                                                      0.5)
                                                              : Colors.green!
                                                                  .withOpacity(
                                                                      0.5),
                                                          width: 1),
                                                      shape: BoxShape.circle),
                                                  child: IconButton(
                                                    onPressed: () {
                                                      if (!datum.isAdd!) {
                                                        showDialog(
                                                            context: context,
                                                            builder: (ctx) =>
                                                                selectAdultChildDailog(
                                                                    context,
                                                                    datum));
                                                      } else {
                                                        datum.isAdd =
                                                            !datum.isAdd!;

                                                        controller.alldata
                                                            .removeWhere(
                                                                (element) =>
                                                                    element[
                                                                        "_id"] ==
                                                                    datum.id);
                                                        controller.rxTtlAmount
                                                            .value = (double.parse(
                                                                    controller
                                                                        .rxTtlAmount
                                                                        .value) -
                                                                double.parse(datum
                                                                    .campingAmount!
                                                                    .toString()))
                                                            .toStringAsFixed(2);
                                                        controller.servicedata
                                                            .refresh();
                                                      }

                                                      // datum.isAdd=!datum.isAdd!;
                                                      //  controller.servicedata.refresh();
                                                      // if(datum.isAdd!)
                                                      //           {
                                                      //             controller.alldata.add({
                                                      //               "_id": datum.id,
                                                      //               "date":datum.serviceDate!.isNotEmpty?datum.serviceDate!:formatter.format(DateTime.now()) ,
                                                      //               "serviceImage": datum.image,
                                                      //               "serviceName": datum.refDataName,
                                                      //               "qty": "1",
                                                      //               "time": datum.startTime,
                                                      //               "startDate": datum.serviceDate,
                                                      //               "campingAmount": datum.campingAmount.toString(),
                                                      //             });
                                                      //             controller.rxTtlAmount.value=(double.parse(controller.rxTtlAmount.value)+double.parse(datum.campingAmount!.toString())).toStringAsFixed(2);
                                                      //           }
                                                      //           else{
                                                      //             controller.alldata.removeWhere((element) => element["_id"]==datum.id);
                                                      //             controller.rxTtlAmount.value=(double.parse(controller.rxTtlAmount.value)-double.parse(datum.campingAmount!.toString())).toStringAsFixed(2);
                                                      //           }
                                                    },
                                                    splashRadius: 25,
                                                    padding: EdgeInsets.all(6),
                                                    constraints: BoxConstraints(
                                                        maxWidth: 30,
                                                        maxHeight: 30),
                                                    icon: !datum.isAdd!
                                                        ? Icon(
                                                            Icons.add,
                                                            color: Colors.green,
                                                            size: 18,
                                                          )
                                                        : Icon(
                                                            Icons.check,
                                                            color: Colors.white,
                                                            size: 18,
                                                          ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            // Checkbox(value: datum.isAdd,onChanged: (value){
                                            //  datum.isAdd=value;
                                            //  controller.servicedata.refresh();
                                            // },)
                                          )
                                        ],
                                      ),
                                      InkWell(
                                        onTap: () {
                                          datum.isChecked = !datum.isChecked!;
                                          controller.servicedata.refresh();
                                        },
                                        child: Row(
                                          children: [
                                            SizedBox(
                                              width: 10,
                                            ),
                                            Expanded(
                                                flex: 9,
                                                child: Row(
                                                  children: [
                                                    Text(
                                                        !datum.isChecked!
                                                            ? "View More  "
                                                            : "Less More",
                                                        style: TextStyle(
                                                          fontSize: 12,
                                                          color: Colors.white54,
                                                          decoration:
                                                              TextDecoration
                                                                  .underline,
                                                        )),
                                                    Icon(
                                                        !datum.isChecked!
                                                            ? Icons.expand_more
                                                            : Icons.expand_less,
                                                        size: 20,
                                                        color: Colors.white54)
                                                  ],
                                                )),
                                          ],
                                        ),
                                      ),
                                      if (datum.isChecked!)
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(left: 10.0),
                                          child: Column(
                                            crossAxisAlignment:
                                                CrossAxisAlignment.start,
                                            children: [
                                              Divider(
                                                thickness: 0.2,
                                                color: Colors.grey
                                                    .withOpacity(0.5),
                                              ),
                                              viewMore(
                                                  "Note",
                                                  datum.description!
                                                      .toString()),
                                              SizedBox(height: 8),
                                            ],
                                          ),
                                        ),
                                      SizedBox(height: 2),
                                      Divider(
                                        height: 0.5,
                                        thickness: 0.5,
                                        color: Theme.of(context)
                                            .colorScheme
                                            .primary
                                            .withOpacity(0.24),
                                      )
                                    ],
                                  ),
                                );
                              }),
                        )
                      : Center(
                          child: Text(
                            controller.etSearchAddBooking.text.isNotEmpty
                                ? "We couldn't find any Service\nmatching '${controller.etSearchAddBooking.text}'  "
                                : "",
                            style: Theme.of(context).textTheme.bodyText1,
                            textAlign: TextAlign.center,
                          ),
                        )
                  : Container())
            ],
          ),
        ),
      ),
    );
  }

  void uploadDailog(
      BuildContext context, String id, BookingsController controller) {
    showCupertinoDialog(
        context: context,
        builder: (BuildContext ctx) {
          return CupertinoAlertDialog(
            title: const Text('Are you sure?'),
            content: const Text('You want to delete Menu ?'),
            actions: [
              CupertinoDialogAction(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('NO'),
                isDefaultAction: true,
                isDestructiveAction: true,
              ),
              // The "No" button
              CupertinoDialogAction(
                onPressed: () {
                  Navigator.of(context).pop();
                  // controller.deleteTodyMenu(id);
                },
                child: const Text('YES'),
                isDefaultAction: false,
                isDestructiveAction: false,
              )
            ],
          );
        });
  }

  showDailog(BuildContext context) {
    return AlertDialog(
      elevation: 10,
      contentPadding: EdgeInsets.only(top: 20, bottom: 10, left: 8, right: 8),
      // backgroundColor: backgroundColor,           // Icon(Icons.close,color: Cors.lored,)
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            widget.title,
            style: Theme.of(context).textTheme.headline4!,
          ),
        ],
      ),
      actions: [
        ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
            onPressed: () {
              Get.back();
            },
            child: Text("Cancel")),
        ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
            onPressed: () {
              Get.back();
              showDialog(
                  context: context,
                  builder: (context) => showDailogPaymentmode(context),
                  barrierDismissible: false);
            },
            child: Text("Continue")),
      ],
      content: StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(
                  height: 4,
                ),
                Column(
                  children: List.generate(
                    controller.alldata.length,
                    (index) => Container(
                      color: Colors.grey.withOpacity(.2),
                      margin: EdgeInsets.only(top: 5),
                      child: ListTile(
                        dense: true,
                        title: Text(
                          controller.alldata[index]["serviceName"],
                          style: Theme.of(context).textTheme.bodyText1!,
                        ),
                        subtitle: Text(
                            "No of adult/child  ${controller.alldata[index]["noOfAdult"].toString() + " / " + controller.alldata[index]["noOfChild"]}"),
                        trailing: Text(
                          amountParser(controller.alldata[index]
                                  ["campingAmount"]
                              .toString()),
                          style: Theme.of(context).textTheme.bodyText1!,
                        ),
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Container(
                  alignment: Alignment.bottomCenter,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Container(
                        color: Colors.grey.withOpacity(.2),
                        padding: EdgeInsets.all(8),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(
                              "  Total Amount ",
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText1!
                                  .copyWith(color: Colors.tealAccent)
                                  .copyWith(
                                      fontSize: 14,
                                      fontWeight: FontWeight.w500),
                            ),
                            Text(
                              "\$ " +
                                  double.parse(controller.rxTtlAmount.value)
                                      .toStringAsFixed(2),
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyText1!
                                  .copyWith(
                                      fontSize: 17,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.amber),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  showDailogPaymentmode(BuildContext context) {
    bool _value = false;
    int val = -1;
    String? _selectedmethod = "cash";
    return AlertDialog(
      // backgroundColor: backgroundColor,
      elevation: 10,
      content: Container(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              "Select Payment Method",
              style: Theme.of(context).textTheme.headline4,
            ),
            SizedBox(
              height: 15,
            ),
            Text(
              "Amount to Pay",
              style: Theme.of(context)
                  .textTheme
                  .bodyText1!
                  .copyWith(fontSize: 16, fontWeight: FontWeight.w500),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 15,
            ),
            Text(
              "\$ " + controller.rxTtlAmount.value,
              style: Theme.of(context).textTheme.bodyText1!.copyWith(
                  color: Colors.amber,
                  fontSize: 20,
                  fontWeight: FontWeight.w500),
              textAlign: TextAlign.center,
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                    onPressed: () {
                      controller.addServiceData(
                          "CASH",
                          devoteecontroller.memberId,
                          devoteecontroller.memberName,
                          devoteecontroller.memberEmail,
                          devoteecontroller.memberPhone);
                    },
                    child: Text(" CASH ")),
                SizedBox(
                  width: 10,
                ),
                ElevatedButton(
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                    onPressed: () {
                      showDialog(
                          context: context,
                          builder: (context) => showDailogCheck());
                    },
                    child: Text("CHECK")),
              ],
            ),
            ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                onPressed: () {
                  Get.snackbar(
                      "Alert!", "Credit Card Payment Method Comming Soon.",
                      borderRadius: 2,
                      backgroundGradient: LinearGradient(
                          colors: [Colors.amber, Colors.black12]));
                },
                child: Text("CREDIT CARD")),
          ],
        ),
      ),
    );
  }

  selectAdultChildDailog(BuildContext context, ServiceDatum datum) {
    controller.etAdult.clear();
    controller.etChild.clear();
    GlobalKey<FormState> _formKey = GlobalKey();
    return AlertDialog(
      elevation: 10,
      contentPadding: EdgeInsets.only(top: 20, bottom: 10, left: 8, right: 8),
      // backgroundColor: backgroundColor,           // Icon(Icons.close,color: Cors.lored,)
      title: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            "Enter No. of adult/child " + "",
            style: Theme.of(context).textTheme.headline4!,
          ),
        ],
      ),
      actions: [
        ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
            onPressed: () {
              Get.back();
            },
            child: Text("Cancel")),
        ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                controller.alldata.add({
                  "_id": datum.id,
                  "date": datum.serviceDate!.isNotEmpty
                      ? datum.serviceDate!
                      : formatter.format(DateTime.now()),
                  "serviceImage": datum.image,
                  "serviceName": datum.refDataName,
                  "qty": "1",
                  "serviceCategory": "CAMPING",
                  "time": datum.startTime,
                  "noOfAdult": controller.etAdult.text,
                  "noOfChild": controller.etChild.text,
                  "startDate": datum.campingStartDate,
                  "endDate": datum.campingEndDate,
                  "campingAmount": datum.campingAmount.toString(),
                  "serviceAmount": datum.campingAmount.toString(),
                });
                controller.rxTtlAmount.value =
                    (double.parse(controller.rxTtlAmount.value) +
                            double.parse(datum.campingAmount.toString()))
                        .toStringAsFixed(2);
                datum.isAdd = !datum.isAdd!;
                controller.servicedata.refresh();
                Get.back();
              }
            },
            child: Text("Add")),
      ],
      content: StatefulBuilder(
        builder: (BuildContext context, StateSetter setState) {
          return SingleChildScrollView(
            child: Form(
              key: _formKey,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  SizedBox(
                    height: 4,
                  ),
                  SizedBox(
                    height: 6,
                  ),
                  Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: EditTextWidget(
                          maxLength: 200,
                          isRead: false,
                          hint: "No.of Adult",
                          isPassword: false,
                          keyboardtype: TextInputType.number,
                          label: "No.of Adult",
                          validator: (value) {
                            if (value.toString().isEmpty) {
                              return "Please Enter No.of Adult";
                            }
                            return null;
                          },
                          controller: controller.etAdult,
                          maxline: 1,
                        ),
                      ),
                      SizedBox(
                        width: 12,
                      ),
                      Expanded(
                        flex: 2,
                        child: EditTextWidget(
                          maxLength: 200,
                          isRead: false,
                          hint: "No.of child",
                          isPassword: false,
                          keyboardtype: TextInputType.number,
                          label: "No.of child",
                          validator: (value) {
                            return null;
                          },
                          controller: controller.etChild,
                          maxline: 1,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 4,
                  ),
                  Container(
                    alignment: Alignment.bottomCenter,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          color: Colors.grey.withOpacity(.2),
                          padding: EdgeInsets.all(8),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "  Total Amount ",
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText1!
                                    .copyWith(color: Colors.tealAccent)
                                    .copyWith(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w500),
                              ),
                              Text(
                                amountParser(datum.campingAmount.toString()),
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyText1!
                                    .copyWith(
                                        fontSize: 17,
                                        fontWeight: FontWeight.w600,
                                        color: Colors.amber),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  showDailogCheck() {
    controller.etAmount.text = controller.rxTtlAmount.value;
    final GlobalKey<FormState> formKey = GlobalKey<FormState>();
    return AlertDialog(content: StatefulBuilder(
      builder: (BuildContext context, StateSetter setState) {
        return SingleChildScrollView(
            scrollDirection: Axis.vertical,
            child: Form(
              key: formKey,
              child: Column(
                children: [
                  Text("Check Details",
                      style: Theme.of(context).textTheme.headline4!),
                  SizedBox(
                    height: 20,
                  ),
                  EditTextWidget(
                    maxLength: 200,
                    hint: "Check Number",
                    isPassword: false,
                    keyboardtype: TextInputType.text,
                    label: "Check Number",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please Enter Check Number';
                      }
                      return null;
                    },
                    controller: controller.etCheckNo,
                    maxline: 1,
                  ),
                  EditTextWidget(
                    maxLength: 200,
                    hint: "Check Amount",
                    isPassword: false,
                    keyboardtype: TextInputType.number,
                    label: "Check Amount",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please Enter Amount';
                      }
                      return null;
                    },
                    isRead: true,
                    controller: controller.etAmount,
                    maxline: 1,
                  ),
                  EditTextWidget(
                    maxLength: 200,
                    hint: "Bank Detail",
                    isPassword: false,
                    keyboardtype: TextInputType.text,
                    label: "Bank Detail",
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please Enter Bank Detail';
                      }
                      return null;
                    },
                    controller: controller.etBankDetails,
                    maxline: 1,
                  ),
                  SizedBox(
                    child: InkWell(
                      onTap: () async {
                        final DateTime? picked = await showDatePicker(
                            context: context,
                            initialDate: DateTime.now(),
                            firstDate: DateTime(2015),
                            lastDate: DateTime(2100),
                            builder: (context, child) {
                              return Theme(
                                data: ThemeData.dark().copyWith(
                                    colorScheme: const ColorScheme.dark(
                                        onPrimary: Colors.white,
                                        // selected text color
                                        onSurface: Colors.white,
                                        // default text color
                                        primary: Colors.teal // circle color
                                        ),
                                    dialogBackgroundColor:
                                        Theme.of(context).backgroundColor,
                                    textButtonTheme: TextButtonThemeData(
                                        style: TextButton.styleFrom(
                                            textStyle: const TextStyle(
                                                color: Colors.white,
                                                fontWeight: FontWeight.normal,
                                                fontSize: 12,
                                                fontFamily: 'Quicksand'),
                                            primary: Colors.white,
                                            // color of button's letters
                                            backgroundColor: Colors.black54,
                                            // Background color
                                            shape: RoundedRectangleBorder(
                                                side: const BorderSide(
                                                    color: Colors.transparent,
                                                    width: 1,
                                                    style: BorderStyle.solid),
                                                borderRadius:
                                                    BorderRadius.circular(
                                                        50))))),
                                child: child!,
                              );
                            });

                        final String formatted = formatter.format(picked!);
                        controller.etDate.text = formatted;
                      },
                      child: AbsorbPointer(
                        child: EditTextWidget(
                          maxLength: 200,
                          hint: "Date",
                          isPassword: false,
                          keyboardtype: TextInputType.text,
                          label: "Date",
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please Select  Date';
                            }
                            return null;
                          },
                          controller: controller.etDate,
                          maxline: 1,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      ButtonWidget(
                        btnName: 'Cancel',
                        onPress: () {
                          Navigator.of(context).pop();
                        },
                        minWidth: 100,
                      ),
                      ButtonWidget(
                        btnName: 'Proceed',
                        onPress: () {
                          if (formKey.currentState!.validate()) {
                            controller.addServiceData(
                                "CHECK",
                                devoteecontroller.memberId,
                                devoteecontroller.memberName,
                                devoteecontroller.memberEmail,
                                devoteecontroller.memberPhone);
                          }
                        },
                        minWidth: 100,
                      ),
                    ],
                  ),
                ],
              ),
            ));
      },
    ));
  }

  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
    final format = DateFormat.jm(); // YOUR DATE GOES HERE
    return format.format(dt);
  }
}
