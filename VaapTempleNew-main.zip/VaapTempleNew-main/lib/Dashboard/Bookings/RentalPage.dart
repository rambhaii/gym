
import 'package:aspgen_mobile/Dashboard/Bookings/AddBookingPage.dart';
import 'package:aspgen_mobile/Dashboard/Bookings/AddRentalBookingPage.dart';
import 'package:aspgen_mobile/Dashboard/Bookings/controller/rental_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinbox/flutter_spinbox.dart';

import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../AppConstant/TextStyle.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/ButtonWidget.dart';
import '../../../Widget/EditextWidget.dart';
import '../../../Widget/SearchBarWidget.dart';
import '../../Widget/LabaleListWidget.dart';
import '../Donations/Model/make_donation.dart';
import 'DevoteeLoginNew.dart';
import 'controller/controller.dart';




class RentalBookingPage extends StatefulWidget {
  final String title;
  final String displayName;
  final String type;
  const RentalBookingPage({Key? key, required this.title, required this.displayName, required this.type}) : super(key: key);

  @override
  _RentalBookingPageState createState() => _RentalBookingPageState();
}

class _RentalBookingPageState extends State<RentalBookingPage> {
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  late RentalController _controller;
  DateTime?tempDate;
  @override
  void initState() {
    _controller=  Get.put(RentalController(widget.title,widget.type));
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Rental Bookings",
        ),
        actions: [
          IconButton(onPressed: (){
            _controller.isSearch.value=!_controller.isSearch.value;
          }, icon: Icon(Icons.search),constraints: BoxConstraints(maxWidth: 30,maxHeight: 30),),
          Padding(
            padding: const EdgeInsets.only(right: 8.0,left: 8),
            child: RawMaterialButton(onPressed: (){
              CheckInternetConnection().then((value1) => value1==true?Get.to(()=>DevoteeLoginNewPage(flag: 2,)):"");

            }
              ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          )
        ],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),

        child: Column(
          children: [
            Obx(() =>SizedBox(height: _controller.isSearch.value?8:0),),
            Obx(() =>_controller.isSearch.value? GetBuilder<RentalController>(
                builder: (controller)=>  SearchBarWidget(
                  hint: "Search",
                  controller: controller.etSearch,
                  onchange: (value){
                    controller.filterBookingData(controller.etSearch.text);
                    //value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi(controller.bodyJson):"";
                    controller.update();
                  },
                  onCancel: (){
                    controller.etSearch.clear();
                    controller.filterBookingData(controller.etSearch.text);
                    controller.update();
                  },
                ),
              ):Container(),
            ),
            SizedBox(height: 6,),
            Obx(()=> _controller.bookingdata.value!=null?_controller.bookingdata.isNotEmpty?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {

                  });
                },
                child: ListView.builder(
                    itemCount:_controller.bookingdata.value.length,
                    itemBuilder: (context,index)
                    {
                      final datum=_controller.bookingdata.value[index];
                      return LableListShowOnlyWidget(
                        title: datum.serviceSetup??"",
                        titlelable: "Rental Name",subTitleLable: "Token No.",subTitle2Lable: "Booking Date",
                        subTitle:"# "+datum.tokenNumber!.toString(),
                        subTitle2:dateParser(datum.serviceDate!.toString()),
                        subTitle3:datum.statusName!.toString(),
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              Row(
                                children: [
                                  Expanded(flex:6,child: viewMore("Event Name  ",datum.eventDetail!.eventName!),

                                  ),
                                  Expanded(flex:2,child:Padding(
                                    padding: const EdgeInsets.only(right: 0.0,left: 0),
                                    child: RawMaterialButton(onPressed: (){
                                      uploadDailog(context,datum.id!);
                                    }
                                      ,child: Icon(Icons.clear),fillColor: Colors.red,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 35.0, minHeight: 35.0),),
                                  )

                                  ),
                                ],
                              ) ,
                              Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              Row(
                                children: [
                                  Expanded(flex: 2,child: viewMore("From Date  ",dateParser(datum.eventDetail!.eventDate!.toString()))),
                                  Expanded(flex: 2,child: viewMore("To Date  ",dateParser(datum.eventDetail!.eventEndDate!))),
                                ],
                              ),
                              Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              viewMore("Customer Name  ",datum.customerName!.toString()) ,
                              Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              viewMore("Phone ",phoneFormatter(datum.customerPhone!).toString()),
                              Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              viewMore("Email ",UtilMethods.decrypt(datum.customerEmail!.toString())),
                              Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              Row(
                                children: [
                                  Expanded(flex: 2,child: viewMore("Payment Status  ",datum.paymentStatus!.toString())),
                                  Expanded(flex: 2,child: viewMore("Amount  ",amountParser(datum.serviceAmount!.toString()))),
                                ],
                              ),
                            ]),
                        textEditingController: _controller.etSearch,
                        isClicked: datum.isChecked!??false,
                        onTapVieMore: (){
                          datum.isChecked=!datum.isChecked!;
                          _controller.bookingdata.refresh();
                        },
                        icon: Icons.paypal_rounded,
                        iconColor: Colors.green,
                        editOnTap: (){
                          CheckInternetConnection().then((value) {
                            if(value==true)
                            {
                              // showDialog(context: context, builder: (context)=>showDailog(datum),
                              //     barrierDismissible:false
                              // );

                            }
                          });
                        },
                      );

                    }),
              ),
            ):
            Center(
              child: Text(_controller.etSearch.text.isNotEmpty?"We couldn't find any Bookings\nmatching '${_controller.etSearch.text}'  ":"",style: Theme.of(context).textTheme.bodyText1,textAlign: TextAlign.center,),
            )
                :Container(),
            )
          ],
        ),
      ),
    );
  }
  void uploadDailog(BuildContext context,String id) {
    showCupertinoDialog(
        context: context,
        builder: (BuildContext ctx) {
          return CupertinoAlertDialog(
            title: const Text('Are you sure?'),
            content: const Text('You want to cancel  Rental Booking ?'),
            actions: [
              CupertinoDialogAction(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                child: const Text('NO'),
                isDefaultAction: true,
                isDestructiveAction: true,
              ),
              // The "No" button
              CupertinoDialogAction(
                onPressed: () {
                  Navigator.of(context).pop();
                 _controller.UpdateStatus(id);
                },
                child: const Text('YES'),
                isDefaultAction: false,
                isDestructiveAction: false,
              )
            ],
          );
        });
  }
}
