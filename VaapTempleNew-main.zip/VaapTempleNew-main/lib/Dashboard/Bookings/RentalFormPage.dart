import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Request/conroller/RequestFormController.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/DropdownButtonWidget.dart';
import '../../../Widget/EditextWidget.dart';
import 'AddRentalBookingPage.dart';
import 'controller/DevoteeController.dart';
import 'controller/rental_controller.dart';


class RentalFormPage extends StatefulWidget {

  RentalFormPage({Key? key}) : super(key: key);

  @override
  State<RentalFormPage> createState() => _RentalFormPageState();
}

class _RentalFormPageState extends State<RentalFormPage> {
  RentalController _controller=Get.find();
  DevoteeController _devoteecontroller=Get.find();

  final GlobalKey expansionTile = new GlobalKey();
  final GlobalKey<FormState> _formKey =  GlobalKey<FormState>();

  @override
  void initState() {

    super.initState();
  }

  @override
  Widget build(BuildContext context) {

    TextStyle title=Theme.of(context).textTheme.bodyText1!;
    TextStyle subTitle=Theme.of(context).textTheme.bodyText2!;
    BoxDecoration decoration=BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.1),width: 0.4)),
        color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.3));
    return Scaffold(
      appBar:  AppBar(

        title: Text("Rental Details "),
        actions: [
          RawMaterialButton(
            onPressed: () {
              if(_formKey.currentState!.validate())
                {
                  Get.to(()=>AddRentalBookingPage(title: 'Rental Bookings',) );
                }
              else{
                _controller.isExpend2.value=true;
                _controller.isSelected.value=2;
              }

            },
            child: Icon(Icons.arrow_forward),
            fillColor: Colors.green,
            shape: CircleBorder(),
            elevation: 5,
            constraints: BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          SizedBox(width: 8,)
        ],
      ),
      body: SingleChildScrollView(
        child: Container(

          child: Obx(()=> ListView(
              shrinkWrap: true,
              physics: NeverScrollableScrollPhysics(),
              key: Key('builder ${_controller.isSelected.value.toString()}'),
              children:[SizedBox(height: 8,),
                Obx(()=>Container(
                  margin: EdgeInsets.only(top:15,left: 5,right: 5),
                  decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend1.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                  child: ListTileTheme(
                    dense: true,
                    horizontalTitleGap: 15.0,
                    minLeadingWidth: 0,
                    child: ExpansionTile(
                        key: Key("0"),
                        collapsedTextColor: Colors.tealAccent,
                        textColor: Colors.tealAccent,
                        childrenPadding: EdgeInsets.only(left: 10,right: 10),
                        onExpansionChanged: (value){
                          _controller.isExpend1.value=value;
                          _controller.isExpend2.value=false;
                          _controller.isExpend3.value=false;
                          _controller.isSelected.value=0;
                        },
                        initiallyExpanded: _controller.isExpend1.value,
                        title: Text("Devotee Info",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                        children:<Widget>
                        [
                          Column(
                            children: [
                              SizedBox(height: 12,),
                              EditTextWidget(
                                maxLength: 200,
                                hint: "Enter Name",
                                isPassword: false,
                                isRead: true,
                                keyboardtype: TextInputType.text,
                                label:"Devotee Name",
                                formatter:[],
                                validator: (value) {

                                  return null;
                                },
                                controller: TextEditingController(text:_devoteecontroller.memberName),
                                maxline: 1,
                              ),
                              SizedBox(height: 6,),
                              EditTextWidget(
                                maxLength: 200,
                                hint: " Email",
                                isPassword: false,
                                isRead: true,
                                keyboardtype: TextInputType.text,
                                label:"Devotee Email",
                                formatter:[],
                                validator: (value) {


                                  return null;
                                },
                                controller: TextEditingController(text:(UtilMethods.decrypt(_devoteecontroller.memberEmail))),
                                maxline: 1,
                              ),


                              SizedBox(height: 6,),

                              EditTextWidget(
                                maxLength: 200,
                                hint: " Phone",
                                isPassword: false,
                                keyboardtype: TextInputType.text,
                                label:"Devotee Phone  ",
                                formatter:[],
                                isRead: true,
                                validator: (value) {

                                  return null;
                                },
                                controller: TextEditingController(text:(phoneFormatter(_devoteecontroller.memberPhone))),
                                maxline: 1,
                              ),
                              SizedBox(height: 6,),







                              Row(
                                children: [
                                  Expanded(
                                    flex: 4,
                                    child:       EditTextWidget(
                                      maxLength: 200,
                                      hint: "Enter State",
                                      isPassword: false,
                                      keyboardtype: TextInputType.text,
                                      label:"State",
                                      formatter:[],
                                      isRead: true,
                                      validator: (value) {


                                        return null;
                                      },
                                      controller: (TextEditingController(text:_devoteecontroller.memberState)),
                                      maxline: 1,
                                    ),
                                  ),


                                  SizedBox(width: 10,),
                                  Expanded(
                                    flex: 4,
                                    child:  EditTextWidget(
                                      maxLength: 6,
                                      hint: "Enter Zip",
                                      isPassword: false,
                                      keyboardtype: TextInputType.number,
                                      label:"Zip",
                                      isRead: true,
                                      formatter:[],
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please Enter Zip';
                                        }

                                        return null;
                                      },
                                      controller: TextEditingController(text:_devoteecontroller.memberZip),
                                      maxline: 1,
                                    ),
                                  ),


                                ],
                              ),

                              SizedBox(height: 6,),
                              EditTextWidget(
                                maxLength: 200,
                                hint: "Enter City",
                                isPassword: false,
                                isRead: true,
                                keyboardtype: TextInputType.text,
                                label:"City",
                                formatter:[],
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter City';
                                  }

                                  return null;
                                },
                                controller: TextEditingController(text:_devoteecontroller.memberCity),
                                maxline: 1,
                              ),
                              SizedBox(height: 6,),
                              EditTextWidget(
                                maxLength: 2000,
                                hint: "Enter Address",
                                isPassword: false,
                                isRead: true,
                                keyboardtype: TextInputType.text,
                                label:"Address",
                                formatter:[],
                                validator: (value) {
                                  return null;
                                },
                                controller: TextEditingController(text:_devoteecontroller.memberAddress),
                                maxline: 1,
                              ),

                            ],
                          ),

                          SizedBox(height: 6,),

                        ]
                    ),
                  ),
                ),
                ),



                Obx(()=> Container(
                  margin: EdgeInsets.only(top:15,left: 5,right: 5),
                  decoration:decoration.copyWith(border: Border.all(color:!_controller.isExpend2.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Color(0xEBFF448D),)),
                  child: ListTileTheme(
                    dense: true,
                    horizontalTitleGap: 15.0,
                    minLeadingWidth: 0,
                    child: ExpansionTile(
                        maintainState: true,
                        collapsedTextColor: Color(0xEBFF448D),
                        textColor:Color(0xEBFF448D),
                        childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                        onExpansionChanged: (value){
                          _controller.isExpend2.value=value;
                          _controller.isExpend1.value=false;
                          _controller.isExpend3.value=false;
                          _controller.isExpend4.value=false;
                          _controller.isSelected.value=1;
                        },
                        initiallyExpanded: _controller.isExpend2.value,
                        key: Key("1"),
                        title: Text("Rental Details",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                        children:<Widget>
                        [
                          Form(
                            key: _formKey,
                            child: Column(
                              children: [
                                SizedBox(height: 6,),
                                EditTextWidget(
                                  maxLength: 2000,
                                  hint: "Enter Event  Name",
                                  isPassword: false,
                                  keyboardtype: TextInputType.text,
                                  label:"Event Name",
                                  formatter:[],
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please Enter Event Name';
                                    }

                                    return null;
                                  },
                                  controller: _controller.etEvent,
                                  maxline: 1,
                                ),

                                SizedBox(height:6,),
                                Row(
                                  children: [
                                    Expanded(
                                      flex:2,
                                      child: GestureDetector(
                                        onTap: ()async{
                                          _controller.startPickedDate= await  showDatePicker(
                                              context: context,
                                              initialDate:DateTime.now(),
                                              firstDate: DateTime.now(),
                                              lastDate: DateTime(2100),
                                              builder: (context, child) {
                                                return Theme(
                                                  data: ThemeData.dark().copyWith(
                                                      colorScheme: const ColorScheme.dark(
                                                          onPrimary: Colors.white,
                                                          // selected text color
                                                          onSurface: Colors.white,
                                                          // default text color
                                                          primary: Colors
                                                              .teal // circle color
                                                      ),
                                                      dialogBackgroundColor: Theme
                                                          .of(context)
                                                          .backgroundColor,

                                                      textButtonTheme: TextButtonThemeData(
                                                          style: TextButton.styleFrom(
                                                              textStyle: const TextStyle(
                                                                  color: Colors.white,
                                                                  fontWeight: FontWeight
                                                                      .normal,
                                                                  fontSize: 12,
                                                                  fontFamily: 'Quicksand'),
                                                              primary: Colors.white,
                                                              // color of button's letters
                                                              backgroundColor: Colors
                                                                  .black54,
                                                              // Background color
                                                              shape: RoundedRectangleBorder(
                                                                  side: const BorderSide(
                                                                      color: Colors
                                                                          .transparent,
                                                                      width: 1,
                                                                      style: BorderStyle
                                                                          .solid),
                                                                  borderRadius: BorderRadius
                                                                      .circular(50))))),

                                                  child: child!,
                                                );
                                              }

                                          );

                                          final String formatted = _controller.formatter.format(_controller.startPickedDate!);
                                          _controller.etEndDate.clear();
                                          _controller.etStartDate.text=formatted;

                                        },
                                        child: AbsorbPointer(
                                          child: EditTextWidget(
                                            label: "Start Date",
                                            controller: _controller.etStartDate,
                                            hint: 'Start Date',
                                            validator: (value) {
                                              if (value == null || value.isEmpty) {
                                                return 'Please Select Date';
                                              }
                                              return null;
                                            },
                                            maxLength: 60,
                                            keyboardtype: TextInputType.text,
                                            isPassword: false,
                                          ),
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 8,),
                                    Expanded(
                                      flex: 2,
                                      child: GestureDetector(
                                        onTap: ()async{
                                          _controller.endPickedDate= await  showDatePicker(
                                              context: context,
                                              initialDate:_controller.startPickedDate?? DateTime.now(),
                                              firstDate: DateTime.now(),
                                              lastDate: DateTime(2100),
                                              builder: (context, child) {
                                                return Theme(
                                                  data: ThemeData.dark().copyWith(
                                                      colorScheme: const ColorScheme.dark(
                                                          onPrimary: Colors.white,
                                                          // selected text color
                                                          onSurface: Colors.white,
                                                          // default text color
                                                          primary: Colors
                                                              .teal // circle color
                                                      ),
                                                      dialogBackgroundColor: Theme
                                                          .of(context)
                                                          .backgroundColor,

                                                      textButtonTheme: TextButtonThemeData(
                                                          style: TextButton.styleFrom(
                                                              textStyle: const TextStyle(
                                                                  color: Colors.white,
                                                                  fontWeight: FontWeight
                                                                      .normal,
                                                                  fontSize: 12,
                                                                  fontFamily: 'Quicksand'),
                                                              primary: Colors.white,
                                                              // color of button's letters
                                                              backgroundColor: Colors
                                                                  .black54,
                                                              // Background color
                                                              shape: RoundedRectangleBorder(
                                                                  side: const BorderSide(
                                                                      color: Colors
                                                                          .transparent,
                                                                      width: 1,
                                                                      style: BorderStyle
                                                                          .solid),
                                                                  borderRadius: BorderRadius
                                                                      .circular(50))))),

                                                  child: child!,
                                                );
                                              }

                                          );
                                          if(_controller.startPickedDate!=null)
                                          {
                                            if(_controller.startPickedDate!.isBefore(_controller.endPickedDate!))
                                            {
                                              final String formatted = _controller.formatter.format(_controller.endPickedDate!);
                                              _controller.etEndDate.text=formatted;
                                            }
                                            else{
                                              _controller.etEndDate.clear();
                                              Fluttertoast.showToast(msg:"End date must be after startDate");
                                            }

                                          }

                                        },
                                        child: AbsorbPointer(
                                          child: EditTextWidget(
                                            label: "End Date",
                                            controller: _controller.etEndDate,
                                            hint: 'End Date',
                                            validator: (value) {
                                              return null;
                                            },
                                            maxLength: 60,
                                            keyboardtype: TextInputType.text,
                                            isPassword: false,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 6,),
                                Row(
                                  children: [
                                    Expanded(child:  GestureDetector(
                                      onTap: ()async{
                                        TimeOfDay? time = await showTimePicker(
                                            context: context,
                                            initialTime: TimeOfDay.now(),
                                            builder: (context, child) {
                                              return Theme(
                                                data: ThemeData.dark().copyWith(
                                                    colorScheme: const ColorScheme.dark(
                                                        onPrimary: Colors.white,
                                                        onSurface: Colors.white,
                                                        primary: Colors.teal // circle color
                                                    ),
                                                    dialogBackgroundColor: Theme
                                                        .of(context)
                                                        .backgroundColor,

                                                    textButtonTheme: TextButtonThemeData(
                                                        style: TextButton.styleFrom(
                                                            textStyle: const TextStyle(
                                                                color: Colors.white,
                                                                fontWeight: FontWeight
                                                                    .normal,
                                                                fontSize: 12,
                                                                fontFamily: 'Quicksand'),
                                                            primary: Colors.white,
                                                            backgroundColor: Colors.black54,
                                                            shape: RoundedRectangleBorder(
                                                                side: const BorderSide(
                                                                    color: Colors
                                                                        .transparent,
                                                                    width: 1,
                                                                    style: BorderStyle
                                                                        .solid),
                                                                borderRadius: BorderRadius
                                                                    .circular(50))))),
                                                child: child!,
                                              );
                                            }
                                        );
                                        if(time!=null)
                                        {
                                          _controller.etStartTime.text=formatTimeOfDay(time!);

                                        }
                                      },
                                      child: AbsorbPointer(
                                        child: EditTextWidget(
                                          label: "Start Time",
                                          controller: _controller.etStartTime,
                                          hint: 'Start Time',
                                          isRead: true,
                                          validator: (value) {

                                          },
                                          maxLength: 60,
                                          keyboardtype: TextInputType.text,
                                          isPassword: false,
                                        ),
                                      ),
                                    ),),
                                    SizedBox(width: 10,),
                                    Expanded(child:  GestureDetector(
                                      behavior: HitTestBehavior.translucent,
                                      onTap: ()async{
                                        TimeOfDay? time = await showTimePicker(
                                            context: context,
                                            initialTime: TimeOfDay.now(),
                                            builder: (context, child) {
                                              return Theme(
                                                data: ThemeData.dark().copyWith(
                                                    colorScheme: const ColorScheme.dark(
                                                        onPrimary: Colors.white,
                                                        onSurface: Colors.white,
                                                        primary: Colors.teal // circle color
                                                    ),
                                                    dialogBackgroundColor: Theme
                                                        .of(context)
                                                        .backgroundColor,

                                                    textButtonTheme: TextButtonThemeData(
                                                        style: TextButton.styleFrom(
                                                            textStyle: const TextStyle(
                                                                color: Colors.white,
                                                                fontWeight: FontWeight
                                                                    .normal,
                                                                fontSize: 12,
                                                                fontFamily: 'Quicksand'),
                                                            primary: Colors.white,
                                                            // color of button's letters
                                                            backgroundColor: Colors
                                                                .black54,
                                                            // Background color
                                                            shape: RoundedRectangleBorder(
                                                                side: const BorderSide(
                                                                    color: Colors
                                                                        .transparent,
                                                                    width: 1,
                                                                    style: BorderStyle
                                                                        .solid),
                                                                borderRadius: BorderRadius
                                                                    .circular(50))))),
                                                child: child!,
                                              );
                                            }
                                        );
                                        if(time!=null)
                                        {
                                          _controller.etEndTime.text=formatTimeOfDay(time);
                                        }
                                      },
                                      child: AbsorbPointer(
                                        child: EditTextWidget(
                                          label: "End Time",
                                          controller: _controller.etEndTime,
                                          hint: 'End Time',
                                          isRead: true,
                                          validator: (value) {

                                          },
                                          maxLength: 60,
                                          keyboardtype: TextInputType.text,
                                          isPassword: false,
                                        ),
                                      ),
                                    ),
                                    ),
                                  ],
                                ),

                                Obx(() => CheckboxListTile(
                                    controlAffinity: ListTileControlAffinity.leading,
                                      title: Text("Same As Home Address",style: Theme.of(context).textTheme.bodyText1!.copyWith(color:Colors.green )),
                                      value: _controller.isSameAddress.value, onChanged: (value){
                                  _controller.isSameAddress.value=value!;
                                  if(_controller.isSameAddress.value)
                                    {
                                      _controller.etEventAddress.text=_devoteecontroller.memberAddress;
                                    }
                                  else
                                    {
                                      _controller.etEventAddress.text="";
                                    }

                                  }),
                                ),
                                SizedBox(height:6,),
                                EditTextWidget(
                                  maxLength: 2000,
                                  hint: "Enter Address",
                                  isPassword: false,
                                  keyboardtype: TextInputType.text,
                                  label:" Address",
                                  formatter:[],
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please Enter Address';
                                    }

                                    return null;
                                  },
                                  controller: _controller.etEventAddress,
                                  maxline: 1,
                                ),

                                SizedBox(height:6,),
                                EditTextWidget(
                                  maxLength: 2000,
                                  hint: "Enter Notes",
                                  isPassword: false,
                                  keyboardtype: TextInputType.text,
                                  label:" Notes",
                                  formatter:[],
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please Enter Notes';
                                    }

                                    return null;
                                  },
                                  isCounter: true,
                                  controller: _controller.etNotes,
                                  maxline: 5,
                                ),

                                SizedBox(height:6,),

                              ],
                            ),
                          ),


                        ]
                    ),
                  ),
                ),
                ),


                SizedBox(height: 15,),
              ]
          ),
          ),
        ),
      ),
    );
  }
  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
    final format = DateFormat.jm(); // YOUR DATE GOES HERE
    return format.format(dt);
  }
}
