
import 'package:aspgen_mobile/Dashboard/Bookings/AddBookingPage.dart';
import 'package:aspgen_mobile/Dashboard/Bookings/DevoteeLoginNew.dart';
import 'package:aspgen_mobile/Dashboard/Bookings/controller/rental_controller.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinbox/flutter_spinbox.dart';

import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';

import '../../../AppConstant/TextStyle.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/ButtonWidget.dart';
import '../../../Widget/EditextWidget.dart';
import '../../../Widget/SearchBarWidget.dart';
import '../../Widget/LabaleListWidget.dart';
import '../Donations/Model/make_donation.dart';
import 'AddCompingBookingPage.dart';
import 'controller/camping_controller.dart';
import 'controller/controller.dart';




class CampingBookingPage extends StatefulWidget {
  final String title;
  final String displayName;
  final String type;
  const CampingBookingPage({Key? key, required this.title, required this.displayName, required this.type}) : super(key: key);

  @override
  _CampingBookingPageState createState() => _CampingBookingPageState();
}

class _CampingBookingPageState extends State<CampingBookingPage> {
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  late CompingController _controller;
  DateTime?tempDate;
  @override
  void initState() {
    _controller=  Get.put(CompingController(widget.title,widget.type));
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Camp Bookings",
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: RawMaterialButton(onPressed: (){
              CheckInternetConnection().then((value1) => value1==true?Get.to(()=>DevoteeLoginNewPage(flag: 3,)):"");
              }
              ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          )
        ],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),

        child: Column(
          children: [
            SizedBox(height: 8,),
            GetBuilder<CompingController>(
              builder: (controller)=>  SearchBarWidget(
                hint: "Search",
                controller: controller.etSearch,
                onchange: (value){
                  controller.filterBookingData(controller.etSearch.text);
                  //value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi(controller.bodyJson):"";
                  controller.update();
                },
                onCancel: (){
                  controller.etSearch.clear();
                  controller.filterBookingData(controller.etSearch.text);
                  controller.update();
                },
              ),
            ),
            SizedBox(height: 8,),
        Obx(()=> _controller.bookingdata.value!=null?_controller.bookingdata.isNotEmpty?Expanded(
          child: RefreshIndicator(
            semanticsLabel: "Refresh",
            onRefresh: (){
              return Future.delayed(Duration.zero, () {

              });
            },
            child: ListView.builder(
                itemCount:_controller.bookingdata.value.length,
                itemBuilder: (context,index)
                {
                  final datum=_controller.bookingdata.value[index];
                  return LableListShowOnlyWidget(
                    title: datum.serviceSetup??"",
                    titlelable: "Camp Name",subTitleLable: "Amount",subTitle2Lable: "Booking Date",
                    subTitle:amountParser(datum.serviceAmount!.toString()),
                    subTitle2:dateParser(datum.serviceDate!.toString()),
                    subTitle3:datum.statusName!.toString(),
                    viewMoreWidget: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children:[
                          Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          Row(
                            children: [
                              Expanded(flex: 2,child: viewMore("Payment Status  ",datum.paymentStatus!.toString())),
                              Expanded(flex: 2,child: viewMore("Token No  ",datum.tokenNumber!.toString())),
                            ],
                          ),
                          Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          viewMore("Customer Name  ",datum.customerName!.toString()) ,
                          Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          viewMore("Phone ",phoneFormatter(datum.customerPhone!).toString()),
                          Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                          viewMore("Email ",UtilMethods.decrypt(datum.customerEmail!.toString()))
                        ]),
                    textEditingController: _controller.etSearch,
                    isClicked: datum.isChecked!??false,
                    onTapVieMore: (){
                      datum.isChecked=!datum.isChecked!;
                      _controller.bookingdata.refresh();
                    },
                    icon: Icons.paypal_rounded,
                    iconColor: Colors.green,
                    editOnTap: (){
                      CheckInternetConnection().then((value) {
                        if(value==true)
                        {
                          // showDialog(context: context, builder: (context)=>showDailog(datum),
                          //     barrierDismissible:false
                          // );

                        }
                      });
                    },
                  );

                }),
          ),
        ):
            Center(
              child: Text(_controller.etSearch.text.isNotEmpty?"We couldn't find any Bookings\nmatching '${_controller.etSearch.text}'  ":"",style: Theme.of(context).textTheme.bodyText1,textAlign: TextAlign.center,),
            )
                :Container(),
            )
          ],
        ),
      ),
    );
  }

}
