import 'dart:convert';

import 'package:country_pickers/country.dart';
import 'package:country_pickers/country_picker_dropdown.dart';
import 'package:country_pickers/utils/utils.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';

import '../../AppConstant/AppColors.dart';
import '../../AppConstant/TextStyle.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/EditextWidget.dart';
import '../../Widget/primary_button.dart';
import 'controller/DevoteeController.dart';

class DevoteeLoginNewPage extends StatefulWidget {
  final int flag;
  DevoteeLoginNewPage({required this.flag}):super();
  @override
  _DevoteeLoginNewPageState createState() => _DevoteeLoginNewPageState();
}

class _DevoteeLoginNewPageState extends State<DevoteeLoginNewPage> {
  bool passwordVisible = false;
  bool loader = false;

  String countryCode = "1";
  final GlobalKey<FormState> _formKey=GlobalKey<FormState>();
  TextEditingController etuserName = new TextEditingController();
  TextEditingController etPasswordName = new TextEditingController();
  TextEditingController etphone = new TextEditingController();

  DevoteeController devoteeController=Get.put(DevoteeController());
  @override
  void initState() {

    super.initState();
  }



  void togglePassword() {
    setState(() {
      passwordVisible = !passwordVisible;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(title: Text("Devotee Login"),),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Padding(
            padding: EdgeInsets.fromLTRB(10.0, 40.0, 10.0, 0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.max,
              children: [
                SizedBox(height: 20,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    //AndroidInitializationSettings('@mipmap/ic_launcher');
                    Image.asset(
                      "assets/images/templelogo.png",
                      width: 130,
                      height: 120,
                    ),
                  ],
                ),
                SizedBox(height: 30,),
                // Center(
                //   child: Text(
                //     'Sign in',
                //     style: heading7.copyWith(color: Theme
                //         .of(context)
                //         .colorScheme
                //         .primary),
                //   ),
                // ),
                SizedBox(
                  height: 30,
                ),
                Form(
                  key: _formKey,
                  child: AutofillGroup(
                    child: Column(
                      children: [
                        Container(
                          margin: EdgeInsets.only(left:5 ,right: 5),
                          padding: EdgeInsets.only(left: 10, right: 10),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: AppColor.primaryBlue,
                            ),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          child: TextFormField(
                            autofillHints: [AutofillHints.newUsername],
                            onChanged: (value){
                              etphone.clear();
                            }, style: heading5.copyWith(color: Theme.of(context).colorScheme.primary),
                            controller: etuserName,
                            decoration: InputDecoration(
                              contentPadding:
                              EdgeInsets.only(left: 2, bottom: 17, top: 17, right: 2),
                              hintText: 'Email Id',
                              hintStyle: heading5.copyWith(color: Colors.grey),
                              border: OutlineInputBorder(borderSide: BorderSide.none,),),),),
                        SizedBox(
                          height: 15,
                        ),

                        Text(" ------ OR ------ "),

                        SizedBox(
                          height: 15,
                        ),


                        Container(
                          margin: EdgeInsets.only(left:5 ,right: 5),
                          padding: EdgeInsets.only(left: 10,right: 10),
                          decoration: BoxDecoration(
                            border: Border.all(
                              color: AppColor.primaryBlue,
                            ),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          child: Row(
                            children: [
                              SizedBox(
                                width: MediaQuery
                                    .of(context)
                                    .size
                                    .width * 0.3,
                                child: CountryPickerDropdown(
                                  initialValue: 'US',
                                  itemBuilder: _buildDropdownItem,
                                  itemFilter: (c) =>
                                      [
                                        'US',
                                        'IN',
                                        'UK',
                                        'CN',
                                        'AU',
                                        'UK',
                                        "CA"
                                      ].contains(c.isoCode),
                                  dropdownColor: Theme.of(context).colorScheme.secondary,
                                  priorityList: [
                                    CountryPickerUtils.getCountryByIsoCode(
                                        'US'),
                                    CountryPickerUtils.getCountryByIsoCode(
                                        'IN'),
                                  ],
                                  sortComparator: (Country a, Country b) =>
                                      a.isoCode.compareTo(b.isoCode),
                                  onValuePicked: (Country country) {
                                    setState(() {
                                      countryCode = country.phoneCode;
                                    });
                                    print("${country.phoneCode}");
                                  },
                                ),
                              ),
                              Expanded(
                                  child: SizedBox(
                                      width:
                                      MediaQuery
                                          .of(context)
                                          .size
                                          .width / 3,
                                      child: TextFormField(
                                        inputFormatters: [maskFormatter],
                                        style: heading5.copyWith(color: Theme
                                            .of(context)
                                            .colorScheme
                                            .primary),
                                        onChanged: (value){
                                          etuserName.clear();
                                          etPasswordName.clear();
                                        },
                                        //obscureText: !passwordVisible,
                                        // maxLength: 12,
                                        controller: etphone,
                                        decoration: InputDecoration(
                                          contentPadding:
                                          EdgeInsets.only(left: 2, bottom: 17, top: 17, right: 2),
                                          hintText: 'Mobile No',
                                          hintStyle: heading5.copyWith(
                                              color: Colors.grey),
                                          suffixIcon: IconButton(
                                            onPressed: () =>
                                                etphone.clear(),
                                            icon: Icon(Icons.clear),
                                          ),
                                          border: OutlineInputBorder(
                                            borderSide: BorderSide.none,
                                          ),
                                        ),
                                      ))),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                SizedBox(
                  height: 25,
                ),
                loader
                    ? Center(
                  child: CircularProgressIndicator(),
                )
                    :
                Container(
                    height: 45,
                    margin: EdgeInsets.only(left:5 ,right: 5),
                    child: CustomPrimaryButton(
                        buttonColor: AppColor.primaryColor,
                        textValue: 'Continue',
                        textColor: Theme
                            .of(context)
                            .colorScheme
                            .primary
                            .withOpacity(0.9),
                        username: etuserName.text,
                        password: etPasswordName.text,
                        press: () {
                          CheckInternetConnection().then((value) =>
                          value == true
                              ? signinApi(
                              etuserName.text, etphone.text, context)
                              : "");
                        }
                    )),
                SizedBox(
                  height: 10,
                ),

                SizedBox(
                  height: 30,
                ),
                // GestureDetector(
                //   onTap: () {
                //     // Navigator.push(context, MaterialPageRoute(builder: (context)=>BottomNavBar()));
                //     // Navigator.canPop(context);
                //   },
                //   child: Center(
                //     child: Row(
                //       mainAxisAlignment: MainAxisAlignment.center,
                //       children: [
                //         Text(
                //           "Don't have an account? ",
                //           style: regular16pt.copyWith(color: Colors.grey),
                //         ),
                //         GestureDetector(
                //           onTap: () {},
                //           child: InkWell(
                //             onTap: () {
                //               Get.to(() => RegistrationPage(type: 1,));
                //             },
                //             child: Text(
                //               'Register',
                //               style: regular16pt.copyWith(
                //                   color: AppColor.primaryBlue),
                //             ),
                //           ),
                //         ),
                //       ],
                //     ),
                //   ),
                // ),
                //
                // SizedBox(
                //   height: 30,
                // ),
              ],
            ),
          ),
        ),
      ),
    );
    ;
  }

  var maskFormatter = new MaskTextInputFormatter(
      mask: '(###) ###-####',
      filter: {"#": RegExp(r'[0-9]')},
      type: MaskAutoCompletionType.lazy);

  Widget _buildDropdownItem(Country country) =>
      Container(

        child: Row(
          children: <Widget>[
            CountryPickerUtils.getDefaultFlagImage(country),
            SizedBox(
              width: 8.0,
            ),
            Text(
              "+${country.phoneCode}(${country.isoCode})",
              style: TextStyle(
                color: Colors.white70,
                fontSize: 12,
              ),
            ),
          ],
        ),
      );

  void signinApi(String _username, String _password,
      BuildContext context) async {
    if (etphone.text.isNotEmpty || etuserName.text.isNotEmpty) {
      if(etuserName.text.toString().isNotEmpty)
      {
        if(!isValidEmail(etuserName.text.toString()))
        {
          Get.snackbar("Alert", "Please Enter Valid Email",borderRadius: 2,icon: Icon(Icons.warning_amber),
              backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.black12])
          );
          return;
        }

      }
      devoteeController.getDevoteeDetails(etuserName.text,etphone.text,widget.flag);
     // controller.memberLogin(maskFormatter.getUnmaskedText(), etuserName.text);

    }
    else{
      Get.snackbar("Alert", "Please Enter  Email or Phone No",borderRadius: 2,icon: Icon(Icons.warning_amber),
          backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.black12])
      );
    }

  }
  void show_dailog()
  {
    final _formKey = GlobalKey<FormState>();
    TextEditingController etUserName= TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
            builder: (context, setState) {
              return  WillPopScope(
                onWillPop:() async{
                  return false;
                },
                child: AlertDialog(
                  contentPadding: EdgeInsets.zero,
                  backgroundColor:Theme.of(context).colorScheme.onPrimaryContainer,
                  content: Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          height: 50,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.teal,
                                  Colors.teal.withOpacity(0.7),

                                ],
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                //stops: [1.0,1.0,],
                                tileMode: TileMode.clamp,
                              )),

                          child:Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Filtersss",style: TextStyle(color: Colors.transparent),),
                              Text("Forgot Password ",style: TextStyle(color: Colors.white,fontSize: 20),),
                              IconButton(onPressed: (){
                                Navigator.pop(context);
                              },icon: Icon(Icons.clear),color: Colors.white,)

                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: EdgeInsets.all(10),
                          child: Column(

                            children: [
                              Form(
                                key: _formKey,
                                child: EditTextWidget(
                                  label: "Username",
                                  controller: etUserName,
                                  onchanged:( (value){

                                  }),
                                  hint: 'Enter User Name',
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please enter Username';
                                    }
                                    return null;
                                  },
                                  maxLength: 90,
                                  keyboardtype: TextInputType.text,
                                  isPassword: false,
                                ),
                              ),
                              SizedBox(height: 5,),

                              SizedBox(height: 10,),
                              ElevatedButton(onPressed: (){
                                if(_formKey.currentState!.validate())
                                {
                                  UtilMethods.forgotPass(context, etUserName.text).then((value) {

                                    if(jsonDecode(value)["user"]["statusCode"]==1)
                                    {
                                      Fluttertoast.showToast(msg: jsonDecode(value)["user"]["message"],toastLength: Toast.LENGTH_LONG);
                                      Navigator.pop(context);
                                    }
                                    else{
                                      Fluttertoast.showToast(msg: jsonDecode(value)["user"]["message"],toastLength: Toast.LENGTH_LONG);

                                    }
                                  });
                                }

                              },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal
                                )
                                ,child: Text("Submit",style: TextStyle( fontSize: 16,color: Colors.white),),


                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                ),
              );
            }
        );
      },
    );
  }
  void show_dailog_UserName()
  {
    final _formKey = GlobalKey<FormState>();
    TextEditingController etUserName= TextEditingController();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
            builder: (context, setState) {
              return  WillPopScope(
                onWillPop:() async{
                  return false;
                },
                child: AlertDialog(
                  contentPadding: EdgeInsets.zero,
                  backgroundColor:Theme.of(context).colorScheme.onPrimaryContainer,
                  content: Container(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Container(
                          height: 50,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(
                                colors: [
                                  Colors.teal,
                                  Colors.teal.withOpacity(0.7),

                                ],
                                begin: Alignment.topCenter,
                                end: Alignment.bottomCenter,
                                //stops: [1.0,1.0,],
                                tileMode: TileMode.clamp,
                              )),

                          child:Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("Filtersss",style: TextStyle(color: Colors.transparent),),
                              Text("Forgot Username ",style: TextStyle(color: Colors.white,fontSize: 20),),
                              IconButton(onPressed: (){
                                Navigator.pop(context);
                              },icon: Icon(Icons.clear),color: Colors.white,)

                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: EdgeInsets.all(10),
                          child: Column(

                            children: [
                              Form(
                                key: _formKey,
                                child: EditTextWidget(
                                  label: "Emial Id",
                                  controller: etUserName,
                                  onchanged:( (value){

                                  }),
                                  hint: 'Enter Email Id',
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please Enter Email Id';
                                    }
                                    if(!isValidEmail(value))
                                    {
                                      return 'Please Enter Valid Email';
                                    }
                                    return null;
                                  },
                                  maxLength: 90,
                                  keyboardtype: TextInputType.text,
                                  isPassword: false,
                                ),
                              ),
                              SizedBox(height: 5,),

                              SizedBox(height: 10,),
                              ElevatedButton(onPressed: (){

                                if(_formKey.currentState!.validate())
                                {
                                  UtilMethods.forgotUsername(context, etUserName.text).then((value) {

                                    if(jsonDecode(value)["user"]["statusCode"]==1)
                                    {
                                      Fluttertoast.showToast(msg: jsonDecode(value)["user"]["message"],toastLength: Toast.LENGTH_LONG);
                                      Navigator.pop(context);
                                    }
                                    else{
                                      Fluttertoast.showToast(msg: jsonDecode(value)["user"]["message"],toastLength: Toast.LENGTH_LONG);

                                    }
                                  });
                                }

                              },
                                style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.teal
                                )
                                ,child: Text("Submit",style: TextStyle( fontSize: 16,color: Colors.white),),
                                // color: AppColor.primaryColor,
                                // padding: EdgeInsets.only(left: 25,right: 25,top: 10,bottom: 10),

                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              );
            }
        );
      },
    );
  }
}