// To parse this JSON data, do
//
//     final rentalServiceDetail = rentalServiceDetailFromJson(jsonString);

import 'dart:convert';

RentalServiceDetail rentalServiceDetailFromJson(String str) => RentalServiceDetail.fromJson(json.decode(str));

String rentalServiceDetailToJson(RentalServiceDetail data) => json.encode(data.toJson());

class RentalServiceDetail {
  RentalServiceDetail({
    this.statusCode,
    this.message,
    this.data,
  });

  String? statusCode;
  String? message;
  List<RentalDatum>? data;

  factory RentalServiceDetail.fromJson(Map<String, dynamic> json) => RentalServiceDetail(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<RentalDatum>.from(json["data"].map((x) => RentalDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class RentalDatum {
  RentalDatum({
    this.id,
    this.rentalCategory,
    this.refDataCode,
    this.refDataName,
    this.description,
    this.facility,
    this.qtyCounter,
    this.units,
    this.personPerUnit,
    this.costPerDay,
    this.sequenceId,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recCreTime,
    this.isChecked,
    this.totalAmount,
    this.quantity,
    this.date,
    this.day,
    this.startTime,
    this.endTime,
    this.imagePath,

  });

  String? id;
  String? rentalCategory;
  String? refDataCode;
  String? refDataName;
  String? description;
  String? facility;
  String? qtyCounter;
  String? units;
  String? personPerUnit;
  String? costPerDay;
  String? sequenceId;
  String? moduleName;
  String? clientId;
  String? productId;
  String? aspectType;
  String? recCreBy;
  String? recCreDate;
  String? recCreTime;
  bool? isChecked;
  double? totalAmount;
  String? date;
  String? day;
  String? startDate;
  String? endDate;
  String? startTime;
  String? endTime;
  String? imagePath;
  String? serviceDescription;
  int? quantity;
  factory RentalDatum.fromJson(Map<String, dynamic> json) => RentalDatum(
    id: json["_id"]??"",
    rentalCategory: json["rentalCategory"]??"",
    refDataCode: json["refDataCode"]??"",
    refDataName: json["refDataName"]??"",
    description: json["description"]??"",
    facility: json["facility"]??"",
    qtyCounter: json["qtyCounter"]??"",
    units: json["units"]??"",
    personPerUnit: json["personPerUnit"],
    costPerDay: json["costPerDay"]??"",
      imagePath: json["imagePath"]??"",
    sequenceId: json["sequenceId"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recCreTime: json["recCreTime"]??"",
      startTime: "",
      endTime: "",

      // date: ApplicationConstant.alldata.toString().contains(json["_id"])
      //     ? getDate(json["_id"])
      //     : json["date"] ?? "",
      // isChecked: ApplicationConstant.alldata.toString().contains(json["_id"])
      //     ? true
      //     : false,
      // quantity: ApplicationConstant.alldata.toString().contains(json["_id"])
      //     ? getQty(json["_id"])
      //     : 1,
      // totalAmount: ApplicationConstant.alldata.toString().contains(json["_id"])
      //     ? double.parse(getAmount(json["_id"]))
      //     : 1 *
      //     double.parse(
      //         json["costPerDay"].toString().replaceAll("\$", "").replaceAll(",", "")==""?"0":json["costPerDay"].toString().replaceAll("\$", "").replaceAll(",", ""))
      //
  );



  Map<String, dynamic> toJson() => {
    "_id": id,
    "rentalCategory": rentalCategory,
    "refDataCode": refDataCode,
    "refDataName": refDataName,
    "description": description,
    "facility": facility,
    "qtyCounter": qtyCounter,
    "units": units,
    "personPerUnit": personPerUnit,
    "costPerDay": costPerDay,
    "sequenceId": sequenceId,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recCreTime": recCreTime,
    "startDate": startDate,
    "endDate": endDate,
    "day": day,
    "startTime": startTime,
    "endTime": endTime,
    "imagePath": imagePath,
  };


}
// String getAmount(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return ApplicationConstant.alldata[index]['costPerDay'];
// }
//
// String getDate(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return ApplicationConstant.alldata[index]['startDate'];
// }
//
// String getDay(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return ApplicationConstant.alldata[index]['day'];
// }
//
// String getstartDate(id) {
//   print("ApplicationConstant.alldata");
//   print(ApplicationConstant.alldata);
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return ApplicationConstant.alldata[index]['startDate'];
// }
//
// String getstartTime(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return ApplicationConstant.alldata[index]['time'];
// }
//
// String getcostPerDay(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   double sm =
//       double.parse(ApplicationConstant.alldata[index]['costPerDay'].toString().replaceAll("\$", "")) /
//           int.parse(ApplicationConstant.alldata[index]['qty']);
//   return sm.toStringAsFixed(2);
// }
//
// int getQty(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return int.parse(ApplicationConstant.alldata[index]['qty']);
// }