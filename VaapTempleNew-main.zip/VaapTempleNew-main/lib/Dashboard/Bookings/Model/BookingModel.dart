// To parse this JSON data, do
//
//     final bookingsModel = bookingsModelFromJson(jsonString);

import 'dart:convert';

BookingsModel bookingsModelFromJson(String str) => BookingsModel.fromJson(json.decode(str));

String bookingsModelToJson(BookingsModel data) => json.encode(data.toJson());

class BookingsModel {
  BookingsModel({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<BookingDatum> ?data;

  factory BookingsModel.fromJson(Map<String, dynamic> json) => BookingsModel(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<BookingDatum>.from((json["data"]??[]).map((x) => BookingDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class BookingDatum {
  BookingDatum({
    this.serviceDate,
    this.serviceAmount,
    this.serviceSetup,
    this.statusName,
    this.tokenNumber,
    this.paymentStatus,
    this.recCreDate,
    this.customerEmail,
    this.isChecked,
    this.customerName,
    this.customerPhone,
    this.eventDetail,
    this.id,
  });

  String ?serviceDate;
  String ?id;
  var serviceAmount;
  String? serviceSetup;
  String ?statusName;
  int ?tokenNumber;
  String? paymentStatus;
  String? recCreDate;
  String? customerEmail;
  String? customerName;
  String? customerPhone;
  bool? isChecked;
  EventDetail ?eventDetail;

  factory BookingDatum.fromJson(Map<String, dynamic> json) => BookingDatum(
    serviceDate: json["serviceDate"]??"",
    id: json["_id"]??"",
    serviceAmount: json["serviceAmount"]??"0",
    serviceSetup: json["ServiceSetup"]??"",
    statusName: json["statusName"]??json["status"]??"",
    tokenNumber: json["tokenNumber"]??"",
    paymentStatus: json["paymentStatus"]??"",
    recCreDate: json["recCreDate"]??"",
    customerEmail: json["customerEmail"]??"",
    customerName: json["customerName"]??"",
    customerPhone: json["customerPhone"]??"",
    eventDetail: EventDetail.fromJson(json["PaymentDetails"]!=null?json["PaymentDetails"]["eventDetail"]??{}:{}),
    isChecked: false,
  );

  Map<String, dynamic> toJson() => {
    "serviceDate": serviceDate,
    "serviceAmount": serviceAmount,
    "ServiceSetup": serviceSetup,
    "statusName": statusName,
    "tokenNumber": tokenNumber,
    "paymentStatus": paymentStatus,
    "recCreDate": recCreDate,
    "isChecked": isChecked,
    "customerEmail": customerEmail,
    "customerName": customerName,
    "customerPhone": customerPhone,
    "id": id,
    "eventDetail": eventDetail!.toJson(),
  };
}
class EventDetail {
  EventDetail({
    this.eventName,
    this.eventDate,
    this.eventEndDate,
    this.eventTime,
    this.eventEndTime,
    this.eventAddress,
    this.eventState,
    this.eventCity,
    this.zip,
    this.eventDescription,
  });

  String ?eventName;
  String ?eventDate;
  String ?eventEndDate;
  String ?eventTime;
  String ?eventEndTime;
  String ?eventAddress;
  String ?eventState;
  String ?eventCity;
  String ?zip;
  String ?eventDescription;

  factory EventDetail.fromJson(Map<String, dynamic> json) => EventDetail(
    eventName: json["eventName"]??"",
    eventDate: json["eventDate"]??"",
    eventEndDate: json["eventEndDate"]??"",
    eventTime: json["eventTime"]??"",
    eventEndTime: json["eventEndTime"]??"",
    eventAddress: json["eventAddress"]??"",
    eventState: json["eventState"]??"",
    eventCity: json["eventCity"]??"",
    zip: json["zip"]??"",
    eventDescription: json["eventDescription"]??"",
  );

  Map<String, dynamic> toJson() => {
    "eventName": eventName,
    "eventDate": eventDate,
    "eventEndDate": eventEndDate,
    "eventTime": eventTime,
    "eventEndTime": eventEndTime,
    "eventAddress": eventAddress,
    "eventState": eventState,
    "eventCity": eventCity,
    "zip": zip,
    "eventDescription": eventDescription,
  };
}
