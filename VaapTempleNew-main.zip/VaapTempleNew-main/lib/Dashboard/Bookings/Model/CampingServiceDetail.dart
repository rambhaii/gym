// To parse this JSON data, do
//
//     final rentalServiceDetail = rentalServiceDetailFromJson(jsonString);

import 'dart:convert';


CampingServiceDetail rentalServiceDetailFromJson(String str) => CampingServiceDetail.fromJson(json.decode(str));

String rentalServiceDetailToJson(CampingServiceDetail data) => json.encode(data.toJson());

class CampingServiceDetail {
  CampingServiceDetail({
    this.statusCode,
    this.message,
    this.data,
  });

  String? statusCode;
  String? message;
  List<Datum>? data;

  factory CampingServiceDetail.fromJson(Map<String, dynamic> json) => CampingServiceDetail(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.sequenceId,
    this.refDataCode,
    this.campingType,
    this.refDataName,
    this.campingStartDate,
    this.campingEndDate,
    this.description,
    this.campingAmount,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recCreTime,
    this.qtyCounter,
    this.isChecked,
    this.totalAmount,
    this.quantity,
    this.date,
    this.day,
    this.startTime,
    this.endTime,
    this.imagePath,
    this.startDate,

  });

  String? id;
  String? sequenceId;
  String? refDataCode;
  String? campingType;
  String? refDataName;
  String? campingStartDate;
  String? campingEndDate;
  String? description;
  String? campingAmount;
  String? moduleName;
  String? clientId;
  String? productId;
  String? aspectType;
  String? recCreBy;
  String? recCreDate;
  String? recCreTime;
  String? qtyCounter;
  bool? isChecked;
  double? totalAmount;
  String? date;
  String? day;
  String? startDate;
  String? endDate;
  String? startTime;
  String? endTime;
  String? imagePath;
  String? serviceDescription;
  int? quantity;
  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
      id: json["_id"],
      sequenceId: json["sequenceId"]??"",
      refDataCode: json["refDataCode"]??"",
      campingType: json["campingType"]??"",
      refDataName: json["refDataName"]??"",
      campingStartDate: json["campingStartDate"]??"",
      campingEndDate: json["campingEndDate"]??"",
      description: json["description"]??"",
      campingAmount: json["campingAmount"].toString()??"0",
      moduleName: json["moduleName"]??"",
      clientId: json["clientID"]??"",
      qtyCounter: json["qtyCounter"]??"YES",
      productId: json["productID"]??"",
      aspectType: json["aspectType"]??"",
      recCreBy: json["recCreBy"]??"",
      recCreDate: json["recCreDate"]??"",
      recCreTime: json["recCreTime"]??"",
      imagePath: json["imagePath"]??"",
      startDate:json["campingStartDate"]??"",
      startTime:"",
      endTime: "",
      //
      // date: ApplicationConstant.alldata.toString().contains(json["_id"])
      //     ? getDate(json["_id"])
      //     : json["campingStartDate"] ?? "",
      // isChecked: ApplicationConstant.alldata.toString().contains(json["_id"])
      //     ? true
      //     : false,
      // quantity: ApplicationConstant.alldata.toString().contains(json["_id"])
      //     ? getQty(json["_id"])
      //     : 1,
      // totalAmount: ApplicationConstant.alldata.toString().contains(json["_id"])
      //     ? double.parse(getAmount(json["_id"]))
      //     : 1 *
      //     double.parse(
      //         json["campingAmount"].toString().replaceAll("\$", "").replaceAll(",", "")==""?"0":json["campingAmount"].toString().replaceAll("\$", "").replaceAll(",", ""))
      //
      //
  );



  Map<String, dynamic> toJson() => {
    "_id": id,
    "sequenceId": sequenceId,
    "refDataCode": refDataCode,
    "campingType": campingType,
    "refDataName": refDataName,
    "campingStartDate": campingStartDate,
    "campingEndDate": campingEndDate,
    "description": description,
    "campingAmount": campingAmount,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recCreTime": recCreTime,
    "qtyCounter": qtyCounter,

    "startDate": startDate,
    "endDate": endDate,
    "day": day,
    "startTime": startTime,
    "endTime": endTime,
    "imagePath": imagePath,
  };


}
// String getAmount(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return ApplicationConstant.alldata[index]['campingAmount'];
// }
//
// String getDate(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return ApplicationConstant.alldata[index]['campingStartDate'];
// }
//
// String getDay(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return ApplicationConstant.alldata[index]['day'];
// }
//
// String getstartDate(id) {
//   print("ApplicationConstant.alldata");
//   print(ApplicationConstant.alldata);
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return ApplicationConstant.alldata[index]['startDate'];
// }
//
// String getstartTime(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return ApplicationConstant.alldata[index]['time'];
// }
//
// String getcampingAmount(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   double sm =
//       double.parse(ApplicationConstant.alldata[index]['campingAmount'].toString().replaceAll("\$", "")) /
//           int.parse(ApplicationConstant.alldata[index]['qty']);
//   return sm.toStringAsFixed(2);
// }
//
// int getQty(id) {
//   int index =
//   ApplicationConstant.alldata.indexWhere((element) => element['_id'] == id);
//   return int.parse(ApplicationConstant.alldata[index]['qty']);
// }