
import 'dart:convert';

import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../../AppConstant/APIsConstant.dart';
import '../../../../AppConstant/AppConstant.dart';
import '../../../../UtilMethods/BaseController.dart';
import '../../../../UtilMethods/base_client.dart';

import '../../../Templates/Model/CategoryData.dart';
import '../../Services/Model/ServiceData.dart';
import '../Model/BookingModel.dart';


class CompingController extends GetxController with GetSingleTickerProviderStateMixin {
  RxList<BookingDatum> bookingdata= RxList<BookingDatum>([]);
  RxList<BookingDatum> filterbookingdata= RxList<BookingDatum>([]);
  CompingController(this.title, this.Type);
  final String title;
  final String Type;

  CategoryData categoryData=CategoryData();
  RxList<CategoryDatum> serviceType= RxList<CategoryDatum>([]);

  Rx<List<ServiceDatum>> servicedata= Rx<List<ServiceDatum>>([]);
  Rx<List<ServiceDatum>> filterservicedata= Rx<List<ServiceDatum>>([]);

  var bodyJson={};
  var bodyJson1={};
  TextEditingController etSearch= new TextEditingController();
  TextEditingController etSearchAddBooking= new TextEditingController();
  TextEditingController etEmail= new TextEditingController();
  RxString rxMessage="".obs;
  TextEditingController etCheckNo= new TextEditingController();
  TextEditingController etAmount= new TextEditingController();
  TextEditingController etBankDetails= new TextEditingController();
  TextEditingController etDate= new TextEditingController();


  TextEditingController etAdult= new TextEditingController();
  TextEditingController etChild= new TextEditingController();
  String memberName="";
  String memberId="";
  String memberEmail="";
  String memberPhone="";
  String totalAmount="";
  var query;
  //Service Details Data
  var rxTtlAmount="0".obs;
  List<Map> alldata = [];

  late TabController tabController;
  RxList<String> caltegoryList=   RxList<String>([]);

  @override
  void onInit() {
    fechApi(query);
    super.onInit();
  }
  fechApi(var query) async{
    Get.context!.loaderOverlay.show();

    var response=await BaseClient().post(APIsConstant.getSpecificAPI, getRequestJson("")).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1") "";
    if(jsonDecode(response)["data"]==null) "";
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No Data Available");
    };
    jsonDecode(response)["data"].forEach((element) {
      print("@@@Status");
      print(element["statusName"]);
    });

    print("vfdvbfdjkvbkdf");
    print(response);
    bookingdata.value=bookingsModelFromJson(response).data!;
    filterbookingdata.value=bookingsModelFromJson(response).data!;
  }
  getRequestJson(String  Category){
    bodyJson["componentConfig"] = {
        "moduleName": "Calendar",
      "serviceCategory": "CAMPING",
      "aspectType": "serviceBooking",
        "productID":AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
         "skip": 0,
        "next": 500
      };
    bodyJson["project"]={
         "_id":0,
        "tokenNumber":1,
        "ServiceSetup":1,
        "serviceDate":1,
        "serviceType":1,
        "statusName":1,
        "serviceAmount":1,
        "status":1,
        "customerEmail":1,
        "customerName":1,
        "customerPhone":1,
        "paymentStatus":1,
        "recCreDate":1
    };
    return bodyJson;
  }

  Future<bool> getDevoteeDetails() async{
    var request={};
    request["componentConfig"]={
      "moduleName":"Contacts",
      "aspectType": "Member Directory",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":etEmail.text.contains("@")?{"aspectType":"Member Directory","memberTypes":"DEVOTEE","email":UtilMethods.encrypt(etEmail.text)}
          :{"aspectType":"Member Directory","memberTypes":"DEVOTEE", "phone":UtilMethods.encrypt(etEmail.text),
      },
      "skip":0,
      "next":200
    };

    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();

    if(jsonDecode(response)["statusCode"].toString()=="-1") {
      Get.snackbar("Alert!", jsonDecode(response)["message"].toString(),borderRadius: 2,backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.black26]));
      return false;
    }
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No User Found!");
      return false;
    };
    var datas=jsonDecode(response)["data"][0];
    memberId=datas["_id"];
    memberName=datas["refDataName"];
    memberEmail=datas["email"];
    memberPhone=datas["phone"];
    return true;
  }

  addServiceData(String paymentType,String memberId,String memberName,String memberEmail,String memberPhone){
    UtilMethods.addServiceCart(alldata, paymentType, etBankDetails.text, etCheckNo.text, etAmount.text, etDate.text, rxTtlAmount.value, "", memberId, memberName, memberEmail, memberPhone, Get.context!);
  }


  getServiceCategory()async{
    var bodyJson={};
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "serviceTypes",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "serviceTypes","refDataCode":"IN-TEMPLE"},
      "skip":0,
      "next":100
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      caltegoryList.value.add(element["refDataName"]);
    });
    tabController = TabController(length: caltegoryList.length, vsync: this);
    caltegoryList.refresh();
  }

  void filterData(String search){
    List<ServiceDatum> result=[];
    if(search.isEmpty)
    {
      result=filterservicedata.value;
    }
    else{
      result=filterservicedata.value.where((element) =>(element.serviceTypes.toString().toLowerCase().contains(search.toString().toLowerCase())) || (element.refDataName.toString().toLowerCase().contains(search.toString().toLowerCase()))).toList();
    }
    servicedata.value=result;
  }
  void filterBookingData(String search){
    List<BookingDatum> result=[];
    if(search.isEmpty)
    {
      result=filterbookingdata.value;
    }
    else{
      result=filterbookingdata.value.where((element) =>(element.customerName.toString().toLowerCase().contains(search.toString().toLowerCase())) || (element.serviceSetup.toString().toLowerCase().contains(search.toString().toLowerCase()))

      ||(element.customerEmail.toString().toLowerCase().contains(search.toString().toLowerCase()))
      ||(element.customerPhone.toString().toLowerCase().contains(search.toString().toLowerCase()))

      ).toList();
    }
    bookingdata.value=result;
  }
  //get All Services
 getServicesApi() async{
    var request={};
    request["componentConfig"] = {
      "moduleName":"Camping Setup",
      "aspectType": "campingSetup",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": {"aspectType":"campingSetup","refDataCode":"CAMPING"},
      "skip": 0,
      "next": 300
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("resdsjnvjds"+response);
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1") "";
    if(jsonDecode(response)["data"]==null) "";
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No Data Available");
    };
    servicedata.value=ServiceData.fromJson(jsonDecode(response)).data!;
    filterservicedata.value=ServiceData.fromJson(jsonDecode(response)).data!;
  }



}