
import 'dart:convert';

import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../../AppConstant/APIsConstant.dart';
import '../../../../AppConstant/AppConstant.dart';
import '../../../../UtilMethods/BaseController.dart';
import '../../../../UtilMethods/base_client.dart';

import '../../../Templates/Model/CategoryData.dart';
import '../../Services/Model/ServiceData.dart';
import '../Model/BookingModel.dart';
import '../Model/RentalServiceDetail.dart';


class RentalController extends GetxController with GetSingleTickerProviderStateMixin {
  RxList<BookingDatum> bookingdata= RxList<BookingDatum>([]);
  RxList<BookingDatum> filterbookingdata= RxList<BookingDatum>([]);
  RentalController(this.title, this.Type);
  final String title;
  final String Type;

  CategoryData categoryData=CategoryData();
  RxList<CategoryDatum> serviceType= RxList<CategoryDatum>([]);

  Rx<List<ServiceDatum>> servicedata= Rx<List<ServiceDatum>>([]);
  Rx<List<ServiceDatum>> filterservicedata= Rx<List<ServiceDatum>>([]);

  TextEditingController etBookStartDate= new TextEditingController();
  TextEditingController etBookEndDate= new TextEditingController();
  TextEditingController etBookStartTime= new TextEditingController();
  TextEditingController etBookEndTime= new TextEditingController();


  var bodyJson={};
  var bodyJson1={};
  TextEditingController etSearch= new TextEditingController();
  TextEditingController etSearchAddBooking= new TextEditingController();
  TextEditingController etEmail= new TextEditingController();
  RxString rxMessage="".obs;
  TextEditingController etCheckNo= new TextEditingController();
  TextEditingController etAmount= new TextEditingController();
  TextEditingController etBankDetails= new TextEditingController();
  TextEditingController etDate= new TextEditingController();

  String totalAmount="";

  RxInt isSelected=0.obs;
  RxBool isExpend1=false.obs;
  RxBool isSameAddress=false.obs;
  RxBool isExpend2=true.obs;
  RxBool isExpend3=false.obs;
  RxBool isExpendReService=true.obs;
  RxBool isExpend4=false.obs;
  RxBool isSearch=false.obs;
  //formData
  TextEditingController etEvent= new TextEditingController();
  TextEditingController etStartDate= new TextEditingController();
  TextEditingController etEndDate= new TextEditingController();
  TextEditingController etStartTime= new TextEditingController();
  TextEditingController etEndTime= new TextEditingController();
  TextEditingController etNotes= new TextEditingController();
  TextEditingController etEventAddress= new TextEditingController();
  DateTime? startPickedDate;
  DateTime? endPickedDate;
  DateTime? startBookPickedDate;
  DateTime? endBookPickedDate;
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  var query;

  TimeOfDay? startBookTimeofTheDay=TimeOfDay.now();
  var rxTtlAmount="0".obs;
  var rxCaculatTtlAmount="0".obs;
  var rxDuration="0".obs;
  var rxDay="0".obs;
  var rxWeek="0".obs;
  List<Map> alldata = [];
  late TabController tabController;
  RxList<String> caltegoryList=   RxList<String>([]);
   Map?eventMap;
   Map?devoteeMap;
  @override
  void onInit() {
    fechApi();
    super.onInit();
  }
  fechApi() async{
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getBookingsDetail, getRequestJson("")).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1") "";
    if(jsonDecode(response)["data"]==null) "";
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No Data Available");
    };
    print("vfdvbfdjkvbkdf");
    bookingdata.value=bookingsModelFromJson(response).data!;
    filterbookingdata.value=bookingsModelFromJson(response).data!;
  }
  getRequestJson(String  Category){
    bodyJson["componentConfig"] = {
      "moduleName": "Calendar",
      "serviceCategory": "RENTAL",
      "aspectType": "serviceBooking",
      "productID":AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip": 0,
      "next": 500
    };
    bodyJson["project"]={
      "_id":1,
      "tokenNumber":1,
      "ServiceSetup":1,
      "serviceDate":1,
      "serviceType":1,
      "statusName":1,
      "serviceAmount":1,
      "status":1,
      "customerEmail":1,
      "customerName":1,
      "customerPhone":1,
      "paymentStatus":1,
      "recCreDate":1
    };
    return bodyJson;
  }

  // Future<bool> getDevoteeDetails() async{
  //   var request={};
  //   request["componentConfig"]={
  //     "moduleName":"Contacts",
  //     "aspectType": "Member Directory",
  //     "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
  //     "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
  //     "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
  //     "query":etEmail.text.contains("@")?{"aspectType":"Member Directory","memberTypes":"DEVOTEE","email":UtilMethods.encrypt(etEmail.text)}
  //         :{"aspectType":"Member Directory","memberTypes":"DEVOTEE", "phone":UtilMethods.encrypt(etEmail.text),
  //     },
  //     "skip":0,
  //     "next":200
  //   };
  //
  //   Get.context!.loaderOverlay.show();
  //   var response=await BaseClient().post(APIsConstant.filterAPI, request).catchError(BaseController().handleError);
  //   Get.context!.loaderOverlay.hide();
  //
  //   if(jsonDecode(response)["statusCode"].toString()=="-1") {
  //     Get.snackbar("Alert!", jsonDecode(response)["message"].toString(),borderRadius: 2,backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.black26]));
  //     return false;
  //   }
  //   if(jsonDecode(response)["data"].isEmpty){
  //     Fluttertoast.showToast(msg: "No User Found!");
  //     return false;
  //   };
  //   var datas=jsonDecode(response)["data"][0];
  //   memberId=datas["_id"];
  //   memberName=datas["refDataName"];
  //   memberEmail=datas["email"];
  //   memberPhone=datas["phone"];
  //   return true;
  // }

  addServiceData(String paymentType,String memberId,String memberName,String memberEmail,String memberPhone){
    UtilMethods.addRentalServiceCart(alldata, paymentType, etBankDetails.text, etCheckNo.text, etAmount.text, etDate.text, rxTtlAmount.value, "", memberId, memberName, memberEmail, memberPhone,eventMap,devoteeMap ,Get.context!);
  }


  getServiceCategory()async{
    var bodyJson={};
    bodyJson["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "serviceTypes",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "serviceTypes","refDataCode":"IN-TEMPLE"},
      "skip":0,
      "next":100
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      caltegoryList.value.add(element["refDataName"]);
    });
    tabController = TabController(length: caltegoryList.length, vsync: this);
    caltegoryList.refresh();
  }

  void filterData(String search){
    List<ServiceDatum> result=[];
    if(search.isEmpty)
    {
      result=filterservicedata.value;
    }
    else{
      result=filterservicedata.value.where((element) =>(element.serviceTypes.toString().toLowerCase().contains(search.toString().toLowerCase())) || (element.refDataName.toString().toLowerCase().contains(search.toString().toLowerCase()))).toList();
    }
    servicedata.value=result;
  }
  void filterBookingData(String search){
    List<BookingDatum> result=[];
    if(search.isEmpty)
    {
      result=filterbookingdata.value;
    }
    else{
      result=filterbookingdata.value.where((element) =>
      (element.serviceSetup.toString().toLowerCase().contains(search.toString().toLowerCase()))
          || (element.serviceSetup.toString().toLowerCase().contains(search.toString().toLowerCase()))
          ||(element.customerEmail.toString().toLowerCase().contains(search.toString().toLowerCase()))
      ||(element.customerPhone.toString().toLowerCase().contains(search.toString().toLowerCase()))

      ).toList();
    }
    bookingdata.value=result;
  }
  //get All Services
 getServicesApi() async{
    var request={};
    request["componentConfig"] = {
      "moduleName":"Rental Setup",
      "aspectType": "rentalSetup",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": {"aspectType":"rentalSetup", "rentalCategory": "RENTAL",},
      "skip": 0,
      "next": 300
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("resdsjnvjds"+response);
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1") "";
    if(jsonDecode(response)["data"]==null) "";
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No Data Available");
    };
    servicedata.value=ServiceData.fromJson(jsonDecode(response)).data!;
    filterservicedata.value=ServiceData.fromJson(jsonDecode(response)).data!;
  }


  UpdateStatus(String id) async{
    var bodyJsonRequest={};
    bodyJsonRequest["_id"]=id;
    bodyJsonRequest["componentConfig"]={
      "moduleName":"Calendar",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
    };
    bodyJsonRequest["dataJson"]={
      "status":"CANCELED"
    };
    print("vdjbfvjkd");
    print(bodyJsonRequest);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.postAPI, bodyJsonRequest).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString().trim()=="1")
    {
      Fluttertoast.showToast(msg: jsonDecode(response)["message"]);
      fechApi();

    }
    else{
      Get.snackbar("Error",jsonDecode(response)["message"].toString().trim(),
          backgroundGradient: LinearGradient(colors: [
            Colors.red,
            Colors.black26,
          ]),
          borderRadius: 2,
          icon: Icon(Icons.error)
      );
    }

  }
  getDuration(String statTime,String startDate,String endTime,String endDate,String amount){
    rxDuration.value=  differTime(
      statTime,
      startDate,
      endTime,
      endDate,
    );
    print("sdjbvdonvdiosfv");

    if(rxDuration.value.isNotEmpty)
      {
        subsDurationtoAmount(amount, rxDuration.value);
      }

  }
  int checkDay(String startDate,String endDate){
    return (int.parse(differInDayTime(startDate,endDate))+1);
  }


  getDay(String startDate,String endDate,String amount){
    rxDay.value= (int.parse(differInDayTime(startDate,endDate))+1).toString();
    rxCaculatTtlAmount.value=(double.parse(amount)*double.parse(rxDay.value)).toStringAsFixed(2);
  }
   subsDurationtoAmount(String amount,String duration){
      String dur=duration.split(":").first.trim()+"."+duration.split(":").last.trim();
      print("sdbvkbvljkdsb");
      print(dur);
      double calAmount= double.parse(amount.toString())*double.parse(dur);
      rxCaculatTtlAmount.value=calAmount.toStringAsFixed(2);
  }
}