
import 'dart:convert';

import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../../AppConstant/APIsConstant.dart';
import '../../../../AppConstant/AppConstant.dart';
import '../../../../UtilMethods/BaseController.dart';
import '../../../../UtilMethods/base_client.dart';
import '../AddCompingBookingPage.dart';
import '../RentalFormPage.dart';


class DevoteeController extends GetxController  {

  String memberName="";
  String memberId="";
  String memberEmail="";
  String memberPhone="";
  String memberAddress="";
  String memberState="";
  String memberCity="";
  String memberZip="";
  @override
  void onInit() {

  }


  Future<bool> getDevoteeDetails(String email,String phone,int type) async{
    var request={};
    request["componentConfig"]={
      "moduleName":"Contacts",
      "aspectType": "Member Directory",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{"aspectType":"Member Directory","memberTypes":"DEVOTEE",
        if(email.isNotEmpty)"email":UtilMethods.encrypt(email),
        if(phone.isNotEmpty) "phone":UtilMethods.encrypt(phone)
      },

      "skip":0,
      "next":200
    };

    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();

    if(jsonDecode(response)["statusCode"].toString()=="-1") {
      Get.snackbar("Alert!", jsonDecode(response)["message"].toString(),borderRadius: 2,backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.black26]));
      return false;
    }
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No User Found!");
      return false;
    };
    var datas=jsonDecode(response)["data"][0];
    memberId=datas["_id"];
    memberName=datas["refDataName"];
    memberEmail=datas["email"];
    memberPhone=datas["phone"];
    memberCity=datas["cityTypes"];
    memberState=datas["stateTypes"];
    memberZip=datas["zip"];
    memberAddress=datas["address"];
    switch(type){
      case 1:
        break;
        case 2:
          Get.to(()=>RentalFormPage());
        break;
        case 3:
          Get.to(()=>AddCompingBookingPage(title: "Book Camp",));
        break;
        case 4:
        break;
    }
    if(type==2){

    }

    return true;
  }










}