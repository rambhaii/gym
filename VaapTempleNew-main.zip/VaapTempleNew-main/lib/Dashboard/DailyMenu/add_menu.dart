
import 'dart:convert';
import 'dart:math';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/Dashboard/DailyMenu/today_menu_page.dart';
import 'package:aspgen_mobile/Dashboard/Menu/MenuController/MenuController.dart';
import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../AppConstant/TextStyle.dart';
import '../../Templates/fieldPageNew.dart';
import '../../UtilMethods/RemoteServices.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListView.dart';
import '../../Widget/FullScreenImageWidget.dart';
import '../../Widget/SearchBarWidget.dart';
import '../Catering/Controller/controller.dart';

import '../DailyMenu/MenuController/TodayMenuController.dart';
import 'Model/MenuData.dart';


class AddTodaysMenuPage extends StatefulWidget {
  final String title;
  final int type;// type=1  for menu,type=2  for Today Menu//type 4 for Catering Menu
  AddTodaysMenuPage({Key? key,required this.title, required this.type}) : super(key: key);

  @override
  State<AddTodaysMenuPage> createState() => _AddTodaysMenuPageState();
}

class _AddTodaysMenuPageState extends State<AddTodaysMenuPage> {
  TextEditingController etdate= new TextEditingController();

  final formGlobalKey = GlobalKey<FormState>();

  DateTime?tempDate;
  MenuControllers controller=Get.put(MenuControllers("Menu"));
  TodayMenuController todayController=Get.put(TodayMenuController("Menu"));
    @override
  void initState() {
      controller.fetchApi(2);
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Add Today's Menu" ,
          textAlign: TextAlign.center,
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child:Obx(()=> RawMaterialButton(
                onPressed:controller.menuAddedData.value.isNotEmpty?()  {
                  controller.menuAddedData.value.forEach((datas)async {
                    var json= {
                      "menuId":datas.id,
                      "image":datas.image,
                      "refDataName":datas.refDataName,
                      "menuCategory":datas.menuCategory,
                      "refDataCode":datas.refDataCode,
                      "consistency":datas.consistency,
                      "unitPrice":datas.unitPrice,
                      "price":datas.carryOutPrice,
                      "date":todayController.formatter.format(DateTime.now()).toString(),
                    };
                   await todayController.fetchAddApi(json);
                  });
                  Future.delayed(Duration(seconds: 1)).then((value) =>  todayController.fetchApi());

                  Get.back();
                  }:null,

                child: Image.asset("assets/images/diskbold.png",height: 22,width: 22,color: Colors.white,),
              fillColor:controller.menuAddedData.value.isNotEmpty? Colors.green:Colors.grey,
                shape: CircleBorder(),
                elevation: 5,
                constraints: BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
            ),
          ),
         ],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 5),

        child: Column(

          children: [
            Obx(() => Text(todayController.runningClock.value,style: TextStyle(fontSize: 18,color: Colors.tealAccent,fontWeight: FontWeight.w600),)),

            SizedBox(height: 6,),
            GetBuilder<MenuControllers>(
              builder: (controller)=>  SearchBarWidget(
                hint: "Search",
                controller: controller.etSearch,
                onchange: (value){
                  value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi(2):"";
                  controller.update();
                },
                onCancel: (){
                  controller.etSearch.clear();
                  controller.fetchApi(2);
                  controller.update();
                },
              ),
            ),
            SizedBox(height: 6,),

            Obx(()=>(controller.menuData.value.data!=null && controller.menuData.value.data!.isNotEmpty)?Expanded(
              child: controller.menuData.value.data!.isNotEmpty?ListView.builder(
                  itemCount:controller.menuData.value.data!.length,
                  itemBuilder: (context,index)
                  {

                    final datas=controller.menuData.value.data![index];
                    return GestureDetector(onTap: (){
                        controller.menuData.value.data![index].isCheck=!controller.menuData.value.data![index].isCheck!;
                        controller.menuData.refresh();
                       },
                      child: Card(
                        color: datas.status=="ACTIVE"? Theme.of(context).colorScheme.onPrimaryContainer:Colors.red.withOpacity(0.3),
                        elevation: 6,

                        child:
                        Column(
                          children: [
                            Divider(
                              height: 0.5,
                              thickness: 0.5,
                              color: Theme.of(context).colorScheme.primary.withOpacity(0.24)
                            ),
                            SizedBox(height: 10),
                            Row(
                              children: [
                                Spacer(flex: 1,),

                                Expanded(
                                  flex: 5,
                                  child: Stack(
                                    children: [
                                      datas.image!.isEmpty?  CircleAvatar(
                                        backgroundColor: Color(Random().nextInt(0xffffffff)),
                                        child: Text(
                                            datas.refDataName.toString().toUpperCase() ==
                                                "" ? "" : datas.refDataName.toString().trim()[0].toString().toUpperCase(),
                                            style: Theme.of(context).textTheme.headline4
                                        ),
                                        maxRadius: 27,
                                      )
                                          :GestureDetector(
                                        onTap: (){
                                          Get.to(()=>FullScreenImageWidget(path: APIsConstant.IP_Base_Url+datas.image!,),fullscreenDialog: true);
                                        },
                                        child: ClipOval(
                                          child: CachedNetworkImage(
                                            fit: BoxFit.cover,
                                            imageUrl:APIsConstant.IP_Base_Url+datas.image!,
                                            height: 50,
                                            width: 50,
                                            placeholder: (context,url)=>const CircularProgressIndicator(),
                                            errorWidget: (context,url,error)=>const Icon(Icons.error),
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Spacer(flex: 1,),
                                Expanded(
                                  flex: 20,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      HigliteText(textData: datas.refDataName!, query: controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle),
                                      if(datas.unitPrice!="")  SizedBox(
                                        height: 4,
                                      ),
                                      if(datas.unitPrice!="")  HigliteText(textData: amountParser(datas.unitPrice!.toString()), query: controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(
                                          color:  Colors.amber,
                                          fontSize: 14,fontWeight: FontWeight.w400
                                      )
                                      ),

                                      Row(
                                        children: [
                                          Expanded(
                                              flex:9,
                                              child: Row(
                                                children: [
                                                  Text(!datas.isCheck!?"View More  ":"Less More ",style:TextStyle(fontSize: 12,color:Colors.white54, decoration: TextDecoration.underline,)),
                                                  Icon(!datas.isCheck!?Icons.expand_more:Icons.expand_less,size: 20,color:Colors.white54)
                                                ],
                                              )),
                                        ],
                                      ),
                                      if(datas.isCheck!)Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          if(datas.menuCategory!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                                  if(datas.menuCategory!.isNotEmpty) viewMore("Category  ",datas.menuCategory??""),
                                                  if(datas.refDataCode!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                                  if(datas.refDataCode!.isNotEmpty) viewMore("Type  ",datas.refDataCode??""),

                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                Expanded(
                                  flex: 5,
                                  child: Padding(
                                    padding: const EdgeInsets.only(top: 15.0),
                                    child:datas.status=="ACTIVE"? Transform.scale(
                                      alignment: Alignment.bottomCenter,
                                      scale:1.4,
                                      child: Checkbox(
                                        shape:  const RoundedRectangleBorder(
                                          borderRadius: BorderRadius.all(Radius.circular(3.0)),
                                        ),
                                        side: BorderSide(
                                            width: 0.8, color:Colors.white),
                                        checkColor: Colors.white,
                                        activeColor: Colors.green,
                                        value: datas.isAdd,
                                        onChanged: (v){
                                          datas.isAdd=v;
                                          if(datas.isAdd!)
                                            {
                                              controller.menuAddedData.value.add(datas);
                                            }
                                          else{
                                           controller.menuAddedData.value.removeWhere((element) => element.id==datas.id);
                                          }
                                          controller.menuData.refresh();
                                          controller.menuAddedData.refresh();
                                        },
                                      ),
                                    ):Container(),
                                  ),
                                ),
                              ],
                            ),

                            SizedBox(height: 10),
                            Divider(
                              height: 0.5,
                              thickness: 0.5,
                              color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
                            )
                          ],
                        ),
                      ),
                    );

                    //   CustomListWidget(
                    //   imgUrl:controller.menuData.value.data![index].image??"" ,
                    //   title: controller.menuData.value.data![index].refDataName??"",
                    //   subTitle:amountParser(controller.menuData.value.data![index].unitPrice.toString()),
                    //   viewMoreWidget: Column(
                    //       crossAxisAlignment: CrossAxisAlignment.start,
                    //       children:[
                    //         if(datas.menuCategory!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                    //         if(datas.menuCategory!.isNotEmpty) viewMore("Category  ",datas.menuCategory??""),
                    //         if(datas.refDataCode!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                    //         if(datas.refDataCode!.isNotEmpty) viewMore("Type  ",datas.refDataCode??""),
                    //       ]),
                    //   isClicked: controller.menuData.value.data![index].isCheck!??false,
                    //   onTapVieMore: (){
                    //     controller.menuData.value.data![index].isCheck=!controller.menuData.value.data![index].isCheck!;
                    //     controller.menuData.refresh();
                    //   },
                    //   icon: (type==2 || type==4)?datas.isAdd!=true?Icons.add:Icons.check:null,
                    //   iconColor: (type==2 || type==4)?datas.isAdd!=true?Colors.green:Colors.white:null,
                    //   editOnTap: (){
                    //     CheckInternetConnection().then((value) {
                    //       if(value==true)
                    //       {
                    //         if(type==1){
                    //           CheckInternetConnection().then((value1) => value1==true?Get.to(()=>FieldPageNew(title: title,type: 2,id: controller.menuData.value.data![index].id!),arguments: {"data": json.decode(json.encode(controller.menuData.value.data![index]))}):"");
                    //         }
                    //         else if(type==2){
                    //           datas.isAdd=!datas.isAdd!;
                    //           if(datas.isAdd==true)
                    //           {
                    //
                    //           }
                    //           else{
                    //
                    //           }
                    //           var json= {
                    //             "menuId":datas.id,
                    //             "image":datas.image,
                    //             "refDataName":datas.refDataName,
                    //             "menuCategory":datas.menuCategory,
                    //             "refDataCode":datas.refDataCode,
                    //             "consistency":datas.consistency,
                    //             "unitPrice":datas.unitPrice,
                    //             "price":datas.carryOutPrice,
                    //             "date":todayController.formatter.format(DateTime.now()).toString(),
                    //           };
                    //           todayController.fetchAddApi(json);
                    //           controller.menuData.value.data!.removeAt(index);
                    //           controller.menuData.refresh();
                    //         }
                    //         else{
                    //           Map data={
                    //             "image":datas.image,
                    //             "refDataName":datas.refDataName,
                    //             "menuCategory":datas.menuCategory,
                    //             "refDataName":datas.refDataName,
                    //             "refDataCode":datas.refDataCode,
                    //             "menuId":datas.id,
                    //             "consistency":datas.consistency,
                    //             "status":datas.status,
                    //             "unitPrice":datas.unitPrice,
                    //             "carryOutPrice":datas.carryOutPrice,
                    //             "servingQuantity":datas.servingQuantity,
                    //             "servingCalories":datas.servingCalories,
                    //             "ingredientList":datas.ingredientList,
                    //             "ChildGrid":datas.ChildGrid,
                    //             "description":datas.description,
                    //           };
                    //           controller.addCateringApi(data);
                    //           controller.menuData.value.data!.removeAt(index);
                    //           controller.menuData.refresh();
                    //         }
                    //       }
                    //     });
                    //   }, textEditingController: controller.etSearch,
                    // );
                  }):Container(),
            ):
            Expanded(child: Center(child: Text(controller.rxMessage.value,style: Theme.of(context).textTheme.bodyText1,))))
          ],
        ),
      ),
    );
  }
}
