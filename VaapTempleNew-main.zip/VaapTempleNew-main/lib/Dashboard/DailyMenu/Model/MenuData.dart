// To parse this JSON data, do
//
//     final menuData = menuDataFromJson(jsonString);

import 'dart:convert';

MenuData menuDataFromJson(String str) => MenuData.fromJson(json.decode(str));

String menuDataToJson(MenuData data) => json.encode(data.toJson());

class MenuData {
  MenuData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<TodayDatum> ?data;

  factory MenuData.fromJson(Map<String, dynamic> json) => MenuData(
    statusCode: json["statusCode"]??"",
    message: json["message"]??"",
    data: List<TodayDatum>.from((json["data"]??"").map((x) => TodayDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class TodayDatum {
  TodayDatum({
    this.id,
    this.image,
    this.itemName,
    this.menuCategory,
    this.menuType,
    this.menuId,
    this.consistency,
    this.status,
    this.unitPrice,
    this.price,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.isCheck,
  });

  String? id;
  String ?image;
  String ?itemName;
  String ?menuCategory;
  String ?menuType;
  String ?menuId;
  String ?consistency;
  String ?status;
  String ?unitPrice;
  String ?price;
  String ?moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  bool ?isCheck;

  factory TodayDatum.fromJson(Map<String, dynamic> json) => TodayDatum(
    id: json["_id"]??"",
    image: json["image"]??"",
    itemName: json["itemName"]??"",
    menuCategory: json["menuCategory"]??"",
    menuType: json["menuType"]??"",
    menuId: json["menuId"]??"",
    consistency: json["consistency"]??"",
    status: json["status"]??"",
    unitPrice: json["unitPrice"]??"",
    price: json["price"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    isCheck: false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "image": image,
    "itemName": itemName,
    "menuCategory": menuCategory,
    "menuType": menuType,
    "menuId": menuId,
    "consistency": consistency,
    "status": status,
    "unitPrice": unitPrice,
    "price": price,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "isCheck": isCheck,
  };


}
