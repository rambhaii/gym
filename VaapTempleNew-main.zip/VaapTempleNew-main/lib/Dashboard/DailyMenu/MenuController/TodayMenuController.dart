import 'dart:async';
import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Menu/Model/MenuData.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../UtilMethods/base_client.dart';

class TodayMenuController extends GetxController{
  TodayMenuController(this.titile);
  final String titile;
  var menuData= MenuData().obs;
  var menufilterData= MenuData().obs;

  RxList<dynamic> datum=RxList<dynamic>([]);
  TextEditingController etSearch= new TextEditingController();
  TextEditingController etEmail= new TextEditingController();
  RxString runningClock="".obs;

  final DateFormat formatter = DateFormat('MM/dd/yyyy');


  String memberName="";
  String memberId="";
  String memberEmail="";
  String memberPhone="";
  RxString totalAmount="0.00".obs;

  TextEditingController etCheckNo= new TextEditingController();
  TextEditingController etAmount= new TextEditingController();
  TextEditingController etBankDetails= new TextEditingController();
  TextEditingController etDate= new TextEditingController();

  List<Map> alldata = [];

  var bodyJson={};
  @override
  void onInit() {
    Timer.periodic(Duration(seconds: 1), (Timer t) => _getTime());
    bodyJson={
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": {"recCreDate":formatter.format(DateTime.now().subtract(Duration(days: 1))).toString()}
    };

    super.onInit();
  }
  void _getTime() {
    final DateTime now = DateTime.now();
    final String formattedDateTime = _formatDateTime(now);
    runningClock.value = formattedDateTime;

  }

  String _formatDateTime(DateTime dateTime) {
    return DateFormat('d  MMM,yyyy hh:mm:ss a').format(dateTime);
  }

  fetchApi()async{

    print(jsonEncode(bodyJson));
    {
      Get.context!.loaderOverlay.show();
      var response=await BaseClient().post(APIsConstant.getTodayMenuAPI, bodyJson).catchError(BaseController().handleError);
      Get.context!.loaderOverlay.hide();
      if(response==null) return;
      if(jsonDecode(response)["statusCode"].toString()=="-1") return;
     menuData.value=menuDataFromJson(response);
      menufilterData.value=menuDataFromJson(response);
    }
  }




 Future<void> fetchAddApi(var list)async{
    var request1= {
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": list
    };
    print("dfgvdfgfg");
    print(request1);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.addTodayMenuAPI, request1).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    print("dvbvhsdjvbjds");
    print(response);
  // menuData.value=menuDataFromJson(response);
  }

  deleteTodyMenu(String id)async{
    var request1= {
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "id":id
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.deleteTodayMenuAPI, request1).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="1") {
      fetchApi();
      Fluttertoast.showToast(msg: "Menu Deleted");
    };

  }
  Future<bool> getDevoteeDetails() async{
    var request={
      "dataJson":{
        "email":UtilMethods.encrypt(etEmail.text)
      },
      "componentConfig":{
        "moduleName": "Contacts",
        "productID":  AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID":AppConstant.sharedPreference.getString(AppConstant.clientId)
      }};
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getDevoteeDetais,request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
     print("vdkjvjkdvf");
     print(response);
    if(jsonDecode(response)["statusCode"].toString()=="-1") {
      Get.snackbar("Alert!", jsonDecode(response)["message"].toString(),borderRadius: 2,backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.black26]));

      return false;
    }
    if(jsonDecode(response)["data"]==null) return false;
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No Data Available");
      return false;
    };
    var datas=jsonDecode(response)["data"][0];
    memberId=datas["_id"];
    memberName=datas["refDataName"];
    memberEmail=datas["email"];
    memberPhone=datas["phone"];
    return true;
  }

  addServiceData(String paymentType){
    UtilMethods.addServiceCart(alldata, paymentType, etBankDetails.text, etCheckNo.text, etAmount.text, etDate.text, totalAmount.value, "", memberId, memberName, memberEmail, memberPhone, Get.context!);
  }

  void filterData(String search){
    List<MenuDatum> result=[];
    if(search.isEmpty)
    {
      result=menufilterData.value.data!;
    }
    else{
      result=menufilterData.value.data!.where((element) =>element.refDataName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    menuData.value.data=result;
    menuData.refresh();
  }
}