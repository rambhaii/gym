

import 'package:aspgen_mobile/Dashboard/Menu/Menu.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/ButtonWidget.dart';
import '../../Widget/CustomListView.dart';
import '../../Widget/EditextWidget.dart';
import '../../Widget/SearchBarWidget.dart';
import '../Menu/Model/MenuData.dart';
import 'MenuController/TodayMenuController.dart';
import 'add_menu.dart';


class TodyMenuPage extends StatefulWidget {
   final String title;
   final int type;// 1 for TodyMenu 2 for Prasadam
   TodyMenuPage({Key? key,required this.title, required this.type}) : super(key: key);

  @override
  State<TodyMenuPage> createState() => _TodyMenuPageState();
}

class _TodyMenuPageState extends State<TodyMenuPage> {
  TextEditingController etdate= new TextEditingController();

   TodayMenuController controller=Get.put(TodayMenuController("Today's menu"));

   final DateFormat formatter = DateFormat('MM/dd/yyyy');

  final formGlobalKey = GlobalKey<FormState>();

  DateTime?tempDate;
  @override
  void initState() {
    controller.fetchApi();
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          textAlign: TextAlign.center,
        ),
        actions: [
         if(widget.type==1) Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            Get.to(()=>AddTodaysMenuPage(title: "Menu", type: 2,));
               }
            ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        ),
          if(widget.type==2)  Center(child: Obx(()=> Text("\$ "+controller.totalAmount.value,style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color:Colors.amber),))),
          if(widget.type==2)      Padding(
            padding: const EdgeInsets.only(right: 8.0,left: 8),
            child: RawMaterialButton(onPressed: (){
              if(controller.alldata.isNotEmpty)
                {
                  showDialog(context: context, builder: (context)=>showDailog(context,));
                }
            }
              ,child: Icon(Icons.paypal),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          )
        ],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 5),

        child: Column(

          children: [
            SizedBox(height: 6,),
              Obx(() => Text(controller.runningClock.value,style: TextStyle(fontSize: 18,color: Colors.tealAccent,fontWeight: FontWeight.w600),)),
            SizedBox(height: 8,),
            GetBuilder<TodayMenuController>(
              builder: (controller)=>  SearchBarWidget(
                hint: "Search",
                controller: controller.etSearch,
                onchange: (value){
                    controller.filterData(value);
                  controller.update();
                },
                onCancel: (){
                  controller.etSearch.clear();
                  controller.filterData(controller.etSearch.text);
                  controller.update();
                },
              ),
            ),
            SizedBox(height: 4,),
            Obx(()=>controller.menuData.value.data!=null?Expanded(
                child: RefreshIndicator(
                  onRefresh: (){
                    return Future.delayed(Duration.zero, () {
                      controller.fetchApi();
                    });
                  },
                  child:ListView.builder(
                      itemCount:controller.menuData.value.data!.length,
                      itemBuilder: (context,index)
                      {
                        final datum=controller.menuData.value.data![index];
                        return CustomListWidget(
                          imgUrl:controller.menuData.value.data![index].image??"" ,
                          title: controller.menuData.value.data![index].refDataName??"",
                          subTitle: amountParser(datum.unitPrice.toString()),
                          viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                          children:[
                            if(datum.menuCategory!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                            if(datum.menuCategory!.isNotEmpty) viewMore("Category  ",datum.menuCategory??""),
                            if(datum.refDataCode!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                            if(datum.refDataCode!.isNotEmpty) viewMore("Type  ",datum.refDataCode??""),
                          ]),
                          isClicked: controller.menuData.value.data![index].isCheck!??false,
                          onTapVieMore: (){
                          controller.menuData.value.data![index].isCheck=!controller.menuData.value.data![index].isCheck!;
                            controller.menuData.refresh();
                          },
                          iconColor: widget.type==2?(!controller.menuData.value.data![index].isAdd!?  Colors.white:Colors.green):Colors.red,
                          icon:widget.type==2? !controller.menuData.value.data![index].isAdd!? (Icons.add):(Icons.check):Icons.delete,
                          editOnTap: (){
                            CheckInternetConnection().then((value) {
                              if(value==true)
                              {
                                if(widget.type==1)
                                  {
                                    uploadDailog(context,controller.menuData.value.data![index].id.toString(),controller);
                                  }
                                else{
                                  controller.menuData.value.data![index].isAdd= !controller.menuData.value.data![index].isAdd!;
                                  controller.menuData.refresh();
                                  if(controller.menuData.value.data![index].isAdd!)
                                    {
                                      controller.alldata.add({
                                        '_id': datum.id,
                                        'date':formatter.format(DateTime.now()) ,
                                        "serviceImage": datum.image,
                                        "serviceName": datum.refDataName,
                                        "serviceCategory": datum.menuCategory,
                                        "serviceType": datum.refDataCode,
                                        "qty": datum.servingQuantity,
                                        "serviceAmount": double.parse(datum.carryOutPrice!.toString()).toStringAsFixed(2),
                                        "totalAmount": double.parse(datum.carryOutPrice!.toString()).toStringAsFixed(2),
                                      });
                                      controller.totalAmount.value=(double.parse(controller.totalAmount.value)+double.parse(datum.carryOutPrice!.toString())).toStringAsFixed(2);
                                    }
                                  else{
                                    controller.alldata.removeWhere((element) => element["_id"]==datum.id);
                                   controller.totalAmount.value=(double.parse(controller.totalAmount.value)-double.parse(datum.carryOutPrice!.toString())).toStringAsFixed(2);
                                  }

                                }
                                //CheckInternetConnection().then((value1) => value1==true?Get.to(()=>FieldPageNew(title: title,type: 2,id: controller.menuData.value.data![index].id!),arguments: {"data": json.decode(json.encode(controller.menuData.value.data![index]))}):"");
                              }
                            });
                          }, textEditingController: controller.etSearch!,
                        );
                   }),
                ),
             ):Container())
          ],
        ),
      ),
    );
  }

   void uploadDailog(BuildContext context,String id,TodayMenuController controller) {
     showCupertinoDialog(
         context: context,
         builder: (BuildContext ctx) {
           return CupertinoAlertDialog(
             title: const Text('Are you sure?'),
             content: const Text('You want to delete Menu ?'),
             actions: [
               CupertinoDialogAction(
                 onPressed: () {
                   Navigator.of(context).pop();
                 },
                 child: const Text('NO'),
                 isDefaultAction: true,
                 isDestructiveAction: true,
               ),
               // The "No" button
               CupertinoDialogAction(
                 onPressed: () {
                   Navigator.of(context).pop();
                   controller.deleteTodyMenu(id);
                 },
                 child: const Text('YES',style: TextStyle(color:Colors.blue),),
                 isDefaultAction: false,
                 isDestructiveAction: false,
               )
             ],
           );
         });
   }

   showDailog(BuildContext context) {
     controller.etEmail.text="";
     final  GlobalKey<FormState> formKey=GlobalKey<FormState>();
     return AlertDialog(
       elevation: 10,
       contentPadding: EdgeInsets.only(top: 20,bottom: 10,left: 8,right: 8),
       // backgroundColor: backgroundColor,           // Icon(Icons.close,color: Cors.lored,)
       title:Row(
         mainAxisAlignment: MainAxisAlignment.spaceBetween,
         children: [
           Text(
             widget.title,
             style: Theme.of(context).textTheme.headline4!,
           ),
         ],

       ) ,
       actions: [
         ElevatedButton(
             style: ElevatedButton.styleFrom(backgroundColor: Colors.grey),
             onPressed: (){
               Get.back();
             }, child: Text("Cancel")),
         ElevatedButton(
             style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
             onPressed: (){
               if(formKey.currentState!.validate())
               {
                 controller.getDevoteeDetails().then((value) {
                   if(value==true)
                   {
                     Get.back();
                     showDialog(context: context, builder: (context)=>showDailogPaymentmode(context),
                        barrierDismissible:false
                    );
                   }
                 }

                 );

               }


             }, child: Text("Continue")),

       ],
       content: StatefulBuilder(
         builder: (BuildContext context, StateSetter setState) {
           return SingleChildScrollView(
             child: Column(
               mainAxisSize: MainAxisSize.min,
               children: [

                 Form(
                   key: formKey,
                   child: EditTextWidget(
                     maxLength: 200,
                     hint: "Enter Email",
                     isPassword: false,
                     keyboardtype: TextInputType.text,
                     label: "Devotee Email",
                     validator: (value) {

                       if (value == null || value.isEmpty) {
                         return 'Please Enter Email';
                       } if (!isValidEmail(value.toString())) {
                         return 'Please Enter Valid Email';
                       }
                       return null;
                     },
                     controller:controller.etEmail,
                     maxline: 1,
                   ),
                 ),
                 SizedBox(height: 4,),
                 Column(
                     children: List.generate(controller.alldata.length, (index) =>
             Container(
               color: Colors.grey.withOpacity(.2),
               margin: EdgeInsets.only(top: 5),
               child: ListTile(
                 dense: true,
                 title: Text(
                   controller.alldata[index]["serviceName"],
                   style: Theme.of(context).textTheme.bodyText1!,
                 ) ,
                 trailing:Text(
                   "\$ "+controller.alldata[index]["serviceAmount"],
                   style: Theme.of(context).textTheme.bodyText1!,
                 ),
               ),
             ),
                     ),
                 ),
                 // Container(
                 //   color: Colors.grey.withOpacity(.2),
                 //   child: ListTile(
                 //     dense: true,
                 //     title: Text(
                 //      datas.refDataName!,
                 //       style: Theme.of(context).textTheme.bodyText1!,
                 //     ) ,
                 //   ),
                 // ),
                 SizedBox(
                   height: 10,
                 ),
                 Container(
                   alignment: Alignment.bottomCenter,

                   child: Column(
                     crossAxisAlignment: CrossAxisAlignment.center,
                     mainAxisAlignment: MainAxisAlignment.end,
                     children: [
                       Container(
                         color: Colors.grey.withOpacity(.2),
                         padding: EdgeInsets.all(8),
                         child: Row(
                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                           children: [
                             Text(
                               "  Total Amount ",
                               style: Theme.of(context)
                                   .textTheme
                                   .bodyText1!
                                   .copyWith(
                                   fontSize: 14,
                                   fontWeight: FontWeight.w500),
                             ),
                             Text("\$ "+double.parse(controller.totalAmount.value).toStringAsFixed(2) ,
                               style: Theme.of(context)
                                   .textTheme
                                   .bodyText1!
                                   .copyWith(
                                   fontSize: 17,
                                   fontWeight: FontWeight.w600,color: Colors.amber),
                            ),
                           ],
                         ),
                       ),

                     ],
                   ),
                 ),
               ],
             ),
           );
         },
       ),
     );
   }

   showDailogPaymentmode(BuildContext context) {
     bool _value = false;
     int val = -1;
     String? _selectedmethod = "cash";
     return AlertDialog(
       // backgroundColor: backgroundColor,
       elevation: 10,
       content: Container(
         child: Column(
           mainAxisSize: MainAxisSize.min,
           children: [
             Text(
               "Select Payment Method",
               style: Theme.of(context).textTheme.headline4,
             ),
             SizedBox(
               height: 15,
             ),
             Text(
               "Amount to Pay",
               style: Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 16, fontWeight: FontWeight.w500), textAlign: TextAlign.center,
             ),
             SizedBox(
               height: 15,
             ),
             Text(
               "\$ "+ controller.totalAmount.value,
               style: Theme.of(context).textTheme.bodyText1!.copyWith(
                   color: Colors.amber,
                   fontSize: 20,
                   fontWeight: FontWeight.w500),
               textAlign: TextAlign.center,
             ),
             SizedBox(
               height: 20,
             ),
             Row(
               mainAxisAlignment: MainAxisAlignment.center,
               children: [
                 ElevatedButton(
                     style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                     onPressed: (){
                       controller.addServiceData("CASH");
                     }, child: Text(" CASH ")),
                 SizedBox(width: 10,),
                 ElevatedButton(
                     style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                     onPressed: (){
                       showDialog(context: context, builder: (context)=>showDailogCheck());
                     }, child: Text("CHECK")),



               ],
             ),
             ElevatedButton(
                 style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                 onPressed: (){
                   Get.snackbar("Alert!", "Credit Card Payment Method Comming Soon.",borderRadius: 2,backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.black12]));
                 }, child: Text("CREDIT CARD")),
           ],
         ),
       ),
     );
   }

   showDailogCheck() {
     controller.etAmount.text=controller.totalAmount.value;
     final GlobalKey<FormState> formKey=GlobalKey<FormState>();
     return AlertDialog(
         content: StatefulBuilder(
           builder: (BuildContext context, StateSetter setState) {
             return SingleChildScrollView(
                 scrollDirection: Axis.vertical,
                 child: Form(
                   key: formKey,
                   child: Column(
                     children: [
                       Text("Check Details",
                           style: Theme.of(context)
                               .textTheme
                               .headline4!),
                       SizedBox(
                         height: 20,
                       ),
                       EditTextWidget(
                         maxLength: 200,
                         hint: "Check Number",
                         isPassword: false,
                         keyboardtype: TextInputType.text,
                         label: "Check Number",
                         validator: (value) {
                           if (value == null || value.isEmpty) {
                             return 'Please Enter Check Number';
                           }
                           return null;
                         },
                         controller: controller.etCheckNo,
                         maxline: 1,
                       ),
                       EditTextWidget(
                         maxLength: 200,
                         hint: "Check Amount",
                         isPassword: false,
                         keyboardtype: TextInputType.number,
                         label: "Check Amount",
                         validator: (value) {

                           if (value == null || value.isEmpty) {
                             return 'Please Enter Amount';
                           }
                           return null;
                         },
                         isRead: true,
                         controller: controller.etAmount,
                         maxline: 1,
                       ),
                       EditTextWidget(
                         maxLength: 200,
                         hint: "Bank Detail",
                         isPassword: false,
                         keyboardtype: TextInputType.text,
                         label: "Bank Detail",
                         validator: (value) {

                           if (value == null || value.isEmpty) {
                             return 'Please Enter Bank Detail';
                           }
                           return null;
                         },
                         controller: controller.etBankDetails,
                         maxline: 1,
                       ),





                       SizedBox(

                         child: InkWell(
                           onTap: () async {
                             final DateTime? picked= await  showDatePicker(
                                 context: context,
                                 initialDate:DateTime.now(),
                                 firstDate: DateTime(2015),
                                 lastDate: DateTime(2100),
                                 builder: (context, child) {
                                   return Theme(
                                     data: ThemeData.dark().copyWith(
                                         colorScheme: const ColorScheme.dark(
                                             onPrimary: Colors.white,
                                             // selected text color
                                             onSurface: Colors.white,
                                             // default text color
                                             primary: Colors
                                                 .teal // circle color
                                         ),
                                         dialogBackgroundColor: Theme
                                             .of(context)
                                             .backgroundColor,

                                         textButtonTheme: TextButtonThemeData(
                                             style: TextButton.styleFrom(
                                                 textStyle: const TextStyle(
                                                     color: Colors.white,
                                                     fontWeight: FontWeight
                                                         .normal,
                                                     fontSize: 12,
                                                     fontFamily: 'Quicksand'),
                                                 primary: Colors.white,
                                                 // color of button's letters
                                                 backgroundColor: Colors
                                                     .black54,
                                                 // Background color
                                                 shape: RoundedRectangleBorder(
                                                     side: const BorderSide(
                                                         color: Colors
                                                             .transparent,
                                                         width: 1,
                                                         style: BorderStyle
                                                             .solid),
                                                     borderRadius: BorderRadius
                                                         .circular(50))))),

                                     child: child!,
                                   );
                                 }

                             );

                             final String formatted = formatter.format(picked!);
                             controller.etDate.text=formatted;

                           },
                           child:  AbsorbPointer(
                             child: EditTextWidget(
                               maxLength: 200,
                               hint: "Date",
                               isPassword: false,
                               keyboardtype: TextInputType.text,
                               label: "Date",
                               validator: (value) {

                                 if (value == null || value.isEmpty) {
                                   return 'Please Select Bank Date';
                                 }
                                 return null;
                               },
                               controller: controller.etDate,
                               maxline: 1,
                             ),
                           ),
                         ),
                       ),
                       SizedBox(
                         height: 10,
                       ),
                       Row(
                         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                         children: [
                           ButtonWidget(
                             btnName: 'Cancel',
                             onPress: () {
                               Navigator.of(context).pop();
                             },
                             minWidth: 100,
                           ),
                           ButtonWidget(
                             btnName: 'Proceed',
                             onPress: () {
                               if(formKey.currentState!.validate())
                               {
                                controller.addServiceData("CHECK");
                               }
                             },
                             minWidth: 100,
                           ),
                         ],
                       ),
                     ],
                   ),
                 ));
           },
         ));
   }
}
