
import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/UtilMethods/BaseController.dart';
import 'package:aspgen_mobile/UtilMethods/base_client.dart';
import 'package:dart_des/dart_des.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../UtilMethods/dailog_healper.dart';
import '../Model/AllContactDatas.dart';

class ContactController extends GetxController {
  RxList<ContactDatum> allContactDatas= RxList<ContactDatum>([]);
  ScrollController controller = ScrollController();
  TextEditingController etSearch=new TextEditingController();
  int skip=1;
  int next = 50;
  var bodyJson={};
  var bodyJson1={};
  RxBool isLoading=false.obs;
  RxBool isLoadMore=false.obs;
  RxBool isSerching=false.obs;
  List<ContactDatum> get allContactData=>allContactDatas.value;
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":"Contacts",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip":0,
      "next":next
    };
    print("djbvkshv");
    print(bodyJson);
  //  fetchApi(bodyJson);
    addItems();
    super.onInit();
  }
  addItems() async {
    print("djbvkshv");
    print(bodyJson);
    controller.addListener(() {
      if (controller.position.maxScrollExtent == controller.position.pixels) {
          skip=next;
          next+=50;
        bodyJson1["componentConfig"]={
          "moduleName":"Contacts",
          "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
          "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
          "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
          "skip":skip,
          "next":next
        };
        if(isLoading.value){
          isLoadMore.value=true;
          fetchApi(bodyJson1);
        }

      }
    });
  }
  fetchApi(var bodyJson)async{
    isLoadMore.value==false? Get.context!.loaderOverlay.show():"";
       var response=await BaseClient().post(APIsConstant.getAPI, bodyJson).catchError(BaseController().handleError);
       Get.context!.loaderOverlay.hide();
      if(response==null) return;
       if(jsonDecode(response)["statusCode"].toString()=="-1") return;
       if(AllContactDatas.fromJson(jsonDecode(response)).data!.isNotEmpty)
         {
           if( isLoadMore.value==false)
             {
               allContactDatas.value=AllContactDatas.fromJson(jsonDecode(response)).data!;
             }
           else{
             AllContactDatas.fromJson(jsonDecode(response)).data!.forEach((element) {
               allContactDatas.value.add(element);
             });
           }
           isLoading.value=true;
           isLoadMore.value=false;
         }
       else{
         isLoading.value=false;
         isLoadMore.value=false;
         Fluttertoast.showToast(msg: "No more data");
       }
    isSerching.value=false;
       print("dsvnjndsjkbvjdkk");
       print(response);


   update();
  }
  fetchFilterApi(String text) async{
    var request={
      "text": text,
      "componentConfig": {
        "moduleName":"Contacts",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    Get.context!.loaderOverlay.show();
    print(request);
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
          if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    allContactDatas.value=allContactDatasFromJson(response).data!;
          isSerching.value=true;
          update();

  }
}