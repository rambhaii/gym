// To parse this JSON data, do
//
//     final contactData = contactDataFromJson(jsonString);

import 'dart:convert';

ContactData contactDataFromJson(String str) => ContactData.fromJson(json.decode(str));

String contactDataToJson(ContactData data) => json.encode(data.toJson());

class ContactData {
  ContactData({
    this.data,
  });
  List<ContactDataDatum>?data;
  factory ContactData.fromJson(Map<String, dynamic> json) => ContactData(
    data: List<ContactDataDatum>.from(json["data"].map((x) => ContactDataDatum.fromJson(x))),
  );
  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class ContactDataDatum {
  ContactDataDatum({
    this.id,
    this.name,
    this.type,
    this.phone,
    this.flutterPhone,
    this.contactName,
    this.title,
    this.email,
    this.flutterEmail,
    this.spouseName,
    this.spousePhone,
    this.spouseEmail,
    this.flutterSpousePhone,
    this.flutterSpouseEmail,
    this.zip,
    this.city,
    this.state,
    this.address,
    this.companyName,
    this.companyEmail,
    this.companyPhone,
    this.flutterCompanyEmail,
    this.flutterCompanyPhone,
    this.website,
  });

  String?id;
  String ?name;
  String ?type;
  String ?phone;
  String ?flutterPhone;
  String ?contactName;
  String ?title;
  String ?email;
  String ?flutterEmail;
  String ?spouseName;
  String ?spousePhone;
  String ?spouseEmail;
  String ?flutterSpousePhone;
  String ?flutterSpouseEmail;
  String ?zip;
  String ?city;
  String ?state;
  String ?address;
  String ?companyName;
  String ?companyEmail;
  String ?companyPhone;
  String ?flutterCompanyEmail;
  String ?flutterCompanyPhone;
  String ?website;

  factory ContactDataDatum.fromJson(Map<String, dynamic> json) => ContactDataDatum(
    id: json["_id"],
    name: json["name"],
    type: json["type"],
    phone: json["phone"],
    flutterPhone: json["flutterPhone"],
    contactName: json["contactName"],
    title: json["title"],
    email: json["email"],
    flutterEmail: json["flutterEmail"],
    spouseName: json["spouseName"],
    spousePhone: json["spousePhone"],
    spouseEmail: json["spouseEmail"],
    flutterSpousePhone: json["flutterSpousePhone"],
    flutterSpouseEmail: json["flutterSpouseEmail"],
    zip: json["zip"],
    city: json["city"],
    state: json["state"],
    address: json["address"],
    companyName: json["companyName"],
    companyEmail: json["companyEmail"],
    companyPhone: json["companyPhone"],
    flutterCompanyEmail: json["flutterCompanyEmail"],
    flutterCompanyPhone: json["flutterCompanyPhone"],
    website: json["website"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "name": name,
    "type": type,
    "phone": phone,
    "flutterPhone": flutterPhone,
    "contactName": contactName,
    "title": title,
    "email": email,
    "flutterEmail": flutterEmail,
    "spouseName": spouseName,
    "spousePhone": spousePhone,
    "spouseEmail": spouseEmail,
    "flutterSpousePhone": flutterSpousePhone,
    "flutterSpouseEmail": flutterSpouseEmail,
    "zip": zip,
    "city": city,
    "state": state,
    "address": address,
    "companyName": companyName,
    "companyEmail": companyEmail,
    "companyPhone": companyPhone,
    "flutterCompanyEmail": flutterCompanyEmail,
    "flutterCompanyPhone": flutterCompanyPhone,
    "website": website,
  };
}
