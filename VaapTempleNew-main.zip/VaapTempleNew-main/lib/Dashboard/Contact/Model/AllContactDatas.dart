// To parse this JSON data, do
//
//     final allContactDatas = allContactDatasFromJson(jsonString);

import 'dart:convert';

import 'package:flutter/material.dart';

AllContactDatas allContactDatasFromJson(String str) => AllContactDatas.fromJson(json.decode(str));
String allContactDatasToJson(AllContactDatas data) => json.encode(data.toJson());

class AllContactDatas {
  AllContactDatas({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<ContactDatum>? data;

  factory AllContactDatas.fromJson(Map<String, dynamic> json) => AllContactDatas(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<ContactDatum>.from(json["data"].map((x) => ContactDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class ContactDatum {
  ContactDatum({
    this.id,
    this.memberName,
    this.refDataName,
    this.memberTypes,
    this.phone,
    this.title,
    this.spouseEmail,
    this.spousePhone,
    this.stateTypes,
    this.cityTypes,
    this.spouseName,
    this.address,
    this.zip,
    this.companyName,
    this.companyEmail,
    this.companyPhone,
    this.website,
    this.email,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.isCheckList,
    this.image,
    this.isSelected,
    this.memberDetail,
    this.gotra,
    this.Nakshtra,
    this.spouseNakshtra,
    this.dob,
    this.phoneCallPref,
    this.smsPref,
    this.emailPref,
    this.companyTitle,
    this.county,
    this.addressLine1,
    this.addressLine2,
    this.spouseRashi,
    this.spouseGotra,
    this.status,
    this.businessDomain,


  });

  String ?id;
  String ?memberName;
  String ?refDataName;
  String ?gotra;
  String ?Nakshtra;
  String ?memberTypes;
  String ?phone;
  String ?title;
  String ?spouseEmail;
  String ?spousePhone;
  String ?stateTypes;
  String ?cityTypes;
  String ?spouseName;
  String ?spouseNakshtra;
  String ?address;
  String ?zip;
  String ?ip;
  List<MemberDetail>? memberDetail;
  String ?companyName;
  String ?companyEmail;
  String ?companyPhone;
  String ?website;
  String ?email;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  String ?county;
  String ?addressLine1;
  String ?addressLine2;
  String ?dob;
  bool ?isCheckList;
  bool ?isSelected;
  bool ?emailPref;
  bool ?phoneCallPref;
  bool ?smsPref;
  String ?image;
  String ?companyTitle;
  String ?spouseGotra;

  String ?spouseRashi;
  String ?businessDomain;
  String ?status;


  factory ContactDatum.fromJson(Map<String, dynamic> json) => ContactDatum(
    id: json["_id"]??"",
    memberName: json["memberName"]??"",
    refDataName: json["refDataName"]??"",
    Nakshtra: json["Nakshtra"]??"",
    gotra: json["gotra"]??"",
    companyTitle: json["companyTitle"]??"",
    spouseNakshtra: json["spouseNakshtra"]??"",
    memberTypes: json["memberTypes"]??"",
    phone: json["phone"]??"",
    title: json["title"]??"",
    county: json["county"]??"",
    businessDomain: json["businessDomain"]??"",
    dob: json["dob"]??"",
    addressLine1: json["addressLine1"]??"",
    addressLine2: json["addressLine2"]??"",
    spouseEmail: json["spouseEmail"]??"",
    spousePhone: json["spousePhone"]??"",
    stateTypes: json["stateTypes"]??"",
    cityTypes: json["cityTypes"]??"",
    spouseName: json["spouseName"]??"",
    spouseGotra: json["spouseGotra"]??"",
    spouseRashi: json["spouseRashi"]??"",
    status: json["status"]??"",

    address: json["address"]??"",
    zip: json["zip"]??"",
    companyName: json["companyName"]??"",
    companyEmail: json["companyEmail"]??"",
    companyPhone: json["companyPhone"]??"",
    website: json["website"]??"",
    email: json["email"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    image: json["image"]??"",
    phoneCallPref: json["phoneCallPref"]??false,
    emailPref: json["emailPref"]??false,
    smsPref: json["smsPref"]??false,
    memberDetail:  List<MemberDetail>.from((json["memberDetail"]??[]).map((x) => MemberDetail.fromJson(x))),

    isCheckList:false,
    isSelected:false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "memberName": memberName,
    "refDataName": refDataName,
    "addressLine1": addressLine1,
    "addressLine2": addressLine2,
    "memberTypes": memberTypes,
    "phone": phone,
    "title": title,
    "dob": dob,
    "county": county,
    "status": status,
    "emailPref": emailPref,
    "smsPref": smsPref,
    "phoneCallPref": phoneCallPref,
    "spouseNakshtra": spouseNakshtra,
    "spouseGotra": spouseGotra,
    "spouseRashi": spouseRashi,
    "spouseEmail": spouseEmail,
    "businessDomain": businessDomain,
    "Nakshtra": Nakshtra,
    "gotra": gotra,
    "companyTitle": companyTitle,
    "spousePhone": spousePhone,
    "stateTypes": stateTypes,
    "cityTypes": cityTypes,
    "spouseName": spouseName,
    "address": address,
    "zip": zip,
    "companyName": companyName,
    "companyEmail": companyEmail,
    "companyPhone": companyPhone,
    "website": website,
    "email": email,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "isCheck":isCheckList,
    "image":image,
    "memberDetail": List<dynamic>.from(memberDetail!.map((x) => x.toJson())),
    "isSelected":isSelected,
  };
}
class MemberDetail {
  MemberDetail({
    this.memberName,
    this.nakshatra,
    this.rashi,
    this.relationship,
    this.dob,
    this.anniversaryDate,
  });

  String ?memberName;
  String ?nakshatra;
  String ?rashi;
  String ?relationship;
  String ?dob;
  String ?anniversaryDate;

  factory MemberDetail.fromJson(Map<String, dynamic> json) => MemberDetail(
    memberName: json["memberName"]??"",
    nakshatra: json["nakshatra"]??"",
    rashi: json["rashi"]??"",
    relationship: json["relationship"]??"",
    dob: json["dob"]??"",
    anniversaryDate: json["anniversaryDate"]??"",
  );

  Map<String, dynamic> toJson() => {
    "memberName": memberName,
    "nakshatra": nakshatra,
    "rashi": rashi,
    "anniversaryDate": anniversaryDate,
    "dob": dob,
    "relationship": relationship,
  };
}
