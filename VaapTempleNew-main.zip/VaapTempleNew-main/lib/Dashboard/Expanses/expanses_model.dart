// To parse this JSON data, do
//
//     final expansesData = expansesDataFromJson(jsonString);

import 'dart:convert';

ExpansesData expansesDataFromJson(String str) => ExpansesData.fromJson(json.decode(str));

String expansesDataToJson(ExpansesData data) => json.encode(data.toJson());

class ExpansesData {
  ExpansesData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<Datum>? data;

  factory ExpansesData.fromJson(Map<String, dynamic> json) => ExpansesData(
    statusCode: json["statusCode"]??"",
    message: json["message"]??"",
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.expenseName,
    this.expenseCode,
    this.expenseCategory,
    this.expenseType,
    this.expenseStatus,
    this.expenseSubmittedBy,
    this.expenseDescription,
    this.expenseRemarks,
    this.expenseVendorName,
    this.expenseVendorLocation,
    this.expenseImage,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.isChecked,
    this.expenseAmount,
  });

  String? id;
  String? expenseName;
  String? expenseCode;
  String? expenseCategory;
  String? expenseType;
  String? expenseStatus;
  String? expenseSubmittedBy;
  String?expenseDescription;
  String? expenseRemarks;
  String? expenseVendorName;
  String? expenseVendorLocation;
  String? expenseImage;
  String? moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  bool ?isChecked;
  String ?expenseAmount;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"]??"",
    expenseName: json["expenseName"]??"",
    expenseCode: json["expenseCode"]??"",
    expenseCategory: json["expenseCategory"]??"",
    expenseType: json["expenseType"]??"",
    expenseStatus: json["expenseStatus"]??"",
    expenseSubmittedBy: json["expenseSubmittedBy"]??"",
    expenseDescription: json["expenseDescription"]??"",
    expenseRemarks: json["expenseRemarks"]??"",
    expenseVendorName: json["expenseVendorName"]??"",
    expenseVendorLocation: json["expenseVendorLocation"]??"",
    expenseImage: json["expenseImage"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    expenseAmount: json["expenseAmount"]??"",
    isChecked: false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "expenseName": expenseName,
    "expenseCode": expenseCode,
    "expenseCategory": expenseCategory,
    "expenseType": expenseType,
    "expenseStatus": expenseStatus,
    "expenseSubmittedBy": expenseSubmittedBy,
    "expenseDescription": expenseDescription,
    "expenseRemarks": expenseRemarks,
    "expenseVendorName": expenseVendorName,
    "expenseVendorLocation": expenseVendorLocation,
    "expenseImage": expenseImage,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "isChecked": isChecked,
    "expenseAmount": expenseAmount,
  };
}
