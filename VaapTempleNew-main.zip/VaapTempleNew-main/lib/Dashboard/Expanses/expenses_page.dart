import 'dart:convert';
import 'dart:io';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/Dashboard/Expanses/expenses_controller.dart';
import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';

import '../../AppConstant/TextStyle.dart';
import '../../Templates/fieldPageNew.dart';
import '../../UtilMethods/RemoteServices.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListView.dart';
import '../../Widget/SearchBarWidget.dart';
import '../inventory_page/controller.dart';



class ExpansesPage extends StatefulWidget {
   final String title;
  const ExpansesPage({Key? key, required this.title}) : super(key: key);

  @override
  _ExpansesPageState createState() => _ExpansesPageState();
}

class _ExpansesPageState extends State<ExpansesPage> {

  TextEditingController etsearch= new TextEditingController();
  late ExpansesController controller;
  DateTime?tempDate;
  @override
  void initState() {
    controller=Get.put(ExpansesController("Expenses"));
    // TODO: implement initState

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
         widget.title,
        ),
        actions: [
          Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            CheckInternetConnection().then((value1) => value1==true? Get.to(()=>FieldPageNew(title:"Expenses",type: 1,)):"");
          }
          ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        )
        ],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),

        child: Column(
          children: [
            SizedBox(height: 10,),
            GetBuilder<ExpansesController>(
              builder: (controller)=>  SearchBarWidget(
                hint: "Search",
                controller: controller.etSearch,
                onchange: (value){
                  value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi():"";
                  controller.update();
                },
                onCancel: (){
                  controller.etSearch.clear();
                  controller.fetchApi();
                  controller.update();
                },
              ),
            ),
            SizedBox(height:4,),
            Obx(() => controller.expansesData.value.data!=null?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {
                    controller.fetchApi();
                  });
                },
                child: ListView.builder(
                    itemCount:controller.expansesData.value.data!.length,
                    itemBuilder: (context,index)
                    {
                      final datum=controller.expansesData.value.data![index];
                      String amount="";
                     try{
                       amount=  double.parse(datum.expenseAmount!.isEmpty?"0":datum.expenseAmount!).toStringAsFixed(2);
                     }catch(e){
                      amount="0.00" ;
                     }
                      print(datum.expenseAmount);
                      return  CustomListWidget(
                        title: datum.expenseName!,
                        subTitle: datum.expenseCategory??"",
                        subTitle2: "\$ "+amount,
                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              if(datum.expenseImage!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.expenseImage!.isNotEmpty)GestureDetector(
                                  onTap: (){

                                 UtilMethods.urlLuncher(APIsConstant.IP_Base_Url+datum.expenseImage!);
                                  },
                                  child: Column(
                                    children: [
                                     Text("Document :    "),
                                      Icon(Icons.visibility_rounded,color: Colors.green,size: 18,),
                                      Text(" View",style: Theme.of(context).textTheme.bodyText1!.copyWith(color: Colors.green,decoration: TextDecoration.underline,fontSize: 14)),],
                                  ),
                                ),
                              if(datum.expenseCode!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.expenseCode!.isNotEmpty) viewMore("Code  ",datum.expenseCode??""),
                              if(datum.expenseRemarks!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.expenseRemarks!.isNotEmpty) viewMore("Notes  ",datum.expenseRemarks??""),
                            ]),
                        isClicked: datum.isChecked??false,
                        onTapVieMore: (){
                          datum.isChecked=!datum.isChecked!;
                          controller.expansesData.refresh();
                        },
                        editOnTap: (){
                          CheckInternetConnection().then((value) {
                            if(value==true)
                            {
                              CheckInternetConnection().then((value1) => value1==true?Get.to(()=>FieldPageNew(title: "Expenses",type: 2,id: datum.id!),arguments: {"data": json.decode(json.encode(datum))}):"");
                            }
                          });
                        }, textEditingController: controller.etSearch,
                      );
                    }
                    ),
              ),
            ):Container(),
            )
          ],
        ),
      ),

    );
  }
}
