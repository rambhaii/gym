// To parse this JSON data, do
//
//     final assetsMgmtDataDetails = assetsMgmtDataDetailsFromJson(jsonString);

import 'dart:convert';

AssetsMgmtDataDetails assetsMgmtDataDetailsFromJson(String str) => AssetsMgmtDataDetails.fromJson(json.decode(str));

String assetsMgmtDataDetailsToJson(AssetsMgmtDataDetails data) => json.encode(data.toJson());

class AssetsMgmtDataDetails {
  AssetsMgmtDataDetails({
    this.data,
    this.success,
  });

  List<AssetsMgmtDataDetailsDatum>?data;
  bool ?success;

  factory AssetsMgmtDataDetails.fromJson(Map<String, dynamic> json) => AssetsMgmtDataDetails(
    data: List<AssetsMgmtDataDetailsDatum>.from(json["data"].map((x) => AssetsMgmtDataDetailsDatum.fromJson(x))),
    success: json["success"],
  );

  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
    "success": success,
  };
}

class AssetsMgmtDataDetailsDatum {
  AssetsMgmtDataDetailsDatum({
    this.id,
    this.assetName,
    this.status,
    this.category,
    this.type,
    this.assetId,
    this.modelNo,
    this.make,
    this.brand,
    this.color,
    this.year,
    this.ownerFirstName,
    this.ownerLastName,
    this.ownerPhone,
    this.ownerEmail,
    this.ownerFax,
    this.location,
    this.firstRegDate,
    this.assetAssignDate,
    this.memberName,
    this.vendorName,
    this.vendorPhone,
    this.vendorEmail,
    this.specification,
  });

  String ?id;
  String ?assetName;
  String ?status;
  String ?category;
  String ?type;
  String ?assetId;
  String ?modelNo;
  String ?make;
  String ?brand;
  String ?color;
  String ?year;
  String ?ownerFirstName;
  String ?ownerLastName;
  String ?ownerPhone;
  String ?ownerEmail;
  String ?ownerFax;
  String ?location;
  String ?firstRegDate;
  String ?assetAssignDate;
  String ?memberName;
  String ?vendorName;
  String ?vendorPhone;
  String ?vendorEmail;
  String ?specification;

  factory AssetsMgmtDataDetailsDatum.fromJson(Map<String, dynamic> json) => AssetsMgmtDataDetailsDatum(
    id: json["_id"],
    assetName: json["assetName"],
    status: json["status"],
    category: json["category"],
    type: json["type"],
    assetId: json["assetId"],
    modelNo: json["modelNo"],
    make: json["make"],
    brand: json["brand"],
    color: json["color"],
    year: json["year"],
    ownerFirstName: json["ownerFirstName"],
    ownerLastName: json["ownerLastName"],
    ownerPhone: json["ownerPhone"],
    ownerEmail: json["ownerEmail"],
    ownerFax: json["ownerFax"],
    location: json["location"],
    firstRegDate: json["firstRegDate"],
    assetAssignDate: json["assetAssignDate"],
    memberName: json["memberName"],
    vendorName: json["vendorName"],
    vendorPhone: json["vendorPhone"],
    vendorEmail: json["vendorEmail"],
    specification: json["specification"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "assetName": assetName,
    "status": status,
    "category": category,
    "type": type,
    "assetId": assetId,
    "modelNo": modelNo,
    "make": make,
    "brand": brand,
    "color": color,
    "year": year,
    "ownerFirstName": ownerFirstName,
    "ownerLastName": ownerLastName,
    "ownerPhone": ownerPhone,
    "ownerEmail": ownerEmail,
    "ownerFax": ownerFax,
    "location": location,
    "firstRegDate": firstRegDate,
    "assetAssignDate": assetAssignDate,
    "memberName": memberName,
    "vendorName": vendorName,
    "vendorPhone": vendorPhone,
    "vendorEmail": vendorEmail,
    "specification": specification,
  };
}
