// To parse this JSON data, do
//
//     final assetData = assetDataFromJson(jsonString);

import 'dart:convert';

AssetData assetDataFromJson(String str) => AssetData.fromJson(json.decode(str));

String assetDataToJson(AssetData data) => json.encode(data.toJson());

class AssetData {
  AssetData({
    this.statusCode,
    this.message,
    this.data,
  });

  String? statusCode;
  String? message;
  List<Datum>? data;

  factory AssetData.fromJson(Map<String, dynamic> json) => AssetData(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.assetName,
    this.modelNo,
    this.assetCategory,
    this.specification,
    this.purchasedDate,
    this.registrationDate,
    this.purchasePrice,
    this.assignedTo,
    this.assignedEmail,
    this.assignedPhone,
    this.vendorName,
    this.vendorEmail,
    this.vendorPhone,
    this.status,
    this.brand,
    this.color,
    this.expiryDate,
    this.make,
    this.warranty,
    this.type,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.isChecked,
  });

  String ?id;
  String ?assetName;
  String ?modelNo;
  String ?assetCategory;
  String ?specification;
  String ?purchasedDate;
  String ?registrationDate;
  String ?purchasePrice;
  String ?assignedTo;
  String ?assignedEmail;
  String ?assignedPhone;
  String ?vendorName;
  String ?vendorEmail;
  String ?vendorPhone;
  String ?status;
  String ?brand;
  String ?color;
  String ?expiryDate;
  String ?make;
  String ?warranty;
  String ?type;
  String ?moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  bool ?isChecked;
  String ?recModDate;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"],
    assetName: json["assetName"]??"",
    modelNo: json["modelNo"]??"",
    assetCategory: json["assetCategory"]??"",
    specification: json["specification"]??"",
    purchasedDate: json["purchasedDate"]??"",
    registrationDate: json["registrationDate"]??"",
    purchasePrice: json["purchasePrice"]??"",
    assignedTo: json["assignedTo"]??"",
    assignedEmail: json["assignedEmail"]??"",
    assignedPhone: json["assignedPhone"]??"",
    vendorName: json["vendorName"]??"",
    vendorEmail: json["vendorEmail"]??"",
    vendorPhone: json["vendorPhone"]??"",
    status: json["status"]??"",
    brand: json["brand"]??"",
    color: json["color"]??"",
    expiryDate: json["expiryDate"]??"",
    make: json["make"]??"",
    warranty: json["warranty"]??"",
    type: json["type"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    isChecked: false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "assetName": assetName,
    "modelNo": modelNo,
    "assetCategory": assetCategory,
    "specification": specification,
    "purchasedDate": purchasedDate,
    "registrationDate": registrationDate,
    "purchasePrice": purchasePrice,
    "assignedTo": assignedTo,
    "assignedEmail": assignedEmail,
    "assignedPhone": assignedPhone,
    "vendorName": vendorName,
    "vendorEmail": vendorEmail,
    "vendorPhone": vendorPhone,
    "status": status,
    "brand": brand,
    "color": color,
    "expiryDate": expiryDate,
    "make": make,
    "warranty": warranty,
    "type": type,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "isChecked": isChecked,
  };
}
