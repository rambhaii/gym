import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/Dashboard/AssetsManagemant/asset_controller.dart';
import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

import '../../AppConstant/TextStyle.dart';
import '../../Templates/fieldPageNew.dart';
import '../../UtilMethods/RemoteServices.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListView.dart';
import '../../Widget/SearchBarWidget.dart';



class AssetPage extends StatefulWidget {
final String title;
  const AssetPage({Key? key, required this.title}) : super(key: key);

  @override
  _AssetPageState createState() => _AssetPageState();
}

class _AssetPageState extends State<AssetPage> {

  TextEditingController etsearch= new TextEditingController();
  late AssetController _controller;
  DateTime?tempDate;
  @override
  void initState() {
    _controller=Get.put(AssetController(widget.title));
    // TODO: implement initState

    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
         widget.title,
        ),
        actions: [  Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            CheckInternetConnection().then((value1) => value1==true? Get.to(()=>FieldPageNew(title: widget.title,type: 1,)):"");
          }
            ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        )],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),

        child: Column(
          children: [
            SizedBox(height: 10,),
            GetBuilder<AssetController>(
              builder: (controller)=>  SearchBarWidget(
                hint: "Search",
                controller: controller.etSearch,
                onchange: (value){
                  value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi():"";
                  controller.update();
                },
                onCancel: (){
                  controller.etSearch.clear();
                  controller.fetchApi();
                  controller.update();
                },
              ),
            ),
            SizedBox(height: 8,),
            Obx(() => _controller.datas.value.data!=null?Expanded(
              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {
                    _controller.fetchApi();
                  });
                },
                child: ListView.builder(
                    itemCount:_controller.datas.value.data!.length,
                    itemBuilder: (context,index)
                    {

                      final datum=_controller.datas.value.data![index];
                      print("jxbkjdbj");
                      print(datum.purchasePrice!);
                      return CustomListWidget(title: datum.assetName??"",
                        subTitle: "\$ "+double.parse(datum.purchasePrice!.isNotEmpty?datum.purchasePrice!:"0.0").toStringAsFixed(2),

                        viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children:[
                              if(datum.status!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.status!.isNotEmpty) viewMore("Status  ",datum.status??""),
                              if(datum.modelNo!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                              if(datum.modelNo!.isNotEmpty) viewMore("Model No  ",datum.modelNo??""),
                              if(datum.purchasedDate!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.3),),
                              if(datum.purchasedDate!.isNotEmpty)  viewMore("Purchase Date",datum.purchasedDate??""),
                            ]),
                        textEditingController: _controller.etSearch,isClicked: datum.isChecked??false,
                        onTapVieMore: (){
                          datum.isChecked=!datum.isChecked!;
                          _controller.datas.refresh();
                        },
                        editOnTap: (){
                        Get.to(()=>FieldPageNew(title: widget.title,type: 2,id: datum.id,),arguments: {"data": json.decode(json.encode(datum))});

                        },
                      );
                      //   Container(
                      //   margin: EdgeInsets.only(left: 10,top: 10,right: 10,bottom: 1),
                      //   padding: EdgeInsets.all(8),
                      //   decoration: BoxDecoration(
                      //     boxShadow: [
                      //       BoxShadow(
                      //         color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                      //         offset: Offset(-1.0, -1.0),
                      //         blurRadius: 1.0,
                      //       ),
                      //       BoxShadow(
                      //         color: Colors.black.withOpacity(0.2),
                      //         offset: Offset(2.0, 2.0),
                      //         blurRadius: 1.0,
                      //       ),
                      //     ],
                      //     color: Theme.of (context).colorScheme.onPrimaryContainer,
                      //     borderRadius: BorderRadius.circular(5.0),
                      //   ),
                      //   child: Stack(
                      //     children: [
                      //       Column(
                      //         children: [
                      //           Row(
                      //             mainAxisAlignment:MainAxisAlignment.start,
                      //             children: [
                      //               Text("Assets Name ",style:Theme.of(context).textTheme.bodyText2,),
                      //             ],
                      //           ),
                      //           SizedBox(height: 5,),
                      //           Row(
                      //             mainAxisAlignment:MainAxisAlignment.start,
                      //             children: [
                      //
                      //               // Expanded(child: Text(datum.itemName!,style: Theme.of(context).textTheme.bodyText1,maxLines: 3,)),
                      //               Expanded(child:
                      //               HigliteText(textData:datum.assetName!,textStyle: Theme.of(context).textTheme.bodyText1 as TextStyle,query: _controller.etSearch.text,)
                      //               ),
                      //
                      //               // Text(filtterdata[index].itemName!,style:Theme.of(context).textTheme.bodyText1 ,),
                      //               // Text("subtitle",style:Theme.of(context).textTheme.bodyText1 ,)
                      //             ],
                      //           ),
                      //           SizedBox(height: 5,),
                      //           Divider(thickness: 0.2,color:Theme.of(context).colorScheme.primary.withOpacity(0.2),),
                      //           SizedBox(height: 10,),
                      //           Row(
                      //               mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      //               children: [
                      //                 Row(
                      //                   children: [
                      //                     Text("Category ",style: Theme.of(context).textTheme.bodyText2,),
                      //                     Text(datum.assetCategory??"",style: Theme.of(context).textTheme.bodyText1,),
                      //                   ],
                      //                 ),
                      //                 Text(datum.status!,style:TextStyle(color:datum.status!.toLowerCase()=="ACTIVE".toLowerCase()? Colors.green:Colors.red,fontSize: 16,fontWeight: FontWeight.w600),),
                      //
                      //               ]),
                      //           SizedBox(height: 10,),
                      //           Divider(thickness: 0.2,color:Theme.of(context).colorScheme.primary.withOpacity(0.2),),
                      //           SizedBox(height: 5,),
                      //           Row(
                      //             mainAxisAlignment:MainAxisAlignment.spaceBetween,
                      //
                      //             children: [
                      //               Container(
                      //                   width:w*0.3,
                      //                   child: Column(
                      //                     crossAxisAlignment: CrossAxisAlignment.start,
                      //                     children: [
                      //                       Text("Model No",style: Theme.of(context).textTheme.bodyText2,textAlign:TextAlign.start ,),
                      //                       const SizedBox(height: 6,),
                      //                       Text(datum.modelNo!,style: Theme.of(context).textTheme.bodyText1,textAlign: TextAlign.center,),
                      //                     ],
                      //                   )
                      //               ),
                      //               Container(
                      //                 width:w*0.3,
                      //                 child: Column(
                      //
                      //                   children: [
                      //                     Text("Purchase Date",style: Theme.of(context).textTheme.bodyText2,),
                      //                     const SizedBox(height: 6,),
                      //                     Text(datum.purchasedDate!,style: Theme.of(context).textTheme.bodyText1,),
                      //                   ],
                      //                 ),
                      //
                      //               ),
                      //               Container(
                      //                   width:w*0.3,
                      //                   child: Column(
                      //                     crossAxisAlignment: CrossAxisAlignment.end,
                      //                     children: [
                      //                       Text("Price",style: Theme.of(context).textTheme.bodyText2,),
                      //                       const SizedBox(height: 6,),
                      //                       Text("\$ "+double.parse(datum.purchasePrice!).toStringAsFixed(2),style: Theme.of(context).textTheme.bodyText1,),
                      //                     ],
                      //                   )
                      //               ),
                      //             ],
                      //           ),
                      //           SizedBox(height: 5,),
                      //
                      //
                      //         ],
                      //       ),
                      //       Positioned(
                      //           right: 0,
                      //           top: 0,
                      //           child: Row(
                      //             children: [
                      //
                      //               InkWell(onTap: (){
                      //                 CheckInternetConnection().then((value) {
                      //                   if(value==true)
                      //                   {
                      //                     Get.to(()=>FieldPageNew(title: widget.title,type: 2,id: datum.id,),arguments: {"data": json.decode(json.encode(datum))});
                      //                   }
                      //                 });
                      //               },child: Icon(Icons.edit,color: Colors.amberAccent,size: 22,),),
                      //               SizedBox(width: 10,),
                      //               InkWell(onTap: (){
                      //
                      //
                      //
                      //                 //Get.to(()=>FieldPage(title: "Inventory",type: 2,id: filtterdata[index].id,),arguments: {"data": filtterdata.sublist(index)});
                      //               },child: Icon(Icons.delete,color: Colors.red,size: 22,),),
                      //             ],
                      //           ))
                      //     ],
                      //   ),
                      // );

                    }),
              ),
            ):Container(),
            )
          ],
        ),
      ),

    );
  }

}
