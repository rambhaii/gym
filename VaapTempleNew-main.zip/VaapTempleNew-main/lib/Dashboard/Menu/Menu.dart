
import 'dart:convert';
import 'package:aspgen_mobile/Dashboard/Menu/MenuController/MenuController.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../Templates/fieldPageNew.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListView.dart';
import '../../Widget/SearchBarWidget.dart';

class MenuPage extends StatefulWidget {
   final String title;
   final int type;// type=1  for menu,type=2  for Today Menu//type 4 for Catering Menu
   MenuPage({Key? key,required this.title, required this.type}) : super(key: key);

  @override
  State<MenuPage> createState() => _MenuPageState();
}

class _MenuPageState extends State<MenuPage> {
   MenuControllers controller=Get.put(MenuControllers("Menu"));

  TextEditingController etdate= new TextEditingController();

  final formGlobalKey = GlobalKey<FormState>();

  DateTime?tempDate;
     @override
  void initState() {
       controller.fetchApi(1);
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.type==1?widget.title:"Add "+widget.title ,
          textAlign: TextAlign.center,
        ),
        actions: [
  Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            CheckInternetConnection().then((value1) => value1==true? Get.to(()=>FieldPageNew(title: widget.title,type: 1,)):"");
          }
            ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        )],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 5),

        child: Column(

          children: [
            SizedBox(height: 6,),
            GetBuilder<MenuControllers>(
              builder: (controller)=>  SearchBarWidget(
                hint: "Search",
                controller: controller.etSearch,
                onchange: (value){
                  value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi(1):"";
                  controller.update();
                },
                onCancel: (){
                  controller.etSearch.clear();
                  controller.fetchApi(1);
                  controller.update();
                },
              ),
            ),
            SizedBox(height: 6,),
            Obx(()=>(controller.menuData.value.data!=null && controller.menuData.value.data!.isNotEmpty)?Expanded(
                child: RefreshIndicator(
                  onRefresh: (){
                    return Future.delayed(Duration.zero, () {
                      controller.fetchApi(1);
                    });
                  },
                  child:controller.menuData.value.data!.isNotEmpty?ListView.builder(
                      itemCount:controller.menuData.value.data!.length,
                      itemBuilder: (context,index)
                      {
                        final datas=controller.menuData.value.data![index];
                        return   CustomListWidget(
                          imgUrl:controller.menuData.value.data![index].image??"" ,
                          title: controller.menuData.value.data![index].refDataName??"",
                          subTitle:amountParser(controller.menuData.value.data![index].unitPrice.toString()),
                          viewMoreWidget: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                          children:[
                            if(datas.menuCategory!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                            if(datas.menuCategory!.isNotEmpty) viewMore("Category  ",datas.menuCategory??""),
                            if(datas.refDataCode!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                            if(datas.refDataCode!.isNotEmpty) viewMore("Type  ",datas.refDataCode??""),
                          ]),
                          isClicked: controller.menuData.value.data![index].isCheck!??false,
                          onTapVieMore: (){
                            controller.menuData.value.data![index].isCheck=!controller.menuData.value.data![index].isCheck!;
                           controller.menuData.refresh();
                          },
                          icon: (widget.type==2 || widget.type==4)?datas.isAdd!=true?Icons.add:Icons.check:null,
                          iconColor: (widget.type==2 || widget.type==4)?datas.isAdd!=true?Colors.green:Colors.white:null,
                          editOnTap: (){
                            CheckInternetConnection().then((value) {
                              if(value==true) {
                                if (widget.type == 1) {
                                  CheckInternetConnection().then((
                                      value1) => value1 == true ? Get.to(() =>
                                      FieldPageNew(title: widget.title,
                                          type: 2,
                                          id: controller.menuData.value
                                              .data![index].id!), arguments: {
                                    "data": json.decode(json.encode(
                                        controller.menuData.value.data![index]))
                                  }) : "");
                                }
                              }
                            });
                          }, textEditingController: controller.etSearch,
                        );
                   }):Container(),
                ),
             ):
            Expanded(child: Center(child: Text(controller.rxMessage.value,style: Theme.of(context).textTheme.bodyText1,))))
          ],
        ),
      ),
    );
  }
}
