import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Menu/Model/MenuData.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../UtilMethods/base_client.dart';
import '../../Catering/Controller/controller.dart';
import '../../DailyMenu/MenuController/TodayMenuController.dart';

class MenuControllers extends GetxController{
  MenuControllers(this.titile);
  final String titile;
  var menuData= MenuData().obs;
  RxList<MenuDatum>  menuAddedData= RxList<MenuDatum>([]);
  TextEditingController etSearch= new TextEditingController();
  var bodyJson={};
  RxString rxMessage="".obs;
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":titile,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip":0,
      "next":500
    };
    // TODO: implement onInit

    super.onInit();
  }
  fetchApi(int type)async{
    {
      Get.context!.loaderOverlay.show();
      var response=await BaseClient().post(APIsConstant.getAPI, bodyJson).catchError(BaseController().handleError);
      Get.context!.loaderOverlay.hide();
      if(response==null) return;
      if(jsonDecode(response)["statusCode"].toString()=="-1") return;
      menuData.value=menuDataFromJson(response);
      if(type==2)
        {
          TodayMenuController todayController=Get.find();
            todayController.menuData.value.data!.forEach((element) {
              menuData.value.data!.removeWhere((menuDatum) => menuDatum.id==element.menuId);
            });
          menuData.refresh();
        }
      if(type==3)
        {
          CateringController catController=Get.find();
          catController.menuData.value.data!.forEach((element) {
            menuData.value.data!.removeWhere((menuDatum) => menuDatum.id==element.menuId);
          });
          menuData.refresh();
        }
      if(menuData.value.data!.isEmpty)
        {
          rxMessage.value="No Menu Available";
        }
    }
  }
  fetchFilterApi(String text)async{
    var request={
      "text": text,
      "componentConfig": {
        "moduleName":titile,
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),

      }
    };
    print("vgjvgjvjgyju");
    print(request);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("dsjkvkjdsv");
    print(response);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    menuData.value=menuDataFromJson(response);

    if(menuData.value.data!.isEmpty)
    {
      rxMessage.value="We couldn't find any menu matching '${etSearch.text}'";
    }
  }



}