// To parse this JSON data, do
//
//     final menuData = menuDataFromJson(jsonString);

import 'dart:convert';

MenuData menuDataFromJson(String str) => MenuData.fromJson(json.decode(str));

String menuDataToJson(MenuData data) => json.encode(data.toJson());

class MenuData {
  MenuData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<MenuDatum> ?data;

  factory MenuData.fromJson(Map<String, dynamic> json) => MenuData(
    statusCode: json["statusCode"]??"",
    message: json["message"]??"",
    data: List<MenuDatum>.from((json["data"]??"").map((x) => MenuDatum.fromJson(x))).reversed.toList(),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class MenuDatum {
  MenuDatum({
    this.id,
    this.image,
    this.refDataName,
    this.menuCategory,
    this.refDataCode,
    this.menuId,
    this.consistency,
    this.status,
    this.unitPrice,
    this.carryOutPrice,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.isCheck,
    this.servingQuantity,
    this.sideItems,
    this.isAdd,
    this.isCatering,
    this.isDailyMenu,
    this.servingCalories,
    this.ingredientList,
    this.ChildGrid,
    this.description,
  });

  String? id;
  String ?image;
  String ?refDataName;
  String ?menuCategory;
  String ?refDataCode;
  String ?menuId;
  String ?consistency;
  String ?status;
  var unitPrice;
  var carryOutPrice;
  String ?moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  String ?servingQuantity;
  var servingCalories;
  var ingredientList;
  var ChildGrid;
  var description;
  String ?sideItems;
  bool ?isCheck;
  bool ?isAdd;
  bool ?isCatering;
  bool ?isDailyMenu;

  factory MenuDatum.fromJson(Map<String, dynamic> json) => MenuDatum(
    id: json["_id"]??"",
    image: json["image"]??"",
    refDataName: json["refDataName"]??"",
    menuCategory: json["menuCategory"]??"",
    refDataCode: json["menuType"]??json["refDataCode"]??"",
    menuId: json["menuId"]??"",
    consistency: json["consistency"]??"",
    status: json["status"]??"",
    unitPrice: json["unitPrice"]??"0",
    carryOutPrice: json["carryOutPrice"]??"0",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    servingQuantity: json["servingQuantity"]??"",
    recModDate: json["recModDate"]??"",
    sideItems: json["sideItems"]??"",
    isCatering: json["isCatering"]??false,
    isDailyMenu: json["isDailyMenu"]??false,
    servingCalories: json["servingCalories"],
    ingredientList: json["ingredientList"],
    ChildGrid: json["Child Grid"],
    description: json["description"],
    isCheck: false,
    isAdd: false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "image": image,
    "refDataName": refDataName,
    "menuCategory": menuCategory,
    "menuType": refDataCode,
    "menuId": menuId,
    "consistency": consistency,
    "status": status,
    "unitPrice": unitPrice,
    "sideItems": sideItems,
    "servingQuantity": servingQuantity,
    "carryOutPrice": carryOutPrice,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "isCheck": isCheck,
    "isAdd": isAdd,
    "isCatering": isCatering,
    "isDailyMenu": isDailyMenu,
    "servingCalories": servingCalories,
    "ingredientList": ingredientList,
    "ChildGrid": ChildGrid,
    "description": description,
  };


}
