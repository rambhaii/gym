import 'dart:ui';
import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/AppConstant/theme_services.dart';
import 'package:aspgen_mobile/Authentication/NewLoginPage.dart';
import 'package:aspgen_mobile/Dashboard/ProfilePage.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../AppConstant/APIsConstant.dart';
import '../Templates/custom_expension_title.dart';
import '../UtilMethods/Utils.dart';
import '../Widget/ShimarEffectDashboaard.dart';
import 'controller/DashBoardController.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({Key? key}) : super(key: key);
  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  var locale = Locale('hi','IN');
  DashboardController dashboardController=Get.put(DashboardController());
  final GlobalKey<ExpansionTileCardState> Group1 = new GlobalKey();
  int selected=-1;
  String name = "";
  String email = "";
  String phone = "";
  String address = "";
  String isSelected='';
  GetStorage storage= GetStorage();
  bool isReady = true;
  bool loader = true;
  var request={};
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer);
      return Scaffold(
        appBar: AppBar(
            title: Text(
              "dashboard".tr,
              textAlign: TextAlign.center,
              style: TextStyle(color:Colors.tealAccent),
            ),
        centerTitle: true,
        leading: PopupMenuButton<String>(
                  child: Icon(Icons.menu,color: Colors.tealAccent,),
                  color: Theme.of(context).dialogBackgroundColor,
                  offset: Offset(0, 50),
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      padding: EdgeInsets.all(0),
                      child:ListTile(
                        onTap: (){
                          Get.off(()=>ProfilePage(title: 'My Profile',));
                        },
                          minLeadingWidth: 10,
                          dense: true,
                          leading:Icon(Icons.person, color: Theme.of(context).colorScheme.primary),
                          title: Text("myProfile".tr,style: TextStyle(color: Theme.of(context).colorScheme.primary,fontSize: 16),)
                      ),
                      value:"My Profile",
                    ),
                    PopupMenuItem(
                      padding: EdgeInsets.all(0),
                      child:ListTile(
                        onTap: (){
                          logout();
                        },
                          minLeadingWidth: 10,
                          dense: true,
                          leading:  Icon(Icons.logout, color: Theme.of(context).colorScheme.primary),
                          title: Text("logout".tr,style: TextStyle(color: Theme.of(context).colorScheme.primary,fontSize: 16))
                      ),
                      value: "Logout",

                    ),
                    PopupMenuItem(
                      padding: EdgeInsets.all(0),
                      child:ExpansionTile(
                       collapsedIconColor: Theme.of(context).colorScheme.primary,
                      //  leading:  Icon(Icons.wb_sunny, color: Theme.of(context).colorScheme.primary),
                          title: Text("themes".tr,style: TextStyle(color: Theme.of(context).colorScheme.primary)),
                        children: <Widget>[
                          ListTile(
                            onTap: (){
                              ThemeService().changeThemeMode(ThemeMode.light);
                              Get.back();
                            },
                              minLeadingWidth: 10,
                              dense: true,
                              leading:  Icon(Icons.wb_sunny_outlined, color: Theme.of(context).colorScheme.primary),
                         title: Text("light".tr,style: TextStyle(color: Theme.of(context).colorScheme.primary),
                          )),
                          ListTile(
                            onTap: (){
                              ThemeService().changeThemeMode(ThemeMode.dark);
                              Get.back();
                            },
                              minLeadingWidth: 10,
                              dense: true,
                              leading:  Icon(Icons.wb_sunny, color: Theme.of(context).colorScheme.primary),
                         title: Text("dark".tr,style: TextStyle(color: Theme.of(context).colorScheme.primary),
                          ))
                        ],
                      ),
                      value: "Themes",

                    ),
                    PopupMenuItem(
                      padding: EdgeInsets.all(0),
                      child:ExpansionTile(
                        collapsedIconColor: Theme.of(context).colorScheme.primary,
                        //  leading:  Icon(Icons.wb_sunny, color: Theme.of(context).colorScheme.primary),
                        title: Text("language".tr,style: TextStyle(color: Theme.of(context).colorScheme.primary)),
                        children: storage.read(AppConstant.language)!=null?storage.read(AppConstant.language).map<Widget>((e){
                          return ListTile(
                              onTap: (){
                                switch(e)
                                {
                                  case "en_US":
                                    Get.updateLocale(Locale('en','US'));
                                    break;
                                    case "es_HN":
                                    Get.updateLocale(Locale('es','VE'));
                                    break;
                                    case "hi_IN":
                                      Get.updateLocale(Locale('hi','IN'));
                                    break;
                                    case "fr_BE":
                                      Get.updateLocale(Locale('fr','BE'));
                                    break;
                                }
                                Get.back();
                              },
                              minLeadingWidth: 10,
                              dense: true,
                              leading: Image.asset(
                                e=="en_US"?"packages/country_pickers/assets/us.png":
                                e=="hi_IN"?"packages/country_pickers/assets/in.png":
                                e=="fr_BE"?"packages/country_pickers/assets/fr.png":
                                "packages/country_pickers/assets/id.png",
                                height: 28,width: 42,fit: BoxFit.cover,),
                              //Icon(Icons.flag, color: Theme.of(context).colorScheme.primary),
                              title: Text(
                                e=="en_US"?"English":
                                e=="hi_IN"?"Hindi":
                                e=="fr_BE"?"French": "Spanish",
                                style: TextStyle(color: Theme.of(context).colorScheme.primary),
                              ));
                        }).toList():[Container()]
                      ),
                      value: "language",
                    ),
                  ]
              ),
        automaticallyImplyLeading: false,
      ),
        body:  Padding(
          padding: const EdgeInsets.only(top: 0,left: 0,right: 0),
          child:RefreshIndicator(
            onRefresh: () {
             return Future.delayed(Duration.zero).then((value){
               dashboardController.getData();
             });
            },
            child: GetBuilder<DashboardController>
              (builder: (dashboardController)=>dashboardController.groupList.value!=null?
             ListView.builder(
                 key: Key('builder ${selected.toString()}'),
                 itemCount: dashboardController.groupList.value.length,
                 physics: const BouncingScrollPhysics(),
                 itemBuilder: (ctx,index){
                   final datas=dashboardController.groupList.value[index];
              return  Container(
                margin: EdgeInsets.only(top:15,left: 10,right: 10),
                decoration:decoration.copyWith(border: Border.all(color: (index != selected)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                child:  ExpansionTile(
                     textColor: Colors.tealAccent,
                    iconColor: Colors.tealAccent,
                    key: Key(index.toString()),
                      initiallyExpanded:  index == selected,
                    onExpansionChanged: ((value){
                    dashboardController.position.value=index;
                    dashboardController.groupList.value.forEach((element) {
                     element.isExpanded=false;
                    });
                     selected=index;
                      datas.isExpanded=value;
                      dashboardController.update();
                   }),
                  leading:CachedNetworkImage(
                      fit: BoxFit.fill,
                      imageUrl:APIsConstant.IP_Base_Url+""+datas.groupImage!,
                      height: 30,
                      width: 30,
                      placeholder: (context,url)=>const  CupertinoActivityIndicator(
                        animating: true,
                        radius: 10,
                        color: Colors.white,
                      ),
                      errorWidget: (context,url,error)=>const Icon(Icons.error),
                    ),
                   title: Text(datas.refDataName??"",style: TextStyle(fontSize: 16,fontWeight: FontWeight.w700),),
                   children:datas.childGrid!.isNotEmpty?[
                    SizedBox(height: 6,),
                        GridView.count(

                            shrinkWrap: true,
                            physics:const BouncingScrollPhysics(),
                            crossAxisCount: 4,
                            crossAxisSpacing: 0,
                           mainAxisSpacing:8,

                            childAspectRatio:1/1.1,
                            children: datas.childGrid!=null?  List<Widget>.generate(datas.childGrid!.length, (index) {
                              datas.childGrid!.sort((a, b) => a.sequenceId!.compareTo(b.sequenceId!));
                          final datum =datas.childGrid![index];
                          return Padding(
                            padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                            child: InkWell(
                              onTap: (){
                                dashboardController.getRoute(datum.backendName.toString(),datum.refDataName.toString());
                              },
                              child: Column(
                          children: [
                            datum.refDataName=="Notifications" ?Container(
                                width: 50,
                                height: 50,
                                decoration: BoxDecoration(
                                    color: Colors.white.withOpacity(0.2),
                                    gradient: LinearGradient(
                                        tileMode: TileMode.clamp,
                                        colors: [Colors.white,Colors.blue.withOpacity(0.5  )],
                                        begin: Alignment.bottomCenter,
                                        end: Alignment.topCenter
                                    )

                                    ,borderRadius: BorderRadius.circular(10)
                                ),
                                padding: EdgeInsets.all(8),
                                child: CachedNetworkImage(
                                  imageUrl:APIsConstant.IP_Base_Url+datum.menuImage.toString(),
                                  height: 20,
                                  width: 20,
                                  placeholder: (context,url)=> CupertinoActivityIndicator(
                                    animating: true,
                                    radius: 10,
                                    color: Colors.white,
                                  ),
                                  errorWidget: (context,url,error)=>const Icon(Icons.error),
                                )
                            ): Container(
                              width: 50,
                              height: 50,
                              decoration: BoxDecoration(
                                  color: Colors.white.withOpacity(0.2),
                                  gradient: LinearGradient(
                                      tileMode: TileMode.clamp,
                                      colors: [Colors.white,Colors.blue.withOpacity(0.5  )],
                                      begin: Alignment.bottomCenter,
                                      end: Alignment.topCenter
                                  )
                                  ,borderRadius: BorderRadius.circular(10)
                              ),
                              padding: EdgeInsets.all(8),
                              child: CachedNetworkImage(
                                imageUrl:APIsConstant.IP_Base_Url+datum.menuImage.toString(),
                                height: 20,
                                width: 20,
                                placeholder: (context,url)=> CupertinoActivityIndicator(
                                  animating: true,
                                  radius: 10,
                                  color: Colors.white,
                                ),
                                errorWidget: (context,url,error)=>const Icon(Icons.error),
                              )
                          ),

                          SizedBox(
                          height: 8,
                          ),
                          Container(

                          child: Expanded(
                            child: Text(datum.refDataName.toString(),
                            textAlign: TextAlign.center,
                            overflow: TextOverflow.fade,
                            maxLines: 2,
                            style: Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 12)),
                          ))
                          ],
                          ),
                            ),
                          );
                        }):<Widget>
                            []
                        ),
                        SizedBox(
                          height: 8,
                        ),

                  ]:[]
                ),

             );
            })
            :ShimmerEffectForDashboard()
        ),
          ),
        ),
    );
  }



  void showDailogDrawer() {
    showGeneralDialog(
        context: context,
        barrierColor: Colors.transparent,
        barrierDismissible: true,
        barrierLabel: 'Label',
      pageBuilder: (_, __, ___) {
          return Container();
        },
      transitionDuration: const Duration(milliseconds: 300),
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) -   1.0;
        return Transform(
          transform: Matrix4.translationValues( curvedValue * 250, 0.0,0.0),
          child: Align(
          alignment: Alignment.centerLeft,
          child:  BackdropFilter(
            filter: ImageFilter.blur(
              sigmaX: 20.0,
              sigmaY: 20.0,
            ),
            child: Container(
              width: 164,
              height: 500,
              decoration: BoxDecoration(
                borderRadius: BorderRadiusDirectional.circular(5),
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(5.0),
                child: BackdropFilter(
                  filter: ImageFilter.blur(
                  sigmaX: 20.0,
                  sigmaY: 20.0,
                ),
                  child: Scaffold(
                    backgroundColor: Colors.black54,
                    body: Container(
                      alignment: Alignment.topLeft,
                        color:Colors.transparent,
                        padding: EdgeInsets.only(top: 0,left: 10,right: 10,bottom: 10),
                        child: Stack(
                          children: [
                            new  Positioned(
                                right: 0,
                                top: 0,
                                child: IconButton(onPressed: (){
                                  Get.back();
                                  },icon: Icon(Icons.arrow_back,color: Theme.of(context).colorScheme.primary,),)
                            ),
                          ],
                        )),
                  ),
                ),
              ),
            ),
          ),

        )
        );

      },

      );

  }

}
