import 'package:get/get.dart';

class TimeController extends GetxController{
    var time= "".obs();
    void onInit() {
        time=DateTime.now().toString();
        super.onInit();

    }
}