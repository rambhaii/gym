import 'dart:convert';
import 'dart:math';
import 'package:aspgen_mobile/AppConstant/config.dart';
import 'package:aspgen_mobile/Dashboard/Contact/Controller/contact_controller.dart';
import 'package:aspgen_mobile/Templates/Model/ListingData.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:aspgen_mobile/Widget/SearchBarWidget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../AppConstant/APIsConstant.dart';
import '../../../Templates/fieldPageNew.dart';
import '../../../Widget/EditextWidget.dart';
import '../../../Widget/FullScreenImageWidget.dart';
import '../../../Widget/LoadMore.dart';
import '../../AppConstant/AppColors.dart';
import '../Inquiry/controller/DevoteeInquiry.dart';
import '../Inquiry/view/Booking_history.dart';
import '../Inquiry/view/PaymentInqirey.dart';

class DevoteePage extends StatefulWidget {
  final String title;
  final String displayName;
  const DevoteePage({Key? key,required this.title, required this.displayName}) : super(key: key);
  @override
  State<DevoteePage> createState() => _DevoteePageState();
}

class _DevoteePageState extends State<DevoteePage> {
  DevoteeInquiryController _controller=  Get.put(DevoteeInquiryController(type: 2));
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

  var bodyJson={};
  @override
  void initState() {
    super.initState();
  }

  makingPhoneCall(String phone) async {
    print("ndbshfs");
    var url = 'tel:'+phone;
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text(widget.displayName),
     
      ),

      body: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          SizedBox(height: 10,),
          GetBuilder<DevoteeInquiryController>(
            builder: (controller)=> Row(
              children: [
                Expanded(
                  flex: 13,
                  child: Container(
                    margin: EdgeInsets.only(left: 10,right: 5),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5),
                        border: Border(
                            top: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                            bottom: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                            right: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                            left: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                        color:Color(0xff6d8d8c).withOpacity(0.3),
                        // borderRadius:  BorderRadius.circular(32),
                      ),
                      child: TextField(
                        autofocus: false,
                        style: Theme.of(context).textTheme.bodyText1,
                        controller:_controller.etSearch,
                        onChanged:((value){
                        _controller.update();
                        }),
                        decoration: new InputDecoration(
                          fillColor: Colors.teal,
                          border: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          errorBorder: InputBorder.none,
                          disabledBorder: InputBorder.none,
                          contentPadding:
                          EdgeInsets.only(left: 10, top: 15, right: 1),
                          hintText: "Search Name / Email / Phone",
                          hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.4)),
                          suffixIcon: _controller.etSearch.text.isNotEmpty?InkWell(
                            onTap: (){
                              _controller.etSearch.clear();
                            },
                            child: Icon(
                              Icons.clear,
                              color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                            ),
                          ):Icon(
                            Icons.clear,
                            color: Colors.transparent,
                          ),
                        ),
                      )
                  ),
                ),
                Expanded(
                  flex: 2,
                  child: Container(
                    margin: EdgeInsets.only(right: 4),
                    child: RawMaterialButton(onPressed: (){

                          _controller.fetchFilterApi(_controller.etSearch.text);


                      }
                      ,child: Icon(Icons.search),fillColor: Colors.green.withOpacity(0.5),shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 44.0, minHeight: 44.0),),
                  ),
                  ),

              ],
            )
          ),
          SizedBox(height: 8,),
          Obx(()=>_controller.allContactDatas.value.isNotEmpty? Expanded(
            child: ListView.builder(
                controller: _controller.controller,
                itemCount:  _controller.allContactDatas.value.length,
                physics: const AlwaysScrollableScrollPhysics(),
                itemBuilder: (context,index){
                  final data=_controller.allContactDatas.value[index];
                  return Card(
                    color: Theme.of(context).colorScheme.onPrimaryContainer,
                    elevation: 6,
                    child:
                    Column(
                      children: [
                        Divider(
                          height: 0.5,
                          thickness: 0.5,
                          color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
                        ),
                        SizedBox(height: 10),
                        Row(
                          children: [
                            Container(
                              width: MediaQuery.of(context).size.width * 0.2,
                              padding: EdgeInsets.only(left: 5),
                              child: Stack(
                                children: [
                                  data.image==""?  CircleAvatar(
                                    backgroundColor: Color(Random().nextInt(0xffffffff)),
                                    child: Text(
                                        data.refDataName.toString().toUpperCase() ==
                                            "" ? "" : data.refDataName![0].toString().toUpperCase(),
                                        style: Theme.of(context).textTheme.headline4
                                    ),
                                    maxRadius: 27,
                                  ):
                                  ClipOval(
                                    child: GestureDetector(
                                      onTap: (){
                                        Get.to(()=>FullScreenImageWidget(path: APIsConstant.IP_Base_Url+data.image.toString(),),fullscreenDialog: true);
                                      },
                                      child: Hero(
                                        tag:"img", child: CachedNetworkImage(
                                        fit: BoxFit.cover,
                                        imageUrl:APIsConstant.IP_Base_Url+data.image.toString(),
                                        height: 55,
                                        width: 55,
                                        placeholder: (context,url)=>const CircularProgressIndicator(),
                                        errorWidget: (context,url,error)=>const Icon(Icons.error),
                                      ),
                                      ),
                                    ),
                                  ),
                                  Positioned(
                                      left:0,
                                      bottom:0,
                                      child: GestureDetector(
                                        onTap: (){
                                          CheckInternetConnection().then((value1) => value1==true?Get.to(()=>FieldPageNew(title: "Contacts",type: 2,id: _controller.allContactDatas.value[index].id!),arguments: {"data": json.decode(json.encode(data))}):"");
                                        },
                                        child: CircleAvatar(
                                          radius: 11,
                                          backgroundColor: Colors.white,
                                          child: CircleAvatar(
                                            backgroundColor: Theme.of(context).colorScheme.onPrimaryContainer,
                                            radius: 10,
                                            child: Icon(Icons.edit,color:Colors.amber,size: 12,),
                                          ),
                                        ),
                                      )
                                  )

                                ],
                              ),
                            ),
                            Container(
                              width: MediaQuery.of(context).size.width * 0.6,
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  HigliteText(textData: data.refDataName!, query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle),
                                  SizedBox(
                                    height: 9,
                                  ),
                                  HigliteText(textData:  data.memberTypes!, query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(
                                      color:  data.memberTypes!.toString() == "PRIEST"
                                          ? Colors.amber
                                          :  data.memberTypes!.toString()== "DEVOTEE"
                                          ? Colors.green:
                                      data.memberTypes!.toString()== "GUEST"?Colors.purple  : Colors.lightBlue,
                                      fontSize: 11,fontWeight: FontWeight.w400,
                                  )
                                  ),
                                  SizedBox(
                                    height: 3,
                                  ),
                                  InkWell(onTap: (){
                                    data.isCheckList!?data.isCheckList=false:data.isCheckList=true;
                                    _controller.allContactDatas.refresh();
                                  },
                                      child: Row(
                                        children: [
                                          Text(data.isCheckList!=true?"View More  ":"Less More ",style:TextStyle(fontSize: 12,color:Colors.white54, decoration: TextDecoration.underline,)),
                                          Icon(data.isCheckList!=true?Icons.expand_more:Icons.expand_less,size: 20,color:Colors.white54),
                                        ],
                                      )
                                  ),
                                  if(data.isCheckList!)   SizedBox(
                                    height: 8,
                                  ),
                                  if(data.isCheckList!) Row(
                                    children: [
                                      Icon(Icons.phone,size: 16,),
                                      SizedBox(width: 8,),
                                      HigliteText(textData: phoneFormatter(data.phone!) , query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle),
                                    ],
                                  ),

                                ],
                              ),
                            ),
                            Container(
                              alignment: Alignment.center,

                              width: MediaQuery.of(context).size.width * 0.175,
                              child: Container(
                                height: 35,
                                width: 35,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                    border: Border.all(color:Colors.white.withOpacity(0.24),width: 1 ),
                                    shape:BoxShape.circle,

                                ),
                                child: PopupMenuButton<String>(
                                  padding: EdgeInsets.zero,
                                  offset: Offset(10,40),
                                  color: AppColor.primaryColor,
                                  elevation: 14,
                                  onSelected: (value){
                                       if(value=="PAYMENTS")
                                       {
                                         Get.to(()=>PaymentInquiryPage(title: 'Payments', type: 3,),arguments: {"data":data.email!.isNotEmpty?UtilMethods.decrypt(data.email):UtilMethods.decrypt(data.phone)});
                                         return;
                                       }
                                       if(value=="BOOKINGS")
                                       {
                                         Get.to(()=>BookingHistoryPage(title: 'Bookings', type: 4,),arguments: {"data":data.email!.isNotEmpty?UtilMethods.decrypt(data.email):UtilMethods.decrypt(data.phone)});
                                         return;
                                       }
                                  },
                                  itemBuilder: (BuildContext context){
                                    return _controller.menuList.map((String choice){
                                      return PopupMenuItem<String>(
                                        value: choice,

                                        padding: EdgeInsets.zero,
                                        child:
                                        Row(
                                          children: [
                                            SizedBox(width: 6,),
                                           choice=="PAYMENTS"?Icon(Icons.paypal):Icon(Icons.bookmark_border_sharp),
                                            SizedBox(width: 10,),
                                            Text(choice,textAlign: TextAlign.center,),
                                          ],
                                        )


                                      );
                                    })
                                        .toList();
                                  }
                                  ,)

                              ),
                            ),
                          ],
                        ),
                        Container(
                          margin: EdgeInsets.only(left: Get.width*0.2,right: 8),
                          child: Column(children: [
                            if(data.isCheckList!)  SizedBox(
                              height: 4,
                            ),
                            if(data.isCheckList!) Row(
                              children: [
                                Icon(Icons.email,size: 16,),
                                SizedBox(width: 8,),
                                Expanded(child: HigliteText(textData: UtilMethods.decrypt(data.email!), query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle)),
                              ],
                            ),
                          ],),
                        ),
                        SizedBox(height: 10),
                        Divider(
                          height: 0.5,
                          thickness: 0.5,
                          color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
                        )
                      ],
                    ),
                  );
                }),
          ): Expanded(child: Center(child: Text(_controller.isSerching.value?"We couldn't find any contact\nmatching '${_controller.etSearch.text}'  ":"",
            style: Theme.of(context).textTheme.bodyText1,
            textAlign: TextAlign.center,),

          ),
          ),
          ),
          Obx(() => _controller.isLoadMore.value?LoadMoreData():Container())
        ],
      ),
    );
  }

}
