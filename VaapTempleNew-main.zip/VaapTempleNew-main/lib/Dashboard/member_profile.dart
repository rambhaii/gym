import 'dart:convert';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/Authentication/controller/auth_controller.dart';
import 'package:aspgen_mobile/Authentication/new_registration.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:aspgen_mobile/Widget/EditextWidget.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import "package:http/http.dart" as http;

import '../Authentication/NewLoginPage.dart';
import '../UtilMethods/Utils.dart';

class MemberProfilePage extends StatelessWidget {
  final String title;
  MemberProfilePage({Key? key, required this.title}) : super(key: key);
   final formGlobalKey = GlobalKey<FormState>();

  Widget build(BuildContext context) {
    print("vbkbervbjkervb");
    BoxDecoration decoration=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer);
    return Scaffold(
        appBar: AppBar(
          title: Text(
            title,
          ),

        ),
        body:SingleChildScrollView(
          child:Padding(
                  padding: const EdgeInsets.only(left: 10,right: 10.0),
                  child: Column(
                    children: [
                      Form(
                        key: formGlobalKey,
                        child: Column(
                          children: [
                            Container(
                              margin: EdgeInsets.only(top:15),
                              decoration:decoration.copyWith(border: Border.all(color:Colors.tealAccent)),
                              child:ExpansionTileCard(
                                  finalPadding: EdgeInsets.only(left: 10,right: 10,bottom: 8),
                                  baseColor: Colors.transparent,
                                  elevation: 0,
                                  initiallyExpanded: true,
                                  expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                                  key: GlobalKey(),
                                  onExpansionChanged: ((value){

                                  }),
                                  title: Text("User Details"),

                                  children:[
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Username",
                                      controller:TextEditingController(text:AppConstant.sharedPreference.getString(AppConstant.userName)),
                                      hint: 'Enter user name ',

                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form username';
                                        }

                                        return null;
                                      },
                                      isRead: true,
                                      maxLength: 60,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),


                                    SizedBox(height: 10,),


                                    EditTextWidget(
                                      label: "Email",
                                      controller: TextEditingController(text:UtilMethods.decrypt(AppConstant.sharedPreference.getString(AppConstant.userEmail))),
                                      hint: 'Enter Email',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form email';
                                        }
                                        if (!isValidEmail(value)) {
                                          return 'Please Enter Valid email';
                                        }
                                        return null;
                                      },
                                      isRead: true,
                                      maxLength: 50,
                                      keyboardtype: TextInputType.emailAddress,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),
                                    EditTextWidget(
                                      label: "Phone",
                                      controller: TextEditingController(text:phoneFormatter(AppConstant.sharedPreference.getString(AppConstant.userPhone).toString())),
                                      hint: 'Enter Phone ',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form phone ';
                                        }
                                        return null;
                                      },
                                      isRead: true,
                                      maxLength: 10,
                                      keyboardtype: TextInputType.phone,
                                      isPassword: false,
                                    ),
                                    SizedBox(height: 10,),

                                    EditTextWidget(
                                      label: "Address",
                                      controller: TextEditingController(text:AppConstant.sharedPreference.getString(AppConstant.address).toString()),
                                      hint: 'Enter address',
                                      validator: (value) {
                                        if (value == null || value.isEmpty) {
                                          return 'Please enter form address';
                                        }
                                        return null;
                                      },
                                      maxLength: 50,
                                      keyboardtype: TextInputType.text,
                                      isPassword: false,
                                    ),
                                    // SizedBox(height: 10,),
                                    // EditTextWidget(
                                    //   label: "State",
                                    //   controller: authController.etstate,
                                    //   hint: 'Enter State',
                                    //   validator: (value) {
                                    //     if (value == null || value.isEmpty) {
                                    //       return 'Please enter form state';
                                    //     }
                                    //     return null;
                                    //   },
                                    //   maxLength: 50,
                                    //   keyboardtype: TextInputType.text,
                                    //   isPassword: false,
                                    // ),
                                    // SizedBox(height: 10,),
                                    // EditTextWidget(
                                    //   label: "City",
                                    //   controller: authController.etcity,
                                    //   hint: 'Enter city',
                                    //
                                    //   validator: (value) {
                                    //     if (value == null || value.isEmpty) {
                                    //       return 'Please enter form city';
                                    //     }
                                    //     return null;
                                    //   },
                                    //   maxLength: 60,
                                    //   keyboardtype: TextInputType.text,
                                    //   isPassword: false,
                                    // ),
                                  ]
                              ),
                            ),

                          ],
                        ),
                      ),

                    ],
                  ),

          ),

        ) // This trailing comma makes auto-formatting nicer for build methods.
    );
  }



}
