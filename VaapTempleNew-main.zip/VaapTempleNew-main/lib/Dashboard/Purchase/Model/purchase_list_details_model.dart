// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

PurchaseListDetailsData purchaseListDetailsDataFromJson(String str) => PurchaseListDetailsData.fromJson(json.decode(str));

String purchaseListDetailsDataToJson(PurchaseListDetailsData data) => json.encode(data.toJson());

class PurchaseListDetailsData {
  PurchaseListDetailsData({
    this.success,
    this.id,
    this.date,
    this.store,
    this.title,
    this.status,
    this.data,
  });

  bool ?success;
  String ?id;
  String ?date;
  String? store;
  String? title;
  String? status;
  List<Datum> ?data;

  factory PurchaseListDetailsData.fromJson(Map<String, dynamic> json) => PurchaseListDetailsData(
    success: json["success"],
    id: json["_id"],
    date: json["date"],
    store: json["store"],
    title: json["title"],
    status: json["status"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "_id": id,
    "date": date,
    "store": store,
    "title": title,
    "status": status,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.categoryName,
    this.item,
    this.qty,
    this.description,
  });

  String ?id;
  String ?categoryName;
  String ?item;
  String ?qty;
  String ?description;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    categoryName: json["categoryName"],
    item: json["item"],
    qty: json["qty"],
    description: json["description"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "categoryName": categoryName,
    "item": item,
    "qty": qty,
    "description": description,
  };
}
