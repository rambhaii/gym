// To parse this JSON data, do
//
//     final purchaseListData = purchaseListDataFromJson(jsonString);

import 'dart:convert';

PurchaseListData purchaseListDataFromJson(String str) => PurchaseListData.fromJson(json.decode(str));

String purchaseListDataToJson(PurchaseListData data) => json.encode(data.toJson());

class PurchaseListData {
  PurchaseListData({
    this.statusCode,
    this.message,
    this.data,
  });

  String? statusCode;
  String? message;
  List<Datum> ?data;

  factory PurchaseListData.fromJson(Map<String, dynamic> json) => PurchaseListData(
    statusCode: json["statusCode"]??"",
    message: json["message"]??"",
    data: List<Datum>.from((json["data"]??"").map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.categoryName,
    this.item,
    this.qty,
    this.description,
    this.date,
    this.store,
    this.title,
    this.status,
    this.orderNo,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.isChecked,
  });

  String ?id;
  String ?categoryName;
  String ?item;
  String ?qty;
  String ?description;
  String ?date;
  String ?store;
  String ?title;
  String ?status;
  String ?orderNo;
  String ?moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  bool ?isChecked;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"]??"",
    categoryName: json["categoryName"]??"",
    item: json["item"]??"",
    qty: json["qty"]??"",
    description: json["description"]??"",
    date: json["date"]??"",
    store: json["store"]??"",
    title: json["title"]??"",
    status: json["status"]??"",
    orderNo: json["orderNo"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    isChecked:false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "categoryName": categoryName,
    "item": item,
    "qty": qty,
    "description": description,
    "date": date,
    "store": store,
    "title": title,
    "status": status,
    "orderNo": orderNo,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "isChecked": isChecked,
  };
}
