import 'dart:convert';

import 'package:aspgen_mobile/Dashboard/Purchase/Model/purchase_list_model.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/Utils.dart';
import '../../UtilMethods/base_client.dart';

class PurchaseController extends GetxController{
  PurchaseController(this.titile);
  final String titile;
  TextEditingController etSearch= new TextEditingController();

  var purchaseData= PurchaseListData().obs;
  var bodyJson={};
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":titile,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip":0,
      "next":500
    };
    fetchApi();
    // TODO: implement onInit
    super.onInit();
  }

  fetchApi()async{
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("fdjkdvdf");
    print(response);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;

    purchaseData.value=purchaseListDataFromJson(response);
  }
  fetchFilterApi(String text)async{
    var request={
      "text": text,
      "componentConfig": {
        "moduleName":titile,
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    purchaseData.value=purchaseListDataFromJson(response);
  }
}