import 'dart:convert';
import 'package:aspgen_mobile/Dashboard/Purchase/purchase_controller.dart';
import 'package:aspgen_mobile/UtilMethods/GlobalApis.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:aspgen_mobile/Widget/SearchBarWidget.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';



import 'package:http/http.dart' as http;

import '../../Templates/fieldPageNew.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListView.dart';


class PurchasePage extends StatefulWidget {
   final String title;
  const PurchasePage({Key? key,required this.title}) : super(key: key);

  @override
  _PurchasePageState createState() => _PurchasePageState();
}

class _PurchasePageState extends State<PurchasePage> {
  final DateFormat formatter = DateFormat.yMMMd('en_US');
  TextEditingController etsearch= new TextEditingController();
  TextEditingController etdate= new TextEditingController();
  final formGlobalKey = GlobalKey<FormState>();
  DateTime?tempDate;

 late PurchaseController punchListController;
  @override
  void initState() {
    punchListController= Get.put(PurchaseController(widget.title));
    super.initState();
  }



  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.title,overflow: TextOverflow.clip,),
        actions: [
        //   Padding(
        //   padding: const EdgeInsets.only(right: 8.0),
        //   child: RawMaterialButton(onPressed: (){
        //     CheckInternetConnection().then((value1) => value1==true? Get.to(()=>FieldPageNew(title: widget.title,type: 1,)):"");
        //   }
        //     ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        // )
        ],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          // mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(height: 10,),
            GetBuilder<PurchaseController>(
              builder: (controller)=>  SearchBarWidget(
                hint: "Search",
                controller: controller.etSearch,
                onchange: (value){
                  value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi():"";
                  controller.update();
                },
                onCancel: (){
                  controller.etSearch.clear();
                  controller.fetchApi();
                  controller.update();
                },
              ),
            ),
            SizedBox(height: 4,),
            Obx(() =>punchListController.purchaseData.value.data!=null?Expanded(
              child: RefreshIndicator(
                 onRefresh: (){
                   return Future.delayed(Duration.zero, () {
                     punchListController.fetchApi();
                   });
                 },
                 child: Column(
                   children: [
                     Expanded(
                       child: ListView.builder(
                           itemCount:punchListController.purchaseData.value.data!.length,
                           itemBuilder: (context,index)
                           {
                             final datum=punchListController.purchaseData.value.data![index];
                             return CustomListWidget(title: datum.title??"",
                               subTitle: datum.store??"",
                               viewMoreWidget: Column(
                                   crossAxisAlignment: CrossAxisAlignment.start,
                                   children:[
                                     if(datum.date!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                     if(datum.date!.isNotEmpty) viewMore("Date  ", dateParser(datum.date.toString())),
                                     if(datum.orderNo!.isNotEmpty)Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                                     if(datum.orderNo!.isNotEmpty) viewMore("Order No  ",datum.orderNo??""),


                                   ]),
                               textEditingController:punchListController.etSearch,
                               onTapVieMore: (){
                                 datum.isChecked=!datum.isChecked!;
                                 punchListController.purchaseData.refresh();
                               },
                               editOnTap: (){
                                 CheckInternetConnection().then((value) {
                                   if(value==true)
                                   {
                                     Get.to(()=>FieldPageNew(title: widget.title,type: 2,id: datum.id,),arguments: {"data": json.decode(json.encode(datum))});
                                   }
                                 });
                               }, isClicked: datum.isChecked!,
                             );


                           }),
                     ),
                   ],
                 ),
           ),
            ):Container(),
           ),

          ],
        ),
      ),

    );
  }

}
