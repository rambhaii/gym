import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/AppConstant/TextStyle.dart';
import 'package:aspgen_mobile/Dashboard/Model/CatoringOrderModel.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:toggle_switch/toggle_switch.dart';
import 'model/kitchen_model_data.dart';

class KitchenOrder extends StatefulWidget {
  const KitchenOrder({Key? key,required this.title}) : super(key: key);
 final String title;
  @override
  _KitchenOrderState createState() => _KitchenOrderState();
}

class _KitchenOrderState extends State<KitchenOrder> {
  late KitchenOrderData? kitchenOrderData=null;
  late CatOrderModel? catOrderModel=null;
  bool isReady=false;
  bool isSearch=false;
  bool kitchenordersAll=false;
  List<bool> kitchenorderstatus=[];
  List<bool> catorderstatus=[];
  List<Map<String, dynamic>> tokenNoList=[];
  List<Map<String, dynamic>> TemptokenNoList=[];
  //List<Map<String, dynamic>> customerList=[];
  //List<String> TempcustomerList=[];
  //List<String> customerDelivery=[];
  String filterValue="SCHEDULED";
  int? toggleIndex =0;
  TextEditingController etsearch = new TextEditingController();
  @override
  void initState() {
    // TODO: implement initState
    getKioskKitchenOrderData("SCHEDULED");
    super.initState();
  }
  getKioskKitchenOrderData(status) async {
    setState(() {
     isReady=false;
     kitchenOrderData=null;
     tokenNoList=[];
     TemptokenNoList=[];
    });
    var url = Uri.parse(
        APIsConstant.Base_Url+"/business/services/nonprofit/getKioskKitchenOrderData");
    var response = await http.post(url,
        body: {
          'productId':APIsConstant.productID,
          'token': APIsConstant.productToken,
          'username':  AppConstant.sharedPreference.getString(AppConstant.userName),
          'status':status
        }
    );
    if (response.statusCode == 200) {
      print("getKioskKitchenOrderData,${response.body}");
      if (json.decode(response.body)['success'] == false) {
        Fluttertoast.showToast(
            msg: json.decode(response.body)['message'],
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor:  Theme.of(context).colorScheme.primary,
            fontSize: 16.0
        );
      }
      setState(() {
        kitchenOrderData=kitchenOrderDataFromJson(response.body);
        isReady=true;
        for(int i=0;i<kitchenOrderData!.data!.length;i++){
          if(!tokenNoList.toString().contains(kitchenOrderData!.data![i].tokenNo.toString())){
            tokenNoList.add(
                {"token": kitchenOrderData!.data![i].tokenNo.toString(),
                  "customName": kitchenOrderData!.data![i].customName.toString(),
                  "delivery": kitchenOrderData!.data![i].delivery.toString(),
                  "isChecked": false
                });
            TemptokenNoList.add(
                {"token": kitchenOrderData!.data![i].tokenNo.toString(),
                  "customName": kitchenOrderData!.data![i].customName.toString(),
                  "delivery": kitchenOrderData!.data![i].delivery.toString(),
                  "isChecked": false
                });
            //TemptokenNoList.add(kitchenOrderData!.data![i].tokenNo.toString());
            //customerList.add(kitchenOrderData!.data![i].customName.toString());
           // TempcustomerList.add(kitchenOrderData!.data![i].customName.toString());
           // customerDelivery.add(kitchenOrderData!.data![i].delivery.toString());
          }
        }
      });
    }
  }
  getKioskCatOrderData(status) async {
    final DateFormat formattera = DateFormat('MM/dd/yyyy');

   // print("username"+ApplicationConstant.sharedPreference.getString("username").toString());
    setState(() {
      isReady=false;
      kitchenOrderData=null;
      tokenNoList=[];
      TemptokenNoList=[];
    });

    var url = Uri.parse(
        APIsConstant.Base_Url+"/business/services/getKioskCateringOrderData");
    var response = await http.post(url,
        body: {
          'productId': APIsConstant.productID,
          'username': AppConstant.sharedPreference.getString(AppConstant.userName),
          'status':status,
          'date':formattera.format(DateTime.now())
        }
    );
    if (response.statusCode == 200) {
      if (json.decode(response.body)['success'] == false) {
        Fluttertoast.showToast(
            msg: json.decode(response.body)['message'],
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor:  Theme.of(context).colorScheme.primary,
            fontSize: 16.0
        );
      }
      setState(() {
        catOrderModel=welcomeFromJson(response.body);
        isReady=true;
        for(int i=0;i<catOrderModel!.data!.length;i++){
          if(!tokenNoList.toString().contains(catOrderModel!.data![i].tokenNo.toString())){
            tokenNoList.add(
                {"token": catOrderModel!.data![i].tokenNo.toString(),
                  "customName": catOrderModel!.data![i].customerName.toString(),
                  "delivery": catOrderModel!.data![i].deliveryOption.toString(),
                  "isChecked": false
                });
            TemptokenNoList.add(
                {"token": catOrderModel!.data![i].tokenNo.toString(),
                  "customName": catOrderModel!.data![i].customerName.toString(),
                  "delivery": catOrderModel!.data![i].deliveryOption.toString(),
                  "isChecked": false
                });
            //TemptokenNoList.add(kitchenOrderData!.data![i].tokenNo.toString());
            //customerList.add(kitchenOrderData!.data![i].customName.toString());
            // TempcustomerList.add(kitchenOrderData!.data![i].customName.toString());
            // customerDelivery.add(kitchenOrderData!.data![i].delivery.toString());
          }
        }
      });
    }
  }
  postKitchenOrder(String id,String _id,String itemName,String tokenNo,String status) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    print(prefs.getString('productId').toString() + "\n" +
        prefs.getString('token').toString() + "\n" +prefs.getString('username').toString()
    +"\n" +id+"\n" +_id+"\n"+status
    );
    var url = Uri.parse(
        APIsConstant.Base_Url+ "/common/services/nonprofit/postKitchenOrder");
    var response = await http.post(url,
        body: {
          'productId': prefs.getString('productId').toString(),
          'token': prefs.getString('token').toString(),
          'id':id,
          '_id':_id,
          'itemName':itemName,
          'tokenNo':tokenNo,
          'status':status
        }
    );
    if (response.statusCode == 200) {
      print("DDDDDDDFDF,${response.body}");

        Fluttertoast.showToast(
            msg: json.decode(response.body)['message'],
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            textColor:  Theme.of(context).colorScheme.primary,
            fontSize: 16.0
        );



    }
  }
  postCatOrder(String id,String _id,String itemName,String tokenNo,String status) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    print(prefs.getString('productId').toString() + "\n" +
        prefs.getString('token').toString() + "\n" +prefs.getString('username').toString()
        +"\n" +id+"\n" +_id+"\n"+status
    );
    var url = Uri.parse(APIsConstant.Base_Url+"/common/services/nonprofit/postCateringOrder");
    var response = await http.post(url,
        body: {
          'productId': prefs.getString('productId').toString(),
          'token': prefs.getString('token').toString(),
          'id':id,
          '_id':_id,
          'itemName':itemName,
          'tokenNo':tokenNo,
          'status':status
        }
    );
    if (response.statusCode == 200) {
      print("DDDDDDDFDF,${response.body}");

      Fluttertoast.showToast(
          msg: json.decode(response.body)['message'],
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          textColor:  Theme.of(context).colorScheme.primary,
          fontSize: 16.0
      );



    }
  }
  @override
  Widget build(BuildContext context) {
    final double h=MediaQuery.of(context).size.height;
    final double w=MediaQuery.of(context).size.width;
    return Scaffold(


      appBar:
      AppBar(
        title:    Text("  "+widget.title+"  "),

        // actions: [
        //   AnimSearchExBar(
        //     //inputFormatters:[maskFormatter],
        //       color: Colors.teal,
        //       helpText: "Search ",
        //       width:400,
        //       rtl: true,
        //       textController: etsearch,
        //       voidCallback: (v) {
        //       },
        //       cacel: (){
        //         etsearch.clear();
        //         //getMenuData();
        //       },
        //       onSuffixTap: () {
        //         print(etsearch.text);
        //         setState(() {
        //           tokenNoList=TemptokenNoList.where((u) => (
        //               u["token"]
        //                   .toLowerCase()
        //                   .contains(etsearch.text.toLowerCase()) ||
        //                   u["customName"]
        //                       .toLowerCase()
        //                       .contains(etsearch.text.toLowerCase())
        //
        //           ))
        //               .toList();
        //
        //
        //         });
        //       }
        //   ),
        //   SizedBox(width: 10,),
        //
        //   SizedBox(width: 10,),
        //   PopupMenuButton(
        //       child: Icon(Icons.menu),
        //       color: backgroundColor,
        //       itemBuilder: (context) => [
        //
        //         PopupMenuItem(
        //           padding: EdgeInsets.all(0),
        //           height: 40,
        //           child: ListTile(
        //               onTap: (){
        //                 setState(() {
        //                   filterValue="COMPLETED";
        //                 });
        //                 toggleIndex==0?getKioskKitchenOrderData("COMPLETED"):getKioskCatOrderData("COMPLETED");
        //                 Get.back();
        //               },
        //               leading:Icon(Icons.star_border_purple500_outlined,size: 20,color:  Theme.of(context).colorScheme.primary,) ,
        //               title:Text("PAST ORDERS",style: title.copyWith(fontSize: 20),) ),
        //           value: 1,
        //         ),
        //         PopupMenuItem(
        //           padding: EdgeInsets.all(0),
        //           height: 40,
        //           child: ListTile(
        //               onTap: (){
        //                 setState(() {
        //                   filterValue="SCHEDULED";
        //                 });
        //                 toggleIndex==0? getKioskKitchenOrderData("SCHEDULED"):getKioskCatOrderData("SCHEDULED");
        //                 Get.back();
        //               },
        //               leading:Icon(Icons.star_border_purple500_outlined,size: 20,color:  Theme.of(context).colorScheme.primary,) ,
        //               title:Text("CURRENT ORDERS",style: title.copyWith(fontSize: 20),) ),
        //           value: 1,
        //         ),
        //         PopupMenuItem(
        //           padding: EdgeInsets.all(0),
        //           height: 40,
        //           child: ListTile(
        //               onTap: (){
        //                 setState(() {
        //                   filterValue="CANCELLED";
        //                 });
        //                 toggleIndex==0? getKioskKitchenOrderData("CANCELLED"):getKioskCatOrderData("CANCELLED");
        //                 Get.back();
        //               },
        //               leading:Icon(Icons.star_border_purple500_outlined,size: 20,color:  Theme.of(context).colorScheme.primary) ,
        //               title:Text("CANCELLED ORDERS",style: title.copyWith(fontSize: 20),) ),
        //           value: 1,
        //         ),
        //       ]
        //   ),
        //   SizedBox(width: 10,),
        // ],
      ),
      body: isReady==true?Container(
        child:  SafeArea(
            child: Column(
             crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Container(
                  margin: EdgeInsets.only(top: 10,right: 0,bottom: 6),
                  height: 38,
                  child:ToggleSwitch(
                    minWidth: 170.0,
                    cornerRadius: 20.0,
                    activeBgColors: [[Colors.blue[800]!], [Colors.blue[800]!]],
                    activeFgColor:  Theme.of(context).colorScheme.primary,
                    inactiveBgColor: AppColor.textblues,
                    inactiveFgColor:  Theme.of(context).colorScheme.primary,
                    initialLabelIndex: toggleIndex,
                    totalSwitches: 2,
                    labels: ['DAILY ORDERS', 'CATERING ORDERS'],
                    radiusStyle: true,
                    onToggle: (index) {
                      print('switched to: $index');
                      toggleIndex=index;
                      if(index==0){
                        getKioskKitchenOrderData("SCHEDULED");
                      }else{
                        getKioskCatOrderData("SCHEDULED");
                      }
                      print('switched to: $index');
                    },
                  ) ,
                )
                ,
                SizedBox(height: 10,),
                isSearch?toggleIndex==0?
                Container(
                  width: w * .465,
                  child: Container(
                      margin: EdgeInsets.only(
                          left: 20, right: 20, bottom: 10, top: 30),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7),
                        border: Border(
                            top: BorderSide(
                                width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                            bottom: BorderSide(
                                width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                            right: BorderSide(
                                width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                            left: BorderSide(
                                width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        // borderRadius:  BorderRadius.circular(32),
                      ),
                      child: TextField(
                        //  textAlign: TextAlign.center,
                        style: TextStyle(
                          color: Theme.of(context).colorScheme.primary,
                          fontSize: 22
                        ),
                        onChanged: (value) {
                          setState(() {
                            print(value);
                            tokenNoList=TemptokenNoList.where((u) => (
                                u["token"]
                                .toLowerCase()
                                .contains(value.toLowerCase()) ||
                                    u["customName"]
                                        .toLowerCase()
                                        .contains(value.toLowerCase())

                            ))
                                .toList();


                          });
                        },
                        controller: etsearch,
                        decoration: new InputDecoration(
                          fillColor: Colors.teal,
                          border: InputBorder.none,
                          focusedBorder: InputBorder.none,
                          enabledBorder: InputBorder.none,
                          errorBorder: InputBorder.none,
                          disabledBorder: InputBorder.none,
                          contentPadding: EdgeInsets.only(
                              left: 15, top: 15, right: 15),
                          hintText: "Search Token No / Devotee Name",
                          hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.6)),
                          suffixIcon: etsearch.text.length > 0
                              ? IconButton(
                            onPressed: () {
                              setState(() => etsearch.clear());
                              tokenNoList=TemptokenNoList.where((u) => (
                                  u["token"]
                                      .toLowerCase()
                                      .contains(etsearch.text.toLowerCase()) ||
                                      u["customName"]
                                          .toLowerCase()
                                          .contains(etsearch.text.toLowerCase())

                              ))
                                  .toList();
                              isSearch=false;
                            },
                            icon: Icon(
                              Icons.clear,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          )
                              : Icon(
                            Icons.search,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                      )),
                ):Container(
                  alignment: Alignment.centerRight,
                  width: w,
                  child: Container(

                    width: w * .465,
                    child: Container(
                        margin: EdgeInsets.only(
                            left: 20, right: 20, bottom: 10, top: 30),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(7),
                          border: Border(
                              top: BorderSide(
                                  width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                              bottom: BorderSide(
                                  width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                              right: BorderSide(
                                  width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                              left: BorderSide(
                                  width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                          // borderRadius:  BorderRadius.circular(32),
                        ),
                        child: TextField(
                          //  textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Theme.of(context).colorScheme.primary,
                              fontSize: 22
                          ),
                          onChanged: (value) {
                            setState(() {
                              print(value);
                              tokenNoList=TemptokenNoList.where((u) => (
                                  u["token"]
                                      .toLowerCase()
                                      .contains(value.toLowerCase()) ||
                                      u["customName"]
                                          .toLowerCase()
                                          .contains(value.toLowerCase())

                              ))
                                  .toList();


                            });
                          },
                          controller: etsearch,
                          decoration: new InputDecoration(
                            fillColor: Colors.teal,
                            border: InputBorder.none,
                            focusedBorder: InputBorder.none,
                            enabledBorder: InputBorder.none,
                            errorBorder: InputBorder.none,
                            disabledBorder: InputBorder.none,
                            contentPadding: EdgeInsets.only(
                                left: 15, top: 15, right: 15),
                            hintText: "Search Token No / Devotee Name",
                            hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.6)),
                            suffixIcon: etsearch.text.length > 0
                                ? IconButton(
                              onPressed: () {
                                setState(() => etsearch.clear());
                                tokenNoList=TemptokenNoList.where((u) => (
                                    u["token"]
                                        .toLowerCase()
                                        .contains(etsearch.text.toLowerCase()) ||
                                        u["customName"]
                                            .toLowerCase()
                                            .contains(etsearch.text.toLowerCase())

                                ))
                                    .toList();
                                isSearch=false;
                              },
                              icon: Icon(
                                Icons.clear,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                            )
                                : Icon(
                              Icons.search,
                              color: Theme.of(context).colorScheme.primary,
                            ),
                          ),
                        )),
                  ),
                ):Container(),

                if(toggleIndex==0) Expanded(child: SingleChildScrollView(
                    child:Column(
                      children: [
                        ListView.builder(
                            itemCount: tokenNoList.length,
                            shrinkWrap: true,
                            itemBuilder: (context,index1){
                              kitchenorderstatus.add(false);
                              return Container(
                                margin: EdgeInsets.only(left: 10,top: 0,right: 10,bottom: 10),
                                padding: EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  boxShadow: [
                                    BoxShadow(
                                      color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                                      offset: Offset(-1.0, -1.0),
                                      blurRadius: 1.0,
                                    ),
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      offset: Offset(2.0, 2.0),
                                      blurRadius: 1.0,
                                    ),
                                  ],
                                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                                  borderRadius: BorderRadius.circular(5.0),
                                ),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text("Devotee",style:Theme.of(context).textTheme.bodyText2,),
                                            SizedBox(height: 5,),
                                            Text(tokenNoList[index1]["customName"],style: Theme.of(context).textTheme.bodyText1,maxLines: 3,),
                                          ],
                                        ),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.center
                                          ,
                                          children: [
                                            Text("# Token",style:Theme.of(context).textTheme.bodyText2,),
                                            SizedBox(height: 5,),
                                            Text(tokenNoList[index1]["token"],style: Theme.of(context).textTheme.bodyText1,maxLines: 3,),
                                          ],
                                        )
                                      ],
                                    ),
                                    SizedBox(height: 5,),
                                    Divider(thickness: 0.2,color: Theme.of(context).colorScheme.primary.withOpacity(0.2),),
                                    SizedBox(height: 10,),
                                    Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            children: [
                                              Text("Delivery ",style: Theme.of(context).textTheme.bodyText2,),
                                              Text(tokenNoList[index1]['delivery']??"",style: Theme.of(context).textTheme.bodyText1,),
                                            ],
                                          ),
                                        //  Text(filtterdata[index].status!,style:TextStyle(color:filtterdata[index].status!.toLowerCase()=="ACTIVE".toLowerCase()? Colors.green:Colors.red,fontSize: 16,fontWeight: FontWeight.w600),),

                                        ]),
                                    SizedBox(height: 10,),
                                    Divider(thickness: 0.2,color: Theme.of(context).colorScheme.primary.withOpacity(0.2),),
                                    SizedBox(height: 5,),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text("Order Details ",style: Theme.of(context).textTheme.bodyText2,),
                                        Text("Quantity ",style: Theme.of(context).textTheme.bodyText2,),
                                      ],
                                    ),
                                    SizedBox(height: 5,),
                                    // Row(
                                    //   mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                    //
                                    //   children: [
                                    //     // Container(
                                    //     //     width:w*0.3,
                                    //     //     child: Column(
                                    //     //       crossAxisAlignment: CrossAxisAlignment.start,
                                    //     //       children: [
                                    //     //         Text("Qty On Hand",style: Theme.of(context).textTheme.bodyText2,textAlign:TextAlign.start ,),
                                    //     //         const SizedBox(height: 6,),
                                    //     //         Text(filtterdata[index].quantityOnHand!,style: Theme.of(context).textTheme.bodyText1,textAlign: TextAlign.center,),
                                    //     //       ],
                                    //     //     )
                                    //     // ),
                                    //     Container(
                                    //       width:w*0.3,
                                    //       child: Column(
                                    //
                                    //         children: [
                                    //           Text("Qty On Stock",style: Theme.of(context).textTheme.bodyText2,),
                                    //           const SizedBox(height: 6,),
                                    //           Text(filtterdata[index].quantityOnOrder!,style: Theme.of(context).textTheme.bodyText1,),
                                    //         ],
                                    //       ),
                                    //
                                    //     ),
                                    //     Container(
                                    //         width:w*0.3,
                                    //         child: Column(
                                    //           crossAxisAlignment: CrossAxisAlignment.end,
                                    //           children: [
                                    //             Text("Bin No",style: Theme.of(context).textTheme.bodyText2,),
                                    //             const SizedBox(height: 6,),
                                    //             Text(filtterdata[index].binNo!,style: Theme.of(context).textTheme.bodyText1,),
                                    //           ],
                                    //         )
                                    //     ),
                                    //   ],
                                    // ),
                                    ListView.builder(
                                        itemCount: kitchenOrderData!.data!.length,
                                        shrinkWrap: true,
                                        physics: NeverScrollableScrollPhysics(),
                                        itemBuilder: (context,index){
                                          kitchenorderstatus.add(false);
                                          return tokenNoList[index1]["token"]== kitchenOrderData!.data![index].tokenNo!.toString()?
                                          Container(
                                            margin: EdgeInsets.only(top: 1,bottom: 1),
                                            color: Colors.teal.withOpacity(0.05),
                                            child: Column(
                                              children: [
                                                Divider(
                                                  height: 0.6,
                                                  thickness: 0.6,
                                                  color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                                ),
                                                SizedBox(
                                                  height: 8,
                                                ),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [


                                                     Column(
                                                        children: [
                                                          Text("   "+kitchenOrderData!.data![index].itemName!,
                                                            style: Theme.of(context).textTheme.bodyText1,textAlign: TextAlign.left,
                                                          ),
                                                        ],
                                                      ),

                                                    Column(
                                                        children: [
                                                          Text(kitchenOrderData!.data![index].qty!+"     ",
                                                            style: Theme.of(context).textTheme.bodyText1,
                                                          ),
                                                        ],


                                                    ),

                                                  ],),

                                                SizedBox(
                                                  height: 8,
                                                ),
                                                Divider(
                                                  height: 0.6,
                                                  thickness: 0.6,
                                                  color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                                ),
                                              ],
                                            ),
                                          ):Container();

                                        }
                                    ),
                                    SizedBox(height: 5,),


                                  ],
                                ),
                              );

                            }
                        ),




                      ],
                    ))),
                if(toggleIndex==1) Expanded(child: SingleChildScrollView(
                    child:Column(
                      children: [
                        ListView.builder(
                            itemCount: tokenNoList.length,
                            shrinkWrap: true,
                            physics: NeverScrollableScrollPhysics(),
                            itemBuilder: (context,index1){
                              return Container(
                                margin: EdgeInsets.only(left: 10,top: 0,right: 10,bottom: 10),
                                padding: EdgeInsets.all(8),
                                decoration: BoxDecoration(
                                  boxShadow: [
                                    BoxShadow(
                                      color: Theme.of(context).colorScheme.primary.withOpacity(0.2),
                                      offset: Offset(-1.0, -1.0),
                                      blurRadius: 1.0,
                                    ),
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.2),
                                      offset: Offset(2.0, 2.0),
                                      blurRadius: 1.0,
                                    ),
                                  ],
                                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                                  borderRadius: BorderRadius.circular(5.0),
                                ),
                                child: Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          children: [
                                            Text("Devotee",style:Theme.of(context).textTheme.bodyText2,),
                                            SizedBox(height: 5,),
                                            Text(tokenNoList[index1]["customName"],style: Theme.of(context).textTheme.bodyText1,maxLines: 3,),
                                          ],
                                        ),
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.center
                                          ,
                                          children: [
                                            Text("# Token",style:Theme.of(context).textTheme.bodyText2,),
                                            SizedBox(height: 5,),
                                            Text(tokenNoList[index1]["token"],style: Theme.of(context).textTheme.bodyText1,maxLines: 3,),
                                          ],
                                        )
                                      ],
                                    ),
                                    SizedBox(height: 5,),
                                    Divider(thickness: 0.2,color: Theme.of(context).colorScheme.primary.withOpacity(0.2),),
                                    SizedBox(height: 10,),
                                    Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Row(
                                            children: [
                                              Text("Delivery ",style: Theme.of(context).textTheme.bodyText2,),
                                              Text(tokenNoList[index1]['delivery']??"",style: Theme.of(context).textTheme.bodyText1,),
                                            ],
                                          ),
                                          //  Text(filtterdata[index].status!,style:TextStyle(color:filtterdata[index].status!.toLowerCase()=="ACTIVE".toLowerCase()? Colors.green:Colors.red,fontSize: 16,fontWeight: FontWeight.w600),),

                                        ]),
                                    SizedBox(height: 10,),
                                    Divider(thickness: 0.2,color: Theme.of(context).colorScheme.primary.withOpacity(0.2),),
                                    SizedBox(height: 5,),
                                    Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text("Order Details ",style: Theme.of(context).textTheme.bodyText2,),
                                        Text("Quantity ",style: Theme.of(context).textTheme.bodyText2,),
                                      ],
                                    ),
                                    SizedBox(height: 5,),
                                    // Row(
                                    //   mainAxisAlignment:MainAxisAlignment.spaceBetween,
                                    //
                                    //   children: [
                                    //     // Container(
                                    //     //     width:w*0.3,
                                    //     //     child: Column(
                                    //     //       crossAxisAlignment: CrossAxisAlignment.start,
                                    //     //       children: [
                                    //     //         Text("Qty On Hand",style: Theme.of(context).textTheme.bodyText2,textAlign:TextAlign.start ,),
                                    //     //         const SizedBox(height: 6,),
                                    //     //         Text(filtterdata[index].quantityOnHand!,style: Theme.of(context).textTheme.bodyText1,textAlign: TextAlign.center,),
                                    //     //       ],
                                    //     //     )
                                    //     // ),
                                    //     Container(
                                    //       width:w*0.3,
                                    //       child: Column(
                                    //
                                    //         children: [
                                    //           Text("Qty On Stock",style: Theme.of(context).textTheme.bodyText2,),
                                    //           const SizedBox(height: 6,),
                                    //           Text(filtterdata[index].quantityOnOrder!,style: Theme.of(context).textTheme.bodyText1,),
                                    //         ],
                                    //       ),
                                    //
                                    //     ),
                                    //     Container(
                                    //         width:w*0.3,
                                    //         child: Column(
                                    //           crossAxisAlignment: CrossAxisAlignment.end,
                                    //           children: [
                                    //             Text("Bin No",style: Theme.of(context).textTheme.bodyText2,),
                                    //             const SizedBox(height: 6,),
                                    //             Text(filtterdata[index].binNo!,style: Theme.of(context).textTheme.bodyText1,),
                                    //           ],
                                    //         )
                                    //     ),
                                    //   ],
                                    // ),
                                    ListView.builder(
                                        itemCount:catOrderModel!.data!.length,
                                        shrinkWrap: true,
                                        physics: NeverScrollableScrollPhysics(),
                                        itemBuilder: (context,index){
                                          kitchenorderstatus.add(false);
                                          return tokenNoList[index1]["token"]== catOrderModel!.data![index].tokenNo!.toString()?
                                          Container(
                                            margin: EdgeInsets.only(top: 1,bottom: 1),
                                            color: Colors.teal.withOpacity(0.05),
                                            child: Column(
                                              children: [
                                                Divider(
                                                  height: 0.6,
                                                  thickness: 0.6,
                                                  color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                                ),
                                                SizedBox(
                                                  height: 8,
                                                ),
                                                Row(
                                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                  children: [


                                                    Column(
                                                      children: [
                                                        Text("   "+catOrderModel!.data![index].itemName!,
                                                          style: Theme.of(context).textTheme.bodyText1,textAlign: TextAlign.left,
                                                        ),
                                                      ],
                                                    ),

                                                    Column(
                                                      children: [
                                                        Text(catOrderModel !.data![index].qty!+"     ",
                                                          style: Theme.of(context).textTheme.bodyText1,
                                                        ),
                                                      ],


                                                    ),

                                                  ],),

                                                SizedBox(
                                                  height: 8,
                                                ),
                                                Divider(
                                                  height: 0.6,
                                                  thickness: 0.6,
                                                  color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                                ),
                                              ],
                                            ),
                                          ):Container();

                                        }
                                    ),
                                    SizedBox(height: 5,),


                                  ],
                                ),
                              );
                            }
                        ),




                      ],
                    ))),


              ],
            ),
          ),

      ):Center(child: CircularProgressIndicator(),),

    );
  }
}
