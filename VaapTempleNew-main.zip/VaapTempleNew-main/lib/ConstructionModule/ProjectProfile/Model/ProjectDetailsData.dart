// To parse this JSON data, do
//
//     final projectDetailData = projectDetailDataFromJson(jsonString);

import 'dart:convert';

ProjectDetailData projectDetailDataFromJson(String str) => ProjectDetailData.fromJson(json.decode(str));

String projectDetailDataToJson(ProjectDetailData data) => json.encode(data.toJson());

class ProjectDetailData {
  ProjectDetailData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<Datum>? data;

  factory ProjectDetailData.fromJson(Map<String, dynamic> json) => ProjectDetailData(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.projectName,
    this.projectType,
    this.address,
    this.division,
    this.lotNo,
    this.projectNumber,
    this.squareFeet,
    this.state,
    this.city,
    this.zip,
    this.projectStartDate,
    this.contactName,
    this.phone,
    this.email,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
  });

  String ?id;
  String? projectName;
  String? projectType;
  String? address;
  String? division;
  String? lotNo;
  String? projectNumber;
  String? squareFeet;
  String? state;
  String? city;
  String? zip;
  String ?projectStartDate;
  String ?contactName;
  String ?phone;
  String ?email;
  String ?moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String? recCreDate;
  String? recModBy;
  String? recModDate;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"]??"",
    projectName: json["projectName"]??"",
    projectType: json["projectType"]??"",
    address: json["address"]??"",
    division: json["division"]??"",
    lotNo: json["lotNo"]??"",
    projectNumber: json["projectNumber"]??"",
    squareFeet: json["squareFeet"]??"",
    state: json["state"]??"",
    city: json["city"]??"",
    zip: json["zip"]??"",
    projectStartDate: json["projectStartDate"]??"",
    contactName: json["contactName"]??"",
    phone: json["phone"]??"",
    email: json["email"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "projectName": projectName,
    "projectType": projectType,
    "address": address,
    "division": division,
    "lotNo": lotNo,
    "projectNumber": projectNumber,
    "squareFeet": squareFeet,
    "state": state,
    "city": city,
    "zip": zip,
    "projectStartDate": projectStartDate,
    "contactName": contactName,
    "phone": phone,
    "email": email,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
  };
}
