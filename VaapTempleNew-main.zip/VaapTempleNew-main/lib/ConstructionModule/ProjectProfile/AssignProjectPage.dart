import 'package:aspgen_mobile/ConstructionModule/ProjectProfile/project_detail_controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../AppConstant/AppConstant.dart';
import '../../Widget/ButtonWidget.dart';
import '../../Widget/DropdownButtonWidget.dart';
import '../../Widget/ProjectTitleWidget.dart';
class AssignProjectPage extends StatefulWidget {
  final String title;
  final String projectName;
  final String projectId;
 final String category;
 final String LotNo;
  const AssignProjectPage({Key? key, required this.title, required this.projectName, required this.projectId, required this.category, required this.LotNo}) : super(key: key);

  @override
  State<AssignProjectPage> createState() => _AssignProjectPageState();
}

class _AssignProjectPageState extends State<AssignProjectPage> {

  ProjectDetailController _controller=Get.find();
  @override
  void initState() {
    _controller.getDroupDownData();
    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
         "Assign "+ widget.title,
        ),
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          children: [
            ProjectTitelWidget(projectTitle: widget.projectName, lotNo: widget.LotNo,),
            SizedBox(height: 8,),
            // Row(
            //   crossAxisAlignment:CrossAxisAlignment.start,
            //   children: [
            //     Container(
            //         width: MediaQuery.of(context).size.width*0.35,
            //         child: Text("Category :-",style: Theme.of(context).textTheme.bodyText2!.copyWith(fontSize: 16),)),
            //     Expanded(child: Text(widget.category,style: Theme.of(context).textTheme.bodyText1,)),
            //   ],
            // ),

            SizedBox(height: 10,),
            Container(
              padding: EdgeInsets.only(left: 10,right:10),
              child: GetBuilder<ProjectDetailController>(
                builder: (controller)=>  DropdownButtonWidget(
                  change: (value) {
                   controller.selectedValue=value;
                    controller.getFilterApi(controller.selectedValue["name"]);
                    controller.update();
                    },
                  title: "Select Member Type",
                  list:controller.dropDownList,
                  hint: "Select Member Type",
                  selectvalue: controller.selectedValue,
                  onPress: '',
                ),
              ),
            ),
            SizedBox(height: 5,),
            GetBuilder<ProjectDetailController>(
              builder: (_controller)=> _controller.allContactDatas.value.data!=null?Expanded(
                child:Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: ListView.builder(
                    itemCount:_controller.allContactDatas.value.data!.length ,
                      itemBuilder: (context,index){
                      final datum=_controller.allContactDatas.value.data![index];
                    return Card(
                      shape:const RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(4.0), topRight: Radius.circular(4.0), bottomLeft: Radius.circular(4.0), bottomRight: Radius.circular(4.0))),

                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                      elevation: 8,
                      child: CheckboxListTile(
                          value: datum.isCheckList,
                          title: Text(_controller.allContactDatas.value.data![index].refDataName??""),
                          onChanged: ((value){
                             datum.isCheckList=value!;
                             _controller.update();
                          })
                      ),
                    );
                  }),
                )):Container()
              ,)
          ],
        ),
      ),
    bottomNavigationBar:   Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        // SaveCancelBtn(),
        ButtonWidget(
          onPress: () {


          },
          btnName: 'Assign',
        ),
        SizedBox(
          width: 20,
        ),
        ButtonWidget(
          onPress: () {
            Get.back();
          },
          btnName: 'Cancel',
        )
      ],
    ),
    );
  }
}
