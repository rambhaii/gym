import 'dart:convert';
import 'package:aspgen_mobile/Dashboard/AssetsManagemant/Module/assets_mgmt_data.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';
import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../Dashboard/Contact/Model/AllContactDatas.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/Utils.dart';
import '../../UtilMethods/base_client.dart';
import 'Model/ProjectDetailsData.dart';


class ProjectDetailController extends GetxController{
  ProjectDetailController(this.titile);
  final String titile;
  var datas= ProjectDetailData().obs;
  var selectedValue;
  List<Map> dropDownList=[];

  Rx<AllContactDatas> allContactDatas= AllContactDatas().obs;

  var requestDroupdownbody={};
  TextEditingController etSearch= new TextEditingController();
  var bodyJson={};
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":titile,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip":0,
      "next":40
    };
    fetchApi();
    // TODO: implement onInit
    super.onInit();
  }

  fetchApi()async{
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    print("dvds bvjksdb"+response);
    datas.value=projectDetailDataFromJson(response);
  }
  fetchFilterApi(String text)async{
    var request={
      "text": text,
      "componentConfig": {
        "moduleName":titile,
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    datas.value=projectDetailDataFromJson(response);

  }
  getDroupDownData(){
    requestDroupdownbody["componentConfig"] = {
      "moduleName": "Master Data Management",
      "aspectType": "memberTypes",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": {
        "aspectType":"memberTypes"
      },
      "skip": 0,
      "next": 100
    };
    UtilMethods.getDropDownData(Get.context!, requestDroupdownbody).then((
        value) {

      if(value.data==null)
        return ;
      dropDownList.clear();
      value.data!.forEach((element1) {
        print("vfbjk"+element1.refDataName.toString());
        dropDownList.add({"name": element1.refDataName});
        update();
      });

  });

}
  getFilterApi(String membetType)async{
    var request={
      "text": membetType,
      "componentConfig": {
        "moduleName":"Contacts",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    allContactDatas.value=allContactDatasFromJson(response);
    if(allContactDatas.value.data!.isEmpty)
      {
        Get.snackbar("No Data", "No Data Available",backgroundColor: Colors.amber.withOpacity(0.5),borderRadius: 2);
      }
    update();
  }


}