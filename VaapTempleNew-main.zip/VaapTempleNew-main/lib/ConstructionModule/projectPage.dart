import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../UtilMethods/RemoteServices.dart';
import '../UtilMethods/Utils.dart';
import '../Widget/SearchBarWidget.dart';


class ProjectPage extends StatelessWidget {
  final String title;

  const ProjectPage({Key? key, required this.title}) : super(key: key);

  Widget build(BuildContext context) {
    //ProjectController projectController=Get.put(ProjectController(title));
    TextEditingController etsearch=new TextEditingController();
    double w = MediaQuery
        .of(context)
        .size
        .width;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Select Project",
        ),
      ),
      body: Container(
        margin: EdgeInsets.only(top: 0),

        child: Column(
          children: [
            SizedBox(height: 10,),
            SearchBarWidget(
              hint: "Search Project Name",
              controller: etsearch,
              onchange: (value) {
               //  projectController.filterData(value);
              },
              onCancel: () {
                etsearch.clear();
             //   projectController.filterData(etsearch.text);
              },
            ),
            SizedBox(height: 8,),
            //  Obx(()=>projectController.filtterdata.value!=null? Expanded(
            //     child: RefreshIndicator(
            //       semanticsLabel: "Refresh",
            //       onRefresh: () {
            //         return Future.delayed(Duration.zero, () {
            //        //   getInventroyListData();
            //         });
            //         // return getInventroyListData();
            //       },
            //       child: ListView.builder(
            //           itemCount: projectController.filtterdata.value.length,
            //           itemBuilder: (context, index) {
            //             return Container(
            //               margin: EdgeInsets.only(
            //                   left: 10, top: 10, right: 10, bottom: 1),
            //               padding: EdgeInsets.all(8),
            //               decoration: BoxDecoration(
            //                 boxShadow: [
            //                   BoxShadow(
            //                     color: Theme
            //                         .of(context)
            //                         .colorScheme
            //                         .primary
            //                         .withOpacity(0.2),
            //                     offset: Offset(-1.0, -1.0),
            //                     blurRadius: 1.0,
            //                   ),
            //                   BoxShadow(
            //                     color: Colors.black.withOpacity(0.2),
            //                     offset: Offset(2.0, 2.0),
            //                     blurRadius: 1.0,
            //                   ),
            //                 ],
            //                 color: Theme
            //                     .of(context)
            //                     .colorScheme
            //                     .onPrimaryContainer,
            //                 borderRadius: BorderRadius.circular(5.0),
            //               ),
            //               child: Stack(
            //                 children: [
            //                   Column(
            //                     crossAxisAlignment: CrossAxisAlignment.start,
            //                     children: [
            //                       Row(
            //                         mainAxisAlignment: MainAxisAlignment.start,
            //                         children: [
            //                           Text("Project Name ", style: Theme
            //                               .of(context)
            //                               .textTheme
            //                               .bodyText2,),
            //                         ],
            //                       ),
            //                       SizedBox(height: 5,),
            //                       Row(
            //                         mainAxisAlignment: MainAxisAlignment.start,
            //                         children: [
            //                           Expanded(child: Text(
            //                             projectController.filtterdata.value[index].projectName!,
            //                             style: Theme
            //                                 .of(context)
            //                                 .textTheme
            //                                 .bodyText1, maxLines: 3,)),
            //
            //                           // Text(filtterdata[index].itemName!,style:Theme.of(context).textTheme.bodyText1 ,),
            //                           // Text("subtitle",style:Theme.of(context).textTheme.bodyText1 ,)
            //                         ],
            //                       ),
            //                       SizedBox(height: 5,),
            //                       Divider(thickness: 0.2, color: Theme
            //                           .of(context)
            //                           .colorScheme
            //                           .primary
            //                           .withOpacity(0.2),),
            //                       SizedBox(height: 5,),
            //                       Column(
            //                         crossAxisAlignment: CrossAxisAlignment.start,
            //                         children: [
            //                           Text("Address  ", style: Theme
            //                               .of(context)
            //                               .textTheme
            //                               .bodyText2,),
            //                           SizedBox(height: 6,),
            //                           Text( projectController.filtterdata.value[index].address ?? "",
            //                             style: Theme
            //                                 .of(context)
            //                                 .textTheme
            //                                 .bodyText1, maxLines: 2,),
            //                         ],
            //                       ),
            //                       SizedBox(height: 5,),
            //                       Divider(thickness: 0.2, color: Theme
            //                           .of(context)
            //                           .colorScheme
            //                           .primary
            //                           .withOpacity(0.2),),
            //                       SizedBox(height: 5,),
            //                       Row(
            //                         mainAxisAlignment: MainAxisAlignment
            //                             .spaceBetween,
            //
            //                         children: [
            //                           Container(
            //                               alignment: Alignment.bottomLeft,
            //                               width: w * 0.3,
            //                               child: Column(
            //                                 crossAxisAlignment: CrossAxisAlignment
            //                                     .start,
            //                                 children: [
            //                                   Text("Community", style: Theme
            //                                       .of(context)
            //                                       .textTheme
            //                                       .bodyText2),
            //                                   const SizedBox(height: 6,),
            //                                   Text( projectController.filtterdata.value[index].community!,
            //                                     style: Theme
            //                                         .of(context)
            //                                         .textTheme
            //                                         .bodyText1, maxLines: 2,),
            //                                 ],
            //                               )
            //                           ),
            //                           Container(
            //                             width: w * 0.3,
            //                             child: Column(
            //                               children: [
            //                                 Text("Lot No", style: Theme
            //                                     .of(context)
            //                                     .textTheme
            //                                     .bodyText2,),
            //                                 const SizedBox(height: 6,),
            //                                 Text( projectController.filtterdata.value[index].lotNo!,
            //                                   style: Theme
            //                                       .of(context)
            //                                       .textTheme
            //                                       .bodyText1,),
            //                               ],
            //                             ),
            //
            //                           ),
            //                           Container(
            //                               alignment: Alignment.bottomRight,
            //                               width: w * 0.3,
            //                               child: Column(
            //                                 crossAxisAlignment: CrossAxisAlignment
            //                                     .center,
            //                                 children: [
            //                                   Text("Project No", style: Theme
            //                                       .of(context)
            //                                       .textTheme
            //                                       .bodyText2,),
            //                                   const SizedBox(height: 6,),
            //                                   Text(
            //                                     projectController.filtterdata.value[index].projectNumber!,
            //                                     style: Theme
            //                                         .of(context)
            //                                         .textTheme
            //                                         .bodyText1,),
            //                                 ],
            //                               )
            //                           ),
            //                         ],
            //                       ),
            //                       SizedBox(height: 5,),
            //
            //
            //                     ],
            //                   ),
            //                   Positioned(
            //                       right: 0,
            //                       top: 0,
            //                       child: Row(
            //                         children: [
            //                           InkWell(onTap: () {
            //                             print("cdsbjkkbjsdvbjkdsv"+projectController.filtterdata.value[index].projectId.toString());
            //                             projectController.routManagement(projectController.filtterdata.value[index]);
            //                           },
            //                             child: Container(
            //                                 padding: EdgeInsets.all(6),
            //                                 decoration: BoxDecoration(
            //                                     border: Border.all(
            //                                         width: 1, color: Theme
            //                                         .of(context)
            //                                         .colorScheme
            //                                         .primary),
            //                                     shape: BoxShape.circle
            //                                 ),
            //                                 child: Icon(
            //                                   Icons.arrow_forward, color: Theme
            //                                     .of(context)
            //                                     .colorScheme
            //                                     .primary, size: 20,)),),
            //                         ],
            //                       ))
            //                 ],
            //               ),
            //             );
            //           }),
            //     ),
            // ): Container(),
            //  )
          ],
        ),
      ),
      floatingActionButton: Visibility(
        visible: title == "Project Profile" ? true : false,
        child: FloatingActionButton(
          child: Container(
              alignment: Alignment.center,
              height: 60,
              width: 60,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColor.backgroundColor.withOpacity(0.9),
                border:
                Border.all(width: 1, color: Theme
                    .of(context)
                    .colorScheme
                    .primary
                    .withOpacity(0.1)),
                boxShadow: [
                  BoxShadow(
                    color: Color.fromRGBO(158, 155, 155, 0.7019607843137254),
                    blurRadius: 5,
                    spreadRadius: 2,
                  ),
                ],
              ),
              child: new Icon(Icons.add)),
          focusColor: Colors.transparent,
          backgroundColor: Colors.transparent,
          onPressed: () {
           // CheckInternetConnection().then((value1) => value1==true?  Get.to(()=>ConstructionFieldPage(title: title, type: 1)):"");
          },
        ),
      ),
    );
  }
}


