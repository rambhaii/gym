import 'package:aspgen_mobile/Templates/Model/CategoryData.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../Widget/ProjectTitleWidget.dart';
import '../../../Widget/SelectionTypeWidget.dart';
import '../EstimatorController.dart';

class Tier1Page extends StatefulWidget {
  final String title;
  final String projectId;
  final String projectName;
  final String refDataCode;
  final String response;
  Tier1Page({Key? key, required this.title, required this.projectId, required this.projectName, required this.refDataCode, required this.response})
      : super(key: key);

  @override
  State<Tier1Page> createState() => _Tier1PageState();
}

class _Tier1PageState extends State<Tier1Page> {
  EstimatorController controller=Get.find();
  @override
  void initState() {
    // TODO: implement initState
   // controller.fechApiEstimatorType(widget.refDataCode);
    //print("chbdsbvbdsh"+widget.response);
     controller.tierDatas1=categoryDataFromJson(widget.response);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "${widget.refDataCode[0].toUpperCase()}${widget.refDataCode.substring(1).toLowerCase()}"+" Estimator",
        ),
      ),
      body: Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          children: [
            ProjectTitelWidget(projectTitle:controller.projectTitle, lotNo: controller.projectLotNo),
            SizedBox(height: 10,),
            Expanded(
              child: controller.tierDatas1.data!=null?ListView.builder(
                  itemCount: controller.tierDatas1.data!.length,
                  itemBuilder: (context, index) {
                    return SelectionTypeWidget(title:controller.tierDatas1.data![index].refDataName ?? "", onTap: (){
                      controller.getRoute(controller.tierDatas1.data![index].nextTierLevel!,controller.tierDatas1.data![index].refDataName!,controller.tierDatas1.data![index].aspectType!,widget.refDataCode);

                    },
                      subTitle: controller.tierDatas1.data![index].code!,
                    );
                  })
                  : Container()  ),

          ],
        ),
      ),

    );
  }
}