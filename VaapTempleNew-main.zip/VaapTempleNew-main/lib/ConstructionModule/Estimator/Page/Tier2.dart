import 'package:aspgen_mobile/Templates/Model/CategoryData.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../AppConstant/AppColors.dart';
import '../../../Widget/ProjectTitleWidget.dart';
import '../../../Widget/SelectionTypeWidget.dart';
import '../EstimatorController.dart';

class Tier2Page extends StatefulWidget {
  final String title;
  final String projectId;
  final String projectName;
  final String refDataCode;
  final String response;
  Tier2Page({Key? key, required this.title, required this.projectId, required this.projectName, required this.refDataCode, required this.response})
      : super(key: key);

  @override
  State<Tier2Page> createState() => _Tier1PageState();
}

class _Tier1PageState extends State<Tier2Page> {
  EstimatorController controller=Get.find();
  @override
  void initState() {
    controller.tierDatas2=categoryDataFromJson(widget.response);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "${widget.refDataCode[0].toUpperCase()}${widget.refDataCode.substring(1).toLowerCase()}"+" Estimator",
        ),
      ),
      body: Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            ProjectTitelWidget(projectTitle:controller.projectTitle, lotNo: controller.projectLotNo),
            Expanded(
                child: controller.tierDatas2.data!=null?ListView.builder(
                    itemCount: controller.tierDatas2.data!.length,
                    itemBuilder: (context, index) {
                      return SelectionTypeWidget(title:controller.tierDatas2.data![index].refDataName ?? "", onTap: (){
                        controller.getRoute(controller.tierDatas2.data![index].nextTierLevel!,controller.tierDatas2.data![index].refDataName!,controller.tierDatas2.data![index].aspectType!,controller.tierDatas2.data![index].estimatorCategory!);
                      },
                      subTitle: controller.tierDatas2.data![index].code!,
                      );
                    })
                    : Container()  ),

          ],
        ),
      ),

    );
  }
}