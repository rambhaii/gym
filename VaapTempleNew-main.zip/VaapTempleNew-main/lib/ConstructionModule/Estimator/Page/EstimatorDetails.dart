import 'package:aspgen_mobile/Templates/Model/CategoryData.dart';
import 'package:aspgen_mobile/Templates/construction_field_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../../../AppConstant/AppColors.dart';
import '../../../Templates/fieldPageNew.dart';
import '../../../UtilMethods/RemoteServices.dart';
import '../../../UtilMethods/Utils.dart';
import '../../../Widget/ProjectTitleWidget.dart';
import '../../../Widget/SelectionTypeWidget.dart';
import '../EstimatorController.dart';

class EstimatorDetailsPage extends StatefulWidget {
  final String title;
  final String projectId;
  final String projectName;
  final String refDataCode;

  EstimatorDetailsPage({Key? key, required this.title, required this.projectId, required this.projectName, required this.refDataCode})
      : super(key: key);

  @override
  State<EstimatorDetailsPage> createState() => _EstimatorDetailsPageState();
}

class _EstimatorDetailsPageState extends State<EstimatorDetailsPage> {
  EstimatorController controller=Get.find();
  String title="";

  @override
  void initState() {
    title=widget.refDataCode;

    controller.getEstimatorDetails(title, controller.detailsJson,title);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5
        ),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer);
    BoxDecoration decoration2=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5
        ),
        borderRadius: BorderRadius.circular(1),
        color: Colors.black.withOpacity(0.2));
    return Scaffold(
      appBar: AppBar(
        title: Text(title,
        ),
          actions: [  Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: RawMaterialButton(onPressed: (){
              CheckInternetConnection().then((value1) => value1==true? Get.to(()=>FieldPageNew(title:title,type: 1,),arguments: {"data":controller.detailsJson}):"");
            }
              ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          )]
      ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.only(top: 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              ProjectTitelWidget(projectTitle:controller.projectTitle, lotNo: controller.projectLotNo),
            GetBuilder<EstimatorController>(

            builder: (controller) => controller.estimatorDetails!=null?
           ListView.builder(
                shrinkWrap: true,
                  itemCount: controller.estimatorDetails.length,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (BuildContext context,int index){
                       var datass=controller.estimatorDetails[index];
                       var ListData=[];
                         datass.forEach((key, value) {
                           if(!(key=="recCreDate" || key=="recCreBy" || key=="recModDate"|| key=="recModBy"|| key=="clientID"|| key=="aspectType"||  key=="productID" ||key=="ProjectId" || key=="_id" ||key=="moduleName" ||key=="Estimator Category" ))
                           {ListData.add({"key":key,"value":value});}
                         });
                         print("ListData");
                         print(ListData);
                       return Container(
                         margin: EdgeInsets.all(8),
                         padding: EdgeInsets.only(top: 12,bottom: 20),
                         decoration: decoration,
                         child:
                         Column(
                           crossAxisAlignment: CrossAxisAlignment.start,
                           mainAxisAlignment: MainAxisAlignment.start,
                           children:
                           new List<Widget>.generate(ListData.length, (int index) {
                             return Padding(
                               padding: EdgeInsets.only(top: 8,left: 20,right: 20),
                               child: Column(
                                 crossAxisAlignment: CrossAxisAlignment.start,
                                 children: [
                                  // Text(ListData[index]["key"][0].toString().toUpperCase()+ListData[index]["key"].toString().substring(1),style: Theme.of(context).textTheme.bodyText1!,),
                                  InputDecorator(decoration: InputDecoration(
                                    labelText:"  " +ListData[index]["key"][0].toString().toUpperCase()+ListData[index]["key"].toString().substring(1),
                                    labelStyle: TextStyle(
                                        color: Colors.greenAccent,
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                    contentPadding: EdgeInsets.all(0),
                                    enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(5.0),
                                      borderSide: const BorderSide(
                                          color: Colors.white70, width: 0.0),
                                    ),
                                    border: const OutlineInputBorder(),
                                  ),
                                  child: Container(
                                     padding: EdgeInsets.only(left: 12),
                                      //: EdgeInsets.only(top: 4),
                                      width: Get.width,
                                      child: Text(ListData[index]["key"]=="totalAmount"?"\$ "+double.parse(ListData[index]["value"].toString()).toStringAsFixed(2):ListData[index]["value"].toString(),style: Theme.of(context).textTheme.bodyText2!,)),
                             ) ,
                                   SizedBox(height: 10,)
                                 ],
                               ),
                             );
                           }),
                         ),
                       );

                }
                )
                  :Container(),
              )
            ],
          ),
        ),
      ),

    );
  }

}