import 'package:aspgen_mobile/Templates/Model/CategoryData.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import '../../../Widget/ProjectTitleWidget.dart';
import '../../../Widget/SelectionTypeWidget.dart';
import '../EstimatorController.dart';

class Tier4Page extends StatefulWidget {
  final String title;
  final String projectId;
  final String projectName;
  final String refDataCode;
  final String response;
  Tier4Page({Key? key, required this.title, required this.projectId, required this.projectName, required this.refDataCode, required this.response})
      : super(key: key);

  @override
  State<Tier4Page> createState() => _Tier4PageState();
}

class _Tier4PageState extends State<Tier4Page> {
  EstimatorController controller=Get.find();
  @override
  void initState() {
    controller.tierDatas4=categoryDataFromJson(widget.response);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          "${widget.refDataCode[0].toUpperCase()}${widget.refDataCode.substring(1).toLowerCase()}"+" Estimator",
        ),
      ),
      body: Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          children: [
            ProjectTitelWidget(projectTitle:controller.projectTitle, lotNo: controller.projectLotNo),
            SizedBox(height: 10,),
            Expanded(
                child: controller.tierDatas4.data!=null?ListView.builder(
                    itemCount: controller.tierDatas4.data!.length,
                    itemBuilder: (context, index) {
                      return SelectionTypeWidget(title:controller.tierDatas4.data![index].refDataName ?? "", onTap: (){
                        print("bjsbbjdsv"+controller.tierDatas4.data![index].unitTypes!);
                        controller.getRoute(controller.tierDatas4.data![index].nextTierLevel!,controller.tierDatas4.data![index].refDataName!,controller.tierDatas4.data![index].aspectType!,"");
                      },subTitle: controller.tierDatas4.data![index].code!+" /"+controller.tierDatas4.data![index].unitTypes!);
                    })
                    : Container()  ),

          ],
        ),
      ),

    );
  }
}