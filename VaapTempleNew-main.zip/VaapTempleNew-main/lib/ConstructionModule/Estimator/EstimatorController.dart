import 'dart:convert';

import 'package:aspgen_mobile/ConstructionModule/Estimator/Page/EstimatorDetails.dart';
import 'package:aspgen_mobile/ConstructionModule/Estimator/Page/Tier1.dart';
import 'package:aspgen_mobile/ConstructionModule/Estimator/Page/Tier4.dart';
import 'package:aspgen_mobile/Templates/Model/CategoryData.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/base_client.dart';
import 'Page/Tier2.dart';
import 'Page/Tier3.dart';

class EstimatorController extends GetxController{
  EstimatorController(this.title, this.projectId, this.projectTitle, this.projectLotNo);
  final String title;
  final String projectId;
  final String projectTitle;
  final String projectLotNo;
  var datas= CategoryData().obs;
  var datas2= CategoryData().obs;
  var tierDatas1= CategoryData();
  var tierDatas2= CategoryData();
  var tierDatas3= CategoryData();
  var tierDatas4= CategoryData();
  var bodyJson2={};
  var query={};
   var estimatorDetails;
  String aspectType="";
  var detailsJson={};

  @override
  void onInit() {
    detailsJson={"ProjectId":projectId};
    aspectType=title.toLowerCase()+"Category";
    query={"aspectType":aspectType};
    fechApi(aspectType,query,"Master Data Management").then((value) {
      if(value!="")
        {
          datas.value=categoryDataFromJson(value);
          update();
        }
    });
    super.onInit();
  }
 Future<String> fechApi(String aspectType,var query,String moduleName) async{
    Get.context!.loaderOverlay.show();
    print("cxcbhasbbjdsvjbkds");
    print(getRequestJson(query, aspectType,moduleName));
    var response=await BaseClient().post(APIsConstant.filterAPI, getRequestJson(query, aspectType,moduleName)).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1") "";
    if(jsonDecode(response)["data"]==null) "";
    if(jsonDecode(response)["data"].isEmpty){
     Fluttertoast.showToast(msg: "No Data Available");
    };
    return response;
  }

  getRoute(String Tier,String refDataName,String aspectType,String estimator){
    if(Tier=="TIER 2")
      {
         fechApi("estimatorTypes",{"aspectType":"estimatorTypes","refDataCode":refDataName},"Master Data Management").then((value){
           if(value!="")
             {
               detailsJson.addAll({"Estimator Category":refDataName.toString().trim()});
               Get.to(()=>Tier1Page(title: title, projectId: projectId, projectName: projectTitle, refDataCode: refDataName,response: value,));
             }
         });
      }
    if(Tier=="TIER 3")
    {
      detailsJson.addAll({"Estimator Type":refDataName.trim()});
      fechApi("itemClassification",{"aspectType":"itemClassification","Estimator Category":estimator,"refDataCode":refDataName},"Master Data Management").then((value){
        Get.to(()=>Tier2Page(title: title, projectId: projectId, projectName: projectTitle, refDataCode:detailsJson["Estimator Category"],response: value,));
      });
    }
    if(Tier=="TIER 4")
    {
      detailsJson.addAll({"Item Classification":refDataName.trim()});
      fechApi("itemSeries",{"aspectType":"itemSeries","Estimator Category":detailsJson["Estimator Category"],"Estimator Type":detailsJson["Estimator Type"],"refDataCode":refDataName},"Master Data Management").then((value){
        Get.to(()=>Tier3Page(title: title, projectId: projectId, projectName: projectTitle, refDataCode: refDataName,response: value,));
      });
    }
    if(Tier=="TIER 5")
    {
      detailsJson.addAll({"itemName":refDataName.trim()});
      fechApi("itemName",{"aspectType":"itemName","Estimator Category":detailsJson["Estimator Category"],"Estimator Type":detailsJson["Estimator Type"],"Item Classification":detailsJson["Item Classification"],"refDataCode":refDataName},"Master Data Management").then((value){
        Get.to(()=>Tier4Page(title: title, projectId: projectId, projectName: projectTitle, refDataCode: refDataName,response: value,));
      });
    }
    if(Tier=="" || Tier=="NO")
      {
        Get.to(()=>EstimatorDetailsPage(title: title, projectId: projectId, projectName: projectTitle, refDataCode: detailsJson["Estimator Category"]));
      }
  }
  getRequestJson(var query,String aspectType,String moduleName){
    bodyJson2["componentConfig"] = {
      "moduleName":moduleName,
      "aspectType": aspectType,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": query,
      "skip": 0,
      "next": 100
    };
    return bodyJson2;
  }


  getEstimatorDetails(String aspectType,var query,String moduleName){
    print("vdsnnvdsnkv"+moduleName.replaceAll(" ", "").toLowerCase()+"Estimator");
    print(query);
//  fechApi(moduleName.replaceAll(" ", "").toLowerCase()+"Estimator",query,moduleName).then((value){
    fechApi("doorsAndWindow"+"Estimator",query,moduleName).then((value){
      estimatorDetails=jsonDecode(value)["data"];
      update();
    });

  }
  Future<List> estimatorApi(String moduleName) async{
  var request=  {
                    "componentConfig": {
                                        "moduleName":moduleName,
                                        "productID": "62c807133d9ee4045ab78d4d",
                                        "clientID": "62cc02e44c25557a1fdbf9a6",
                                        "userName": "Harshna001",
                                        "skip":0,
                                        "next":40
                                        }
                    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.estimatorDetailAPI,request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1"){
      Fluttertoast.showToast(msg: "No Data Available");
      return [""];
    };
    if(jsonDecode(response)["data"]==null) "";
    if(jsonDecode(response)["data"].isEmpty){
      Fluttertoast.showToast(msg: "No Data Available");
    };
     update();
    return json.decode(response)["data"];
  }
}

