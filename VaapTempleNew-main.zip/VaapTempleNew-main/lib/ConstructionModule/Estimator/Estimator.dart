
import 'package:aspgen_mobile/ConstructionModule/Estimator/EstimatorController.dart';
import 'package:aspgen_mobile/Widget/ProjectTitleWidget.dart';
import 'package:aspgen_mobile/Widget/SelectionTypeWidget.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'Page/Tier1.dart';
class EstimatorPage extends StatelessWidget {
  final String title;
  final String projectId;
  final String projectName;
  final String lotNo;
  const EstimatorPage(
      {Key? key, required this.title, required this.projectId, required this.projectName, required this.lotNo})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    EstimatorController controller=Get.put(EstimatorController(title,projectId,projectName,lotNo));
    return Scaffold(
      appBar: AppBar(
        title: Text(
          title,
        ),
      ),
      body: Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          children: [
            ProjectTitelWidget(projectTitle: projectName, lotNo: lotNo),
            SizedBox(height: 10,),
            GetBuilder<EstimatorController>(
                builder: (controller1) =>controller.datas.value.data!=null?ListView.builder(
                  itemCount: controller.datas.value.data!.length,
                  shrinkWrap: true,
                  itemBuilder: (context, index) {
                    return ExpansionTileCard(
                        expandedColor:Colors.grey.withOpacity(0.2),
                      elevation: 0,
                      initiallyExpanded: controller.datas.value.data![index].isExpand!,
                        baseColor: Colors.transparent,
                        onExpansionChanged: ((value){
                          controller.datas.value.data![index].estimatorCategorydeatais!.isEmpty?controller.estimatorApi(controller.datas.value.data![index].refDataName!).then((value) {
                             print("vsdbbvhjds"+value.toString());
                             if(!value.isEmpty){
                               controller.datas.value.data![index].estimatorCategorydeatais=value;
                               controller.datas.value.data![index].isExpand=true;
                             }
                             else{
                               controller.datas.value.data![index].isExpand=true;
                             }

                          }):"";
                        //  controller.getRoute(controller.datas.value.data![index].nextTierLevel!,controller.datas.value.data![index].refDataName!,controller.datas.value.data![index].aspectType!,controller.datas.value.data![index].refDataName!);

                        }),

                        trailing: RawMaterialButton(child: Icon(Icons.arrow_forward,),
                        fillColor: Theme.of(context).backgroundColor,

                          constraints : const BoxConstraints(minWidth: 30.0, minHeight: 30.0),
                        shape: CircleBorder(),
                        elevation: 5,
                        onPressed: (){
                          controller.getRoute(controller.datas.value.data![index].nextTierLevel!,controller.datas.value.data![index].refDataName!,controller.datas.value.data![index].aspectType!,controller.datas.value.data![index].refDataName!);

                        },),
                      key: new GlobalKey(),
                      title: Text(controller.datas.value.data![index].refDataName!),
                      children:List.generate(controller.datas.value.data![index].estimatorCategorydeatais!.length, (index2) => Container(
                          child: Container(
                            margin: EdgeInsets.only(left: 20,bottom: 15),
                            child: Column(
                              children: [
                                Row(
                                  children: [
                                    Text("No Of Items: ",style: Theme.of(context).textTheme.bodyText1!),
                                    Text(controller.datas.value.data![index].estimatorCategorydeatais![index2]["No Of Item"].toString()+" Unit",style: Theme.of(context).textTheme.headline4!.copyWith(fontSize: 18,color: Colors.blueAccent),),
                                  ],
                                ),
                                SizedBox(height: 8,),
                                Row(
                                  children: [
                                    Text("Total Amount:   ",style: Theme.of(context).textTheme.bodyText1,),
                                    Text("\$ "+(controller.datas.value.data![index].estimatorCategorydeatais![index2]["Total Amount"]).toStringAsFixed(2),style: Theme.of(context).textTheme.headline4!.copyWith(fontSize: 18,color: Colors.amber)),
                                  ],
                                ),
                              ],
                            ),
                          )))
                    );
                    // return SelectionTypeWidget(title:controller.datas.value.data![index].refDataName ?? "", onTap: (){
                     // controller.getRoute(controller.datas.value.data![index].nextTierLevel!,controller.datas.value.data![index].refDataName!,controller.datas.value.data![index].aspectType!,controller.datas.value.data![index].refDataName!);
                    // });
                  })
             : Container()  )

          ],
        ),
      ),

    );
  }
}

