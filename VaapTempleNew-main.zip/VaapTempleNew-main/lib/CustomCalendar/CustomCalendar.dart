import 'package:aspgen_mobile/CustomCalendar/controller.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
class CustomCalendar extends StatefulWidget {
  const CustomCalendar({Key? key}) : super(key: key);

  @override
  State<CustomCalendar> createState() => _CustomCalendarState();
}

class _CustomCalendarState extends State<CustomCalendar> {
  CustomClock clockController=Get.put(CustomClock());

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(title: Text("Custom Calendar"),),
        body: Column(
          children: [
            Container(
              height:45,

              child: TabBar(
                onTap: (value){
                  clockController.tabCalculator(value);
                  clockController.index.value=value;
                },
                tabs: [
                Tab(text: "Day",),
                Tab(text: "Week",),
                Tab(text: "Month",),
                Tab(text: "Year",),
              ],
              ),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                IconButton(onPressed: (){
                  if(clockController.index==1)
                    {
                      clockController.prevDateWeek();
                      return;
                    } if(clockController.index==2)
                    {
                      clockController.prevDateMonth();
                      return;
                    }
                  if(clockController.index==3)
                    {
                      clockController.prevYear();
                      return;
                    }
                  clockController.preDate();
                  }, icon: Icon(Icons.arrow_back_ios)),

                Obx(() => Text(clockController.rxStartDate.value)),
                IconButton(onPressed: (){
                  if(clockController.index==1)
                  {
                    clockController.nextDateWeek();
                    return;
                  }
                  if(clockController.index==2)
                  {
                    clockController.nextDateMonth();
                    return;
                  }
                  if(clockController.index==3)
                  {
                    clockController.nextYear();
                    return;
                  }
                  clockController.nextDate();
                }, icon: Icon(Icons.arrow_forward_ios_outlined)),

              ],
            ),
            Container(
        height: 50,
              child: TabBarView(
                children: [
                  Day(),
                  Week(),
                  Day(),
                  Day(),
                ],
              ),
            )

          ],
        ),
      ),
    );
  }
  Widget Day(){
    return Obx(() =>  Text(clockController.rxStartDate.value));
  }
  Widget Week(){
    return Obx(() =>  Text(clockController.rxStartDate.value));
  }
}
