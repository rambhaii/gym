import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';

class CustomClock extends GetxController{
  RxInt index=1.obs;
  DateTime singleDate= new DateTime.now();
  RxString rxStartDate="".obs;
  RxString rxEndDate="".obs;

  DateTimeRange pickedRangeDate=DateTimeRange(start: DateTime.now(), end: DateTime.now().add(Duration(days: 7)));
  final DateFormat formatter = DateFormat('MMM dd , yyyy');

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }

  tabCalculator(int i){
    switch(i){
      case 0:
        singleDate=DateTime.now();
        rxStartDate.value=formatter.format(singleDate);
        break;
        case 1:
          DateTimeRange pickedRangeDate=DateTimeRange(start: DateTime.now(), end: DateTime.now().add(Duration(days: 7)));
          rxStartDate.value= formatter.format(pickedRangeDate.start)+" - "+ formatter.format(pickedRangeDate.end);
        break;
        case 2:
          DateTimeRange date=DateTimeRange(start:DateTime(pickedRangeDate.start.year, pickedRangeDate.start.month, 1), end:DateTime(pickedRangeDate.start.year, pickedRangeDate.start.month + 1,0));
          rxStartDate.value= formatter.format(date.start)+" - "+ formatter.format(date.end);
        break;
        case 3:
          DateTimeRange date=DateTimeRange(start:DateTime(pickedRangeDate.start.year, 1 , 1), end:DateTime(pickedRangeDate.start.year, 13 ,0));
          rxStartDate.value= formatter.format(date.start)+" - "+ formatter.format(date.end);
          break;
    }
  }
  nextDate(){
     DateTime date= singleDate.add(Duration(days: 1));
     singleDate=date;
    rxStartDate.value=  formatter.format(date);
  }
  preDate(){
    DateTime date= singleDate.subtract(Duration(days: 1));
    singleDate=date;
    rxStartDate.value=  formatter.format(date);
  }
  nextDateWeek(){
    DateTimeRange date=DateTimeRange(start:pickedRangeDate.end, end: pickedRangeDate.end.add(Duration(days: 7)));
     pickedRangeDate=date;
    rxStartDate.value= formatter.format(date.start)+" - "+ formatter.format(date.end);
  }
  prevDateWeek(){
    DateTimeRange date=DateTimeRange(start:pickedRangeDate.start.subtract(Duration(days: 7)), end: pickedRangeDate.end.subtract(Duration(days: 7)));
    pickedRangeDate=date;
    rxStartDate.value= formatter.format(date.start)+" - "+ formatter.format(date.end);
  }
  nextDateMonth(){
    var noOfMonth =  DateTime(pickedRangeDate.start.year, pickedRangeDate.start.month+2, 0);
    DateTimeRange date=DateTimeRange(start:DateTime(pickedRangeDate.start.year, pickedRangeDate.start.month + 1, 1), end:DateTime(pickedRangeDate.start.year, pickedRangeDate.start.month + 1,noOfMonth.day));
    pickedRangeDate=date;
    rxStartDate.value= formatter.format(date.start)+" - "+ formatter.format(date.end);
  }
  prevDateMonth(){
    var noOfMonth =  DateTime(pickedRangeDate.start.year, pickedRangeDate.start.month-2, 0);
    DateTimeRange date=DateTimeRange(start:DateTime(pickedRangeDate.start.year, pickedRangeDate.start.month - 1, 1), end:DateTime(pickedRangeDate.start.year, pickedRangeDate.start.month -1,noOfMonth.day));
    pickedRangeDate=date;
    rxStartDate.value= formatter.format(date.start)+" - "+ formatter.format(date.end);
  }
  nextYear(){
    var noOfMonth =  DateTime(pickedRangeDate.start.year, 12, 0);
    DateTimeRange date=DateTimeRange(start:DateTime(pickedRangeDate.start.year+1, 1 , 1), end:DateTime(pickedRangeDate.start.year+1, 12 ,noOfMonth.day));
    pickedRangeDate=date;
    rxStartDate.value= formatter.format(date.start)+" - "+ formatter.format(date.end);
  }
  prevYear(){
    var noOfMonth =  DateTime(pickedRangeDate.start.year, 12, 0);
    DateTimeRange date=DateTimeRange(start:DateTime(pickedRangeDate.start.year-1, 1 , 1), end:DateTime(pickedRangeDate.start.year-1, 12 ,noOfMonth.day));
    pickedRangeDate=date;
    rxStartDate.value= formatter.format(date.start)+" - "+ formatter.format(date.end);
  }
}