import 'dart:io';

import 'package:aspgen_mobile/main.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'AppConstant/AppConstant.dart';
import 'flavors.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  AppConstant.sharedPreference=await SharedPreferences.getInstance();
  HttpOverrides.global = MyHttpOverrides();
  F.appFlavor = Flavor.CONTRACTOR;
  runApp( MyApp());
}
