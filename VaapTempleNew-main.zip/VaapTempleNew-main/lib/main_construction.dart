import 'dart:io';

import 'package:aspgen_mobile/main.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'AppConstant/AppConstant.dart';
import 'flavors.dart';

void main()async{
  WidgetsFlutterBinding.ensureInitialized();
  AppConstant.sharedPreference=await SharedPreferences.getInstance();
  HttpOverrides.global = MyHttpOverrides();
  await GetStorage.init();
  F.appFlavor = Flavor.CONSTRUCTION;
  runApp( MyApp());
}
