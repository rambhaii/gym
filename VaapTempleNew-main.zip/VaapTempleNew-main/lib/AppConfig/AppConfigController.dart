import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../AppConstant/AppConstant.dart';
import '../AppConstant/AppThemes.dart';
import '../AppConstant/theme_services.dart';

class AppConfigController extends GetxController{
  RxString apptheme = "Dark".obs;
  RxList<String> languageList=[""].obs;
  final GlobalKey<ExpansionTileCardState> expensionThemeKey = new GlobalKey();
  final GlobalKey<ExpansionTileCardState> expensionLanguageKey = new GlobalKey();

  onChangeRadioValue(String value){
    if(value=="Dark")
      {
        ThemeService().changeThemeMode(ThemeMode.dark);
      }
    else{
      ThemeService().changeThemeMode(ThemeMode.light);
    }
    apptheme.value=value;
  }
  RxList<bool> isSelected=[false].obs;
  @override
  void onInit() {
    languageList.value=storage.read(AppConstant.language);
    languageList.value.forEach((element) {
      if(element=="en_US")
        {
          isSelected.value.add(true);
        }
      else{
        isSelected.value.add(false);
      }

    });

    // TODO: implement onInit
    super.onInit();
  }
  onChange(index){
    isSelected.value.clear();
    languageList.value.forEach((element) {
      isSelected.value.add(false);
    });
    isSelected.value[index]=true;

  }
}