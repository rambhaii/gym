import 'package:cached_network_image/cached_network_image.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'AppConfigController.dart';
class AppConfig extends StatelessWidget {
  AppConfig({Key? key}) : super(key: key);
  AppConfigController appConfigController=Get.put(AppConfigController());
  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.1),width: 0.4)),

        color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.3));
    return Scaffold(
      appBar: AppBar(title: Text("App Config"),),
      body: SingleChildScrollView(
        child: Container(
          padding: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 10,),

              ListTileTheme(
                dense: true,
                horizontalTitleGap: 15.0,
                minLeadingWidth: 0,
                child: ExpansionTileCard(
                    baseColor: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.2),
                    elevation: 0,
                    expandedColor:Colors.transparent,
                    finalPadding: EdgeInsets.zero,
                    leading:Icon(Icons.dark_mode_outlined),
                    key: appConfigController.expensionThemeKey,
                    title: Text("App Themes"),
                    children:<Widget>
                    [

                      Container(
                        decoration: decoration,
                        child: Obx(()=> Row(
                          children: [
                            Expanded(flex: 5,   child: ListTile(title: Text("Dark"),
                              leading:   Radio(
                                value: "Dark",
                                groupValue: appConfigController.apptheme.value,
                                onChanged: (value) {
                                  appConfigController.onChangeRadioValue(value.toString());
                                },
                              ),
                            )),
                            Expanded(flex: 5, child: ListTile(title:  Text("Light"),
                              leading:  Radio(
                                value: "Light",
                                groupValue: appConfigController.apptheme.value,
                                onChanged: (value) {
                                  appConfigController.onChangeRadioValue(value.toString());
                                },
                              ),
                            ),),
                            Spacer(flex: 1),
                          ],
                        ),
                        ),
                      ),

                    ]
                ),
              ),

              SizedBox(height: 15,),

              ListTileTheme(
                dense: true,
                horizontalTitleGap: 15.0,
                minLeadingWidth: 0,
                child: ExpansionTileCard(
                    baseColor: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.2),
                    elevation: 0,
                    expandedColor:Colors.transparent,
                    finalPadding: EdgeInsets.zero,

                    leading:Icon(Icons.g_translate),
                    key: appConfigController.expensionLanguageKey,
                    title: Text("App Languages"),
                    children:<Widget>
                    [
                    Container(
                      decoration: decoration,
                      child: Obx(()=>appConfigController.languageList.value.isNotEmpty?ListView.builder(
                      shrinkWrap: true,
                      itemCount:appConfigController.languageList.value.length ,
                      itemBuilder: (BuildContext ctx,index)
                      {
                        final e=appConfigController.languageList.value[index];
                        return Card(
                          elevation: 0,
                          color:appConfigController.isSelected.value[index]? Colors.greenAccent.withOpacity(0.1):Colors.transparent,
                          child: ListTile(
                              onTap: (){
                                appConfigController.onChange(index);

                                switch(e)
                                {
                                  case "en_US":
                                    Get.updateLocale(Locale('en','US'));
                                    break;
                                  case "es_HN":
                                    Get.updateLocale(Locale('es','VE'));
                                    break;
                                  case "hi_IN":
                                    Get.updateLocale(Locale('hi','IN'));
                                    break;
                                  case "fr_BE":
                                    Get.updateLocale(Locale('fr','BE'));
                                    break;
                                }
                                // Get.back();
                              },
                              selectedTileColor: Colors.red,
                              leading: Image.asset(
                                e=="en_US"?"packages/country_pickers/assets/us.png":
                                e=="hi_IN"?"packages/country_pickers/assets/in.png":
                                e=="fr_BE"?"packages/country_pickers/assets/fr.png":
                                "packages/country_pickers/assets/id.png",
                                height: 28,width: 42,fit: BoxFit.cover,),
                              //Icon(Icons.flag, color: Theme.of(context).colorScheme.primary),
                              title: Text(
                                e=="en_US"?"English":
                                e=="hi_IN"?"Hindi":
                                e=="fr_BE"?"French": "Spanish",
                                style: TextStyle(color: Theme.of(context).colorScheme.primary),
                              ),
                              trailing:appConfigController.isSelected.value[index]? Image.asset("assets/images/check.png",height: 30,width: 30,):Text("")
                          ),
                        );
                      },
              ):Container(),
                      ),
                    )



                    ]
                ),
              ),



            ],
          ),
        ),
      ),
    );
  }
}
