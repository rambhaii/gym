import 'package:aspgen_mobile/calendar/Booking/BookingCalender.dart';
import 'package:aspgen_mobile/calendar/calendar.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../Widget/SelectionTypeWidget.dart';

class SelectCalendarPage extends StatelessWidget {
  final String title;
   SelectCalendarPage({Key? key,required this.title}) : super(key: key);
  List<String> item=[
    "Temple",
    "Priest",
    "Bookings"
  ];
  @override
  Widget build(BuildContext context) {
    TextEditingController etsearch=new TextEditingController();
    return Scaffold(
      appBar: AppBar(
        title: Text("Select "+title),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top:8.0,left: 4,right: 4),
        child: ListView.builder(
                  itemCount:item.length,
                  itemBuilder: (context,index)
                  {
                    return SelectionTypeWidget(title: item[index].toUpperCase(), onTap: (){
                    });


                  }),
      ),
    );
  }
}