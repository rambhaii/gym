import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/Widget/DropdownButtonWidget.dart';
import 'package:flutter/material.dart';
class serviceSelectPage extends StatefulWidget {
  @override
  _HomePageState createState() => new _HomePageState();
}

class _HomePageState extends State<serviceSelectPage> {
  bool loading = true;
  bool subLoading = false;
  bool searchBar = false;
  late List<Map> serviceCategory = [];
  TextEditingController controller = new TextEditingController();
  var selectedServiceCat;
  var serviceCatVar = "";
  var index4 = 0;
  // Get json result and convert it to model. Then add
  Future<Null> getUserDetails() async {
    setState(() {
      loading = true;
    });

  }

  @override
  void initState() {
    super.initState();
    getUserDetails();
  }

  @override
  Widget build(BuildContext context) {
    return new Scaffold(
      appBar: AppBar(
        title: Text(
          "Select Service",
          style: TextStyle(color: Theme.of(context).colorScheme.primary),
          textAlign: TextAlign.center,
        ),
        actions: [
          Padding(
            padding: EdgeInsets.only(right: 20),
            child: InkWell(
              onTap: () {
                setState(() {
                  searchBar = searchBar ? false : true;
                });
              },
              child: Icon(Icons.search),
            ),
          )
        ],

      ),
      body: loading
          ? Center(
              child: CircularProgressIndicator()
            )
          : Container(
              color:AppColor.backgroundColor,
              child: new Column(
                children: <Widget>[
                  Padding(
                    padding: EdgeInsets.all(10),
                    child: DropdownButtonWidget(
                      change: (value) {
                        setState(() {
                          selectedServiceCat = value;
                          serviceCatVar = selectedServiceCat["name"];
                        });
                        setState(() {
                          _userDetails.clear();
                          subLoading = true;
                        });
                        },
                      title: 'Select Service Category',
                      list: serviceCategory,
                      hint: 'Select Service Category',
                      selectvalue: selectedServiceCat,
                      onPress: '',
                    ),
                  ),
                  subLoading ? CircularProgressIndicator() : Container(),
                  searchBar
                      ? new Container(
                          margin: const EdgeInsets.all(18.0),
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(7),
                            border: Border(
                                top: BorderSide(
                                    width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                bottom: BorderSide(
                                    width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                right: BorderSide(
                                    width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                left: BorderSide(
                                    width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                            color: Theme.of(context).colorScheme.onPrimaryContainer,
                            // borderRadius:  BorderRadius.circular(32),
                          ),
                          child: new Padding(
                            padding: const EdgeInsets.all(0),
                            child: new ListTile(
                              leading: new Icon(
                                Icons.search,
                                color: Theme.of(context).colorScheme.primary,
                              ),
                              title: new TextField(
                                style: TextStyle(color: Theme.of(context).colorScheme.primary),
                                controller: controller,
                                decoration: new InputDecoration(
                                    hintText: 'Search',
                                    border: InputBorder.none,
                                    hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary)),
                                onChanged: onSearchTextChanged,
                              ),
                              trailing: new IconButton(
                                icon: new Icon(Icons.cancel, color: Theme.of(context).colorScheme.primary),
                                onPressed: () {
                                  controller.clear();
                                  onSearchTextChanged('');
                                },
                              ),
                            ),
                          ),
                        )
                      : Container(),
                  new Expanded(
                    child: _searchResult.length != 0 ||
                            controller.text.isNotEmpty
                        ? new ListView.builder(
                            itemCount: _searchResult.length,
                            itemBuilder: (context, i) {
                              return new Card(
                                color: AppColor.backgroundColor,
                                child: Container(
                                  decoration: BoxDecoration(
                                      border: Border(
                                          top: BorderSide(
                                              width: 0.1,
                                              color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                          bottom: BorderSide(
                                              width: 0.1,
                                              color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                                      color: Theme.of(context).colorScheme.onPrimaryContainer),
                                  child: new ListTile(
                                    title: new Text(_searchResult[i].firstName,
                                        style: TextStyle(color: Theme.of(context).colorScheme.primary)),
                                    trailing: Icon(
                                      Icons.arrow_forward_ios,
                                      size: 15.0,
                                      color:Theme.of(context).colorScheme.primary,
                                    ),
                                    onTap: () {

                                      // Navigator.push(
                                      //     context,
                                      //     MaterialPageRoute(
                                      //         builder: (context) => AddEventNew(
                                      //               title: _searchResult[i]
                                      //                       .firstName +
                                      //                   "," +
                                      //                   _searchResult[i].id,
                                      //             )));
                                    },
                                  ),
                                ),
                                margin: const EdgeInsets.all(0.0),
                              );
                            },
                          )
                        : new ListView.builder(
                            itemCount: _userDetails.length,
                            itemBuilder: (context, index) {
                              return new Card(
                                color: AppColor.backgroundColor,
                                child: Container(
                                  decoration: BoxDecoration(
                                      border: Border(
                                          top: BorderSide(
                                              width: 0.1,
                                              color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                                          bottom: BorderSide(
                                              width: 0.1,
                                              color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                                      color: Theme.of(context).colorScheme.onPrimaryContainer),
                                  child: new ListTile(
                                    //leading: new CircleAvatar(backgroundImage: new NetworkImage(_userDetails[index].profileUrl,),),
                                    title: new Text(
                                      _userDetails[index].firstName,
                                      style: TextStyle(color: Theme.of(context).colorScheme.primary),
                                    ),
                                    trailing: Icon(
                                      Icons.arrow_forward_ios,
                                      size: 15.0,
                                      color: Theme.of(context).colorScheme.primary,
                                    ),
                                    onTap: () {
                                      // Navigator.pop(context, _userDetails[index].firstName+","+_userDetails[index].id);
                                      // Navigator.push(
                                      //     context,
                                      //     MaterialPageRoute(
                                      //         builder: (context) => AddEventNew(
                                      //               title: _userDetails[index]
                                      //                       .firstName +
                                      //                   "," +
                                      //                   _userDetails[index].id,
                                      //             )));
                                    },
                                  ),
                                ),
                                margin: const EdgeInsets.all(0.0),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
    );
  }

  onSearchTextChanged(String text) async {
    _searchResult.clear();
    if (text.isEmpty) {
      setState(() {});
      return;
    }

    _userDetails.forEach((userDetail) {
      if (userDetail.firstName.contains(text.toUpperCase()) ||
          userDetail.lastName.contains(text.toUpperCase()))
        _searchResult.add(userDetail);
    });

    setState(() {});
  }
}

List<UserDetails> _searchResult = [];

List<UserDetails> _userDetails = [];

class UserDetails {
  final String id;
  final String firstName, lastName, profileUrl;

  UserDetails(
      {required this.id,
      required this.firstName,
      required this.lastName,
      this.profileUrl =
          'https://i.amz.mshcdn.com/3NbrfEiECotKyhcUhgPJHbrL7zM=/950x534/filters:quality(90)/2014%2F06%2F02%2Fc0%2Fzuckheadsho.a33d0.jpg'});

  factory UserDetails.fromJson(Map<String, dynamic> json) {
    return new UserDetails(
      id: json['_id'] == null ? "" : json['_id'],
      firstName: json['serviceName'],
      lastName: "",
    );
  }
}
