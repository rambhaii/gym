import 'dart:convert';

import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';

import '../AppConstant/APIsConstant.dart';
import '../AppConstant/AppConstant.dart';
import '../UtilMethods/BaseController.dart';
import '../UtilMethods/base_client.dart';
import 'calendar.dart';
import 'module/calendar_data.dart';

class EventCalendarController extends GetxController{
  EventCalendarController(this.title);
  final String title;
  var datas= CalendraData().obs;
  var  calendarView=CalendarView.schedule.obs;

  CalendarController controller = CalendarController();

  var bodyJson={};
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":title,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip":0,
      "next":300
    };
    // TODO: implement onInit
    super.onInit();
    fetchApi();
  }
  fetchApi()async{
    var response=await BaseClient().post(APIsConstant.getAPI, bodyJson).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    datas.value=calendraDataFromJson(response);
  }
  void onCalendarTapped(CalendarTapDetails details) {
    if (details.targetElement == CalendarElement.appointment || details.targetElement == CalendarElement.agenda) {
      final Appointment appointmentDetails = details.appointments![0];
      final index =datas.value.data!.indexWhere((element) => element.id ==appointmentDetails.id);
      Datum datas2=datas.value.data![index];
      print(datas2.refDataName);
      Get.to(()=>EditEvent(title: title,),arguments: {"data":datas2});
    }
  }
}