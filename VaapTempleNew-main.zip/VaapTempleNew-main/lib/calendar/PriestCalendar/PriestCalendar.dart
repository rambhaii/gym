library event_calendar;

import 'dart:collection';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'dart:math';

import 'package:aspgen_mobile/AppConstant/AppThemes.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;
import 'package:http/io_client.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import 'package:syncfusion_flutter_core/theme.dart';

import '../../AppConstant/AppColors.dart';
import '../module/menu_item.dart';
import 'PriestBookingController.dart';

class PriestBookingCalendar extends StatefulWidget {
  final String title;
  final String displayName;
  const PriestBookingCalendar({Key? key, required this.title, required this.displayName}) : super(key: key);

  @override
  PriestBookingCalendarState createState() => PriestBookingCalendarState();
}
class PriestBookingCalendarState extends State<PriestBookingCalendar> {
  late PriestBookingCalendarController eventCalendarController;
  @override
  void initState() {
    eventCalendarController=Get.put(PriestBookingCalendarController(widget.title));
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.displayName,
        ),

      ),
      resizeToAvoidBottomInset: false,
      body:Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Container(
            color: AppColor.backgroundColor,
            padding: EdgeInsets.only(top: 10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                InkWell(
                    onTap: () {
                      eventCalendarController.controller.view = CalendarView.day;
                    },
                    child: Column(
                      children: [
                        new Icon(
                          Icons.calendar_view_day,
                          color:Theme.of(context).colorScheme.primary,
                          size: 24.0,
                        ),
                        Text(
                          "Day",
                          style: TextStyle(color: Theme.of(context).colorScheme.primary),
                        )
                      ],
                    )),
                InkWell(
                  onTap: () {
                    eventCalendarController.controller.view = CalendarView.schedule;
                  },
                  child: Column(
                    children: [
                      new Icon(
                        Icons.list,
                        color:Theme.of(context).colorScheme.primary,
                        size: 24.0,
                      ),
                      Text(
                        "List",
                        style: TextStyle(color:Theme.of(context).colorScheme.primary),
                      )
                    ],
                  ),
                ),
                InkWell(
                    onTap: () {
                      eventCalendarController.controller.view = CalendarView.workWeek;
                    },
                    child: Column(
                      children: [
                        new Icon(
                          Icons.calendar_view_week,
                          color: Theme.of(context).colorScheme.primary,
                          size: 24.0,
                        ),
                        Text(
                          "Week",
                          style: TextStyle(color:Theme.of(context).colorScheme.primary),
                        )
                      ],
                    )),
                InkWell(
                    onTap: () {
                      eventCalendarController.controller.view = CalendarView.month;
                    },
                    child: Column(
                      children: [
                        new Icon(
                          Icons.calendar_today,
                          color: Theme.of(context).colorScheme.primary,
                          size: 24.0,
                        ),
                        Text(
                          "Month",
                          style: TextStyle(color:Theme.of(context).colorScheme.primary),
                        )
                      ],
                    )),
              ],
            ),
          ),

          Expanded(
              child: Obx(()=>eventCalendarController.datas.value.data!=null? RefreshIndicator(
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {
                    eventCalendarController.fetchApi();
                  });
                },
                child: SfCalendarTheme(
                    data: SfCalendarThemeData(
                      brightness: Brightness.dark,
                      backgroundColor: AppColor.backgroundColor,
                      todayHighlightColor: Colors.green,
                      allDayPanelColor: Theme.of(context).colorScheme.primary ,
                      viewHeaderDayTextStyle: TextStyle(color:  Theme.of(context).colorScheme.primary),
                      cellBorderColor:  Theme.of(context).colorScheme.primary.withOpacity(0.5),
                      leadingDatesTextStyle:TextStyle(color:  Theme.of(context).colorScheme.primary) ,
                      trailingDatesTextStyle:TextStyle(color:  Theme.of(context).colorScheme.primary)  ,
                      weekNumberTextStyle:TextStyle(color:  Theme.of(context).colorScheme.primary),
                      viewHeaderDateTextStyle:TextStyle(color:  Theme.of(context).colorScheme.primary),
                      selectionBorderColor: Colors.greenAccent,
                      headerTextStyle: TextStyle(color:  Theme.of(context).colorScheme.primary),
                      // timeTextStyle: TextStyle(color:  Theme.of(context).colorScheme.primary),
                    ),
                    child: getEventCalendar(_getCalendarDataSource(), eventCalendarController.onCalendarTapped)),
              ):
              Center(child: CircularProgressIndicator()),
              )),

        ],
      ),

    );
  }
  List<Appointment> appointments = <Appointment>[];
  List<Appointment> _appointmentDetails=<Appointment>[];
  DataSource _getCalendarDataSource() {
    appointments=[];
    DateTime now = DateTime.now();
    DateFormat everydate = DateFormat("MM/dd/yyyy");
    eventCalendarController.datas.value.data!.forEach((element) {
      print("element");
      print(json.encode(element));
      appointments.add(Appointment(
          id: element.id,
          startTime: getDate(element.serviceDate==""?everydate.format(now):element.serviceDate, element.startTime,""),
          endTime:getEndDate(element.serviceDate==""?everydate.format(now):element.serviceDate, element.endTime,element.startTime),
          isAllDay: false,
          subject: "${element.priestName}"+" >> "+element.ServiceSetup!,
          notes: element.ServiceSetup!+"",
          color: element.colour==""?Colors.blue:element.colour.toString().toColor(),
          startTimeZone: '',
          endTimeZone: '',
         // recurrenceRule:recurrenceRule(element.!)
      ));
    });


    return DataSource(appointments);
  }
  recurrenceRule(String day){
    switch(day){
      case "EVERY SUNDAY":
        return 'FREQ=WEEKLY;INTERVAL=1;BYDAY=SUN;UNTIL=20231225';
      case "EVERY MONDAY":
        return 'FREQ=WEEKLY;INTERVAL=1;BYDAY=MO;UNTIL=20231225';
      case "EVERY TUESDAY":
        return 'FREQ=WEEKLY;INTERVAL=1;BYDAY=TUE;UNTIL=20231225';
      case "EVERY WEDNESDAY":
        return 'FREQ=WEEKLY;INTERVAL=1;BYDAY=WED;UNTIL=20231225';
      case "EVERY THURSDAY":
        return 'FREQ=WEEKLY;INTERVAL=1;BYDAY=THU;UNTIL=20231225';
      case "EVERY FRIDAY":
        return 'FREQ=WEEKLY;INTERVAL=1;BYDAY=FRI;UNTIL=20231225';
      case "EVERY SATURDAY":
        return 'FREQ=WEEKLY;INTERVAL=1;BYDAY=SAT;UNTIL=20231225';
      case "EVERY DAY":
        return 'FREQ=WEEKLY;INTERVAL=1;BYDAY=SAT,MO,WED,THU,FRI,TUE,SUN;UNTIL=20231225';
      default:
        return null;
    }
  }
  // SfCalendar.generateRRule(recurrence,
  // DateTime.now(), DateTime.now().add(Duration(hours: 2)))

  PopupMenuItem<MenuItem1> buildItem(MenuItem1 item) => PopupMenuItem(
      value: item,
      child: Row(
        children: [
          Icon(
            item.icon,
            color:  Theme.of(context).shadowColor.withOpacity(0.7),
            size: 20,
          ),
          SizedBox(
            width: 12,
          ),
          Text(item.text),
        ],
      ));

  // SfCalendar getEventCalendar(CalendarDataSource _calendarDataSource, CalendarTapCallback calendarTapCallback) {
  //   Orientation currentOrientation = MediaQuery.of(context).orientation;
  //   return SfCalendar(
  //
  //       view: eventCalendarController.calendarView.value,
  //       controller:  eventCalendarController.controller,
  //       dataSource: _calendarDataSource,
  //       showNavigationArrow: true,
  //       resourceViewSettings: ResourceViewSettings(
  //           visibleResourceCount: 4,
  //           displayNameTextStyle: TextStyle(fontSize: 17, color: Colors.redAccent, fontStyle: FontStyle.italic)),
  //       scheduleViewMonthHeaderBuilder: scheduleViewHeaderBuilder,
  //       scheduleViewSettings: ScheduleViewSettings(
  //           dayHeaderSettings: DayHeaderSettings(
  //               dayFormat: 'EEE',
  //               width: 70,
  //               dayTextStyle: TextStyle(
  //                 fontSize: 10,
  //                 fontWeight: FontWeight.w600,
  //                 color:  Theme.of(context).shadowColor.withOpacity(0.7),
  //               ),
  //               dateTextStyle: TextStyle(
  //                 fontSize: 14,
  //                 fontWeight: FontWeight.w600,
  //                 color: Theme.of(context).shadowColor,
  //               )),
  //           monthHeaderSettings:MonthHeaderSettings(
  //             height: 100
  //           ),
  //           hideEmptyScheduleWeek:false,
  //
  //           appointmentTextStyle: TextStyle(
  //             fontSize: 15,
  //             color:Theme.of(context).shadowColor,
  //           )),
  //       onTap: calendarTapCallback,
  //       initialDisplayDate: DateTime(DateTime.now().year, DateTime.now().month,
  //           DateTime.now().day, 0, 0, 0),
  //       monthViewSettings: MonthViewSettings(
  //           appointmentDisplayCount:2,
  //           showAgenda: eventCalendarController.showAgenda.value,
  //           dayFormat: "EEE",
  //           monthCellStyle: MonthCellStyle(
  //               todayBackgroundColor: Colors.green.withOpacity(0.4),
  //               textStyle: TextStyle(color: Theme.of(context).shadowColor)
  //           ),
  //           appointmentDisplayMode: MonthAppointmentDisplayMode.appointment),
  //       timeSlotViewSettings: TimeSlotViewSettings(
  //         allDayPanelColor: Theme.of(context).backgroundColor,
  //         minimumAppointmentDuration: const Duration(minutes: 60),
  //
  //         timeTextStyle: TextStyle(
  //           fontWeight: FontWeight.w500,
  //           fontSize: 12,
  //           color:  Theme.of(context).shadowColor.withOpacity(0.8),
  //         ),
  //       ));
  // }
  SfCalendar getEventCalendar(CalendarDataSource _calendarDataSource, CalendarTapCallback calendarTapCallback) {
    Orientation currentOrientation = MediaQuery.of(context).orientation;
    return SfCalendar(
        view: eventCalendarController.calendarView.value,
        controller:  eventCalendarController.controller,
        dataSource: _calendarDataSource,
        showNavigationArrow: true,
        resourceViewSettings: ResourceViewSettings(
            visibleResourceCount: 4,
            displayNameTextStyle: TextStyle(fontSize: 17, color: Colors.redAccent, fontStyle: FontStyle.italic)),
        scheduleViewSettings: ScheduleViewSettings(

            monthHeaderSettings: MonthHeaderSettings(
                monthFormat: 'MMMM, yyyy',
                height: 80,
                textAlign: TextAlign.left,
                backgroundColor: Colors.transparent,
                monthTextStyle: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.w400)),
            dayHeaderSettings: DayHeaderSettings(
                dayFormat: 'EEE',
                width: 70,
                dayTextStyle: TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  color:  Colors.white.withOpacity(0.7),
                ),
                dateTextStyle: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: Colors.white,
                )),

            hideEmptyScheduleWeek: true,

            appointmentTextStyle: TextStyle(
              fontSize: 15,
              color:Theme.of(context).colorScheme.primary,
            )),
        onTap: calendarTapCallback,
        initialDisplayDate: DateTime(DateTime.now().year, DateTime.now().month,
            DateTime.now().day, 0, 0, 0),
        monthViewSettings: MonthViewSettings(
            dayFormat: "EEE",
            monthCellStyle: MonthCellStyle(
                todayBackgroundColor: Colors.green.withOpacity(0.4),
                textStyle: TextStyle(color: Colors.white.withOpacity(0.7))
            ),
            appointmentDisplayMode: MonthAppointmentDisplayMode.appointment),
        timeSlotViewSettings: TimeSlotViewSettings(
          allDayPanelColor: Theme.of(context).backgroundColor,
          minimumAppointmentDuration: const Duration(minutes: 60),
          timeTextStyle: TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 12,
            color:  Theme.of(context).colorScheme.primary.withOpacity(0.8),
          ),
        ));
  }


  Widget scheduleViewHeaderBuilder(BuildContext buildContext, ScheduleViewMonthHeaderDetails details) {
    final String monthName = _getMonthName(details.date.month);
    return Stack(
      children: [
        Image(
            image: ExactAssetImage('assets/images/' + monthName + '.png'),
            fit: BoxFit.cover,
            width: details.bounds.width,
            height: details.bounds.height),
        Positioned(
          left: 55,
          right: 0,
          top: 20,
          bottom: 0,
          child: Text(
            monthName + ', ' + details.date.year.toString(),
            style: TextStyle(fontSize: 22,color:Theme.of(context).shadowColor,fontWeight: FontWeight.w500),
          ),
        )
      ],
    );
  }
  String _getMonthName(int month) {
    if (month == 01) {
      return 'January';
    } else if (month == 02) {
      return 'February';
    } else if (month == 03) {
      return 'March';
    } else if (month == 04) {
      return 'April';
    } else if (month == 05) {
      return 'May';
    } else if (month == 06) {
      return 'June';
    } else if (month == 07) {
      return 'July';
    } else if (month == 08) {
      return 'August';
    } else if (month == 09) {
      return 'September';
    } else if (month == 10) {
      return 'October';
    } else if (month == 11) {
      return 'November';
    } else {
      return 'December';
    }
  }


}

class DataSource extends CalendarDataSource {
  DataSource(List<Appointment> source) {
    appointments = source;
  }
}
getDate(param0, params2,String day) {
  print("params2+param0");
  print(params2+"     "+param0);
  String p = "";
  if (params2 != "") {
    if (params2.contains("AM") || params2.contains("PM")) {
      p = param0 + ' ' + params2;
    } else {
      p = param0 + ' 12:00 PM';
    }
  } else {
    p = param0 + ' 12:00 PM';
  }
 // DateTime now = DateTime.now();
  DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
 // DateFormat everydate = DateFormat("MM/dd/yyyy");
 // var  formattedDate = everydate.format(now);
//  String formateDate=formattedDate+' '+params2.toString().trim();
  DateTime dateTime = dateFormat.parse(p);
  // DateTime everydateTime = dateFormat.parse(formateDate);
  return dateTime;
}
getEndDate(param0, params2, start) {
  DateTime dateTime;
  DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
  print("params2+param0");
  print(params2+"     "+param0);
  String p = "";
  if (params2 != "") {
    if (params2.contains("AM") || params2.contains("PM")) {
      p = param0 + ' ' + params2;
    } else {
      p = param0 + ' 12:00 PM';
    }
    dateTime = dateFormat.parse(p);
  } else {
    DateFormat dateFormat = DateFormat("hh:mm a");
    DateTime dateTimenew = dateFormat.parse(start).add(new Duration (hours: 1));
    dateTime=dateTimenew;
  }
  print("END TIME");
  print(dateTime);
  return dateTime;
}

