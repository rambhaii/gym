import 'dart:convert';


import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:get/get.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import '../../AppConstant/APIsConstant.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/Utils.dart';
import '../../UtilMethods/base_client.dart';
import 'BookingData.dart';

class PriestBookingCalendarController extends GetxController{
  PriestBookingCalendarController(this.title);
  final String title;
  var datas= BookingCalendarData().obs;
  var  calendarView=CalendarView.month.obs;
  RxBool  showAgenda=false.obs;

  CalendarController controller = CalendarController();

  var bodyJson={};
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":"Service Inquiry",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip":0,
      "next":50
    };
    // TODO: implement onInit
    super.onInit();
  fetchApi();
  }
  fetchApi()async{
    // var response=await UtilMethods.get(bodyJson);
    // if(response==null) return;
    // if(response["statusCode"].toString()=="-1") return;
    print("sdgdgdfhdfhtfhf");
    print(bodyJson);
    var response=await BaseClient().post(APIsConstant.getAPI, bodyJson).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    print("sfbjsfvgjs"+response);
    datas.value=bookingCalendarDataFromJson(response);

  }
  void onCalendarTapped(CalendarTapDetails details) {
   // showAgenda.value=true ;
    if (details.targetElement == CalendarElement.appointment || details.targetElement == CalendarElement.agenda) {
      final Appointment appointmentDetails = details.appointments![0];
      final index =datas.value.data!.indexWhere((element) => element.id ==appointmentDetails.id);
      BookingDatum datas2=datas.value.data![index];
    }else{

    }
  }
}