
import 'package:aspgen_mobile/AppConstant/AppThemes.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../Widget/ButtonWidget.dart';
import 'BookingData.dart';

class BookingDetails extends StatefulWidget {
  final String title;

  const BookingDetails({Key? key, required this.title}) : super(key: key);
  @override
  _BookingDetailsState createState() => _BookingDetailsState();
}

class _BookingDetailsState extends State<BookingDetails> {
  @override
  BookingDatum _datum=BookingDatum();
  DateFormat formatter = DateFormat.yMMMd('en_US');
  List eventlist = ["CANCELED","NEW","SCHEDULED"];
  final formGlobalKey = GlobalKey<FormState>();
String dateformate="";
  @override
  void initState() {
    _datum=Get.arguments["data"];
    try {
      DateFormat dateFormat2 = DateFormat("MM/dd/yyyy");
      dateformate=formatter.format(dateFormat2.parse(_datum.serviceDate!));
    } on Exception catch (e) {
      // TODO
    }
    super.initState();
  }

  Widget build(BuildContext context) {
  final titlestyle=  TextStyle(color: Theme.of(context).shadowColor, fontSize: 15, fontWeight: FontWeight.w600);
  final subTitlestyle=  TextStyle(color: Theme.of(context).shadowColor.withOpacity(.7), fontSize: 15, fontWeight: FontWeight.w600);
    var w = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          title: Text("Bookings Details",
            style: TextStyle(color:Theme.of(context).shadowColor),

          ),

          actions: [
            IconButton(
                onPressed: () {
                  // RemoteServices.cancelTempleCalendar(
                  //     json.decode(_category)['_id'], context);
                },
                icon: Icon(Icons.cancel)),
            IconButton(
                onPressed: () {
                  showdailog();
                },
                icon: Icon(Icons.check)),

          ],

        ),
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.all(28.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(
                  height: 15,
                ),
                Container(
                    padding: EdgeInsets.only(
                      left: w * .045,
                      right: w * .02,
                    ),
                    decoration: BoxDecoration(
                        border: Border(
                            top: BorderSide(
                                width: 0.1,
                                color:  Theme.of(context).shadowColor.withOpacity(0.7)),
                            bottom: BorderSide(
                                width: 0.1,
                                color:  Theme.of(context).shadowColor.withOpacity(0.7))),
                        color: Theme.of(context).colorScheme.onPrimaryContainer),
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 8,
                          ),
                          Row(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Service Name  ",
                                style: titlestyle,
                              ),
                            ],
                          ),
                          SizedBox(height: 6),
                          Text(
                            _datum.ServiceSetup!,
                            maxLines: 4,
                            overflow: TextOverflow.ellipsis,
                            style:subTitlestyle.copyWith(color:_datum.colour!=""? _datum.colour.toString().toColor():Colors.green,fontSize: 20),
                          ),
                          SizedBox(
                            height: 4,
                          ),
                          Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 6,
                              ),
                              Container(
                                  padding: EdgeInsets.all(5),
                                  width: MediaQuery.of(context)
                                      .size
                                      .width,
                                  decoration: BoxDecoration(
                                      border: Border(
                                          top: BorderSide(
                                              width: 0.1,
                                              color: Theme.of(context).shadowColor.withOpacity(.7)),
                                          bottom: BorderSide(
                                              width: 0.1,
                                              color: Theme.of(context).shadowColor.withOpacity(.7))),
                                      color: Theme.of(context).colorScheme.onPrimaryContainer),
                                  child: Column(
                                    children: [

                                      Row(
                                        children: [
                                          Container(
                                            padding:
                                            EdgeInsets.only(
                                                left: 0),
                                            child: Icon(
                                              Icons
                                                  .calendar_view_month_outlined,
                                              color: Theme.of(context).shadowColor,
                                              size: 20.0,
                                            ),
                                          ),
                                          SizedBox(
                                            width: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                20,
                                          ),
                                          Expanded(
                                            child: Text(
                                              "Date",
                                              style: titlestyle,
                                            ),
                                          ),
                                          Text(
                                            'All Day',
                                            style:titlestyle,
                                          ),
                                          Transform.scale(
                                              scale: 0.8,
                                              child:
                                              CupertinoSwitch(
                                                value: false,
                                                onChanged:
                                                    (value) {
                                                  setState(() {
                                                    // _switchValue = value;
                                                  });
                                                },
                                              ))
                                        ],
                                      ),

                                      Row(children: [
                                        Container(
                                          margin: EdgeInsets.only(
                                              left: MediaQuery.of(
                                                  context)
                                                  .size
                                                  .width /
                                                  9),
                                          padding:
                                          EdgeInsets.all(
                                              8),
                                          decoration: BoxDecoration(
                                              color:Theme.of(context).backgroundColor.withOpacity(0.7),
                                              borderRadius:
                                              BorderRadius
                                                  .circular(
                                                  5.0)),
                                          child: Text(_datum.serviceDate??"",
                                              style:
                                              subTitlestyle),
                                        ),
                                      ]),
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                9),
                                        padding:
                                        EdgeInsets.only(
                                            top: 10,
                                            bottom: 10),
                                        child: Divider(
                                          height: 1.0,
                                          thickness: 1.0,
                                          color:  Theme.of(context).shadowColor.withOpacity(0.1),
                                        ),
                                      ),
                                      Row(
                                        children: [
                                          SizedBox(
                                            width: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                9,
                                          ),
                                          Expanded(
                                            flex: 2,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "Start Time",
                                                  style: TextStyle(
                                                      color: Theme.of(context).shadowColor,
                                                      fontSize:
                                                      15,
                                                      fontWeight:
                                                      FontWeight
                                                          .w600),
                                                ),
                                                SizedBox(height: 8,),
                                                Text(
                                                  _datum.startTime!??"",
                                                  style: TextStyle(
                                                      color: Theme.of(context).shadowColor.withOpacity(.7),
                                                      fontSize:
                                                      15,
                                                      fontWeight:
                                                      FontWeight
                                                          .w600),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 2,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "Finish Time",
                                                  style: TextStyle(
                                                      color: Theme.of(context).shadowColor,
                                                      fontSize:
                                                      15,
                                                      fontWeight:
                                                      FontWeight
                                                          .w600),
                                                ),
                                                SizedBox(height: 8,),
                                                Text(
                                                  _datum.endTime!??"",
                                                  style: TextStyle(
                                                      color: Theme.of(context).shadowColor.withOpacity(.7),
                                                      fontSize:
                                                      15,
                                                      fontWeight:
                                                      FontWeight
                                                          .w600),
                                                ),
                                              ],
                                            ),
                                          ),



                                          //Text("  "+json.decode(_category)['fromTime']+"-"+json.decode(_category)['toTime'],style: TextStyle(color: Theme.of(context).shadowColor54,fontSize: 12,fontWeight:  FontWeight.w600),)
                                        ],
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                9),
                                        padding:
                                        EdgeInsets.only(
                                            top: 10,
                                            bottom: 10),
                                        child: Divider(
                                          height: 1.0,
                                          thickness: 1.0,
                                          color:  Theme.of(context).shadowColor.withOpacity(0.1),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                9,top: 6,bottom: 10),
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Total Time        ",
                                              style: TextStyle(
                                                  color: Theme.of(context).shadowColor,
                                                  fontSize:
                                                  15,
                                                  fontWeight:
                                                  FontWeight
                                                      .w600),
                                            ),
                                            SizedBox(height: 8,),
                                            Text(differTime(_datum.startTime!,_datum.serviceDate!,_datum.endTime!),
                                              style: TextStyle(
                                                  color: Theme.of(context).shadowColor,
                                                  fontSize:
                                                  36,
                                                  fontWeight:
                                                  FontWeight.normal),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  )),
                              SizedBox(
                                height: 6,
                              ),
                            ],
                          )
                        ])),
                SizedBox(
                  height: 15,
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  padding: EdgeInsets.only(
                      left: 20, right: 10, top: 10),
                  decoration: BoxDecoration(
                      border: Border(
                          top: BorderSide(
                              width: 0.1,
                              color: Theme.of(context).shadowColor.withOpacity(0.7)),
                          bottom: BorderSide(
                              width: 0.1,
                              color: Theme.of(context).shadowColor.withOpacity(0.7))),
                      color: Theme.of(context).colorScheme.onPrimaryContainer),
                  child: Column(
                    children: [
                      ListTile(
                        visualDensity: VisualDensity(
                            horizontal: 0, vertical: -4),
                        leading: Icon(
                          Icons.list,
                          color: Theme.of(context).shadowColor,
                          size: 20,
                        ),
                        contentPadding:
                        EdgeInsets.only(bottom: 0),
                        title: Align(
                          child: Text(
                            'Sub-calender',
                            style: titlestyle,
                          ),
                          alignment: Alignment(-1.2, 0),
                        ),
                      ),
                      Row(
                        children: [
                          Container(
                              height: 15,
                              width: 15,
                              decoration: BoxDecoration(
                                color:  Color(0xFF385723),
                                borderRadius:
                                BorderRadius.circular(2),
                              )),
                          Text(
                              "   At the location :- " +_datum.location!,
                              style: subTitlestyle),

                          //
                        ],
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Divider(
                        height: 0.3,
                        thickness: 0.3,
                        color: Theme.of(context).shadowColor.withOpacity(0.54),
                      ),
                      ListTile(
                        visualDensity: VisualDensity(
                            horizontal: 0, vertical: -4),
                        leading: Icon(
                          Icons.person,
                          color: Theme.of(context).shadowColor,
                          size: 20,
                        ),
                        contentPadding: EdgeInsets.symmetric(
                            vertical: -10.0),
                        title: Align(
                          child: Text(
                            'Who',
                            style: titlestyle,
                          ),
                          alignment: Alignment(-1.2, 0),
                        ),
                      ),
                      Row(
                        children: [
                          Text(
                            _datum.priestName!,
                            style:subTitlestyle,
                          ),
                        ],
                      ),
                      SizedBox(height:10),
                      InkWell(
                          onTap: () {
                            // GlobalApis.makingPhoneCall(
                            //     json.decode(_category)[
                            //     'flutterPriestPhone']);
                          },
                          child:
                          Row(
                            //mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Icon(
                                Icons.phone,
                                color: Colors.green,
                              ),
                              Text(
                                "  " +_datum.priestPhone!,
                                style:subTitlestyle,
                                overflow: TextOverflow.ellipsis,
                              ),
                            ],
                          )),
                      SizedBox(height:10),
                      InkWell(
                          onTap: () {
                            // GlobalApis.makingemail(
                            //     json.decode(_category)[
                            //     'flutterPriestEmail']);
                          },
                          child: Row(
                            children: [
                              Icon(
                                Icons.email, color: Colors.yellow,
                              ), Text("  "+_datum.priestEmail!,
                                style: subTitlestyle,
                                overflow: TextOverflow.ellipsis,
                              ),

                            ],
                          )),
                      SizedBox(
                        height: 10,
                      ),
                      Divider(
                        height: 0.3,
                        thickness: 0.3,
                        color: Theme.of(context).shadowColor.withOpacity(0.54),
                      ),
                      ListTile(
                        visualDensity: VisualDensity(
                            horizontal: 0, vertical: -4),
                        leading: Icon(
                          Icons.location_on,
                          color: Theme.of(context).shadowColor.withOpacity(0.54),
                          size: 20,
                        ),
                        contentPadding: EdgeInsets.symmetric(
                            vertical: -10.0),
                        title: Align(
                          child: Text(
                            'Where',
                            style: titlestyle,
                          ),
                          alignment: Alignment(-1.2, 0),
                        ),
                      ),
                      Row(
                        children: [
                          Expanded(
                            child: Text(
                              _datum.customerAddress!+", " +_datum.customerCity!+", "+_datum.customerState!+", "+_datum.customerZip!,
                              style: subTitlestyle,
                              maxLines: 3,
                              overflow: TextOverflow.fade,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 8,
                      ),
                      Divider(
                        height: 0.3,
                        thickness: 0.3,
                        color: Theme.of(context).shadowColor.withOpacity(0.54),
                      ),
                      SizedBox(
                        height: 1,
                      ),
                      ListTile(
                        visualDensity: VisualDensity(
                            horizontal: 0, vertical: -4),
                        leading: Icon(
                          Icons.bookmarks_sharp,
                          color: Theme.of(context).shadowColor.withOpacity(0.7),
                          size: 20,
                        ),
                        contentPadding: EdgeInsets.symmetric(
                            vertical: -10.0),
                        title: Align(
                          child: Text(
                            'Notes',
                            style:titlestyle,
                          ),
                          alignment: Alignment(-1.2, 0),
                        ),
                      ),
                      Row(
                        children: [
                          Text(
                            _datum.description!,
                            style:subTitlestyle,
                          ),
                        ],
                      ),
                      SizedBox(
                        height: 20,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ));
  }



  void showdailog() {
    showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return StatefulBuilder(builder: (context, setState) {
          return AlertDialog(
            backgroundColor: Theme.of(context).backgroundColor,
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.all(Radius.circular(20.0))),
            content: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Card(
                    color: Theme.of(context).backgroundColor,
                    elevation: 2,
                    child: Container(
                        margin: EdgeInsets.all(10),
                        child: DropdownButtonHideUnderline(
                          child: DropdownButton(
                            value: "selectEvent",
                            items: eventlist.map((dynamic item) {
                              return DropdownMenuItem(
                                child: Text("$item"),
                                value: item,
                              );
                            }).toList(),
                            onChanged: (value) {
                              //  getAllTypes(value.toString().split(":")[1].trim());
                              setState(() {
                              });
                            },
                            hint: Text(
                              "Select Status",
                              style:
                              TextStyle(color: Theme.of(context).shadowColor, fontSize: 13),
                            ),
                            disabledHint: Text("Status"),
                            style: TextStyle(color: Theme.of(context).shadowColor, fontSize: 14),
                            iconDisabledColor: Colors.grey,
                            iconEnabledColor: Colors.grey,
                            isExpanded: true,
                            dropdownColor: Theme.of(context).backgroundColor,
                          ),
                        )),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  ButtonWidget(
                    onPress: () {

                    },
                    btnName: 'Update',
                    minWidth: 100,
                  )
                ],
              ),
            ),
          );
        });
      },
    );
  }
  String differTime(String time ,String date,String endtime){
    try {
      DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
      DateTime dt1 = dateFormat.parse("$date $endtime");
      DateTime dt2 = dateFormat.parse("$date $time");
      Duration diff = dt1.difference(dt2);
      int min =(diff.inMinutes % 60);
      String finalHour=diff.inHours<10?"0"+diff.inHours.toString():diff.inHours.toString();
      String finalMinute=min<10?"0"+min.toString():min.toString();
      String difftime=finalHour+" : "+finalMinute;
      return difftime;
    } on Exception catch (e) {
      return "";
      // TODO
    }
  }
}
