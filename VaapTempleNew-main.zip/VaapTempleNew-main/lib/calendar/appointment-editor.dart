part of event_calendar;

class EditEvent extends StatefulWidget {
  final String title;

  const EditEvent({Key? key, required this.title}) : super(key: key);
  @override
  _EditEventState createState() => _EditEventState();
}

class _EditEventState extends State<EditEvent> {
  @override
   Datum _datum=Datum();
  DateFormat formatter = DateFormat.yMMMd('en_US');
  List eventlist = ["CANCELED","NEW","SCHEDULED"];
  final formGlobalKey = GlobalKey<FormState>();
  String dateformate="";
  @override
  void initState() {
    _datum=Get.arguments["data"];
    if(_datum.serviceDate!="")
      {
        DateFormat dateFormat2 = DateFormat("MM/dd/yyyy");
        dateformate=  formatter.format(dateFormat2.parse(_datum.serviceDate!));
      }

    super.initState();
  }

  Widget build(BuildContext context) {
    final titlestyle=  TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.w600);
    final subTitlestyle=  TextStyle(color: Colors.white70, fontSize: 15, fontWeight: FontWeight.w600);
    var w = MediaQuery.of(context).size.width;
    return Scaffold(
        appBar: AppBar(
          title: Text(
            _datum.refDataName!,
            style: TextStyle(color:Theme.of(context).colorScheme.primary),

          ),

          actions: [
            IconButton(
                onPressed: () {
                  // RemoteServices.cancelTempleCalendar(
                  //     json.decode(_category)['_id'], context);
                },
                icon: Icon(Icons.cancel)),
            IconButton(
                onPressed: () {

                },
                icon: Icon(Icons.check)),
           
          ],

        ),
        body: SingleChildScrollView(
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                SizedBox(
                  height: 15,
                ),
                Container(
                    padding: EdgeInsets.only(
                      left: w * .05,
                      right: w * .02,
                    ),
                    decoration: BoxDecoration(
                        border: Border(
                            top: BorderSide(
                                width: 0.1,
                                color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                            bottom: BorderSide(
                                width: 0.1,
                                color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
                        color:_datum.colour!=""? _datum.colour.toString().toColor():Colors.green),
                    width: MediaQuery.of(context).size.width,
                    child: Column(
                        crossAxisAlignment:
                        CrossAxisAlignment.start,
                        children: [
                          SizedBox(
                            height: 8,
                          ),
                          Row(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                "Service Name  ",
                                style: titlestyle,
                              ),
                            ],
                          ),
                          SizedBox(height: 6),
                          Text(
                            _datum.refDataName!,
                            maxLines: 4,
                            overflow: TextOverflow.ellipsis,
                            style:subTitlestyle.copyWith(color:Colors.white,fontSize: 20),
                          ),
                          SizedBox(
                            height: 4,
                          ),
                          Column(
                            crossAxisAlignment:
                            CrossAxisAlignment.start,
                            children: [
                              SizedBox(
                                height: 6,
                              ),
                              Container(
                                  padding: EdgeInsets.all(5),
                                  width: MediaQuery.of(context)
                                      .size
                                      .width,
                                  decoration: BoxDecoration(
                                      border: Border(
                                          top: BorderSide(
                                              width: 0.1,
                                              color: Colors
                                                  .white70),
                                          bottom: BorderSide(
                                              width: 0.1,
                                              color: Colors
                                                  .white70)),
                                      color: _datum.colour!=""? _datum.colour.toString().toColor():Colors.green),
                                  child: Column(
                                    children: [

                                      Row(
                                        children: [
                                          Container(
                                            padding:
                                            EdgeInsets.only(
                                                left: 0),
                                            child: Icon(
                                              Icons
                                                  .calendar_view_month_outlined,
                                              color: Colors
                                                  .white,
                                              size: 20.0,
                                            ),
                                          ),
                                          SizedBox(
                                            width: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                20,
                                          ),
                                          Expanded(
                                            child: Text(
                                              "Date",
                                              style: titlestyle,
                                            ),
                                          ),
                                          Text(
                                            'All Day',
                                            style:titlestyle,
                                          ),
                                          Transform.scale(
                                              scale: 0.8,
                                              child:
                                              CupertinoSwitch(
                                                value: false,
                                                onChanged:
                                                    (value) {
                                                  setState(() {
                                                    // _switchValue = value;
                                                  });
                                                },
                                              ))
                                        ],
                                      ),

                                      Row(children: [
                                        Container(
                                          margin: EdgeInsets.only(
                                              left: MediaQuery.of(
                                                  context)
                                                  .size
                                                  .width /
                                                  9),
                                          padding:
                                          EdgeInsets.all(
                                              8),
                                          decoration: BoxDecoration(
                                              color:AppColor.backgroundColor.withOpacity(0.7),
                                              borderRadius:
                                              BorderRadius
                                                  .circular(
                                                  5.0)),
                                          child: Text(_datum.serviceDate==""?_datum.dayTypes.toString():dateformate,
                                              style:
                                              subTitlestyle),
                                        ),
                                      ]),
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                9),
                                        padding:
                                        EdgeInsets.only(
                                            top: 10,
                                            bottom: 10),
                                        child: Divider(
                                          height: 1.0,
                                          thickness: 1.0,
                                          color:  Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                        ),
                                      ),
                                      Row(
                                        children: [
                                          SizedBox(
                                            width: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                9,
                                          ),
                                          Expanded(
                                            flex: 2,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "Start Time",
                                                  style: TextStyle(
                                                      color: Colors
                                                          .white,
                                                      fontSize:
                                                      15,
                                                      fontWeight:
                                                      FontWeight
                                                          .w600),
                                                ),
                                                SizedBox(height: 8,),
                                                Text(
                                                  _datum.serviceStartTime!,
                                                  style: TextStyle(
                                                      color: Colors
                                                          .white70,
                                                      fontSize:
                                                      15,
                                                      fontWeight:
                                                      FontWeight
                                                          .w600),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Expanded(
                                            flex: 2,
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  "Finish Time",
                                                  style: TextStyle(
                                                      color: Colors
                                                          .white,
                                                      fontSize:
                                                      15,
                                                      fontWeight:
                                                      FontWeight
                                                          .w600),
                                                ),
                                                SizedBox(height: 8,),
                                                Text(_datum.serviceEndTime!,
                                                  style: TextStyle(
                                                      color: Colors
                                                          .white70,
                                                      fontSize:
                                                      15,
                                                      fontWeight:
                                                      FontWeight
                                                          .w600),
                                                ),
                                              ],
                                            ),
                                          ),



                                          //Text("  "+json.decode(_category)['fromTime']+"-"+json.decode(_category)['toTime'],style: TextStyle(color: Theme.of(context).colorScheme.primary54,fontSize: 12,fontWeight:  FontWeight.w600),)
                                        ],
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                9),
                                        padding:
                                        EdgeInsets.only(
                                            top: 10,
                                            bottom: 10),
                                        child: Divider(
                                          height: 1.0,
                                          thickness: 1.0,
                                          color:  Theme.of(context).colorScheme.primary.withOpacity(0.1),
                                        ),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(
                                            left: MediaQuery.of(
                                                context)
                                                .size
                                                .width /
                                                9,top: 6,bottom: 10),
                                        child: Row(
                                          crossAxisAlignment: CrossAxisAlignment.start,
                                          mainAxisAlignment: MainAxisAlignment.start,
                                          children: [
                                            Text(
                                              "Total Time        ",
                                              style: TextStyle(
                                                  color: Colors
                                                      .white,
                                                  fontSize:
                                                  15,
                                                  fontWeight:
                                                  FontWeight
                                                      .w600),
                                            ),
                                            SizedBox(height: 8,),
                                            Text(differTime(_datum.serviceStartTime!,_datum.serviceDate!,_datum.serviceEndTime!)??"",
                                              style: TextStyle(
                                                  color: Colors.white,
                                                  fontSize:
                                                  36,
                                                  fontWeight: FontWeight.normal),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  )),
                              SizedBox(
                                height: 6,
                              ),
                            ],
                          )
                        ])),

              ],
            ),
          ),
        ));
  }


  String differTime(String time ,String date,String endtime){
    print("dvsjkbjvkds"+time +"\n"+endtime+"\n"+date);
    DateFormat dateFormat2 = DateFormat("MM/dd/yyyy");
    var date2=date==""?dateFormat2.format(DateTime.now()):date;
    DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
    DateTime dt1 = dateFormat.parse("$date2 $endtime");
    DateTime dt2 = dateFormat.parse("$date2 $time");
    Duration diff = dt1.difference(dt2);
    int min =(diff.inMinutes % 60);
    String finalHour=diff.inHours<10?"0"+diff.inHours.toString():diff.inHours.toString();
    String finalMinute=min<10?"0"+min.toString():min.toString();
    String difftime=finalHour+" : "+finalMinute;
    print(" shvsdb"+difftime);
    return difftime;
  }
}
