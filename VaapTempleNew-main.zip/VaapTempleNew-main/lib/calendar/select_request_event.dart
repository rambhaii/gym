import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/Widget/ButtonWidget.dart';
import 'package:flutter/material.dart';
import "package:http/http.dart" as http;
import 'package:intl/intl.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:shared_preferences/shared_preferences.dart';
class RequesrEvent extends StatefulWidget {
  const RequesrEvent({Key? key}) : super(key: key);

  @override
  _RequesrEventState createState() => _RequesrEventState();
}

class _RequesrEventState extends State<RequesrEvent> {
  @override
  TextEditingController etserviceName=new TextEditingController();
  TextEditingController etcategory=new TextEditingController();
  TextEditingController ettype=new TextEditingController();
  TextEditingController etpriest=new TextEditingController();
  TextEditingController etpriestEmail=new TextEditingController();
  TextEditingController etpriestPhone=new TextEditingController();
  TextEditingController etfromDate=new TextEditingController();
  TextEditingController ettoDate=new TextEditingController();
  TextEditingController etfromTime=new TextEditingController();
  TextEditingController ettoTime=new TextEditingController();
  TextEditingController etcustomerName=new TextEditingController();
  TextEditingController etcustomerEmail=new TextEditingController();
  TextEditingController etcustomerPhone=new TextEditingController();
  TextEditingController etstatus=new TextEditingController();
  TextEditingController etlocation=new TextEditingController();
  TextEditingController eturl=new TextEditingController();
  TextEditingController etnotes=new TextEditingController();
  TextEditingController eteventType=new TextEditingController();
  TextEditingController etaddress=new TextEditingController();
  TextEditingController etstate=new TextEditingController();
  TextEditingController etcity=new TextEditingController();
  TextEditingController etzip=new TextEditingController();
  final DateFormat formatter =  DateFormat.yMMMd('en_US')  ;
  var selectcategory;
  String categoryvalue="";
  List<Map> category=[];
  var selecttype;
  String typevalue="";
  List<Map> type=[];
  var selectServicname;
  String servicevalue="";
  List<Map> serviceName=[];
  var selectLocation;
  String locationvalue="";
  List<Map> locationlist=[];
  var selectCustomer;
  String customervalue="";
  List<Map> Customerlist=[];
  var selectPriest;
  String preiestvalue="";
  String custAdd="Customer Address";
  String custEmail="Customer Email";
   String custMobile="Customer Mobile";
  String Email="Email";
  String Mobile="Mobile";
   String custState="State";
   String custCity="City";
   String custZip="Zip";
  List<Map> pristlist=[];
  var selectEvent;
  String eventvalue="";
  bool loader=true;
  List eventlist=['TEMPLE','PRIEST','BOOKING'];
  final formGlobalKey=GlobalKey<FormState> ();
  @override
  void initState() {
    // TODO: implement initState
    getAllServiceRequest();
    super.initState();
  }
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColor.backgroundColor,
      appBar: AppBar(
        leading: new IconButton(
          icon: new Icon(Icons.arrow_back, color:  Theme.of(context).colorScheme.primary),
          onPressed: () =>
          {
            //   Navigator.push<Widget>(
            //   context,
            //   MaterialPageRoute(
            //       builder: (BuildContext context) => BottomNavBar()),
            // )},
          }
        ),
        title: Text("Service Request",
        style: TextStyle(color: Theme.of(context).colorScheme.primary),textAlign: TextAlign.center,),
        flexibleSpace: Container(

          decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Colors.teal,Colors.teal.withOpacity(0.7),
                  Colors.teal ,],
                begin: Alignment.topCenter,
                end:Alignment.bottomCenter,
                //stops: [1.0,1.0,],
                tileMode: TileMode.clamp,
              )
          ),

        ),),
      body:
      loader? new Center(
        child: CircularProgressIndicator(),
      ):
      new
      Container(
        color: Theme.of(context).colorScheme.onPrimaryContainer,
        child: ListView.builder
          (
            itemCount: category.length,
            itemBuilder: (BuildContext ctxt, int index) {
              DateTime servicedate = new DateFormat("MM/dd/yyyy").parse( category[index]['serviceDate']);
              DateTime date = new DateFormat("MM/dd/yyyy").parse( category[index]['date']);


              return new

                Container(
                  margin: EdgeInsets.only(top: 10),
                  padding: EdgeInsets.only(left: 10, right: 10,top:10,bottom:10),
                decoration: BoxDecoration(
                    border: Border(top:BorderSide(width: 0.1,color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                        bottom: BorderSide(width: 0.1,color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))

                    ),
                    color: Theme.of(context).colorScheme.onPrimaryContainer
                ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [

                      SizedBox(
                        height: 6,
                      ),
                      Row(
                        children: [

              Container(
              width: MediaQuery.of(context).size.width/1.3,
              padding: EdgeInsets.only(left:10),
              child:
              Text(category[index]['serviceName'],overflow:TextOverflow.ellipsis,style: TextStyle(color:Theme.of(context).colorScheme.primary,fontSize: 15),))
                        ],
                      ),
                      SizedBox(
                        height: 6,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [

                              Container(
                                padding: EdgeInsets.only(left:10),

                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(category[index]['customerName'],style: TextStyle(color:  Theme.of(context).colorScheme.primary.withOpacity(0.7),fontSize: 15,fontWeight:  FontWeight.w600),),
                                    SizedBox(height: 6,),
                                    Text("suresh@gmail.com",style: TextStyle(color:  Theme.of(context).colorScheme.primary.withOpacity(0.7),fontSize: 15,fontWeight:  FontWeight.w600),),
                                    SizedBox(height: 6,),
                                    Text("+9122222222",style: TextStyle(color:  Theme.of(context).colorScheme.primary.withOpacity(0.7),fontSize: 15,fontWeight:  FontWeight.w600),)

                                  ],
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,

                                children: [
                                  Container(
                                    child: Text("Service Date",textAlign:TextAlign.left,style: TextStyle(color:  Theme.of(context).colorScheme.primary,fontSize: 13,fontWeight: FontWeight.bold),),
                                  ),
                                  SizedBox(
                                    height: 6,
                                  ),

                                  Column(
                                    children: [

              Text(formatter.format(servicedate),style: TextStyle(color: Theme.of(context).colorScheme.primary,fontSize: 13),)
                                    ],
                                  )

                                ],
                              )
                            ],
                          )

                        ],
                      )
                      ,



                      SizedBox(
                        height: 5,
                      ),

                      SizedBox(
                        height: 5,
                      ),
                      Container(
                          width: 100,
                          child:ButtonWidget(
                            onPress: (){
                             // UtilMethods.approveServiceRequest(category[index]['_id'], context);
                            },
                           btnName: "Approve",
                            minWidth: 100,
                          //  child: Text("Approve"),
                          )),

                    ],
                  ),
                )
              ;
            }
        ) ,
      )
     ,
    );
  }
  Future<void> getAllServiceRequest() async
  {
    setState(() {
      loader=true;
    }
    );
    print("vvv");
    SharedPreferences prefs = await SharedPreferences.getInstance();
    print(prefs.getString('productId').toString()+"\n"+prefs.getString('token').toString());
    var url = Uri.parse("https://temple.vaaptech.com/business/services/nonprofit/getServiceRequestListData");
    var response = await http.post(
        url, body: {
      'productId':prefs.getString('productId').toString(),
      'page':'Calendar',
      //'serviceDate':'12/10/2021',
      'token':prefs.getString('token').toString()
    });
    print(response.body.toString());
    setState(() {
      loader=false;
    }
    );
    if (response.statusCode == 200) {
      var datass=jsonDecode(response.body);
      if(datass['success']==false){
        Fluttertoast.showToast(
            msg: datass['message'],
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor:  Theme.of(context).colorScheme.primary,
            fontSize: 16.0
        );
      }
     // print("dvdv"+datass['data'][0]['customerName']);

      // CityData cityData=cityDataFromJson(response.body);
      // print("dhsfsdhvjd,${cityData.data!.data![0].name}");
      for(int i=0;i<datass['data'].length;i++)
      {
        setState(() {
          category.add({
            "_id":datass['data'][i]['_id'],
            "customerName":datass['data'][i]['customerName'],
            "date":datass['data'][i]['date'],
            "serviceDate":datass['data'][i]['serviceDate'],
            "serviceName":datass['data'][i]['serviceName'],
            "status":datass['data'][i]['status'],
          });

        });
      }
    }
  }

  Future<void> getAllServiceName() async
  {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    print(prefs.getString('productId').toString()+"\n"+prefs.getString('token').toString());
    var url = Uri.parse("https://temple.vaaptech.com/business/services/getServiceName");
    var response = await http.post(
        url, body: {
      'productId':prefs.getString('productId').toString(),

    });

    if (response.statusCode == 200) {
      var datasss=jsonDecode(response.body);
      type.clear();

      for(int i=0;i<datasss['data'].length;i++)
      {
        setState(() {
          serviceName.add({"service":datasss['data'][i]['serviceName']});
        });
      }
    }
  }

}
