// To parse this JSON data, do
//
//     final calendraData = calendraDataFromJson(jsonString);

import 'dart:convert';

CalendraData calendraDataFromJson(String str) => CalendraData.fromJson(json.decode(str));

String calendraDataToJson(CalendraData data) => json.encode(data.toJson());

class CalendraData {
  CalendraData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String? message;
  List<Datum> ?data;

  factory CalendraData.fromJson(Map<String, dynamic> json) => CalendraData(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.refDataName,
    this.customerName,
    this.location,
    this.priestName,
    this.status,
    this.serviceDate,
    this.serviceStartTime,
    this.serviceEndTime,
    this.customerEmail,
    this.customerPhone,
    this.customerAddress,
    this.customerState,
    this.customerCity,
    this.customerZip,
    this.priestPhone,
    this.priestEmail,
    this.addtionalPriest,
    this.serviceCategory,
    this.serviceType,
    this.eventType,
    this.description,
    this.prefferedLanguage,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.dayTypes,
    this.recurrenceRule,
    this.colour,
    this.customDayTypes,
  });

  String ?id;
  String ?refDataName;
  String ?customerName;
  String ?location;
  String ?priestName;
  String ?status;
  String ?serviceDate;
  String ?serviceStartTime;
  String ?serviceEndTime;
  String ?customerEmail;
  String ?customerPhone;
  String ?customerAddress;
  String ?customerState;
  String ?customerCity;
  String ?customerZip;
  String ?priestPhone;
  String ?priestEmail;
  String ?addtionalPriest;
  String ?serviceCategory;
  String ?serviceType;
  String ?eventType;
  String ?description;
  String ?prefferedLanguage;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  String ?dayTypes;
  String ?customDayTypes;
  String ?recurrenceRule;
  String ?colour;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["_id"],
    refDataName: json["refDataName"]??"",
    customerName: json["customerName"]??"",
    location: json["location"]??"",
    priestName: json["priestName"]??"",
    status: json["status"]??"",
    serviceDate: json["eventDate"]??"",
    serviceStartTime: json["startTime"]??"",
    serviceEndTime: json["endTime"]??"",
    customerEmail: json["customerEmail"]??"",
    customerPhone: json["customerPhone"]??"",
    customerAddress: json["customerAddress"]??"",
    customerState: json["customerState"]??"",
    customerCity: json["customerCity"]??"",
    customerZip: json["customerZip"]??"",
    priestPhone: json["priestPhone"]??"",
    priestEmail: json["priestEmail"]??"",
    addtionalPriest: json["addtionalPriest"]??"",
    serviceCategory: json["serviceCategory"]??"",
    serviceType: json["serviceType"]??"",
    eventType: json["eventType"]??"",
    description: json["description"]??"",
    prefferedLanguage: json["prefferedLanguage"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    dayTypes: json["dayTypes"]??"",
    colour: json["colour"]??"",
    customDayTypes: json["customDayTypes"]??"",
    recurrenceRule:json["dayTypes"]=="EVERY MONDAY"?'FREQ=WEEKLY;INTERVAL=2;BYDAY=MO;UNTIL=20220125':null,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "serviceName": refDataName,
    "customerName": customerName,
    "location": location,
    "priestName": priestName,
    "status": status,
    "serviceDate": serviceDate,
    "serviceStartTime": serviceStartTime,
    "serviceEndTime": serviceEndTime,
    "customerEmail": customerEmail,
    "customerPhone": customerPhone,
    "customerAddress": customerAddress,
    "customerState": customerState,
    "customerCity": customerCity,
    "customerZip": customerZip,
    "priestPhone": priestPhone,
    "priestEmail": priestEmail,
    "addtionalPriest": addtionalPriest,
    "serviceCategory": serviceCategory,
    "serviceType": serviceType,
    "eventType": eventType,
    "description": description,
    "prefferedLanguage": prefferedLanguage,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "dayTypes": dayTypes,
    "customDayTypes": customDayTypes,
    "recurrenceRule": recurrenceRule,
    "colour": colour,
  };
}
