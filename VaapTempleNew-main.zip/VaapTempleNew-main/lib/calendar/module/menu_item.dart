import 'package:flutter/cupertino.dart';

class MenuItem1 {
  final String text;
  final IconData icon ;

  const MenuItem1(
  {
    required this.icon,
    required  this.text
  }
  );
}