// To parse this JSON data, do
//
//     final templeCalendarData = templeCalendarDataFromJson(jsonString);

import 'dart:convert';

TempleCalendarData templeCalendarDataFromJson(String str) => TempleCalendarData.fromJson(json.decode(str));

String templeCalendarDataToJson(TempleCalendarData data) => json.encode(data.toJson());

class TempleCalendarData {
  TempleCalendarData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<TempleDatum>? data;

  factory TempleCalendarData.fromJson(Map<String, dynamic> json) => TempleCalendarData(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<TempleDatum>.from(json["data"].map((x) => TempleDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class TempleDatum {
  TempleDatum({
    this.id,
    this.eventName,
    this.dayTypes,
    this.eventDate,
    this.startTime,
    this.endTime,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
  });

  String ?id;
  String ?eventName;
  String ?dayTypes;
  String ?eventDate;
  String ?startTime;
  String ?endTime;
  String ?moduleName;
  String? clientId;
  String? productId;
  String? aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;

  factory TempleDatum.fromJson(Map<String, dynamic> json) => TempleDatum(
    id: json["_id"],
    eventName: json["eventName"]??"",
    dayTypes: json["dayTypes"]??"",
    eventDate: json["eventDate"]??"",
    startTime: json["startTime"]??"",
    endTime: json["endTime"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "eventName": eventName,
    "dayTypes": dayTypes,
    "eventDate": eventDate,
    "startTime": startTime,
    "endTime": endTime,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
  };
}
