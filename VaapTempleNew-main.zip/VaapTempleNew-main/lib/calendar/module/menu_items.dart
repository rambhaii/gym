import 'package:aspgen_mobile/calendar/module/menu_item.dart';
import 'package:flutter/material.dart';
class MenuItems{
  static const List<MenuItem1> itemsfirst=[
    itemday,
    itemmonth,
    itemschedule
  ];

  static const itemmonth=MenuItem1(
    text:"Month",
    icon:Icons.settings,
  );
  static const itemday=MenuItem1(
    text:"day",
    icon:Icons.settings,
  );
  static const itemschedule=MenuItem1(
    text:"Schedule",
    icon:Icons.settings,
  );
}