// To parse this JSON data, do
//
//     final bookingCalendarData = bookingCalendarDataFromJson(jsonString);

import 'dart:convert';

BookingCalendarData bookingCalendarDataFromJson(String str) => BookingCalendarData.fromJson(json.decode(str));

String bookingCalendarDataToJson(BookingCalendarData data) => json.encode(data.toJson());

class BookingCalendarData {
  BookingCalendarData({
    this.statusCode,
    this.message,
    this.data,
  });

  String? statusCode;
  String? message;
  List<BookingDatum>? data;

  factory BookingCalendarData.fromJson(Map<String, dynamic> json) => BookingCalendarData(
    statusCode: json["statusCode"]??"",
    message: json["message"]??"",
    data: List<BookingDatum>.from(json["data"].map((x) => BookingDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class BookingDatum {
  BookingDatum({
    this.id,
    this.ServiceSetup,
    this.serviceType,
    this.eventType,
    this.serviceDate,
    this.startTime,
    this.endTime,
    this.status,
    this.locationTypes,
    this.priestName,
    this.priestEmail,
    this.priestPhone,
    this.addtionalPriest,
    this.customerName,
    this.customerPhone,
    this.customerEmail,
    this.customerState,
    this.customerCity,
    this.customerAddress,
    this.customerZip,
    this.description,
    this.prefferedLanguage,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.eventName,
    this.serviceTypes,
    this.serviceCategoryTypes,
    this.colour,
  });

  String ?id;
  String ?ServiceSetup;
  String ?serviceType;
  String ?serviceCategoryTypes;
  String ?serviceTypes;
  String ?eventType;
  String ?serviceDate;
  String ?startTime;
  String ?endTime;
  String ?status;
  String ?locationTypes;
  String ?priestName;
  String ?priestEmail;
  String ?priestPhone;
  String ?addtionalPriest;
  String ?customerName;
  String ?customerPhone;
  String ?customerEmail;
  String ?customerState;
  String ?customerCity;
  String ?customerAddress;
  String ?customerZip;
  String ?description;
  String ?prefferedLanguage;
  String ?moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  String ?eventName;
  String ?colour;

  factory BookingDatum.fromJson(Map<String, dynamic> json) => BookingDatum(
    id: json["_id"]??"",
    ServiceSetup: json["ServiceSetup"]??"",
    serviceType: json["serviceType"]??"",
    eventType: json["eventType"]??"",
    serviceCategoryTypes: json["serviceCategoryTypes"]??"",
    serviceTypes: json["serviceTypes"]??"",
    serviceDate: json["serviceDate"]??"",
    startTime: json["startTime"]??"",
    endTime: json["endTime"]??"",
    status: json["status"]??"",
    locationTypes: json["locationTypes"]??"",
    priestName: json["priestName"]??"",
    priestEmail: json["priestEmail"]??"",
    priestPhone: json["priestPhone"]??"",
    addtionalPriest: json["addtionalPriest"]??"",
    customerName: json["customerName"]??"",
    customerPhone: json["customerPhone"]??"",
    customerEmail: json["customerEmail"]??"",
    customerState: json["customerState"]??"",
    customerCity: json["customerCity"]??"",
    customerAddress: json["customerAddress"]??"",
    customerZip: json["customerZip"]??"",
    description: json["description"]??"",
    prefferedLanguage: json["prefferedLanguage"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    eventName: json["eventName"]??"",
    colour: json["colour"]??"",
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "serviceName": ServiceSetup,
    "serviceType": serviceType,
    "eventType": eventType,
    "serviceDate": serviceDate,
    "startTime": startTime,
    "endTime": endTime,
    "status": status,
    "location": locationTypes,
    "priestName": priestName,
    "priestEmail": priestEmail,
    "priestPhone": priestPhone,
    "addtionalPriest": addtionalPriest,
    "customerName": customerName,
    "customerPhone": customerPhone,
    "customerEmail": customerEmail,
    "customerState": customerState,
    "customerCity": customerCity,
    "customerAddress": customerAddress,
    "customerZip": customerZip,
    "description": description,
    "prefferedLanguage": prefferedLanguage,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "serviceCategoryTypes": serviceCategoryTypes,
    "serviceTypes": serviceTypes,
    "recModDate": recModDate,
    "eventName": eventName == null ? null : eventName,
    "colour": colour == null ? "null" : colour,
  };
}
