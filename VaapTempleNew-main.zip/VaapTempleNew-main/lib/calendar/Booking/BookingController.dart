import 'dart:convert';

import 'package:aspgen_mobile/calendar/Booking/BookingDetails.dart';
import 'package:get/get.dart';
import 'package:syncfusion_flutter_calendar/calendar.dart';
import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/base_client.dart';
import 'BookingData.dart';

class BookingCalendarController extends GetxController{
  BookingCalendarController(this.title);
  final String title;
  var datas= BookingCalendarData().obs;
  var  calendarView=CalendarView.schedule.obs;

  CalendarController controller = CalendarController();

  var bodyJson={};
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":title,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip":0,
      "next":500
    };
    // TODO: implement onInit
    super.onInit();
    fetchApi();
  }
  fetchApi()async{
    print(bodyJson);
    var response=await BaseClient().post(APIsConstant.getAPI, bodyJson).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    print("sfbjsfvgjs"+response);
    datas.value=bookingCalendarDataFromJson(response);
  }
  void onCalendarTapped(CalendarTapDetails details) {
    if (details.targetElement == CalendarElement.appointment || details.targetElement == CalendarElement.agenda) {
      final Appointment appointmentDetails = details.appointments![0];
      final index =datas.value.data!.indexWhere((element) => element.id ==appointmentDetails.id);
      BookingDatum datas2=datas.value.data![index];
      Get.to(()=>BookingDetails(title: title,),arguments: {"data":datas2});
    }
  }
}