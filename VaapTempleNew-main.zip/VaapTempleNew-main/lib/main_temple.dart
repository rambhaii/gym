import 'dart:convert';

import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:aspgen_mobile/main.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_app_badger/flutter_app_badger.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'dart:io';
import 'package:shared_preferences/shared_preferences.dart';
import 'AppConstant/AppConstant.dart';
import 'AppConstant/theme_services.dart';
import 'Dashboard/Model/setting.dart';
import 'flavors.dart';
void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await GetStorage.init();
  WidgetsFlutterBinding.ensureInitialized();
  AppConstant.sharedPreference=await SharedPreferences.getInstance();
  HttpOverrides.global = MyHttpOverrides();
  Get.put(ThemeController());
  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
    alert: true,
    badge: true,
    sound: true,
  );
  F.appFlavor = Flavor.TEMPLE;

  try {
    UtilMethods.getSetting().then((value){
      runApp(MyApp());
    });
  } catch(e) {
    Future.delayed(Duration(seconds: 2 )).then((value) => runApp(MyApp())

    );
    // TODO
  }

}
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
    FlutterAppBadger.updateBadgeCount(1);

}