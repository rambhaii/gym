enum Flavor {
  TEMPLE,
  CONSTRUCTION,
  CONTRACTOR,
  SPORT,
}

class F {
  static Flavor? appFlavor;

  static String get name => appFlavor?.name ?? '';

  static String get title {
    switch (appFlavor) {
      case Flavor.TEMPLE:
        return 'Temple App';
      case Flavor.CONSTRUCTION:
        return 'Construction App';
      case Flavor.CONTRACTOR:
        return 'Contractor App';
      case Flavor.SPORT:
        return 'Sport App';
      default:
        return 'title';
    }
  }

}
