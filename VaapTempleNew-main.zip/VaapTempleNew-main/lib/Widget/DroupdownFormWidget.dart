import 'package:aspgen_mobile/AppConstant/AppThemes.dart';
import 'package:flutter/material.dart';

class DropdownFormWidget extends StatelessWidget {
  final  Object? selectvalue;
  final List<Map> list;
  final String title;
  final String hint;
  final String onPress;
  final ValueChanged<Object?> change;
  final Color ?textColor;
  const DropdownFormWidget({Key? key, this.selectvalue, required this.list, required this.title, required this.hint, required this.onPress, required this.change, this.textColor}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DropdownButtonFormField(
      decoration: InputDecoration(
          enabledBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey.withOpacity(0.7),width: 0.8)
          ),
          focusedBorder:  OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey)
          ),
          errorBorder:   OutlineInputBorder(
              borderSide: BorderSide(color: Colors.red)
          ),
          focusedErrorBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.grey)
          ),
          counter: Offstage(),
          hintText: hint,
          hintStyle:Theme.of(context).textTheme.bodyText2,
          labelText:title,
          isDense: true,
          contentPadding: const EdgeInsets.all(8.5),
          labelStyle: Theme.of(context).textTheme.bodyText2,
      ),
      dropdownColor: Theme.of(context).colorScheme.onPrimaryContainer,
      value: selectvalue,
      validator: (value) {
        if(value==null)
        {
          return "Please select brand";
        }
        return null;
      },
      onChanged: change,
        items: list.map((dynamic item) {
          return DropdownMenuItem<Map>(
            child: Padding(
              padding: EdgeInsets.zero,
              child: Row(
                children: [
                  if(title=="Select Colour")Container(
                    height: 30,
                    width: 30,
                    decoration: BoxDecoration(
                        color: item["name"].toString().toColor(),
                        borderRadius: BorderRadius.circular(3),
                        boxShadow: [
                          BoxShadow(
                            color: item["name"].toString().toColor().withOpacity(0.3),
                            offset: const Offset(
                              2.0,
                              2.0,
                            ),
                            blurRadius: 5.0,
                            spreadRadius: 1.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            offset: const Offset(-2.0, -2.0),
                            blurRadius: 5.0,
                            spreadRadius: 1.0,
                          ), //B
                        ]

                    ),

                  ),
                  title=="Select Colour"? Expanded(child: Text("    ${item["name"]}",style: TextStyle(color:textColor!=null?textColor: Theme.of(context).colorScheme.primary, fontSize: 16,backgroundColor:Colors.transparent),overflow: TextOverflow.ellipsis,maxLines: 2 )):Expanded(child: Text("${item["name"]}",style: TextStyle(color:textColor!=null?textColor: Theme.of(context).colorScheme.primary, fontSize: 16,backgroundColor:Colors.transparent),overflow: TextOverflow.ellipsis,maxLines: 2,)),
                ],
              ) ,
            ),
            value: item,
          );
        }).toList()
    );
  }
}
