import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:photo_view/photo_view.dart';

class FullScreenImageWidget extends StatelessWidget {
  final String path;
  const FullScreenImageWidget({Key? key, required this.path}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            child: PhotoView(
              imageProvider: NetworkImage(path),
              heroAttributes: PhotoViewHeroAttributes(
                tag: "img",
              ),
            ),
          ),
          Positioned(
              top: 35,
              right: 0,
              child: IconButton(onPressed: (){
                Get.back();
              },icon: Icon(Icons.clear,size: 30,),))
        ],
      ),

    );

  }

}