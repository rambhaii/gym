import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class SelectionTypeWidget extends StatelessWidget {
  final String title;
  final VoidCallback onTap;
  final String ?subTitle;
  const SelectionTypeWidget({Key? key, required this.title, required this.onTap, this.subTitle=""}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return  Card(
        shape:const RoundedRectangleBorder(borderRadius: BorderRadius.only(topLeft: Radius.circular(4.0), topRight: Radius.circular(4.0), bottomLeft: Radius.circular(4.0), bottomRight: Radius.circular(4.0))),
      color: Theme.of(context).colorScheme.onPrimaryContainer,
      child:subTitle==""? ListTile(
        onTap: onTap,
        trailing: Container(
          padding: EdgeInsets.all(6),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(color:Colors.grey,width: 0.6)
            ),
            child: Icon(Icons.arrow_forward_ios_rounded,color: Theme.of(context).colorScheme.primary,size: 18,)),
        title: Text(title,style: Theme.of(context).textTheme.bodyText1!.copyWith( color:getColor(title))),
      ):ListTile(
        onTap: onTap,
        trailing: Icon(Icons.arrow_forward,color: Theme.of(context).colorScheme.primary,),
        title: Text(title,style:  Theme.of(context).textTheme.bodyText1!,),
        subtitle:Text(subTitle!,style: Theme.of(context).textTheme.bodyText2!.copyWith(color: Colors.amber,fontSize: 15,fontWeight: FontWeight.w600),) ,
      ),
    );
  }
  getColor(String text){
    switch(text){
      case "BOOKINGS":
        return Color(0xffbafcab);
      case "DONATIONS":
        return Colors.amber;
      case "SERVICES":
        return Colors.limeAccent;
      case "FINANCIALS":
        return Colors.cyanAccent;
      case "OPERATIONS":
        return Colors.red;
      default:
        return Colors.white;
    }
  }
}
