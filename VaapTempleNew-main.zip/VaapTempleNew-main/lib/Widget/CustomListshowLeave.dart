import 'dart:math';

import 'package:aspgen_mobile/Widget/EditextWidget.dart';
import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../AppConstant/APIsConstant.dart';
import '../UtilMethods/Utils.dart';
import 'ButtonWidget.dart';
import 'FullScreenImageWidget.dart';
class CustomListLeaveWidget extends StatelessWidget {
  final String title;
  final String ?imgUrl;
  final String subTitle;
  final String ?subTitle2;
  final String ?subTitle3;
  final String ?subTitlea;
  final TextEditingController textEditingController;
  final VoidCallback  onTapVieMore;
  final VoidCallback  ?editOnTap;
  final Widget?viewMoreWidget;
  final bool isClicked;
  final IconData ?icon;
  final Color ?iconColor;
  const CustomListLeaveWidget({Key? key, required this.title, required this.subTitle,  required this.subTitlea, required this.textEditingController, required this.onTapVieMore, required this.isClicked, this.editOnTap, this.imgUrl, this.viewMoreWidget, this.icon, this.iconColor, this.subTitle2, this.subTitle3}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTapVieMore,
      child: Card(
        color: Theme.of(context).colorScheme.onPrimaryContainer,
        elevation: 6,
        child: Column(
          children: [
            Divider(
              height: 0.5,
              thickness: 0.5,
              color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
            ),
            SizedBox(height: 10),
            Row(
              crossAxisAlignment:isClicked? CrossAxisAlignment.start:CrossAxisAlignment.center,
              children: [
                Spacer(flex: 1,),
                Expanded(
                  flex: 5,
                  child: Stack(
                    children: [
                      (imgUrl==null || imgUrl=="")?  CircleAvatar(
                        backgroundColor: Color(Random().nextInt(0xffffffff)),
                        child: Text(
                            title.toString().toUpperCase() ==
                                "" ? "" : title[0].toString().toUpperCase(),
                            style: Theme.of(context).textTheme.bodyText1
                        ),
                        maxRadius: 27,
                      )
                          :GestureDetector(
                        onTap: (){
                          Get.to(()=>FullScreenImageWidget(path: APIsConstant.IP_Base_Url+imgUrl!,),fullscreenDialog: true);
                        },
                        child: ClipOval(
                          child: CachedNetworkImage(
                            fit: BoxFit.cover,
                            imageUrl:APIsConstant.IP_Base_Url+imgUrl!,
                            height: 50,
                            width: 50,
                            placeholder: (context,url)=>const CircularProgressIndicator(),
                            errorWidget: (context,url,error)=>const Icon(Icons.error),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Spacer(flex: 1,),
                Expanded(
                  flex:25,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          HigliteText(textData: title, query: textEditingController.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(fontWeight: FontWeight.w800) as TextStyle),
                          if(subTitle.toString() == "PENDING")
                            InkWell(
                              onTap: editOnTap,
                              child: Padding(
                                padding: const EdgeInsets.only(right:8.0),
                              child: Row(
                                children: [
                                  Icon(Icons.pending_actions,color: Colors.amber,),
                                ],
                              ),
                          ),
                            ) ,
                          if(subTitle.toString() == "REJECTED")
                            Padding(
                              padding: const EdgeInsets.only(right:8.0),
                            child: Icon(Icons.clear,color: Colors.redAccent,),
                          ) ,
                          if(subTitle.toString() == "APPROVED")
                          Padding(
                            padding: const EdgeInsets.only(right:8.0),
                            child: Icon(Icons.check_circle,color: Colors.green,),
                          ),

                        ],
                      ),
                      if(subTitle2!=null) SizedBox(
                        height: 6,
                      ),
                    if(subTitle2!=null)HigliteText(textData: subTitle2.toString(), query: textEditingController.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 15,color: Colors.amber) as TextStyle),
                      if(subTitle3!=null) SizedBox(
                        height: 6,
                      ),
                    if(subTitle3!=null)HigliteText(textData: subTitle3.toString(), query: textEditingController.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 15,color: Colors.white) as TextStyle),
                      if(subTitle3!=null) SizedBox(
                        height: 6,
                      ),
                      Row(
                        children: [
                          Expanded(
                              flex:9,
                              child: Row(
                                children: [
                                  Text(!isClicked?"View More  ":"Less More",style:TextStyle(fontSize: 12,color:Colors.white54, decoration: TextDecoration.underline,)),
                                  Icon(!isClicked?Icons.expand_more:Icons.expand_less,size: 20,color:Colors.white54)
                                ],
                              )),

                        ],
                      ),
                      if(isClicked)Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          viewMoreWidget!,
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),

            SizedBox(height: 10),
            Divider(
              height: 0.5,
              thickness: 0.5,
              color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
            )
          ],
        ),
      ),
    );
  }
}
Widget viewMoreLeave(String title,String subTitle,etUserName){
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title,style: Theme.of(Get.context!).textTheme.bodyText2,),
      SizedBox(height:4,),
      Text(subTitle.toLowerCase(),style: Theme.of(Get.context!).textTheme.bodyText1!.copyWith(color:Colors.white,fontWeight: FontWeight.w400)),
      EditTextWidget(
        label: "Message",
        controller: etUserName,
        onchanged:( (value){

        }),
        hint: 'Enter Message',
        validator: (value) {
          if (value == null || value.isEmpty) {
            return 'Please Message';
          }
          return null;
        },
        maxLength: 90,
        keyboardtype: TextInputType.text,
        isPassword: false,
      ),
      Container(
        height: 30,

          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            shape: BoxShape.rectangle,
            color: Colors.teal,
          ),
          child: IconButton(icon:Icon(Icons.send,size: 22,), onPressed: () {  },))
    ],
  );
}
