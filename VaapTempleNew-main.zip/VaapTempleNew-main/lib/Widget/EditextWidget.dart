
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class EditTextWidget extends StatelessWidget {
  final String hint;
  final String label;
  final int maxLength;
  final bool isPassword;
  final bool?isCounter;
  final TextInputType keyboardtype;
   final FormFieldValidator validator;
  final TextEditingController?controller;
  final bool?isRead;
  final int?maxline;
  final List<TextInputFormatter>?formatter;
  final ValueChanged<String> ?onchanged;
  const EditTextWidget({Key?key,required this.hint,required this.label,required this.validator, required this.keyboardtype,required this.maxLength,required this.isPassword, this.controller,  this.maxline, this.onchanged, this.formatter,this.isRead=false, this.isCounter=false}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Container(
      width: w,
      child:
      TextFormField(
        style:Theme.of(context).textTheme.bodyText1,
         readOnly: isRead!,

        decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.grey.withOpacity(0.7),width: 0.8)
            ),
            focusedBorder:  OutlineInputBorder(
                borderSide: BorderSide(color: Colors.grey)
            ),
            errorBorder:   OutlineInputBorder(
                borderSide: BorderSide(color: Colors.red)
            ),
            focusedErrorBorder: OutlineInputBorder(
                borderSide: BorderSide(color: Colors.grey)
            ),
            counter:isCounter==false?Offstage() :null,
            hintText: hint,
             alignLabelWithHint: true,
            hintStyle:Theme.of(context).textTheme.bodyText2,
            labelText:label,

             // prefixIcon: Icon(icon,color:  Theme.of(context).colorScheme.primary,),
            // icon: Icon(Icons.person),
            contentPadding: const EdgeInsets.all(12.0),
            labelStyle: Theme.of(context).textTheme.bodyText2,
        ),

        controller: controller,
        keyboardType: keyboardtype,
        maxLength: maxLength,
        obscureText: isPassword,
        validator:validator,
        inputFormatters:formatter??[],
        maxLines: maxline,
        autofocus: false,
      onChanged: onchanged,
      ),

    );
  }
}
