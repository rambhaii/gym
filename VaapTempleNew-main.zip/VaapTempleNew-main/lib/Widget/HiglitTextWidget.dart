import 'package:flutter/material.dart';

class HigliteText extends StatelessWidget {
  final String textData;
  final String query;
   final TextStyle textStyle;
  const HigliteText({Key? key, required this.textData, required this.query, required this.textStyle}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    int startIndex = textData.toLowerCase().indexOf(query.toLowerCase());
    return query.isEmpty || startIndex == -1
        ? Text(textData,style: textStyle,):RichText(
        text: TextSpan(
          text: textData.substring(0, startIndex),
          style: textStyle,
          children: [
            TextSpan(
              text: " "+textData.substring(
                  startIndex, startIndex + query.length)+" ",
              style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17, color: Colors.white,backgroundColor: Colors.amberAccent.withOpacity(0.5)),
            ),
            TextSpan(
              text: textData
                  .substring(startIndex + query.length),
              style: textStyle,
            )
          ],
        ));
  }
}
