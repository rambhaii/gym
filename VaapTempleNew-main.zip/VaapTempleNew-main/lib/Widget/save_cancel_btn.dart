import 'package:flutter/material.dart';
class SaveCancelBtn extends StatelessWidget {
  const SaveCancelBtn({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          RawMaterialButton(onPressed: (){},
            padding: EdgeInsets.zero,
            shape:const CircleBorder(),
            fillColor: Colors.green,child: Icon(Icons.check,color: Colors.white,
          ),
              // shape: new CircleBorder(),

          ),
          RawMaterialButton(onPressed: (){},
            shape: const CircleBorder(),
            fillColor: Colors.red,child: Icon(Icons.cancel_outlined,color: Colors.white,
          ),

          )
        ],
      );
  }
}
