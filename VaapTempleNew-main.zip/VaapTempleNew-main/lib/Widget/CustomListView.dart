import 'dart:math';

import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../AppConstant/APIsConstant.dart';
import '../UtilMethods/Utils.dart';
import 'FullScreenImageWidget.dart';
class CustomListWidget extends StatelessWidget {
final String title;
final String ?imgUrl;
  final String subTitle;
final String ?subTitle2;
  final TextEditingController textEditingController;
  final VoidCallback  onTapVieMore;
  final VoidCallback  ?editOnTap;
  final Widget?viewMoreWidget;
  final bool isClicked;
  final IconData ?icon;
  final Color ?iconColor;
  const CustomListWidget({Key? key, required this.title, required this.subTitle, required this.textEditingController, required this.onTapVieMore, required this.isClicked, this.editOnTap, this.imgUrl="", this.viewMoreWidget, this.icon, this.iconColor, this.subTitle2}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: onTapVieMore,
      child: Card(
        color: Theme.of(context).colorScheme.onPrimaryContainer,
        elevation: 6,

        child:
        Column(
          children: [
            Divider(
              height: 0.5,
              thickness: 0.5,
              color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
            ),
            SizedBox(height: 10),
            Row(
              crossAxisAlignment:isClicked?CrossAxisAlignment.start:CrossAxisAlignment.center,

              children: [

                Spacer(flex: 1,),
                Expanded(
                  flex: 5,
                  child: Stack(
                    children: [
                      imgUrl!.isEmpty?  CircleAvatar(
                        backgroundColor: Color(Random().nextInt(0xffffffff)),
                        child: Text(
                            title.toString().toUpperCase() ==
                                "" ? "" : title.trim()[0].toString().toUpperCase(),
                            style: Theme.of(context).textTheme.headline4
                        ),
                        maxRadius: 27,
                      )
                          :GestureDetector(
                        onTap: (){
                          Get.to(()=>FullScreenImageWidget(path: APIsConstant.IP_Base_Url+imgUrl!,),fullscreenDialog: true);
                        },
                        child: ClipOval(
                          child: CachedNetworkImage(
                            fit: BoxFit.cover,
                            imageUrl:APIsConstant.IP_Base_Url+imgUrl!,
                            height: 50,
                            width: 50,
                            placeholder: (context,url)=>const CircularProgressIndicator(),
                            errorWidget: (context,url,error)=>const Icon(Icons.error),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Spacer(flex: 1,),
                Expanded(
                  flex: 20,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      HigliteText(textData: title, query: textEditingController.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle),
                      if(subTitle!="")  SizedBox(
                        height: 4,
                      ),
                      if(subTitle!="")  HigliteText(textData: subTitle, query:textEditingController.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(
                          color:  subTitle.toString() == "PRIEST"
                              ? Colors.amber
                              :  subTitle.toString()== "DEVOTEE"
                              ? Colors.green:
                          subTitle.toString()== "GUEST"?Colors.purple  : Colors.amber,
                          fontSize: 14,fontWeight: FontWeight.w400
                      )
                      ),
                      if(subTitle2!=null)    SizedBox(
                        height: 4,
                      ),
                      if(subTitle2!=null)  HigliteText(textData: subTitle2.toString(), query: textEditingController.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 15) as TextStyle),

                      Row(
                        children: [
                          Expanded(
                              flex:9,
                              child: Row(
                                children: [
                                  Text(!isClicked?"View More  ":"Less More ",style:TextStyle(fontSize: 12,color:Colors.white54, decoration: TextDecoration.underline,)),
                                  Icon(!isClicked?Icons.expand_more:Icons.expand_less,size: 20,color:Colors.white54)
                                ],
                              )),
                        ],
                      ),
                      if(isClicked)Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          viewMoreWidget!,
                        ],
                      ),
                    ],
                  ),
                ),
                Expanded(
                  flex: 5,
                  child: InkWell(
                    onTap: editOnTap,
                    child: Container(
                      margin: EdgeInsets.only(top:isClicked? 10:0),
                      padding: EdgeInsets.all(6),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                          border: Border.all(color:icon==null?Colors.amber.withOpacity(0.24):iconColor!.withOpacity(0.25),width: 1 ),
                          shape:BoxShape.circle
                      ),
                      child:icon==null? Icon(
                        Icons.edit,
                        color: Colors.amber,
                        size: 18,
                      ):Icon(icon, color: iconColor!,
                        size: 18,),
                    ),
                  ),
                ),
              ],
            ),

            SizedBox(height: 10),
            Divider(
              height: 0.5,
              thickness: 0.5,
              color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
            )
          ],
        ),
      ),
    );
  }
}
Widget viewMore(String title,String subTitle){
  return Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(title,style: Theme.of(Get.context!).textTheme.bodyText2,),
      SizedBox(height:4,),
      Text(subTitle,style:subTitle=="COMPLETED"?Theme.of(Get.context!).textTheme.bodyText1!.copyWith(color: Colors.green):Theme.of(Get.context!).textTheme.bodyText1)
    ],
  );
}