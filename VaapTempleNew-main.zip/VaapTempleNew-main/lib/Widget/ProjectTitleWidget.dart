import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:flutter/material.dart';

class ProjectTitelWidget extends StatelessWidget {
  final String projectTitle;
  final String lotNo;
  const ProjectTitelWidget({Key? key, required this.projectTitle, required this.lotNo}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          padding: EdgeInsets.only(top: 10,bottom: 10,left: 6,right: 6),
          decoration: BoxDecoration(
            color: AppColor.darkteal,
            border: Border(
              bottom: BorderSide(
                width: 0.5,
                color: Colors.white.withOpacity(0.4)
              )
            )
          ),

          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: (MediaQuery.of(context).size.width*0.7)-6,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                 Text("Project Name:-",style: Theme.of(context).textTheme.bodyText2!.copyWith(fontSize: 16),),
                    SizedBox(height: 6,),
                    Text(projectTitle,style: Theme.of(context).textTheme.bodyText1,)                ],
                ),
              ),
              Container(
                width:  (MediaQuery.of(context).size.width*0.3)-6,
                alignment: Alignment.topRight,
                child: Column(

                  children: [Text("Lot No:-",style: Theme.of(context).textTheme.bodyText2!.copyWith(fontSize: 16),),
                  SizedBox(height: 6,),
                  Text(lotNo,style: Theme.of(context).textTheme.bodyText1 ,),

                ],),
              )
            ],
          ),
        ),

      ],
    );
  }
}
