import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:flutter/material.dart';
class ButtonWidget extends StatelessWidget {
  final String btnName;
  final VoidCallback onPress;
  final double?minWidth;
  const ButtonWidget({Key? key,required this.btnName,required this.onPress, this.minWidth}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialButton(onPressed: () { onPress(); },
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.all(Radius.circular(6.0))),
      elevation: 5.0,
      minWidth:minWidth ,
      height: 40,
      color:btnName=="Cancel" ?Colors.grey:Colors.teal,
      child: new Text(btnName,
          style: new TextStyle(fontSize:  16.0, color: Theme.of(context).colorScheme.primary, fontWeight:FontWeight.bold)),

    );
  }
}
