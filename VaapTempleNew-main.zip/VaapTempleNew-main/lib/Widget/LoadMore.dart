
import 'package:flutter/material.dart';

class LoadMoreData extends StatelessWidget {
  const LoadMoreData({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
        SizedBox(height:26,width:26,child: CircularProgressIndicator(strokeWidth: 3,)),
        SizedBox(width: 15,),
        Text("Loading...  ",style: Theme.of(context).textTheme.bodyText2,)
      ],),
    );
  }
}
