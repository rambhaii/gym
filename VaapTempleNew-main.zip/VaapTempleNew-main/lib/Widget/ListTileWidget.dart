import 'package:flutter/material.dart';

class ListTileWidget extends StatelessWidget {
  final String title;
  final VoidCallback onPress;
  const ListTileWidget({Key? key, required this.title, required this.onPress}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Theme.of(context).colorScheme.onPrimaryContainer,
      child: ListTile(
        onTap: ()=>onPress(),
        title: Text(title,style: Theme.of(context).textTheme.bodyText1,),
        trailing: Icon(Icons.arrow_forward,color: Theme.of(context).colorScheme.primary,),

      ),
    );;
  }
}
