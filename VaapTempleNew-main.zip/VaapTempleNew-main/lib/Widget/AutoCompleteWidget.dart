
import 'package:flutter/material.dart';
import 'package:aspgen_mobile/Dashboard/Model/field.dart';

class AutoCompleteWidget extends StatelessWidget {
  final TechnicalChildDatum fieldDatum;
  final ValueChanged onSelected;
  const AutoCompleteWidget({Key? key, required this.fieldDatum, required this.onSelected}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Autocomplete(

      optionsBuilder: (TextEditingValue textEditingValue) {
        List<String> matches = <String>[];
        matches.addAll(fieldDatum.autoList!);
        matches.retainWhere((s){
          return s.toLowerCase().contains(textEditingValue.text.toLowerCase());
        });
        return matches;
      },
      fieldViewBuilder: (BuildContext context, TextEditingController textEditingController,
          FocusNode focusNode,
          VoidCallback onFieldSubmitted) {
        return  TextFormField(
          validator: (value) {
            // if (fieldDatum.mandatory == "YES") {
            if (value == null || value.isEmpty) {
              return 'Please Enter ' + fieldDatum.fieldName!;
            }
            if (!fieldDatum.autoList!.contains(value)) {
              return 'Please enter valid value';
            }

            //  }
            return null;
          },
          decoration:myTextFieldDecoration(context,fieldDatum.fieldLabel!, fieldDatum.fieldLabel!),
          controller: textEditingController,
          focusNode: focusNode,

        );
      },
      onSelected:onSelected

    );


  }
  InputDecoration myTextFieldDecoration(BuildContext context,String label, String hintText)
  {
    return InputDecoration(
        enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey)
        ),
        focusedBorder:  OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey)
        ),
        errorBorder:   OutlineInputBorder(
            borderSide: BorderSide(color: Colors.red)
        ),
        focusedErrorBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey)
        ),
        counter: Offstage(),
        hintText: hintText,

        hintStyle:TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.4)),
        labelText:label,
        // prefixIcon: Icon(icon,color:  Theme.of(context).colorScheme.primary,),
        // icon: Icon(Icons.person),
        contentPadding: const EdgeInsets.all(15.0),
        labelStyle:
        TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.8),fontWeight: FontWeight.normal)
    );
  }
}
