import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
class ShimmerEffectForField extends StatelessWidget {
  const ShimmerEffectForField({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: Shimmer.fromColors(
        baseColor:Colors.grey,
        highlightColor:  Theme.of(context).colorScheme.primary,
        direction: ShimmerDirection.ltr,
        child: ListView.builder(
          physics: NeverScrollableScrollPhysics(),
          itemBuilder: (_, __) => Padding(
            padding: const EdgeInsets.only(bottom: 8.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Container(
                        margin: EdgeInsets.only(left: 3,right: 3,top: 8),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(3),
                          color:  Theme.of(context).colorScheme.primary.withOpacity(0.4),
                        ),
                        width: double.infinity,
                        height:47,

                      ),

                    ],
                  ),
                )
              ],
            ),
          ),
          itemCount: 11,
        ),
      ),
    );
  }
}
