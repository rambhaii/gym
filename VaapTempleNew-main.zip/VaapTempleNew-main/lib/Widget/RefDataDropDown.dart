import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/AppThemes.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
class RefDataDropDown extends StatelessWidget {
  final  Object? selectvalue;
  final List<Map> list;
  final String title;
  final String hint;
  final String onPress;
  final ValueChanged<Object?> change;
  final Color ?textColor;
  const RefDataDropDown({Key? key,required this.selectvalue,required this.change,required this.onPress,required this.list,required this.title, required this.hint,this.textColor}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.only(left: 10, right: 10),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          border: Border.all(
              width: 0.8, color: textColor!=null?textColor!:Colors.grey.withOpacity(0.6))
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton2(
          value: selectvalue,
          items: list.map((dynamic item) {
            return DropdownMenuItem<Map>(
              child: Padding(
                padding: EdgeInsets.zero,
                child: Row(
                  children: [
                    if(title=="Select Colour")Container(
                      height: 30,
                      width: 30,
                      decoration: BoxDecoration(
                          color: item["refDataName"].toString().toColor(),
                          borderRadius: BorderRadius.circular(3),
                          boxShadow: [
                            BoxShadow(
                              color: item["refDataName"].toString().toColor().withOpacity(0.3),
                              offset: const Offset(
                                2.0,
                                2.0,
                              ),
                              blurRadius: 5.0,
                              spreadRadius: 1.0,
                            ), //BoxShadow
                            BoxShadow(
                              color: Colors.black.withOpacity(0.3),
                              offset: const Offset(-2.0, -2.0),
                              blurRadius: 5.0,
                              spreadRadius: 1.0,
                            ), //B
                          ]

                      ),

                    ),
                    title=="Select Colour"? Text("    ${item["name"]}",style: TextStyle(color:textColor!=null?textColor: Theme.of(context).colorScheme.primary, fontSize: 16,backgroundColor:Colors.transparent) ):Text("${item["name"]}",style: TextStyle(color:textColor!=null?textColor: Theme.of(context).colorScheme.primary, fontSize: 16,backgroundColor:Colors.transparent)),
                  ],
                ) ,
              ),
              value: item,
            );
          }).toList(),
          onChanged:change,
          hint: Text(title, style:Theme.of(context).textTheme.bodyText2
          ),
          style:Theme.of(context).textTheme.bodyText2,
          iconDisabledColor: textColor!=null?textColor: Theme.of(context).colorScheme.primary,
          iconEnabledColor: textColor!=null?textColor: Theme.of(context).colorScheme.primary,
          isExpanded: true,
          dropdownElevation: 8,
          scrollbarRadius: const Radius.circular(40),
          scrollbarThickness: 6,
          scrollbarAlwaysShow: true,
          dropdownDecoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            color: Theme.of(context).colorScheme.onPrimaryContainer,
          ),
          dropdownMaxHeight: MediaQuery.of(context).size.height*0.5  ,
        ),
      ),
      //Icon(Icons.calendar_today, color:  Theme.of(context).colorScheme.primary),


    );
  }
}
