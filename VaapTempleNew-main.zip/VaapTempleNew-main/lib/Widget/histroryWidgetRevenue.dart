
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get_state_manager/src/rx_flutter/rx_notifier.dart';

class histroryWidgetRevenue extends StatelessWidget {
  final String ?title;
  final String ?value;
  final String ?type;
  const histroryWidgetRevenue({Key? key,  this.value, this.title, this.type}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: 10,bottom: 10),
      margin: EdgeInsets.only(top: 10),
      decoration: BoxDecoration(
        border: Border.all(width: 0.5, color: Colors.greenAccent),
        borderRadius: const BorderRadius.all(
          Radius.circular(5),
        ),
      ),
      child: Row(
        children: [
          Expanded(flex: 2, child:
          title.toString().trim()=="CREDIT CARD"?Image.asset("assets/images/creditcard.png",height: 35,width: 35):
          title.toString().trim()=="CASH"? Image.asset("assets/images/cashon.png",height: 35,width: 35,):
          title.toString().trim()=="CHECK"? Image.asset("assets/images/cheque.png",height: 35,width: 35,):
           Icon(
        FontAwesomeIcons.dotCircle,
        color: Colors.blueGrey,
        size: 20,
      ),
          ) ,
          Expanded(flex: 5,child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                  title!,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(color:
                  title=="CASH"?
                  Colors.green:
                  title=="CREDIT CARD"?
                  Colors.blue:
                  title=="CHECK"?
                  Colors.purple:
                  Colors.green,),
                ),
              SizedBox(height: 6,),
              Text(
                type!??"",
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: TextStyle(color:
                Theme.of(context).colorScheme.onPrimary,),
              ),
            ],
          ),)  ,
          Expanded(flex:3,
              child:Text("\$ "+value!,  style: TextStyle(color:Theme.of(context).colorScheme.primary,fontWeight: FontWeight.bold,fontSize: 15),
                textAlign: TextAlign.center,

          ))

        ],
      )
    );
  }
}
