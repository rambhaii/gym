import 'dart:convert';
import 'package:aspgen_mobile/AppConstant/TextStyle.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';


class CustomPrimaryButton extends StatelessWidget {
  final Color buttonColor;
  final String textValue;
  final String password;
  final String username;
  final Color textColor;
  final VoidCallback press;

  CustomPrimaryButton({required this.buttonColor, required this.textValue, required this.textColor, required this.username, required this.password, required this.press});

  @override
  Widget build(BuildContext context) {
    return
      Material(
      borderRadius: BorderRadius.circular(14.0),
      elevation: 0,
      child: Container(
        height: 36,
        decoration: BoxDecoration(
          color: buttonColor,
          borderRadius: BorderRadius.circular(5.0),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: press,
            borderRadius: BorderRadius.circular(5.0),
            child: Center(
              child: Text(
                textValue,
                style: heading2.copyWith(color: textColor),
              ),
            ),
          ),
        ),
      ),
    );
    ;
  }

}
