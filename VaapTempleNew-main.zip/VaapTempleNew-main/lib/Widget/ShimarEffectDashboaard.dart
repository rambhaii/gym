import 'package:flutter/material.dart';
import 'package:shimmer/shimmer.dart';
class ShimmerEffectForDashboard extends StatelessWidget {
  const ShimmerEffectForDashboard({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Shimmer.fromColors(
        baseColor:Colors.grey,
        highlightColor:  Theme.of(context).colorScheme.primary,
        direction: ShimmerDirection.ltr,
        child:GridView.count(
            crossAxisCount: 3,
            crossAxisSpacing: 0,
            mainAxisSpacing:0,
            children: List.generate(11, (index) {
              return Column(
                children: [
                  Container(
                      width: 60,
                      height: 60,
                      child: ClipRRect(
                          borderRadius:
                          BorderRadius.circular(20.0),

                      )
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  Container(
                      width: 80,
                    height: 40,
                  )
                ],
              );
            })

        )
        // ListView.builder(
        //   itemBuilder: (_, __) => Padding(
        //     padding: const EdgeInsets.only(bottom: 8.0),
        //     child: Row(
        //       crossAxisAlignment: CrossAxisAlignment.start,
        //       children: <Widget>[
        //         Expanded(
        //           child: Column(
        //             crossAxisAlignment: CrossAxisAlignment.start,
        //             children: <Widget>[
        //               Container(
        //                 margin: EdgeInsets.only(left: 10,right: 10,top: 8),
        //                 decoration: BoxDecoration(
        //                   borderRadius: BorderRadius.circular(3),
        //                   color:  Theme.of(context).colorScheme.primary.withOpacity(0.4),
        //                 ),
        //                 width: double.infinity,
        //                 height:47,
        //
        //               ),
        //
        //             ],
        //           ),
        //         )
        //       ],
        //     ),
        //   ),
        //   itemCount: 11,
        // ),
      ),
    );
  }
}
