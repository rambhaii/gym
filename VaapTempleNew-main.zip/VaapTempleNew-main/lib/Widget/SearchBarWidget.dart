import 'dart:ui';

import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/theme_services.dart';
import 'package:flutter/material.dart';

class SearchBarWidget extends StatelessWidget {
  final String?hint;
  final ValueChanged?onchange;
  final TextEditingController?controller;
  final VoidCallback?onCancel;
  const SearchBarWidget({Key? key, this.hint, this.onchange, this.controller, this.onCancel}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10.0),
      child: Container(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            border: Border(
                top: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                bottom: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                right: BorderSide(width: 0.1, color: Theme.of(context).colorScheme.primary.withOpacity(0.7)),
                left: BorderSide(width: 0.1, color:  Theme.of(context).colorScheme.primary.withOpacity(0.7))),
            color:Color(0xff6d8d8c).withOpacity(0.3),
            // borderRadius:  BorderRadius.circular(32),
          ),
          child: TextField(
            autofocus: false,
            //  textAlign: TextAlign.center,
            style: Theme.of(context).textTheme.bodyText1,
            controller:controller,
            onChanged:onchange,
            decoration: new InputDecoration(
              fillColor: Colors.teal,
              border: InputBorder.none,
              focusedBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              errorBorder: InputBorder.none,
              disabledBorder: InputBorder.none,
              contentPadding:
              EdgeInsets.only(left: 15, top: 15, right: 15),
              hintText: hint,
              hintStyle: TextStyle(color: Theme.of(context).colorScheme.primary.withOpacity(0.4)),
              suffixIcon: controller!.text.isNotEmpty?InkWell(
                onTap: onCancel,
                child: Icon(
                  Icons.clear,
                  color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
                ),
              ):Icon(
                Icons.clear,
                color: Colors.transparent,
              ),
              prefixIcon: Icon(
                Icons.search,
              ),
            ),
          )
       ),
    );
  }
}
