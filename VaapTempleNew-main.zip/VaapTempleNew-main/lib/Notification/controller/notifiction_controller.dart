import 'dart:convert';

import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/base_client.dart';
import '../model/NotificationData.dart';

class NotificationPageController extends GetxController{
  var bodyJson={};
  List<NotificationDatum> data=[];
  @override
  void onInit() {
    // TODO: implement onInit
    fetchApi("Notifications");
    super.onInit();
  }
  fetchApi(String title)async{
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getAPI,getJson(title)).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    data.addAll(NotificationData.fromJson(jsonDecode(response)).data!);
    update();

  }
  getJson(String title)
  {
    bodyJson["componentConfig"]={
      "moduleName":title,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "skip":0,
      "next":100
    };
    return bodyJson;
  }
}