import 'dart:convert';
import 'dart:io';

import 'package:aspgen_mobile/Dashboard/Model/field.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../Dashboard/Contact/ContactPage.dart';
import '../../Dashboard/Contact/Model/AllContactDatas.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/Utils.dart';
import '../../UtilMethods/base_client.dart';

class NotificationController extends GetxController{
  Rx<FieldModel> fieldData= FieldModel().obs;//All Fields Model
  final String title;//Module Name
  final String?id;//Module Name
  final int type;//  1 for add And 2 for update
  NotificationController(this.title,this.type, this.id);
  var bodyJson={};
  Map? datum;//Map for set contact Data
  var requestDroupdownbody={};
  Rx<AllContactDatas> allContactDatas=AllContactDatas().obs;
  RxList<TechnicalChildDatum> Group_1=RxList<TechnicalChildDatum>([]);
  RxList<TechnicalChildDatum> Group_2=RxList<TechnicalChildDatum>([]);
  RxList<TechnicalChildDatum> Group_3=RxList<TechnicalChildDatum>([]);
  RxList<TechnicalChildDatum> fielSubdData=RxList<TechnicalChildDatum>([]);
  Rx<File>? pickfile;
  var isReady=false.obs;
  var image="".obs;

  Rx<File>? pickfilepicker;

  var fileextension="".obs;
  var filename="Attach File".obs;
  String day="";
  TimeOfDay startTime=TimeOfDay.now();
  @override
  void onInit() {
    bodyJson["componentConfig"]={
      "moduleName":title,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
    };
    getFields();
    // TODO: implement onInit

    super.onInit();
  }

  getFields()
  {
    try {
      UtilMethods.getDynamicField(Get.context!,title).then((value) {

        fieldData.value=fieldModelFromJson(json.encode(json.decode(value)["result"]));
        for(TechnicalChildDatum data in fieldData.value.data![0].technicalChildData!){
          if(data.group=="Group 1")
          {
            Group_1.add(data);

          }
          else if(data.group=="Group 2")
          {
            Group_2.add(data);
          }
          else if(data.group=="Group 3")
          {
            Group_3.add(data);
          }
          else{
            fielSubdData.add(data);
          }
        }
        update();
        getDroupDownValue();
        if(type==2 && title=="Contacts")
        {
          datum=Get.arguments['data']??[];
          setData();
          getSubDropDown(datum!["stateTypes"],Get.context!);
        }


      });
    } catch(e) {
      Get.snackbar("Error", "Faild to load data");
    }

  }

  addEditData() {
    var formValue = {};
    fielSubdData.forEach((element) {
      if (element.fieldType == "DROP DOWN") {
        formValue[element.fieldName] = element.dropDownValue!;
      }
      else {
        if(element.fieldType!.toLowerCase().contains("email") || element.fieldType!.toLowerCase().contains("phone"))
        {
          formValue[element.fieldName]=element.textEditingController!.text;
          return;
        }
        formValue[element.fieldName] =element.textEditingController!.text;
      }
    });
    Group_1.forEach((element) {
      if(element.dropDownType=="Checkbox")
      {
        formValue[element.fieldName] = element.dropDownList!.toList();
        return;
      }
      if (element.fieldType == "DROP DOWN") {
        formValue[element.fieldName] = element.dropDownValue!;
      }
      else {

          formValue[element.fieldName] =element.textEditingController!.text;



      }
    });
    Group_2.forEach((element) {
      if (element.fieldType == "DROP DOWN") {
        formValue[element.fieldName] = element.dropDownValue!;
      }
      else {
        if(element.fieldName=="DROP DOWN" || element.dropDownType=="Checkbox")
        {
          formValue[element.fieldName] = element.dropDownList!.toList();
        }else {
          formValue[element.fieldName] = element.textEditingController!.text;
        }
      }
    });
    Group_3.forEach((element) {
      if (element.fieldType == "DROP DOWN") {
        formValue[element.fieldName] = element.dropDownValue!;
      }
      else {
        formValue[element.fieldName] =element.textEditingController!.text;
      }
    });

    bodyJson["dataJson"] = formValue;
    if (type == 1) {

      UtilMethods.addAPI(Get.context!,bodyJson).then((value) {
        if(jsonDecode(value)["statusCode"].toString().trim()=="1")
        {
          Fluttertoast.showToast(msg: jsonDecode(value)["message"]);
          Get.back();
        }
        else{
          Get.snackbar("Error",jsonDecode(value)["message"].toString().trim());
        }
      });
    }
    else {
      bodyJson["_id"] = id;
      UtilMethods.postAPI(Get.context!,bodyJson).then((value) {
        if(jsonDecode(value)["statusCode"].toString().trim()=="1")
        {
          Fluttertoast.showToast(msg: jsonDecode(value)["message"]);
          Get.back();
        }
        else{
          Get.snackbar("Error",jsonDecode(value)["message"].toString().trim());
        }
      });
    }
  }
  void setData() {
    fieldData.value.data![0].technicalChildData!.forEach((element) {
      if (element.fieldType == "DROP DOWN") {
        return ;
      }
      else if(element.fieldType == "FILE"){
        filename.value = datum![element.fieldName!];
        element.textEditingController!.text = datum![element.fieldName!];
      }
      else{
        element.textEditingController!.text = datum![element.fieldName!];
      }
    });

  }
  getDroupDownValue() {
    Group_1.forEach((element) {
      if(element.fieldType=="DROP DOWN" && element.fieldName=="cityTypes" || element.fieldName=="serviceTypes")
      {
        return;
      }
      if(element.fieldType=="DROP DOWN")
      {
        requestDroupdownbody["componentConfig"] = {
          "moduleName": "Master Data Management",
          "aspectType": element.fieldName,
          "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
          "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
          "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
          "query": {
            "aspectType":element.fieldName
          },
          "skip": 0,
          "next": 100
        };
        UtilMethods.getDropDownData(Get.context!, requestDroupdownbody).then((
            value) {
          if(value.data==null)
            return ;
          value.data!.forEach((element1) {
            element.dropDownList!.add({"name": element1.refDataName,"isCheck":false});
            element.autoList!.add(element1.refDataName!);

          });
          if(type==2) {
            int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName!]);
            if (index > -1) {
              element.selectedDropDownValue = element.dropDownList![index];
              element.dropDownValue = element.dropDownList![index]["name"];
            }
          }
          update();
        });

      }
    });
    Group_2.forEach((element) {
      if(element.fieldType=="DROP DOWN" && element.fieldName=="cityTypes" || element.fieldName=="serviceTypes")
      {
        return;
      }
      if(element.fieldType=="DROP DOWN")
      {
        requestDroupdownbody["componentConfig"] = {
          "moduleName": "Master Data Management",
          "aspectType": element.fieldName,
          "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
          "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
          "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
          "query": {
            "aspectType":element.fieldName
          },
          "skip": 0,
          "next": 100
        };
        UtilMethods.getDropDownData(Get.context!, requestDroupdownbody).then((
            value) {
          if(value.data==null)
            return ;
          value.data!.forEach((element1) {
            element.dropDownList!.add({"name": element1.refDataName});
            element.autoList!.add(element1.refDataName!);

          });
          if(type==2) {
            int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName!]);
            if (index > -1) {
              element.selectedDropDownValue = element.dropDownList![index];
              element.dropDownValue = element.dropDownList![index]["name"];
            }
          }
          update();
        });

      }
    });
    Group_3.forEach((element) {
      if(element.fieldType=="DROP DOWN" && element.fieldName=="cityTypes" || element.fieldName=="serviceTypes")
      {
        return;
      }
      if(element.fieldType=="DROP DOWN")
      {
        requestDroupdownbody["componentConfig"] = {
          "moduleName": "Master Data Management",
          "aspectType": element.fieldName,
          "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
          "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
          "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
          "query": {
            "aspectType":element.fieldName
          },
          "skip": 0,
          "next": 100
        };
        UtilMethods.getDropDownData(Get.context!, requestDroupdownbody).then((
            value) {
          if(value.data==null)
            return ;
          value.data!.forEach((element1) {
            element.dropDownList!.add({"name": element1.refDataName});
            element.autoList!.add(element1.refDataName!);

          });
          if(type==2) {
            int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName!]);
            if (index > -1) {
              element.selectedDropDownValue = element.dropDownList![index];
              element.dropDownValue = element.dropDownList![index]["name"];
            }
          }
          update();
        });

      }
    });
    fielSubdData.forEach((element) {
      if(element.fieldType=="DROP DOWN" && element.fieldName=="cityTypes" || element.fieldName=="serviceTypes")
      {
        return;
      }
      if(element.fieldType=="DROP DOWN")
      {
        requestDroupdownbody["componentConfig"] = {
          "moduleName": "Master Data Management",
          "aspectType": element.fieldName,
          "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
          "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
          "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
          "query": {
            "aspectType":element.fieldName
          },
          "skip": 0,
          "next": 100
        };
        UtilMethods.getDropDownData(Get.context!, requestDroupdownbody).then((
            value) {
          if(value.data==null)
            return ;
          value.data!.forEach((element1) {
            element.dropDownList!.add({"name": element1.refDataName});
            element.autoList!.add(element1.refDataName!);

          });
          if(type==2) {
            int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName!]);
            if (index > -1) {
              element.selectedDropDownValue = element.dropDownList![index];
              element.dropDownValue = element.dropDownList![index]["name"];
            }
          }
          update();
        });

      }

    });

  }

  getSubDropDown(String subType,BuildContext context){
    Group_1.forEach((element) {
      if (element.fieldType == "DROP DOWN" && element.fieldName == "cityTypes" || element.fieldName=="serviceTypes") {
        requestDroupdownbody["componentConfig"] = {
          "moduleName": "Master Data Management",
          "aspectType": element.fieldName,
          "productID": AppConstant.sharedPreference.getString(
              AppConstant.productId),
          "clientID": AppConstant.sharedPreference.getString(
              AppConstant.clientId),
          "userName": AppConstant.sharedPreference.getString(
              AppConstant.userName),
          "query": {
            "aspectType": element.fieldName, "refDataCode": subType
          },
          "skip": 0,
          "next": 100
        };
        UtilMethods.getDropSubDownData(context, requestDroupdownbody).then((
            value) {
          element.dropDownList!.clear();
          element.selectedDropDownValue=null;
          element.dropDownValue="";
          if (value.data == null)
            return;
          value.data!.forEach((element1) {
            element.dropDownList!.add({"name": element1.refDataName,"isCheck":false});
            element.autoList!.add(element1.refDataName!);
          });
          if(type==2) {
            int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName!]);
            if (index > -1) {
              element.selectedDropDownValue = element.dropDownList![index];
              element.dropDownValue = element.dropDownList![index]["name"];
            }
          }
          update();
        });

      }
    });
    Group_2.forEach((element) {
      if (element.fieldType == "DROP DOWN" && element.fieldName == "cityTypes" || element.fieldName=="serviceTypes") {
        requestDroupdownbody["componentConfig"] = {
          "moduleName": "Master Data Management",
          "aspectType": element.fieldName,
          "productID": AppConstant.sharedPreference.getString(
              AppConstant.productId),
          "clientID": AppConstant.sharedPreference.getString(
              AppConstant.clientId),
          "userName": AppConstant.sharedPreference.getString(
              AppConstant.userName),
          "query": {
            "aspectType": element.fieldName, "refDataCode": subType
          },
          "skip": 0,
          "next": 100
        };
        UtilMethods.getDropSubDownData(context, requestDroupdownbody).then((
            value) {
          element.dropDownList!.clear();
          element.selectedDropDownValue=null;
          element.dropDownValue="";
          if (value.data == null)
            return;
          value.data!.forEach((element1) {
            element.dropDownList!.add({"name": element1.refDataName});
            element.autoList!.add(element1.refDataName!);
          });
          if(type==2) {
            int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName!]);
            if (index > -1) {
              element.selectedDropDownValue = element.dropDownList![index];
              element.dropDownValue = element.dropDownList![index]["name"];
            }
          }
          update();
        });

      }
    });
    Group_3.forEach((element) {
      if (element.fieldType == "DROP DOWN" && element.fieldName == "cityTypes" || element.fieldName=="serviceTypes") {
        requestDroupdownbody["componentConfig"] = {
          "moduleName": "Master Data Management",
          "aspectType": element.fieldName,
          "productID": AppConstant.sharedPreference.getString(
              AppConstant.productId),
          "clientID": AppConstant.sharedPreference.getString(
              AppConstant.clientId),
          "userName": AppConstant.sharedPreference.getString(
              AppConstant.userName),
          "query": {
            "aspectType": element.fieldName, "refDataCode": subType
          },
          "skip": 0,
          "next": 100
        };
        UtilMethods.getDropSubDownData(context, requestDroupdownbody).then((
            value) {
          element.dropDownList!.clear();
          element.selectedDropDownValue=null;
          element.dropDownValue="";
          if (value.data == null)
            return;
          value.data!.forEach((element1) {
            element.dropDownList!.add({"name": element1.refDataName});
            element.autoList!.add(element1.refDataName!);
          });
          if(type==2) {

            int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName!]);

            if (index > -1) {
              element.selectedDropDownValue = element.dropDownList![index];
              element.dropDownValue = element.dropDownList![index]["name"];
            }
          }
          update();
        });

      }
    });
    fielSubdData.forEach((element) {
      if (element.fieldType == "DROP DOWN" && element.fieldName == "cityTypes" || element.fieldName=="serviceTypes") {
        requestDroupdownbody["componentConfig"] = {
          "moduleName": "Master Data Management",
          "aspectType": element.fieldName,
          "productID": AppConstant.sharedPreference.getString(
              AppConstant.productId),
          "clientID": AppConstant.sharedPreference.getString(
              AppConstant.clientId),
          "userName": AppConstant.sharedPreference.getString(
              AppConstant.userName),
          "query": {
            "aspectType": element.fieldName, "refDataCode": subType
          },
          "skip": 0,
          "next": 100
        };
        UtilMethods.getDropSubDownData(context, requestDroupdownbody).then((
            value) {
          element.dropDownList!.clear();
          element.selectedDropDownValue=null;
          element.dropDownValue="";
          if (value.data == null)
            return;
          value.data!.forEach((element1) {
            element.dropDownList!.add({"name": element1.refDataName});
            element.autoList!.add(element1.refDataName!);
          });
          if(type==2) {

            int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName!]);
            if (index > -1) {
              element.selectedDropDownValue = element.dropDownList![index];
              element.dropDownValue = element.dropDownList![index]["name"];
            }
          }
          update();
        });

      }
    });

  }


  void pickImage(ImageSource src)async{
    Get.back();
    final imagepicker=await ImagePicker().pickImage(source: src,imageQuality:80);
    if(imagepicker!.path!=null)
    {

      final bytes = File(imagepicker.path).readAsBytesSync().lengthInBytes;
      final kb = bytes / 1024;
      if(kb<500)
      {
        pickfile=Rx<File>(File(imagepicker.path));
        image.value=imagepicker.path;
        isReady.value=true;
        update();
        try {
          UtilMethods.uploadSingleImage(Get.context!, image.value, "profile",imagepicker.name).then((value) {
            Group_1.forEach((element) {
              if(element.fieldName=="image"){
                element.textEditingController!.text=value;
              }
            }); Group_2.forEach((element) {
              if(element.fieldName=="image"){
                element.textEditingController!.text=value;
              }
            });
            Group_3.forEach((element) {
              if(element.fieldName=="image"){
                element.textEditingController!.text=value;
              }
            });
            fieldData.value.data![0].technicalChildData!.forEach((element) {
              if(element.fieldName=="image"){
                element.textEditingController!.text=value;
              }
            });
          });
        } on Exception catch (e) {

          // TODO
        }

        // Get.snackbar("Accept", kb.toString());
      }
      else{
        Get.snackbar("Size is large","Please select image size less then 500k",backgroundColor: Colors.red);
      }


    }
  }
  void selectFile()async{
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    PlatformFile file = result!.files.first;
    if (result != null) {
      final bytes = File(file.path!).readAsBytesSync().lengthInBytes;
      final kb = bytes / 1024;
      if(kb<500) {
        fileextension.value = file.extension!;
        filename.value = file.name;
        try {
          UtilMethods.uploadSingleImage(Get.context!, file.path!, "profile",file.name)
              .then((value) {
            fieldData.value.data![0].technicalChildData!.forEach((element) {
              if (element.fieldType == "FILE") {
                element.textEditingController!.text = value;
              }
            });
          });
        } on Exception catch (e) {
          // TODO
        }

        //updateModel();
      }
      else{
        Get.snackbar("Size is large","Please select image size less then 500k",backgroundColor: Colors.red.withOpacity(0.6),
          icon: Icon(Icons.cancel, color: Colors.white),
          snackPosition: SnackPosition.TOP,
          borderRadius: 5,
        );
      }

    } else {
      // User canceled the picker
    }
  }

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }
  @override
  void dispose() {

    // TODO: implement dispose
    super.dispose();
  }

}