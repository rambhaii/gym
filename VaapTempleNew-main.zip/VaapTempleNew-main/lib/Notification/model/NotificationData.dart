// To parse this JSON data, do
//
//     final notificationData = notificationDataFromJson(jsonString);

import 'dart:convert';

NotificationData notificationDataFromJson(String str) => NotificationData.fromJson(json.decode(str));

String notificationDataToJson(NotificationData data) => json.encode(data.toJson());

class NotificationData {
  NotificationData({
    this.statusCode,
    this.message,
    this.data,
  });

  String? statusCode;
  String? message;
  List<NotificationDatum> ?data;

  factory NotificationData.fromJson(Map<String, dynamic> json) => NotificationData(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<NotificationDatum>.from(json["data"].map((x) => NotificationDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class NotificationDatum {
  NotificationDatum({
    this.id,
    this.memberTypes,
    this.subject,
    this.description,
    this.notificationTypes,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.email,
    this.phone,
    this.message,
  });

  String ?id;
  String ?memberTypes;
  String ?subject;
  String ?description;
  dynamic notificationTypes;
  String ?moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  String ?email;
  String ?phone;
  String ?message;

  factory NotificationDatum.fromJson(Map<String, dynamic> json) => NotificationDatum(
    id: json["_id"]??"",
    memberTypes: json["memberTypes"]??"",
    subject: json["subject"],
    description: json["description"]??"",
    notificationTypes: json["notificationTypes"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    email: json["email"]??"",
    phone: json["phone"] ??"",
    message: json["Message"]??"",
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "memberTypes": memberTypes,
    "subject": subject,
    "description": description,
    "notificationTypes": notificationTypes,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "email": email ,
    "phone": phone ,
    "Message": message ,
  };
}

class NotificationType {
  NotificationType({
    this.name,
    this.isCheck,
  });

  String ?name;
  bool ?isCheck;

  factory NotificationType.fromJson(Map<String, dynamic> json) => NotificationType(
    name: json["name"]??"",
    isCheck: json["isCheck"]??false,
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "isCheck": isCheck,
  };
}
