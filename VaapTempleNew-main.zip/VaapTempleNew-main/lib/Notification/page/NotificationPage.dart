import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import '../../AppConstant/TextStyle.dart';
import '../../Templates/fieldPageNew.dart';
import '../../UtilMethods/RemoteServices.dart';
import '../../UtilMethods/Utils.dart';
import '../controller/notification_field.dart';
import '../controller/notifiction_controller.dart';
import 'NotificationViewPaget.dart';
import 'notification_details.dart';
import 'notification_field_page.dart';
class NotificationPage extends StatefulWidget {
  final String title;
  const NotificationPage({Key? key, required this.title}) : super(key: key);
  @override
  _NotificationPageState createState() => _NotificationPageState();
}

class _NotificationPageState extends State<NotificationPage> {
  final DateFormat formatter = DateFormat.yMMMd('en_US');

  TextEditingController etsearch= new TextEditingController();
  NotificationPageController notificationController=Get.put(NotificationPageController());
  DateTime?tempDate;
  @override
  void initState() {
    //getListData();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
        ),
        actions: [  Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child: RawMaterialButton(onPressed: (){
            CheckInternetConnection().then((value1) => value1==true? Get.to(()=>NotificationViewPager()):"");
          }
            ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
        )],
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          children: [
            SizedBox(height: 5,),
            GetBuilder<NotificationPageController>(
              builder:(controller)=> controller.data!=null?
                  Expanded(
                child: RefreshIndicator(
                  semanticsLabel: "Refresh",
                  onRefresh: (){
                    return Future.delayed(Duration.zero, () {

                    });
                    },
                  child: ListView.builder(
                      itemCount:controller.data.length,
                      itemBuilder: (context,index)
                      {
                        final datum=controller.data[index];
                        return Card(
                          color: Theme.of(context).colorScheme.onPrimaryContainer,
                          child: ListTile(
                            onTap: (){
                              Get.to(()=>NotificationDetails(datum: datum,));
                              },
                            minLeadingWidth: 20,
                            leading: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Icon(Icons.notifications,color: Color(
                                    0xffffe6cd),),
                                Text(datum.moduleName=="Notifications"?"Group":"User",style: TextStyle(color:datum.moduleName=="Notifications"? Colors.tealAccent:Colors.amber),)
                              ],
                            ),
                            trailing: Icon(Icons.arrow_forward,color:  Theme.of(context).colorScheme.primary,),
                            title: Text(datum.subject??""),
                            subtitle: Text(datum.memberTypes==""?datum.email!:datum.memberTypes!,style: Theme.of(context).textTheme.bodyText2,),
                          ),
                        );

                      }),
                ),
              ):Container()
            )
          ],
        ),
      ),

    );
  }

}
