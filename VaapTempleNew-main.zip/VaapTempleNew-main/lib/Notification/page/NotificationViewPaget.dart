import 'package:aspgen_mobile/Notification/page/notification_field_page.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controller/notification_field.dart';
import '../controller/notification_view_pager_controller.dart';

class NotificationViewPager extends StatefulWidget {
  const NotificationViewPager({Key? key}) : super(key: key);

  @override
  State<NotificationViewPager> createState() => _NotificationViewPagerState();
}

class _NotificationViewPagerState extends State<NotificationViewPager> with SingleTickerProviderStateMixin  {
  NotificationPagerController notificationPagerController=Get.put(NotificationPagerController());
  late final _tabController = TabController(length: 2, vsync: this);

  @override
  void initState() {

    // TODO: implement initState
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:  AppBar(
          title: const Text('Notifications'),
          // Use TabBar to show the three tabs
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: RawMaterialButton(
              onPressed: () {
                NotificationController notificationController=Get.find();
                notificationController.addEditData();
              },
              child: Icon(Icons.send),
              fillColor: Colors.green,
              shape: CircleBorder(),
              constraints: BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          )
        ],
          bottom: TabBar(
            indicatorColor: Colors.teal,
            labelColor:  Colors.teal,
            unselectedLabelColor: Colors.white70,
            onTap: ((value){
                notificationPagerController.pagecontroller.animateToPage(
                value, duration: Duration(milliseconds: 300),
                curve: Curves.fastOutSlowIn);
            }),
            controller: _tabController,
            tabs: const <Widget>[
              Tab(
                text: 'Group',
              ),
              Tab(
                text: 'Individual',
              ),

            ],
          ),
      ),
      body: SafeArea(
        child: PageView(
          onPageChanged: ((value) {
             _tabController.index=value;
          }),
          controller: notificationPagerController.pagecontroller,
          children: [
            NotificationFieldPage(title: "Notifications", type: 1),
            NotificationFieldPage(title: "User Notification", type: 1),
          ],
        ),
      ),
    );
  }
}

