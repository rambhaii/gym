import 'package:aspgen_mobile/Notification/model/NotificationData.dart';
import 'package:flutter/material.dart';
class NotificationDetails extends StatelessWidget {
  const NotificationDetails({Key? key, required this.datum}) : super(key: key);
  final NotificationDatum datum;
  @override
  Widget build(BuildContext context) {
    TextStyle title=Theme.of(context).textTheme.bodyText1!;
    TextStyle subTitle=Theme.of(context).textTheme.bodyText2!;
    return Scaffold(
        appBar: AppBar(
          title: Text(
           "Notification Details",
          ),

        ),
      body:Container(
        margin: EdgeInsets.all(20),
        child: Column(
          children: [

            InputDecorator(decoration: InputDecoration(
            labelText:"Subject  ",
            labelStyle: subTitle,
            contentPadding: EdgeInsets.only(left: 15,right: 15),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(2.0),
              borderSide: const BorderSide(
                  color: Colors.white70, width: 0.0),
            ),
            border: const OutlineInputBorder(),
          ),
            child: Text(datum.subject??"",style: title,)
              ,
            ),
            if(datum.message!="")  SizedBox(height: 20,),
            if(datum.message!="")   InputDecorator(decoration: InputDecoration(
              labelText:"Message  ",
              labelStyle: subTitle,
              contentPadding: EdgeInsets.only(left: 15,right: 15),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(2.0),
                borderSide: const BorderSide(
                    color: Colors.white70, width: 0.0),
              ),
              border: const OutlineInputBorder(),
            ),
              child: Text(datum.message??"",style: title,)
              ,
            ),
            if(datum.memberTypes!="")  SizedBox(height: 20,),
            if(datum.memberTypes!="")   InputDecorator(decoration: InputDecoration(
              labelText:"Member Type  ",
              labelStyle: subTitle,
              contentPadding: EdgeInsets.only(left: 15,right: 15),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(2.0),
                borderSide: const BorderSide(
                    color: Colors.white70, width: 0.0),
              ),
              border: const OutlineInputBorder(),
            ),
              child: Text(datum.memberTypes??"",style: title,)
              ,
            ),
            if(datum.description!="")  SizedBox(height: 20,),
            if(datum.description!="")InputDecorator(decoration: InputDecoration(
              labelText:"Description  ",
              labelStyle: subTitle,
              contentPadding: EdgeInsets.only(left: 15,right: 15),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(2.0),
                borderSide: const BorderSide(
                    color: Colors.white70, width: 0.0),
              ),
              border: const OutlineInputBorder(),
            ),
              child: Text(datum.description??"",style: title,)
              ,
            ),
            if(datum.email!="")   SizedBox(height: 20,),
            if(datum.email!="")   InputDecorator(decoration: InputDecoration(
              labelText:"Email  ",
              labelStyle: subTitle,
              contentPadding: EdgeInsets.only(left: 15,right: 15),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(2.0),
                borderSide: const BorderSide(
                    color: Colors.white70, width: 0.0),
              ),
              border: const OutlineInputBorder(),
            ),
              child: Text(datum.email??"",style: title,)
              ,
            ),
            if(datum.phone!="")    SizedBox(height: 20,),
         if(datum.phone!="")   InputDecorator(decoration: InputDecoration(
              labelText:"Phone  ",
              labelStyle: subTitle,
              contentPadding: EdgeInsets.only(left: 15,right: 15),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(2.0),
                borderSide: const BorderSide(
                    color: Colors.white70, width: 0.0),
              ),
              border: const OutlineInputBorder(),
            ),
              child: Text(datum.phone??"",style: title,)
              ,
            ),

            if(datum.notificationTypes!="")    SizedBox(height: 20,),
            if(datum.notificationTypes!="")   InputDecorator(decoration: InputDecoration(
              labelText:"Notification Type  ",
              labelStyle: subTitle,
              contentPadding: EdgeInsets.only(left: 15,right: 15,top: 15,bottom: 16),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(2.0),
                borderSide: const BorderSide(
                    color: Colors.white70, width: 0.0),
              ),
              border: const OutlineInputBorder(),
            ),
              child:Column(
                crossAxisAlignment: CrossAxisAlignment.start,
              children:List.generate(datum.notificationTypes.length, (index) =>Text(datum.notificationTypes[index]["name"]??"",style: title,) )

              )


             // Text(datum.notificationTypes.name??"",style: title,)
              ,
            ),
          ],
        ),
      )
    );
  }
}
