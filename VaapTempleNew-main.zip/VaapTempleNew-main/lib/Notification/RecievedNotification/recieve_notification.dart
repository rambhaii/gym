
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;

import '../../UtilMethods/RemoteServices.dart';
import '../../Widget/CustomListView.dart';
import 'controller.dart';
class RecieveNotificationPage extends StatefulWidget {
  final String title;
  const RecieveNotificationPage({Key? key, required this.title}) : super(key: key);
  @override
  _RecieveNotificationPageState createState() => _RecieveNotificationPageState();
}

class _RecieveNotificationPageState extends State<RecieveNotificationPage> {
  final DateFormat formatter = DateFormat.yMMMd('en_US');

  TextEditingController etsearch= new TextEditingController();
  ReciveNotiController controller=Get.put(ReciveNotiController());
  DateTime?tempDate;
  @override
  void initState() {
    controller.fetchApi();
    controller.isReadApi();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
        ),
      ),
      body:  Container(
        margin: EdgeInsets.only(top: 0),
        child: Column(
          children: [
            SizedBox(height: 5,),
           Obx(() =>  controller.datas.value.data!=null?
                Expanded(
                  child: RefreshIndicator(
                    semanticsLabel: "Refresh",
                    onRefresh: (){
                      return Future.delayed(Duration.zero, () {
                       controller.fetchApi();
                      });
                    },
                    child: ListView.builder(
                        itemCount:controller.datas.value.data!.length,
                        itemBuilder: (context,index)
                        {
                          final datum=controller.datas.value.data![index];
                          return
                            Card(
                              color: Theme.of(context).colorScheme.onPrimaryContainer,
                              child: ExpansionTile(title: Text(
                                datum.subject!,style: Theme.of(context).textTheme.bodyText1!.copyWith(color: Colors.white),),
                               tilePadding: EdgeInsets.all(8),
                                leading: CircleAvatar(
                                  radius: 15,
                                  backgroundColor: Colors.transparent,
                                  backgroundImage:AssetImage("assets/images/notification.png"),
                                ),
                                childrenPadding: EdgeInsets.only(left: 15,right: 15),
                                subtitle: RichText(
                                  text: TextSpan(
                                    text: "by "+datum.from!,
                                    style: Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 14,color:Colors.amber),
                                    children: <TextSpan>[

                                      TextSpan(
                                          text:"\n"+timeago.format(DateTime.fromMillisecondsSinceEpoch(datum.date!)),
                                          style: Theme.of(context).textTheme.bodyText2!.copyWith(fontWeight: FontWeight.w700,color: Colors.white.withOpacity(0.9) ,height: 1.4)),


                                    ],
                                  ),
                                ),

                                //Text(datum.from!),
                                children: [
                                  // SizedBox(height: 15,),
                                  RichText(
                                    text: TextSpan(
                                      children: <TextSpan>[
                                        TextSpan(
                                            text:datum.description,
                                            style: Theme.of(context).textTheme.bodyText1!.copyWith(fontSize: 13,fontWeight: FontWeight.w200,color: Colors.white.withOpacity(0.7) )),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 15,)
                                ],

                              )

                          );
                        }),
                  ),
                ):Container()
            )
          ],
        ),
      ),

    );
  }

}
