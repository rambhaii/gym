// To parse this JSON data, do
//
//     final recieveNotification = recieveNotificationFromJson(jsonString);

import 'dart:convert';

RecieveNotification recieveNotificationFromJson(String str) => RecieveNotification.fromJson(json.decode(str));

String recieveNotificationToJson(RecieveNotification data) => json.encode(data.toJson());

class RecieveNotification {
  RecieveNotification({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<RecieveDatum>? data;

  factory RecieveNotification.fromJson(Map<String, dynamic> json) => RecieveNotification(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<RecieveDatum>.from(json["data"].map((x) => RecieveDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class RecieveDatum {
  RecieveDatum({
    this.id,
    this.email,
    this.from,
    this.subject,
    this.description,
    this.isRead,
    this.notificationTypes,
    this.date,
    this.aspectType,
  });

  String ?id;
  String ?email;
  String ?from;
  String ?subject;
  String ?description;
  bool ?isRead;
  String? notificationTypes;
  int ?date;
  String ?aspectType;

  factory RecieveDatum.fromJson(Map<String, dynamic> json) => RecieveDatum(
    id: json["_id"]??"",
    email: json["email"]??"",
    from: json["from"]??"",
    subject: json["subject"]??"",
    description: json["description"]??"",
    isRead: json["isRead"]??"",
    notificationTypes: json["notificationTypes"]??"",
    date: json["date"]??"",
    aspectType: json["aspectType"]??"",
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "email": email,
    "from": from,
    "subject": subject,
    "description": description,
    "isRead": isRead,
    "notificationTypes": notificationTypes,
    "date": date,
    "aspectType": aspectType,
  };
}
