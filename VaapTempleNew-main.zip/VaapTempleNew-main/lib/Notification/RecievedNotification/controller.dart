import 'dart:async';
import 'dart:convert';

import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/base_client.dart';
import '../model/NotificationData.dart';
import 'model.dart';
class ReciveNotiController extends GetxController{
  var datas=RecieveNotification().obs;
  var fetchCountData=RecieveNotification().obs;
  var bodyJson={};
  var bodyJson2={};
  var bodyJson3={};
  RxInt notiCount=0.obs;
  @override
  void onInit() {
    print("cbdskvbkvdsb");
    print(AppConstant.sharedPreference.getString(AppConstant.userEmail));
    bodyJson= {
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientId":AppConstant.sharedPreference.getString(AppConstant.clientId),
      "useremail": AppConstant.sharedPreference.getString(AppConstant.userEmail),
      "query": {"isRead": true}
    };
    bodyJson2= {
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "useremail": AppConstant.sharedPreference.getString(AppConstant.userEmail),
      "query": {"isRead": false}
    };
    bodyJson3= {
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientId":   AppConstant.sharedPreference.getString(AppConstant.clientId),
      "useremail": AppConstant.sharedPreference.getString(AppConstant.userEmail),
      "isRead": true,
    };
   // timer();
    // TODO: implement onInit
    fetchCountApi();
    super.onInit();
  }
  fetchApi()async{

  Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getNotification,bodyJson).catchError(BaseController().handleError);
   Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    datas.value=recieveNotificationFromJson(response);
  }
  fetchCountApi()async{
    var response=await BaseClient().post(APIsConstant.getNotification,bodyJson2).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    fetchCountData.value=recieveNotificationFromJson(response);
    notiCount.value=(fetchCountData.value.data!.length);
  }
  isReadApi() async {
    var response=await BaseClient().post(APIsConstant.updateNotofication,bodyJson3).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;

  }
  void timer(){
    Timer(Duration(seconds: 10), () {
      fetchCountApi();
      timer();
    });
  }
}