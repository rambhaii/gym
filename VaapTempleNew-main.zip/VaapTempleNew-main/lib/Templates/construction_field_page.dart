
import 'package:aspgen_mobile/Dashboard/Model/field.dart';
import 'package:aspgen_mobile/Templates/controller/FieldControlller.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:aspgen_mobile/Widget/EditextWidget.dart';
import 'package:aspgen_mobile/Widget/ShimerEffectforField.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../AppConstant/APIsConstant.dart';
import '../Widget/AutoCompleteWidget.dart';
import '../Widget/DropdownButtonWidget.dart';
class ConstructionFieldPageNew extends StatefulWidget {
  final String title;
  final String?id;
  final int type;//type 1==Add and 2==Edit
  const
  ConstructionFieldPageNew({Key? key,required this.title, this.id,required this.type}) : super(key: key);
  @override
  State<ConstructionFieldPageNew> createState() => _ConstructionFieldPageNewState();
}

class _ConstructionFieldPageNewState extends State<ConstructionFieldPageNew> {
  final formGlobalKey = GlobalKey<FormState>();
  FieldModel fieldData = new FieldModel();
  var bodyJson = {};
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  final TextEditingController _typeAheadController = TextEditingController();
  final GlobalKey<ExpansionTileCardState> Group1 = new GlobalKey();
  final GlobalKey<ExpansionTileCardState> Group2 = new GlobalKey();
  final GlobalKey<ExpansionTileCardState> Group3 = new GlobalKey();
  String?_selectedCity;
  late FieldController fieldController;

  @override
  void initState() {
    fieldController = Get.put(FieldController(widget.title, widget.type, widget.id ?? ""));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5
        ),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer);
    return Scaffold(
      appBar: AppBar(title: Text(
          widget.type == 1 ? "Add " + widget.title : "Edit " + widget.title),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 8.0),
            child: RawMaterialButton(
              onPressed: () {
                if (formGlobalKey.currentState!.validate()) {
                  CheckInternetConnection().then((value) {
                    if (value == true) {
                      fieldController.addEditData();
                    }
                  }
                  );
                }
              },
              child: Icon(Icons.save),
              fillColor: Colors.green,
              shape: CircleBorder(),
              constraints: BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
          )
        ],
      ),
      body: GetBuilder<FieldController>(
          builder: (fieldController) {
            return  SingleChildScrollView(
              padding: EdgeInsets.only(left: 5,right: 5,top: 10),
              child: Form(
                key: formGlobalKey,
                child:fieldController.fieldData.value.data!=null? Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    fieldController.Group_4_List.value.isNotEmpty? Container(
                      decoration: decoration,
                      padding: EdgeInsets.only(left: 10,right: 10,top: 8,bottom: 4),
                      child: ListView.builder(
                          itemCount: fieldController.Group_4_List.value.length,
                          physics: NeverScrollableScrollPhysics(),
                          shrinkWrap: true,
                          itemBuilder: (context, index) {
                            final fieldDatum = fieldController.Group_4_List.value[index];
                            return AllFieldWidget(fieldDatum, index, fieldController.Group_4_List.value);
                          }),
                    )
                        :Container(),

                    fieldController.Group_1_List.value.isNotEmpty?  Container(
                      margin: EdgeInsets.only(top:15),
                      padding: EdgeInsets.all(4),
                      decoration:decoration,
                      child:ExpansionTileCard(
                        initiallyExpanded: true,
                        baseColor: Colors.transparent,
                        elevation: 0,
                        expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,

                        key: Group1,
                        title: Text(fieldController.Group_1_List.value[0].groupTitle==""?fieldController.Group_1_List.value[0].fieldLabel!.split(' ').first.toString()+" Details":fieldController.Group_1_List .value[0].groupTitle!),
                        children:List<Widget>.generate(fieldController.Group_1_List.value.length, (index) {
                          final fieldDatum =fieldController.Group_1_List.value[index];
                          return Padding(
                            padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                            child: AllFieldWidget(fieldDatum, index,fieldController.Group_1_List.value),
                          );
                        }),
                      ),

                    ):Container() ,
                    fieldController.Group_2_List.value.isNotEmpty?  Container(
                      margin: EdgeInsets.only(top:15),

                      decoration:decoration,
                      child:ExpansionTileCard(
                        elevation: 0,
                        baseColor: Colors.transparent,
                        initiallyExpanded: true,
                        expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                        key: Group2,
                        title: Text(fieldController.Group_2_List.value[0].groupTitle==""?fieldController.Group_2_List.value[0].fieldLabel!.split(' ').first.toString()+" Details":fieldController.Group_2_List.value[0].groupTitle!),
                        children:List<Widget>.generate(fieldController.Group_2_List.value.length, (index) {
                          final fieldDatum =fieldController.Group_2_List.value[index];
                          return Padding(
                            padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                            child: AllFieldWidget(fieldDatum, index,fieldController.Group_2_List.value),
                          );
                        }),
                      ),

                    )
                        :Container() ,
                    fieldController.Group_3_List.value.isNotEmpty?  Container(
                      margin: EdgeInsets.only(top:15),
                      decoration:decoration,
                      child:ExpansionTileCard(
                        baseColor: Colors.transparent,
                        elevation: 0,
                        expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                        key: Group3,
                        title: Text(fieldController.Group_3_List.value[0].groupTitle==""?fieldController.Group_3_List.value[0].fieldLabel!.split(' ').first.toString()+" Details":fieldController.Group_3_List.value[0].groupTitle!),
                        children:List<Widget>.generate(fieldController.Group_3_List.value.length, (index) {
                          final fieldDatum =fieldController.Group_3_List.value[index];
                          return Padding(
                            padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                            child: AllFieldWidget(fieldDatum, index,fieldController.Group_3_List.value),
                          );
                        }),
                      ),

                    ):Container()

                  ],
                ):ShimmerEffectForField() ,
              ),
            );
            //: ShimmerEffectForField();
          }),
    );
  }

  showOptionDailog(BuildContext context) {
    return showDialog(context: context, builder: (context) =>
        SimpleDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(4.0))),
          backgroundColor: Theme
              .of(context)
              .dialogBackgroundColor
              .withOpacity(0.9),

          children: [
            // SimpleDialogOption(
            //   onPressed: () => fieldController.pickImage(ImageSource.gallery),
            //   child: Row(
            //     children: [
            //       Icon(Icons.image),
            //       Text("   Gallery", style: Theme
            //           .of(context)
            //           .textTheme
            //           .bodyText1,)
            //     ],
            //   ),
            // ),
            // SimpleDialogOption(
            //   onPressed: () => fieldController.pickImage(ImageSource.camera),
            //   child: Row(
            //     children: [
            //       Icon(Icons.camera),
            //       Text("   Camera", style: Theme
            //           .of(context)
            //           .textTheme
            //           .bodyText1,)
            //     ],
            //   ),
            // ),
            SimpleDialogOption(
              onPressed: () => Get.back(),
              child: Row(
                children: [
                  Icon(Icons.clear),
                  Text("  Cancel", style: Theme
                      .of(context)
                      .textTheme
                      .bodyText1,)
                ],
              ),
            ),
          ],
        ));
  }

  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);

    final format = DateFormat.jm(); // YOUR DATE GOES HERE

    return format.format(dt);
  }

  Widget AllFieldWidget(TechnicalChildDatum fieldDatum,int index,List<TechnicalChildDatum> model){
    return fieldDatum.fieldType == "DROP DOWN" ?
    Padding(
      padding: EdgeInsets.only(top: 5,bottom: 8 ),
      child:
      DropdownButtonWidget(
        change: (value) {
          fieldDatum.selectedDropDownValue=value;
          fieldDatum.dropDownValue=fieldDatum.selectedDropDownValue["name"];
          fieldController.update();

          },
        title: "Select ${fieldDatum.fieldLabel!}",
        list:fieldDatum.dropDownList!,
        hint: "Select ${fieldDatum.fieldName!}",
        selectvalue:fieldDatum.selectedDropDownValue,
        onPress: '',
      ),
    ) : fieldDatum.fieldType == "DATE" ? fieldController.day.contains("EVERY")?
    Container():Padding(
      padding: EdgeInsets.only(top: 5),
      child: GestureDetector(
        onTap: () async {
          var day=UtilMethods.getDayInt(fieldController.day);
          print(day.toString());
          var now = new DateTime.now();
          final DateTime? date;
          if(
          day==9
          ){
            date = await showDatePicker(
                context: context,
                initialDate:DateTime.now(),
                firstDate: DateTime(1900),
                lastDate: DateTime(2100),
                builder: (context, child) {
                  return Theme(
                    data: ThemeData.dark().copyWith(
                        colorScheme: const ColorScheme.dark(
                            onPrimary: Colors.white,
                            // selected text color
                            onSurface: Colors.white,
                            // default text color
                            primary: Colors
                                .teal // circle color
                        ),
                        dialogBackgroundColor: Theme
                            .of(context)
                            .backgroundColor,
                        textButtonTheme: TextButtonThemeData(
                            style: TextButton.styleFrom(
                                textStyle: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight
                                        .normal,
                                    fontSize: 12,
                                    fontFamily: 'Quicksand'),
                                primary: Colors.white,
                                // color of button's letters
                                backgroundColor: Colors
                                    .black54,
                                // Background color
                                shape: RoundedRectangleBorder(
                                    side: const BorderSide(
                                        color: Colors
                                            .transparent,
                                        width: 1,
                                        style: BorderStyle
                                            .solid),
                                    borderRadius: BorderRadius
                                        .circular(50))))),
                    child: child!,
                  );
                }
            );
          }else{
            while(now.weekday!=day)
            {
              now=now.add(new Duration(days: 1));
            }
            date = await showDatePicker(
                context: context,
                initialDate:now,
                firstDate: DateTime(1900),
                lastDate: DateTime(2100),
                selectableDayPredicate: (DateTime val) => val.weekday == day ? true : false,
                builder: (context, child) {
                  return Theme(
                    data: ThemeData.dark().copyWith(
                        colorScheme: const ColorScheme.dark(
                            onPrimary: Colors.white,
                            // selected text color
                            onSurface: Colors.white,
                            // default text color
                            primary: Colors
                                .teal // circle color
                        ),
                        dialogBackgroundColor: Theme
                            .of(context)
                            .backgroundColor,
                        textButtonTheme: TextButtonThemeData(
                            style: TextButton.styleFrom(
                                textStyle: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight
                                        .normal,
                                    fontSize: 12,
                                    fontFamily: 'Quicksand'),
                                primary: Colors.white,
                                // color of button's letters
                                backgroundColor: Colors
                                    .black54,
                                // Background color
                                shape: RoundedRectangleBorder(
                                    side: const BorderSide(
                                        color: Colors
                                            .transparent,
                                        width: 1,
                                        style: BorderStyle
                                            .solid),
                                    borderRadius: BorderRadius
                                        .circular(50))))),
                    child: child!,
                  );
                }
            );
          }
          final DateFormat formatter = DateFormat(
              'MM/dd/yyyy');
          final String formatted = formatter.format(date!);
          fieldDatum.textEditingController!.text =
              formatted;
        },
        child: AbsorbPointer(
          child: EditTextWidget(
            maxLength: int.parse(fieldDatum.maxLength!),
            hint: "Enter " + fieldDatum.fieldLabel!,
            isPassword: false,
            keyboardtype: TextInputType.datetime,
            validator: (value) {
              if (fieldDatum.mandatory == "YES") {
                if (value == null || value.isEmpty) {
                  return 'Please Enter ' +
                      fieldDatum.fieldName!;
                }
              }
              return null;
            },
            controller: fieldDatum.textEditingController,
            maxline: 1,
            label: fieldDatum.fieldLabel!,
          ),
        ),
      ),
    ) :
    fieldDatum.fieldType == "TIME" ?
    Padding(
      padding: EdgeInsets.only(top: 5),
      child: GestureDetector(
        onTap: () async {
          final timeindex =model.indexWhere((element) => element.fieldName == "endTime");
          model[timeindex].textEditingController!.clear();
          TimeOfDay? time = await showTimePicker(
              context: context,
              initialTime: fieldController.startTime,
              builder: (context, child) {
                return Theme(
                  data: ThemeData.dark().copyWith(
                      colorScheme: const ColorScheme.dark(
                          onPrimary: Colors.white,
// selected text color
                          onSurface: Colors.white,
// default text color
                          primary: Colors
                              .teal // circle color
                      ),
                      dialogBackgroundColor: Theme
                          .of(context)
                          .backgroundColor,

                      textButtonTheme: TextButtonThemeData(
                          style: TextButton.styleFrom(
                              textStyle: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight
                                      .normal,
                                  fontSize: 12,
                                  fontFamily: 'Quicksand'),
                              primary: Colors.white,
// color of button's letters
                              backgroundColor: Colors
                                  .black54,
// Background color
                              shape: RoundedRectangleBorder(
                                  side: const BorderSide(
                                      color: Colors
                                          .transparent,
                                      width: 1,
                                      style: BorderStyle
                                          .solid),
                                  borderRadius: BorderRadius
                                      .circular(50))))),
                  child: child!,
                );
              }

          );

          fieldDatum.fieldName=="startTime" ? fieldController.startTime=time! :"";
          final now = new DateTime.now();
          final start = DateTime(now.year, now.month, now.day, fieldController.startTime.hour, fieldController.startTime.minute);
          final end = DateTime(now.year, now.month, now.day, time!.hour, time.minute);
          bool isValidDate = start.isBefore(end);
          print("vbdsvbdb");
          print(isValidDate);
          if(fieldDatum.fieldName=="endTime")
          {
            if(isValidDate)
            {
              fieldDatum.textEditingController!.text = formatTimeOfDay(time);
            }
            else{
              Fluttertoast.showToast(msg: "Please Select Future Time");
            }
          }
          else{
            fieldDatum.textEditingController!.text = formatTimeOfDay(time);
          }
        },
        child: AbsorbPointer(
          child: EditTextWidget(
            maxLength: int.parse(fieldDatum.maxLength!),
            hint: "Enter " + fieldDatum.fieldLabel!,
            isPassword: false,
            keyboardtype: TextInputType.datetime,
            validator: (value) {
              if (fieldDatum.mandatory == "YES") {
                if (value == null || value.isEmpty) {
                  return 'Please Enter ' +
                      fieldDatum.fieldName!;
                }
              }
              return null;
            },
            controller: fieldDatum.textEditingController,
            maxline: 1,
            label: fieldDatum.fieldLabel!,
          ),
        ),
      ),
    ) :
    fieldDatum.fieldType == "FILE" ?
    Padding(
      padding: EdgeInsets.only(top: 5, bottom: 5),
      child: Container(
        height: 50,
        decoration: BoxDecoration(
            border: Border.all(
                color: Colors.grey, width: 1),
            borderRadius: BorderRadius.circular(5)
        ),
        child: Row(
          children: [
            fieldController.fileextension.value == ""
                ? Expanded(
                flex: 2,
                child: Icon(Icons.attach_file))
                :
            Expanded(
                flex: 2,
                child: Container(
                  margin: EdgeInsets.only(left: 3,
                      right: 15,
                      top: 3,
                      bottom: 3),
                  decoration: BoxDecoration(
                      color: Colors.amber.withOpacity(0.7),
                      borderRadius: BorderRadius.circular(4)
                  ),
                  alignment: Alignment.center,
                  height: 55,
                  child: Text(
                    fieldController.fileextension.value
                        .toString(), style: TextStyle(
                      color: Colors.white.withOpacity(0.85),
                      fontWeight: FontWeight.bold,
                      fontSize: 20),),
                )),
            Expanded(
                flex: 4,
                child: Text(fieldController.filename.value
                    .toString())),
            Expanded(
              flex: 2,
              child: TextButton(child: Text("Select"),
                  onPressed: () async {
                    //fieldController.selectFile();
                  }),)
          ],
        ),
      ),
    ) :
    fieldDatum.fieldType == "IMAGE" ?
    Padding(
      padding: const EdgeInsets.all(8.0),
      child: Stack(
        children: [
          Center(
              child: fieldController.isReady.value == false
                  ? widget.type == "1" ? Container(
                alignment: Alignment.center,
                height: 120,
                width: 115,
                decoration: BoxDecoration(
                  color: Theme
                      .of(context)
                      .colorScheme
                      .primary
                      .withOpacity(0.5),
                  shape: BoxShape.circle,
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment
                      .center,
                  children: [
                    CircleAvatar(
                        radius: 50,
                        backgroundColor: Colors.transparent,
                        child: Icon(Icons
                            .add_photo_alternate_outlined,
                          color: Colors.grey, size: 50,)),

                  ],
                ),
              )
                  :
              CircleAvatar(
                  radius: 50,
                  backgroundColor: Colors.grey.withOpacity(
                      0.2),
                  backgroundImage: NetworkImage(
                      APIsConstant.IP_Base_Url +
                          "uploads/others/" +
                          fieldDatum.textEditingController!
                              .text)
              )
                  : CircleAvatar(
                radius: 50,
                backgroundImage: FileImage(fieldController.pickfile!.value),
              )
          ),

          Center(
            child: Container(
              margin: EdgeInsets.only(top: 97),
              height: 30,
              width: 45,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: Colors.white.withOpacity(0.4),
              ),
              child: IconButton(icon: Icon(
                Icons.add_a_photo_outlined,
                color: Colors.white, size: 15,),
                onPressed: () async {
                  showOptionDailog(context);
//uploadImage(filepath);
                },),
            ),
          ),
        ],
      ),
    ) :
    fieldDatum.fieldType == "REMARK" ?
    Padding(padding: const EdgeInsets.only(top: 5), child: EditTextWidget(
      maxLength: int.parse(fieldDatum.maxLength!),
      hint: "Enter " + fieldDatum.fieldLabel!,
      isPassword: false,
      keyboardtype: fieldDatum.fieldType == "EMAIL"
          ? TextInputType.emailAddress
          : fieldDatum.fieldType == "PHONE"
          ? TextInputType.phone
          :
      fieldDatum.fieldType == "NUMBER" ? TextInputType
          .number : TextInputType.text,
      label: fieldDatum.fieldLabel!,
      validator: (value) {
        if (fieldDatum.mandatory == "YES") {
          if (value == null || value.isEmpty) {
            return 'Please Enter ' +
                fieldDatum.fieldName!;
          }
        }
        return null;
      },
      controller: fieldDatum.textEditingController,
      maxline: 3,
    ),
    ) :
    Padding(
      padding: const EdgeInsets.only(top: 5),
      child: EditTextWidget(
        maxLength: int.parse(fieldDatum.maxLength!),
        hint: "Enter " + fieldDatum.fieldLabel!,
        isPassword: false,
        keyboardtype: fieldDatum.fieldType == "EMAIL" ?
        TextInputType.emailAddress : fieldDatum.fieldType ==
            "PHONE" ? TextInputType.phone :
        fieldDatum.fieldType == "NUMBER" ? TextInputType
            .number : TextInputType.text,
        label: fieldDatum.fieldLabel!,
        validator: (value) {
          if (fieldDatum.mandatory == "YES") {
            if (value == null || value.isEmpty) {
              return 'Please Enter ' +
                  fieldDatum.fieldName!;
            }
          }
          return null;
        },
        controller: fieldDatum.textEditingController,
        maxline: 1,
      ),
    );
  }

}

