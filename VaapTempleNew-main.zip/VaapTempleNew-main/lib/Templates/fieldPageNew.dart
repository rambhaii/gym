
import 'package:aspgen_mobile/Dashboard/Model/field.dart';
import 'package:aspgen_mobile/Templates/controller/FieldControlller.dart';
import 'package:aspgen_mobile/Templates/custom_expension_title.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:aspgen_mobile/Widget/EditextWidget.dart';
import 'package:aspgen_mobile/Widget/ShimerEffectforField.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import '../AppConstant/APIsConstant.dart';
import '../UtilMethods/Utils.dart';
import '../Widget/AutoCompleteWidget.dart';
import '../Widget/DropdownButtonWidget.dart';
class FieldPageNew extends StatefulWidget {
  final String title;
  final String ?displayName;

  final String?id;
  final int type;//type 1==Add and 2==Edit
  const
  FieldPageNew({Key? key,required this.title, this.id,required this.type,  this.displayName}) : super(key: key);
  @override
  State<FieldPageNew> createState() => _FieldPageNewState();
}

class _FieldPageNewState extends State<FieldPageNew> {
  FieldModel fieldData = new FieldModel();
  var bodyJson = {};
  final TextEditingController _typeAheadController = TextEditingController();
  String?_selectedCity;
  String disptitle="";
  late FieldController fieldController;
  @override
  void initState() {

    fieldController = Get.put(FieldController(widget.title, widget.type, widget.id ?? ""));
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer);
    return Scaffold(
      appBar: AppBar(title: Text(
          widget.type == 1 ? "Add " + widget.title : "Edit " + widget.title),
        actions: [
         Obx(() =>  Padding(
              padding: const EdgeInsets.only(right: 8.0),
              child: RawMaterialButton(
                onPressed:fieldController.isReady.value? () {
                  if (fieldController.formGlobalKey.currentState!.validate()) {
                    CheckInternetConnection().then((value) {
                      if (value == true) {
                        fieldController.addEditData();
                      }
                    });
                  }
                }:null,
                child: Image.asset("assets/images/diskbold.png",height: 22,width: 22,color: Colors.white,),
                fillColor:fieldController.isReady.value? Colors.green:Colors.grey,
                shape: CircleBorder(),
                elevation: 5,
                constraints: BoxConstraints(minWidth: 38.0, minHeight: 38.0),),
            ),
          )
        ],
      ),
      body: GetBuilder<FieldController>(
        builder: (fieldController) {
          return  SingleChildScrollView(
            padding: EdgeInsets.only(left: 5,right: 5,top: 10),
            child: Form(
              key:fieldController.formGlobalKey,
              child:fieldController.fieldData.value.data!=null? Column(
                mainAxisSize: MainAxisSize.max,
                children: [
                  fieldController.Group_1_List.value.isNotEmpty?  Container(
                    margin: EdgeInsets.only(top:15),
                    decoration:decoration.copyWith(border: Border.all(color: (fieldController.isExpanded1==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                    child:ExpansionTileCardCustom(
                      baseColor: Colors.transparent,
                      elevation: 0,
                      expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                      key: fieldController.Group1,
                      onExpansionChanged: ((value){
                        fieldController.Group3.currentState?.expand(false);
                        fieldController.Group2.currentState?.expand(false);
                        fieldController.Group4.currentState?.expand(false);
                        fieldController.Group5.currentState?.expand(false);
                        fieldController.Group1.currentState?.expand(value);
                        fieldController.isExpanded1=value;
                        fieldController.update();
                      }),
                      title: Text(fieldController.Group_1_List.value[0].groupTitle==""?fieldController.Group_1_List.value[0].fieldLabel!.split(' ').first.toString()+" Details":fieldController.Group_1_List .value[0].groupTitle!),
                      children:List<Widget>.generate(fieldController.Group_1_List.value.length, (index) {
                        final fieldDatum =fieldController.Group_1_List.value[index];
                        return Padding(
                          padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                          child: AllFieldWidget(fieldDatum, index,fieldController.Group_1_List.value),
                        );
                      }),
                    ),

                  ):Container() ,
                  fieldController.Group_2_List.value.isNotEmpty?  Container(
                    margin: EdgeInsets.only(top:15),
                    decoration:decoration.copyWith(border: Border.all(color: (fieldController.isExpanded2==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                    child:ExpansionTileCardCustom(
                      elevation: 0,
                      baseColor: Colors.transparent,
                      expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                      key: fieldController.Group2,
                      onExpansionChanged: ((value){
                        fieldController.Group3.currentState?.expand(false);
                        fieldController.Group1.currentState?.expand(false);
                        fieldController.Group4.currentState?.expand(false);
                        fieldController.Group2.currentState?.expand(value);
                        fieldController.Group5.currentState?.expand(false);
                        fieldController.isExpanded2=value;
                        fieldController.update();
                      }),
                      title: Text(fieldController.Group_2_List.value[0].groupTitle==""?fieldController.Group_2_List.value[0].fieldLabel!.split(' ').first.toString()+" Details":fieldController.Group_2_List.value[0].groupTitle!),
                      children:List<Widget>.generate(fieldController.Group_2_List.value.length, (index) {
                        final fieldDatum =fieldController.Group_2_List.value[index];
                        return Padding(
                          padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                          child: AllFieldWidget(fieldDatum, index,fieldController.Group_2_List.value),
                        );
                      }),
                    ),

                  )
                      :Container() ,
                  fieldController.Group_3_List.value.isNotEmpty?  Container(
                    margin: EdgeInsets.only(top:15),
                    decoration:decoration.copyWith(border: Border.all(color: (fieldController.isExpanded3==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                    child:ExpansionTileCardCustom(
                      baseColor: Colors.transparent,
                      elevation: 0,
                      expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                      key: fieldController.Group3,
                      onExpansionChanged: ((value){
                        fieldController.Group1.currentState?.expand(false);
                        fieldController.Group2.currentState?.expand(false);
                        fieldController.Group4.currentState?.expand(false);
                        fieldController.Group5.currentState?.expand(false);
                        fieldController.Group3.currentState?.expand(value);

                        fieldController.isExpanded3=value;
                        fieldController.update();
                      }),
                      title: Text(fieldController.Group_3_List.value[0].groupTitle==""?fieldController.Group_3_List.value[0].fieldLabel!.split(' ').first.toString()+" Details":fieldController.Group_3_List.value[0].groupTitle!),
                      children:List<Widget>.generate(fieldController.Group_3_List.value.length, (index) {
                        final fieldDatum =fieldController.Group_3_List.value[index];
                        return Padding(
                          padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                          child: AllFieldWidget(fieldDatum, index,fieldController.Group_3_List.value),
                        );
                      }),
                    ),

                  ):Container(),
                  fieldController.Group_4_List.value.isNotEmpty?  Container(
                    margin: EdgeInsets.only(top:15),
                    decoration:decoration.copyWith(border: Border.all(color: (fieldController.isExpanded4==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                    child:ExpansionTileCardCustom(
                      baseColor: Colors.transparent,
                      elevation: 0,
                      expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                      key: fieldController.Group4,
                      onExpansionChanged: ((value){
                        fieldController.Group3.currentState?.expand(false);
                        fieldController.Group1.currentState?.expand(false);
                        fieldController.Group2.currentState?.expand(false);
                        fieldController.Group5.currentState?.expand(false);
                        fieldController.Group4.currentState?.expand(value);
                        fieldController.isExpanded4=value;
                        fieldController.update();
                      }),
                      title: Text(fieldController.Group_4_List.value[0].groupTitle==""?fieldController.Group_4_List.value[0].fieldLabel!.split(' ').first.toString()+" Details":fieldController.Group_4_List.value[0].groupTitle!),
                      children:List<Widget>.generate(fieldController.Group_4_List.value.length, (index) {
                        final fieldDatum =fieldController.Group_4_List.value[index];
                        return Padding(
                          padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                          child: AllFieldWidget(fieldDatum, index,fieldController.Group_4_List.value),
                        );
                      }),
                    ),

                  ):Container(),

             if(widget.title=="Contacts")Obx(()=>fieldController.isMemberDetails==true?
             Container(
                      margin: EdgeInsets.only(top:15),
                      decoration:decoration.copyWith(border: Border.all(color: (fieldController.isExpanded5==false)?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                      child:ExpansionTileCardCustom(
                        baseColor: Colors.transparent,
                        elevation: 0,
                        expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                        key: fieldController.Group5,
                        onExpansionChanged: ((value){
                          fieldController.Group3.currentState?.expand(false);
                          fieldController.Group1.currentState?.expand(false);
                          fieldController.Group2.currentState?.expand(false);
                          fieldController.Group4.currentState?.expand(false);
                          fieldController.Group5.currentState?.expand(value);
                          fieldController.isExpanded5=value;
                          fieldController.update();
                        }),
                        title: Text("Sankalpam Info"),
                        children:List<Widget>.generate(fieldController.Group_5List.length, (index) {
                          return Padding(
                            padding: const EdgeInsets.only(left: 8.0,right: 8.0),
                            child: memberWidegt(index,fieldController.Group_5List[index]),
                          );
                        }),
                      ),

                    ):Container(),
             )
                ],
              ):ShimmerEffectForField() ,
            ),
          );
          //: ShimmerEffectForField();
    }),
    );
  }
  Widget memberWidegt(int index ,Map data){
    return Column(
      children: [
        Divider(thickness: 1,color: Colors.teal,),
     Padding(
    padding: const EdgeInsets.only(top: 5),
    child: EditTextWidget(
    maxLength: 200,
    hint: "Enter family Member "+(index+1).toString(),
    isPassword: false,
    keyboardtype: TextInputType.text,
    label: "Family Member "+(index+1).toString(),
    validator: (value) {
      return null;
    },
    controller: data["memberName"],
    maxline: 1,
    ),
    ),
    Padding(
    padding: const EdgeInsets.only(top: 5),
    child: EditTextWidget(
    maxLength: 200,
    hint: "Enter Nakshatra "+(index+1).toString(),
    isPassword: false,
    keyboardtype: TextInputType.text,
    label: "Nakshatra "+(index+1).toString(),
    validator: (value) {

    return null;
    },
    controller: data["nakshatra"],
    maxline: 1,
    ),
    ),
    Padding(
    padding: const EdgeInsets.only(top: 5),
    child: EditTextWidget(
    maxLength: 200,
    hint: "Enter Rashi "+(index+1).toString(),
    isPassword: false,
    keyboardtype: TextInputType.text,
    label: "Rashi "+(index+1).toString(),
    validator: (value) {

    return null;
    },
    controller: data["rashi"],
    maxline: 1,
    ),
    ),
    Obx(() {
    int ind=fieldController.rxRelationList.value.indexWhere((element) => element["name"]==data["relationship"].text);
    if(ind!=-1)
    {
    data["selectedValue"]= fieldController.rxRelationList.value[ind];
    }

    return DropdownButtonWidget(
    change: (value) {
    data["selectedValue"] = value;
    data["relationship"].text = data["selectedValue"]["name"];
    fieldController.rxRelationList.refresh();
    },
    title: "Select Relationship",
    list: fieldController.rxRelationList.value,
    hint: "Select Relationship",
    selectvalue: data["selectedValue"],
    onPress: '',
    );
    },),
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: GestureDetector(
            onTap: ()async{
              var date = await showDatePicker(
                  context: context,
                  initialDate:DateTime.now(),
                  firstDate: DateTime(1900),
                  lastDate: DateTime(2100),
                  builder: (context, child) {
                    return Theme(
                      data: ThemeData.dark().copyWith(
                          colorScheme: const ColorScheme.dark(
                              onPrimary: Colors.white,
                              // selected text color
                              onSurface: Colors.white,
                              // default text color
                              primary: Colors
                                  .teal // circle color
                          ),
                          dialogBackgroundColor: Theme
                              .of(context)
                              .backgroundColor,
                          textButtonTheme: TextButtonThemeData(
                              style: TextButton.styleFrom(
                                  textStyle: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight
                                          .normal,
                                      fontSize: 12,
                                      fontFamily: 'Quicksand'),
                                  primary: Colors.white,
                                  // color of button's letters
                                  backgroundColor: Colors
                                      .black54,
                                  // Background color
                                  shape: RoundedRectangleBorder(
                                      side: const BorderSide(
                                          color: Colors
                                              .transparent,
                                          width: 1,
                                          style: BorderStyle
                                              .solid),
                                      borderRadius: BorderRadius
                                          .circular(50))))),
                      child: child!,
                    );
                  });


              final DateFormat formatter = DateFormat('MM/dd/yyyy');
              final String formatted = formatter.format(date!);
              data["dob"].text = formatted;
            },
            child: AbsorbPointer(
              child: EditTextWidget(
                maxLength: 200,
                hint: "Enter DOB ",
                isPassword: false,
                keyboardtype: TextInputType.text,
                label: "DOB ",
                validator: (value) {

                  return null;
                },
                controller: data["dob"],
                maxline: 1,
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.only(top: 5),
          child: GestureDetector(
            onTap: ()async{
              var date =await showDatePicker(
                  context: context,
                  initialDate:DateTime.now(),
                  firstDate: DateTime(1900),
                  lastDate: DateTime(2100),
                  builder: (context, child) {
                    return Theme(
                      data: ThemeData.dark().copyWith(
                          colorScheme: const ColorScheme.dark(
                              onPrimary: Colors.white,
                              // selected text color
                              onSurface: Colors.white,
                              // default text color
                              primary: Colors
                                  .teal // circle color
                          ),
                          dialogBackgroundColor: Theme
                              .of(context)
                              .backgroundColor,
                          textButtonTheme: TextButtonThemeData(
                              style: TextButton.styleFrom(
                                  textStyle: const TextStyle(
                                      color: Colors.white,
                                      fontWeight: FontWeight
                                          .normal,
                                      fontSize: 12,
                                      fontFamily: 'Quicksand'),
                                  primary: Colors.white,
                                  // color of button's letters
                                  backgroundColor: Colors
                                      .black54,
                                  // Background color
                                  shape: RoundedRectangleBorder(
                                      side: const BorderSide(
                                          color: Colors
                                              .transparent,
                                          width: 1,
                                          style: BorderStyle
                                              .solid),
                                      borderRadius: BorderRadius
                                          .circular(50))))),
                      child: child!,
                    );
                  });

              final DateFormat formatter = DateFormat('MM/dd/yyyy');
              final String formatted = formatter.format(date!);
              data["anniversaryDate"].text = formatted;
            },
            child: AbsorbPointer(
              child: EditTextWidget(
                maxLength: 200,
                hint: "Enter Anniversary Date ",
                isPassword: false,
                keyboardtype: TextInputType.text,
                label: "Enter Anniversary Date ",
                validator: (value) {

                  return null;
                },
                controller: data["anniversaryDate"],
                maxline: 1,
              ),
            ),
          ),
        ),

      ],
    );

  }



  showOptionDailog(BuildContext context,TechnicalChildDatum datum) {
    return showDialog(context: context, builder: (context) =>
        SimpleDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(4.0))),
          backgroundColor: Theme
              .of(context)
              .dialogBackgroundColor
              .withOpacity(0.9),
          children: [
            SimpleDialogOption(
              onPressed: () => fieldController.pickImage(ImageSource.gallery,datum),
              child: Row(
                children: [
                  Icon(Icons.image),
                  Text("   Gallery", style: Theme
                      .of(context)
                      .textTheme
                      .bodyText1,)
                ],
              ),
            ),
            SimpleDialogOption(
              onPressed: () => fieldController.pickImage(ImageSource.camera,datum),
              child: Row(
                children: [
                  Icon(Icons.camera),
                  Text("   Camera", style: Theme
                      .of(context)
                      .textTheme
                      .bodyText1,)
                ],
              ),
            ),
            SimpleDialogOption(
              onPressed: () => Get.back(),
              child: Row(
                children: [
                  Icon(Icons.clear),
                  Text("  Cancel", style: Theme
                      .of(context)
                      .textTheme
                      .bodyText1,)
                ],
              ),
            ),
          ],
        ));
  }
  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);
    final format = DateFormat.jm(); // YOUR DATE GOES HERE
    return format.format(dt);
  }
  Widget AllFieldWidget(TechnicalChildDatum fieldDatum,int index,List<TechnicalChildDatum> model){
  return fieldDatum.fieldType == "DROP DOWN" ?
  Padding(
    padding: EdgeInsets.only(top: 5,bottom: 8 ),
    child:
    DropdownButtonWidget(
      change: (value) {
        fieldDatum.selectedDropDownValue=value;
        fieldDatum.dropDownValue=fieldDatum.selectedDropDownValue["name"];
        if(fieldDatum.fieldName=="stateTypes")
        {
          fieldController.getSubDropDown(fieldDatum.dropDownValue!,context);
        }
        if(fieldDatum.fieldName=="memberType")
        {
          fieldController.getSubDropDown(fieldDatum.dropDownValue!,context);

        }
        if(fieldDatum.fieldName=="itemCategory")
        {
          fieldController.getSubDropDown(fieldDatum.dropDownValue!,context);
        }
        if(fieldDatum.fieldName=="memberTypes")
        {
          if(fieldDatum.dropDownValue=="DEVOTEE")
            {
               print("vdsbksbvkudsvv");
              fieldController.isMemberDetails.value=true;
            }
          else
            {
              fieldController.isMemberDetails.value=false;
            }
        }

        if(fieldDatum.fieldName=="serviceCategoryTypes")
        {
          fieldController.getSubDropDown(fieldDatum.dropDownValue!,context);
          fieldController.ServiceCategory=fieldDatum.dropDownValue!;
        }
        if(fieldDatum.fieldName=="menuCategory")
        {
          fieldController.getSubDropDown(fieldDatum.dropDownValue!,context);
        }
        if(fieldDatum.fieldName=="assetCategory")
        {
          fieldController.getSubDropDown(fieldDatum.dropDownValue!,context);
        }
        if(fieldDatum.fieldName=="serviceTypes")
        {
          fieldController.getServiceNameDown(fieldDatum.dropDownValue!,context);
        }
        if(fieldDatum.fieldName=="priestName")
        {
          final cuEmailIndex =model.indexWhere((element) => element.fieldName == "priestEmail");
          final cuPhoneIndex = model.indexWhere((element) => element.fieldName == "priestPhone");
          if(cuEmailIndex>-1)
          {
          model[cuEmailIndex].textEditingController!.text=UtilMethods.decrypt(fieldDatum.selectedDropDownValue["email"])??"";
          }
          if(cuPhoneIndex>-1){
          model[cuPhoneIndex].textEditingController!.text=UtilMethods.decrypt(fieldDatum.selectedDropDownValue["phone"])??"";
          }
        }
        if(fieldDatum.fieldName=="customerName")
        {
          final cuEmailIndex =model.indexWhere((element) => element.fieldName == "customerEmail");
          final cuPhoneIndex = model.indexWhere((element) => element.fieldName == "customerPhone");
          final cuStateIndex = model.indexWhere((element) => element.fieldName == "customerState");
          final cuCityIndex = model.indexWhere((element) => element.fieldName == "customerCity");
          final cuZipIndex = model.indexWhere((element) =>   element.fieldName == "customerZip");
          final cuAddressIndex = model.indexWhere((element) =>element.fieldName == "customerAddress");
          if(cuEmailIndex>-1)
          {
            model[cuEmailIndex].textEditingController!.text= UtilMethods.decrypt(model[index].selectedDropDownValue["email"]);
          }
          if(cuPhoneIndex>-1){
            model[cuPhoneIndex].textEditingController!.text=UtilMethods.decrypt(model[index].selectedDropDownValue["phone"]);
          }
          if(cuStateIndex>-1){
            model[cuStateIndex].textEditingController!.text=model[index].selectedDropDownValue["state"];
          }
          if(cuCityIndex>-1){
            model[cuCityIndex].textEditingController!.text=model[index].selectedDropDownValue["city"];
          }
          if(cuZipIndex>-1){
            model[cuZipIndex].textEditingController!.text=model[index].selectedDropDownValue["zip"];
          }
          if(cuAddressIndex>-1){
            model[cuAddressIndex].textEditingController!.text=model[index].selectedDropDownValue["address"];
          }
        }
        if(fieldDatum.fieldName=="dayTypes")
        {
          fieldController.day=fieldDatum.dropDownValue!;
          // final cuEmailIndex =model.indexWhere((element) => element.fieldName == "eventDate");
          // model[cuEmailIndex].textEditingController!.clear();
        }

        if(fieldDatum.fieldName=="ServiceSetup")
        {

          fieldController.day=fieldDatum.selectedDropDownValue["day"]??"";
          final dateInd =model.indexWhere((element) => element.fieldName == "serviceDate");
          final startTimeInd =model.indexWhere((element) => element.fieldName == "startTime");
          final endTimeInd=model.indexWhere((element) => element.fieldName == "endTime");
          final amount=model.indexWhere((element) => element.fieldName == "serviceAmount");
          if(dateInd>-1 )
            {
              model[dateInd].textEditingController!.text=model[index].selectedDropDownValue["startDate"];
            }
          if(startTimeInd>-1)
            {
              model[startTimeInd].textEditingController!.text=model[index].selectedDropDownValue["startTime"];
            }
          if(endTimeInd>-1)
            {
              model[endTimeInd].textEditingController!.text=model[index].selectedDropDownValue["endTime"];
            }
          if(amount>-1)
            {
              model[amount].textEditingController!.text=model[index].selectedDropDownValue["amount"];
            }

        }
      fieldController.update();


      },
      title: "Select ${fieldDatum.fieldLabel!}",
      list:fieldDatum.dropDownList!,
      hint: "Select ${fieldDatum.fieldName!}",
      selectvalue:fieldDatum.selectedDropDownValue,
      onPress: '',
    ),
  ) : fieldDatum.fieldType == "DATE" ? widget.title!="Calendar"? fieldController.day.contains("EVERY")?
  Container():Padding(
    padding: EdgeInsets.only(top: 5),
    child: GestureDetector(
      onTap: () async {
        var day=UtilMethods.getDayInt(fieldController.day);

        var now = new DateTime.now();
        final DateTime? date;
        if(
        day==9
        ){
          date = await showDatePicker(
              context: context,
              initialDate:DateTime.now(),
              firstDate: DateTime(1900),
              lastDate: DateTime(2100),
              builder: (context, child) {
                return Theme(
                  data: ThemeData.dark().copyWith(
                      colorScheme: const ColorScheme.dark(
                          onPrimary: Colors.white,
                          // selected text color
                          onSurface: Colors.white,
                          // default text color
                          primary: Colors
                              .teal // circle color
                      ),
                      dialogBackgroundColor: Theme
                          .of(context)
                          .backgroundColor,
                      textButtonTheme: TextButtonThemeData(
                          style: TextButton.styleFrom(
                              textStyle: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight
                                      .normal,
                                  fontSize: 12,
                                  fontFamily: 'Quicksand'),
                              primary: Colors.white,
                              // color of button's letters
                              backgroundColor: Colors
                                  .black54,
                              // Background color
                              shape: RoundedRectangleBorder(
                                  side: const BorderSide(
                                      color: Colors
                                          .transparent,
                                      width: 1,
                                      style: BorderStyle
                                          .solid),
                                  borderRadius: BorderRadius
                                      .circular(50))))),
                  child: child!,
                );
              }
          );
        }else{
          while(now.weekday!=day)
          {
            now=now.add(new Duration(days: 1));
          }
          date = await showDatePicker(
              context: context,
              initialDate:now,
              firstDate: DateTime(1900),
              lastDate: DateTime(2100),
              selectableDayPredicate: (DateTime val) => val.weekday == day ? true : false,
              builder: (context, child) {
                return Theme(
                  data: ThemeData.dark().copyWith(
                      colorScheme: const ColorScheme.dark(
                          onPrimary: Colors.white,
                          // selected text color
                          onSurface: Colors.white,
                          // default text color
                          primary: Colors
                              .teal // circle color
                      ),
                      dialogBackgroundColor: Theme
                          .of(context)
                          .backgroundColor,
                      textButtonTheme: TextButtonThemeData(
                          style: TextButton.styleFrom(
                              textStyle: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight
                                      .normal,
                                  fontSize: 12,
                                  fontFamily: 'Quicksand'),
                              primary: Colors.white,
                              // color of button's letters
                              backgroundColor: Colors
                                  .black54,
                              // Background color
                              shape: RoundedRectangleBorder(
                                  side: const BorderSide(
                                      color: Colors
                                          .transparent,
                                      width: 1,
                                      style: BorderStyle
                                          .solid),
                                  borderRadius: BorderRadius
                                      .circular(50))))),
                  child: child!,
                );
              }
          );
        }
        final DateFormat formatter = DateFormat(
            'MM/dd/yyyy');
        final String formatted = formatter.format(date!);
        fieldDatum.textEditingController!.text =
            formatted;
      },
      child: AbsorbPointer(
        child: EditTextWidget(
          maxLength: int.parse(fieldDatum.maxLength!),
          hint: "Enter " + fieldDatum.fieldLabel!,
          isPassword: false,
          keyboardtype: TextInputType.datetime,
          validator: (value) {

            if (fieldDatum.mandatory == "YES") {
              if (value == null || value.isEmpty) {
                fieldController.checkGroupExpand(fieldDatum.group!);

                return 'Please Enter ' +
                    fieldDatum.fieldName!;
              }
            }
            return null;
          },
          controller: fieldDatum.textEditingController,
          maxline: 1,
          label: fieldDatum.fieldLabel!,
        ),
      ),
    ),
  ):Padding(
    padding: EdgeInsets.only(top: 5),
    child: GestureDetector(
      onTap: () async {
        var day=UtilMethods.getDayInt(fieldController.day);
        var now = new DateTime.now();
        final DateTime? date;
        if(
        day==9
        ){
          date = await showDatePicker(
              context: context,
              initialDate:DateTime.now(),
              firstDate: DateTime(1900),
              lastDate: DateTime(2100),
              builder: (context, child) {
                return Theme(
                  data: ThemeData.dark().copyWith(
                      colorScheme: const ColorScheme.dark(
                          onPrimary: Colors.white,
                          // selected text color
                          onSurface: Colors.white,
                          // default text color
                          primary: Colors
                              .teal // circle color
                      ),
                      dialogBackgroundColor: Theme
                          .of(context)
                          .backgroundColor,
                      textButtonTheme: TextButtonThemeData(
                          style: TextButton.styleFrom(
                              textStyle: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight
                                      .normal,
                                  fontSize: 12,
                                  fontFamily: 'Quicksand'),
                              primary: Colors.white,
                              // color of button's letters
                              backgroundColor: Colors
                                  .black54,
                              // Background color
                              shape: RoundedRectangleBorder(
                                  side: const BorderSide(
                                      color: Colors
                                          .transparent,
                                      width: 1,
                                      style: BorderStyle
                                          .solid),
                                  borderRadius: BorderRadius
                                      .circular(50))))),
                  child: child!,
                );
              }
          );
        }else{
          while(now.weekday!=day)
          {
            now=now.add(new Duration(days: 1));
          }
          date = await showDatePicker(
              context: context,
              initialDate:now,
              firstDate: DateTime(1900),
              lastDate: DateTime(2100),
              selectableDayPredicate: (DateTime val) => val.weekday == day ? true : false,
              builder: (context, child) {
                return Theme(
                  data: ThemeData.dark().copyWith(
                      colorScheme: const ColorScheme.dark(
                          onPrimary: Colors.white,
                          // selected text color
                          onSurface: Colors.white,
                          // default text color
                          primary: Colors
                              .teal // circle color
                      ),
                      dialogBackgroundColor: Theme
                          .of(context)
                          .backgroundColor,
                      textButtonTheme: TextButtonThemeData(
                          style: TextButton.styleFrom(
                              textStyle: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight
                                      .normal,
                                  fontSize: 12,
                                  fontFamily: 'Quicksand'),
                              primary: Colors.white,
                              // color of button's letters
                              backgroundColor: Colors
                                  .black54,
                              // Background color
                              shape: RoundedRectangleBorder(
                                  side: const BorderSide(
                                      color: Colors
                                          .transparent,
                                      width: 1,
                                      style: BorderStyle
                                          .solid),
                                  borderRadius: BorderRadius
                                      .circular(50))))),
                  child: child!,
                );
              }
          );
        }
        final DateFormat formatter = DateFormat(
            'MM/dd/yyyy');
        final String formatted = formatter.format(date!);
        fieldDatum.textEditingController!.text =
            formatted;
      },
      child: AbsorbPointer(
        child: EditTextWidget(
          maxLength: int.parse(fieldDatum.maxLength!),
          hint: "Enter " + fieldDatum.fieldLabel!,
          isPassword: false,
          keyboardtype: TextInputType.datetime,
          validator: (value) {
            if (fieldDatum.mandatory == "YES") {
              if (value == null || value.isEmpty) {
                fieldController.checkGroupExpand(fieldDatum.group!);
                return 'Please Enter ' + fieldDatum.fieldName!;
              }
            }
            return null;
          },
          controller: fieldDatum.textEditingController,
          maxline: 1,
          label: fieldDatum.fieldLabel!,
        ),
      ),
    ),
  ) :
  fieldDatum.fieldType == "TIME" ?
  Padding(
    padding: EdgeInsets.only(top: 5),
    child: GestureDetector(
      onTap: () async {
        final timeindex =model.indexWhere((element) => element.fieldName == "endTime");
        model[timeindex].textEditingController!.clear();
        TimeOfDay? time = await showTimePicker(
            context: context,
            initialTime: fieldController.startTime,
            builder: (context, child) {
              return Theme(
                data: ThemeData.dark().copyWith(
                    colorScheme: const ColorScheme.dark(
                        onPrimary: Colors.white,
                        onSurface: Colors.white,
                        primary: Colors.teal // circle color
                    ),
                    dialogBackgroundColor: Theme
                        .of(context)
                        .backgroundColor,

                    textButtonTheme: TextButtonThemeData(
                        style: TextButton.styleFrom(
                            textStyle: const TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight
                                    .normal,
                                fontSize: 12,
                                fontFamily: 'Quicksand'),
                            primary: Colors.white,
// color of button's letters
                            backgroundColor: Colors
                                .black54,
// Background color
                            shape: RoundedRectangleBorder(
                                side: const BorderSide(
                                    color: Colors
                                        .transparent,
                                    width: 1,
                                    style: BorderStyle
                                        .solid),
                                borderRadius: BorderRadius
                                    .circular(50))))),
                child: child!,
              );
            }

        );

        fieldDatum.fieldName=="startTime" ? fieldController.startTime=time! :"";
        final now = new DateTime.now();
        final start = DateTime(now.year, now.month, now.day, fieldController.startTime.hour, fieldController.startTime.minute);
        final end = DateTime(now.year, now.month, now.day, time!.hour, time.minute);
        bool isValidDate = start.isBefore(end);
        if(fieldDatum.fieldName=="endTime")
        {
          if(isValidDate)
          {
            fieldDatum.textEditingController!.text = formatTimeOfDay(time);
          }
          else{
            Fluttertoast.showToast(msg: "Please Select Future Time");
          }
        }
        else{
          fieldDatum.textEditingController!.text = formatTimeOfDay(time);
        }
      },
      child: AbsorbPointer(
        child: EditTextWidget(
          maxLength: int.parse(fieldDatum.maxLength!),
          hint: "Enter " + fieldDatum.fieldLabel!,
          isPassword: false,
          keyboardtype: TextInputType.datetime,
          validator: (value) {
            if (fieldDatum.mandatory == "YES") {
              if (value == null || value.isEmpty) {
                fieldController.checkGroupExpand(fieldDatum.group!);

                return 'Please Enter ' +
                    fieldDatum.fieldName!;
              }
            }
            return null;
          },
          controller: fieldDatum.textEditingController,
          maxline: 1,
          label: fieldDatum.fieldLabel!,
        ),
      ),
    ),
  ) :
  fieldDatum.fieldType == "FILE" ?
  Padding(
    padding: EdgeInsets.only(top: 5, bottom: 5),
    child: Container(
      height: 50,
      decoration: BoxDecoration(
          border: Border.all(
              color: Colors.grey, width: 1),
          borderRadius: BorderRadius.circular(5)
      ),
      child: Row(
        children: [
          fieldController.fileextension.value == ""
              ? Expanded(
              flex: 2,
              child: Icon(Icons.attach_file))
              :
          Expanded(
              flex: 2,
              child: Container(
                margin: EdgeInsets.only(left: 3,
                    right: 15,
                    top: 3,
                    bottom: 3),
                decoration: BoxDecoration(
                    color: Colors.amber.withOpacity(0.7),
                    borderRadius: BorderRadius.circular(4)
                ),
                alignment: Alignment.center,
                height: 55,
                child: Text(
                  fieldController.fileextension.value
                      .toString(), style: TextStyle(
                    color: Colors.white.withOpacity(0.85),
                    fontWeight: FontWeight.bold,
                    fontSize: 20),),
              )),
          Expanded(
              flex: 4,
              child: Text(fieldController.filename.value
                  .toString())),
          Expanded(
            flex: 2,
            child: TextButton(child: Text("Select"),
                onPressed: () async {
                  fieldController.selectFile(fieldDatum);
                }),)
        ],
      ),
    ),
  ) :
  fieldDatum.fieldType == "IMAGE" ?
  Padding(
    padding: const EdgeInsets.all(8.0),
    child: Stack(
      children: [
        Center(
            child:
            CircleAvatar(
                radius: 50,
                backgroundColor: Colors.grey.withOpacity(0.2),
                backgroundImage: NetworkImage(APIsConstant.IP_Base_Url + fieldDatum.textEditingController!.text)
            )

        ),

        Center(
          child: Container(
            margin: EdgeInsets.only(top: 97),
            height: 30,
            width: 45,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: Colors.white.withOpacity(0.4),
            ),
            child: IconButton(icon: Icon(
              Icons.add_a_photo_outlined,
              color: Colors.white, size: 15,),
              onPressed: () async {
                showOptionDailog(context,fieldDatum);
              },),
          ),
        ),
      ],
    ),
  ) :
  fieldDatum.fieldType == "TEXTAREA" ?
  Padding(padding: const EdgeInsets.only(top: 5), child:
  EditTextWidget(
    maxLength: int.parse(fieldDatum.maxLength!),
    hint: "Enter " + fieldDatum.fieldLabel!,
    isPassword: false,
    keyboardtype: fieldDatum.fieldType == "EMAIL"
        ? TextInputType.emailAddress
        : fieldDatum.fieldType == "PHONE"
        ? TextInputType.phone
        :
    fieldDatum.fieldType == "NUMBER" ? TextInputType
        .number : TextInputType.text,
    label: fieldDatum.fieldLabel!,
    validator: (value) {
      if (fieldDatum.mandatory == "YES") {
        if (value == null || value.isEmpty) {
          fieldController.checkGroupExpand(fieldDatum.group!);

          return 'Please Enter ' +
              fieldDatum.fieldName!;
        }
      }
      return null;
    },
    controller: fieldDatum.textEditingController,
    maxline: 4,
  ),
  ) :  fieldDatum.fieldType == "CHECKBOX" ?
  Padding(padding: const EdgeInsets.only(top: 5,bottom: 6), child:
      Container(
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(5),
            border: Border.all(
                width: 0.8, color: Colors.grey.withOpacity(0.6))
        ),
        child: InkWell(
          onTap: (){
            fieldDatum.checkBoxValue=!fieldDatum.checkBoxValue!;
            fieldController.update();
          },
          child: Row(
            children: [
             SizedBox(width: 10,),
              Expanded(
                  flex: 8,
                  child:  Text(fieldDatum.fieldLabel!,style: Theme.of(context).textTheme.bodyText1,),),
              Expanded(
                  flex: 2,
                  child: Checkbox(
                    value: fieldDatum.checkBoxValue??false,
                      onChanged: (value){
                        fieldDatum.checkBoxValue=value;
                        fieldController.update();
                      },
                  ))
            ],
          ),
        )
      )

  ): Padding(
    padding: const EdgeInsets.only(top: 5),
    child: EditTextWidget(
      maxLength: lengthParser(fieldDatum.maxLength.toString()),
      hint: "Enter " + fieldDatum.fieldLabel!,
      isPassword: false,
      keyboardtype:
      fieldDatum.fieldType == "EMAIL" ? TextInputType.emailAddress :
      fieldDatum.fieldType == "PHONE" ? TextInputType.phone :
      fieldDatum.fieldType == "NUMBER" ? TextInputType.number : TextInputType.text,
      label: fieldDatum.fieldLabel!,
      formatter:[],
      // fieldDatum.fieldType == "TEXT"? [FilteringTextInputFormatter.allow(RegExp('[a-zA-Z]')),]:
      // fieldDatum.fieldType == "EMAIL"?[FilteringTextInputFormatter.allow(RegExp('[a-z@.]')),]:
      // [FilteringTextInputFormatter.allow(RegExp('[0-9]')),],
      validator: (value) {
        if (fieldDatum.mandatory == "YES") {
          if (value == null || value.isEmpty) {
            fieldController.checkGroupExpand(fieldDatum.group!);
            return 'Please Enter ' + fieldDatum.fieldName!;
          }
        }
        return null;
      },
      controller: fieldDatum.textEditingController,
      maxline: 1,
    ),
  );
}



}

