// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

CityData cityDataFromJson(String str) => CityData.fromJson(json.decode(str));

String cityDataToJson(CityData data) => json.encode(data.toJson());

class CityData {
  CityData({
    this.data,
    this.success,
  });
  List<Datum>?data;
  bool ?success;
  factory CityData.fromJson(Map<String, dynamic> json) => CityData(
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    success: json["success"],
  );
  Map<String, dynamic> toJson() => {
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
    "success": success,
  };
}
class Datum {
  Datum({
    this.city,
    this.cityName,
  });
  String?city;
  String?cityName;
  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    city: json["city"],
    cityName: json["cityName"],
  );
  Map<String, dynamic> toJson() => {
    "city": city,
    "cityName": cityName,
  };
}
