// To parse this JSON data, do
//
//     final customerDetailsData = customerDetailsDataFromJson(jsonString);

import 'dart:convert';

CustomerDetailsData customerDetailsDataFromJson(String str) => CustomerDetailsData.fromJson(json.decode(str));

String customerDetailsDataToJson(CustomerDetailsData data) => json.encode(data.toJson());

class CustomerDetailsData {
    CustomerDetailsData({
        this.data,
    });

    List<Datum> ?data;

    factory CustomerDetailsData.fromJson(Map<String, dynamic> json) => CustomerDetailsData(
        data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
    );

    Map<String, dynamic> toJson() => {
        "data": List<dynamic>.from(data!.map((x) => x.toJson())),
    };
}

class Datum {
    Datum({
        this.customerName,
        this.phone,
        this.email,
        this.flutterPhone,
        this.flutterEmail,
        this.address,
        this.state,
        this.city,
        this.zip,
    });

    String ?customerName;
    String ?phone;
    String ?email;
    String ?flutterPhone;
    String ?flutterEmail;
    String ?address;
    String ?state;
    String ?city;
    String ?zip;

    factory Datum.fromJson(Map<String, dynamic> json) => Datum(
        customerName: json["customerName"],
        phone: json["phone"],
        email: json["email"],
        flutterPhone: json["flutterPhone"],
        flutterEmail: json["flutterEmail"],
        address: json["address"],
        state: json["state"],
        city: json["city"],
        zip: json["zip"],
    );

    Map<String, dynamic> toJson() => {
        "customerName": customerName,
        "phone": phone,
        "email": email,
        "flutterPhone": flutterPhone,
        "flutterEmail": flutterEmail,
        "address": address,
        "state": state,
        "city": city,
        "zip": zip,
    };
}
