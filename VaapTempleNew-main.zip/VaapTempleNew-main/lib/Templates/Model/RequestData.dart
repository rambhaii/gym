// To parse this JSON data, do
//
//     final requestData = requestDataFromJson(jsonString);

import 'dart:convert';

RequestData requestDataFromJson(String str) => RequestData.fromJson(json.decode(str));

String requestDataToJson(RequestData data) => json.encode(data.toJson());

class RequestData {
  RequestData({
    this.componentConfig,
  });

  ComponentConfig ?componentConfig;

  factory RequestData.fromJson(Map<String, dynamic> json) => RequestData(
    componentConfig: ComponentConfig.fromJson(json["componentConfig"]),
  );

  Map<String, dynamic> toJson() => {
    "componentConfig": componentConfig!.toJson(),
  };
}

class ComponentConfig {
  ComponentConfig({
    this.moduleName,
    this.aspectType,
    this.productId,
    this.clientId,
    this.query,
    this.userName,
    this.skip,
    this.next,
  });

  String ?moduleName;
  String ?aspectType;
  String ?productId;
  String ?clientId;
  Query ?query;
  String? userName;
  int ?skip;
  int ?next;

  factory ComponentConfig.fromJson(Map<String, dynamic> json) => ComponentConfig(
    moduleName: json["moduleName"]??"",
    aspectType: json["aspectType"]??"",
    productId: json["productID"]??"",
    clientId: json["clientID"]??"",
    query: Query.fromJson(json["query"]??[]),
    userName: json["userName"]??"",
    skip: json["skip"]??"",
    next: json["next"]??"",
  );

  Map<String, dynamic> toJson() => {
    "moduleName": moduleName,
    "aspectType": aspectType,
    "productID": productId,
    "clientID": clientId,
    "query": query!.toJson(),
    "userName": userName,
    "skip": skip,
    "next": next,
  };
}

class Query {
  Query({
    this.aspectType,
  });

  String? aspectType;

  factory Query.fromJson(Map<String, dynamic> json) => Query(
    aspectType: json["aspectType"],
  );

  Map<String, dynamic> toJson() => {
    "aspectType": aspectType,
  };
}
