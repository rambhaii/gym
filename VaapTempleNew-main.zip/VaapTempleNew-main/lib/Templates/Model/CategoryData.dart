// To parse this JSON data, do
//
//     final categoryData = categoryDataFromJson(jsonString);

import 'dart:convert';

CategoryData categoryDataFromJson(String str) => CategoryData.fromJson(json.decode(str));

String categoryDataToJson(CategoryData data) => json.encode(data.toJson());

class CategoryData {
  CategoryData({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  List<CategoryDatum>? data;

  factory CategoryData.fromJson(Map<String, dynamic> json) => CategoryData(
    statusCode: json["statusCode"],
    message: json["message"],
    data: List<CategoryDatum>.from(json["data"].map((x) => CategoryDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class CategoryDatum {
  CategoryDatum({
    this.id,
    this.refDataName,
    this.moduleName,
    this.clientId,
    this.productId,
    this.aspectType,
    this.recCreBy,
    this.recCreDate,
    this.recModBy,
    this.recModDate,
    this.nextTierLevel,
    this.estimatorCategory,
    this.estimatorTypes,
    this.code,
    this.unitTypes,
    this.estimatorCategorydeatais,
    this.isExpand,
  });

  String ?id;
  String ?refDataName;
  String ?moduleName;
  String ?clientId;
  String ?productId;
  String ?aspectType;
  String ?recCreBy;
  String ?recCreDate;
  String ?recModBy;
  String ?recModDate;
  String ?nextTierLevel;
  String ?code;
  String ?unitTypes;
  String ?estimatorCategory;
  String ?estimatorTypes;
  List ?estimatorCategorydeatais;
  bool ?isExpand;

  factory CategoryDatum.fromJson(Map<String, dynamic> json) => CategoryDatum(
    id: json["_id"]??"",
    refDataName: json["refDataName"]??"",
    moduleName: json["moduleName"]??"",
    clientId: json["clientID"]??"",
    productId: json["productID"]??"",
    aspectType: json["aspectType"]??"",
    recCreBy: json["recCreBy"]??"",
    recCreDate: json["recCreDate"]??"",
    recModBy: json["recModBy"]??"",
    recModDate: json["recModDate"]??"",
    nextTierLevel: json["nextTierLevel"]??"",
    estimatorCategory: json["estimatorCategory"]??"",
    estimatorTypes: json["estimatorTypes"]??"",
    code: json["code"]??"",
    unitTypes: json["unitType"]??"",
    estimatorCategorydeatais: [],
    isExpand: false,

  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "refDataName": refDataName,
    "moduleName": moduleName,
    "clientID": clientId,
    "productID": productId,
    "aspectType": aspectType,
    "recCreBy": recCreBy,
    "recCreDate": recCreDate,
    "recModBy": recModBy,
    "recModDate": recModDate,
    "nextTierLevel": nextTierLevel,
    "estimatorCategory": estimatorCategory,
    "estimatorTypes": estimatorTypes,
    "code": code,
    "unitTypes": unitTypes,
    "estimatorCategorydeatais": isExpand,
  };
}
