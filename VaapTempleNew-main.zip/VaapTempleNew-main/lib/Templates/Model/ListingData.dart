// To parse this JSON data, do
//
//     final contactListingData = contactListingDataFromJson(jsonString);

import 'dart:convert';

ListingData listingDataFromJson(String str) => ListingData.fromJson(json.decode(str));

String listingDataToJson(ListingData data) => json.encode(data.toJson());

class ListingData {
  ListingData({
    this.success,
    this.moduleName,
    this.data,
  });

  bool?success;
  String? moduleName;
  List<Datum> ?data;

  factory ListingData.fromJson(Map<String, dynamic> json) => ListingData(
    success: json["success"],
    moduleName: json["moduleName"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "success": success,
    "moduleName": moduleName,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.fieldName,
    this.fieldLabel,
  });

  String?fieldName;
  String ?fieldLabel;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    fieldName: json["fieldName"],
    fieldLabel: json["fieldLabel"],
  );

  Map<String, dynamic> toJson() => {
    "fieldName": fieldName,
    "fieldLabel": fieldLabel,
  };
}
