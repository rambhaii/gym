import 'dart:convert';
import 'dart:io';

import 'package:aspgen_mobile/Dashboard/Model/field.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:aspgen_mobile/Templates/custom_expension_title.dart';
import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../Dashboard/Contact/Model/AllContactDatas.dart';
import '../../Dashboard/Services/Model/ServiceData.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/Utils.dart';
import '../../UtilMethods/base_client.dart';

class FieldController extends GetxController{
  Rx<FieldModel> fieldData= FieldModel().obs;//All Fields Model
  final String title;//Module Name
  final String?id;//Module Name
  final int type;//  1 for add And 2 for update
  FieldController(this.title,this.type, this.id);
  var bodyJson={};
  bool isValidate=true;
  var bodyJsonRequest={};
  Map? datum;//Map for set contact Data
  var requestDroupdownbody={};
   String ServiceCategory="";
   final GlobalKey<ExpansionTileCardCustomState> Group1 = new GlobalKey();
  final GlobalKey<ExpansionTileCardCustomState> Group2 = new GlobalKey();
  final GlobalKey<ExpansionTileCardCustomState> Group3 = new GlobalKey();
  final GlobalKey<ExpansionTileCardCustomState> Group4 = new GlobalKey();
  final GlobalKey<ExpansionTileCardCustomState> Group5 = new GlobalKey();
  bool isExpanded1=false;
  bool isExpanded2=false;
  bool isExpanded3=false;
  bool isExpanded4=false;
  bool isExpanded5=false;
  RxBool isMemberDetails=false.obs;
  final formGlobalKey = GlobalKey<FormState>();
  // final formGlobalKey = GlobalKey<FormState>();
  Rx<AllContactDatas> allContactDatas= AllContactDatas().obs;
  RxList<TechnicalChildDatum> Group_1_List=RxList<TechnicalChildDatum>([]);
  RxList<TechnicalChildDatum> Group_2_List=RxList<TechnicalChildDatum>([]);
  RxList<TechnicalChildDatum> Group_3_List=RxList<TechnicalChildDatum>([]);
  RxList<TechnicalChildDatum> Group_4_List=RxList<TechnicalChildDatum>([]);
  RxList<Map> rxRelationList= [{"name":"FATHER"}, {"name":"MOTHER"}, {"name":"SPOUSE"}, {"name":"SON"},{"name":"DAUGHTER"}].obs;
  RxList<Map> Group_5List=RxList<Map>([
    { "memberName": TextEditingController(),
      "nakshatra": TextEditingController(),
      "rashi": TextEditingController(),
      "relationship": TextEditingController(),
      "dob": TextEditingController(),
      "anniversaryDate": TextEditingController(),
      "selectedValue":null,

    },
    { "memberName": TextEditingController(),
      "nakshatra": TextEditingController(),
      "rashi": TextEditingController(),
      "relationship": TextEditingController(),
      "dob": TextEditingController(),
      "anniversaryDate": TextEditingController(),
      "selectedValue":null,

    },
    { "memberName": TextEditingController(),
      "nakshatra": TextEditingController(),
      "rashi": TextEditingController(),
      "relationship": TextEditingController(),
      "dob": TextEditingController(),
      "anniversaryDate": TextEditingController(),
      "selectedValue":null,

    },
    {
      "memberName": TextEditingController(),
      "nakshatra": TextEditingController(),
      "rashi": TextEditingController(),
      "relationship": TextEditingController(),
      "dob": TextEditingController(),
      "anniversaryDate": TextEditingController(),
      "selectedValue":null,

    },
    { "memberName": TextEditingController(),
      "nakshatra": TextEditingController(),
      "rashi": TextEditingController(),
      "relationship": TextEditingController(),
      "dob": TextEditingController(),
      "anniversaryDate": TextEditingController(),
      "selectedValue":null,
    },
    {
      "memberName": TextEditingController(),
      "nakshatra": TextEditingController(),
      "rashi": TextEditingController(),
      "relationship": TextEditingController(),
      "dob": TextEditingController(),
      "anniversaryDate": TextEditingController(),
      "selectedValue":null
    },
  ]);
  Rx<File>? pickfile;
  var isReady=false.obs;
  var image="".obs;
  Rx<File>? pickfilepicker;

  var fileextension="".obs;
  var filename="Attach File".obs;
  String day="";
  TimeOfDay startTime=TimeOfDay.now();
  var formValue = {};
  @override
  void onInit() {
    bodyJsonRequest["componentConfig"]={
      "moduleName":title,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
    };
    getFields();
    // TODO: implement onInit

    super.onInit();


  }

//Get all Field datas
  getFields()
  {
    try {
      UtilMethods.getDynamicField(Get.context!,title).then((value) {
        fieldData.value=fieldModelFromJson(json.encode(json.decode(value)["result"]));
        for(TechnicalChildDatum data in fieldData.value.data![0].technicalChildData!){
          print("sdbhvhjdsbj");
          if(data.group=="Group 1")
          {
            print("shaccva      "+data.fieldName!);
            Group_1_List.add(data);
          }
          else if(data.group=="Group 2")
            {
              Group_2_List.add(data);
            }
      else if(data.group=="Group 3")
            {
              Group_3_List.add(data);
            }
      else  if(data.group=="Group 4")
            {
              Group_4_List.add(data);
            }
        else{
          Group_4_List.add(data);
        }

        }
        if(title=="priestCalendar" || title=="Calendar")
        {
          getFilterApiCu("PRIEST");
          Future.delayed(Duration.zero).then((value) => getFilterApiCu("DEVOTEE"));
        }
        update();
        getDroupDownValue();

        if(type==2 && title=="Contacts")
          {
            datum=Get.arguments['data']??[];
            setData();
            getSubDropDown(datum!["stateTypes"],Get.context!);
            if(datum!["memberTypes"]=="DEVOTEE")
              {
                print("sdbvjkjdasvblkdsv");
                print(datum!["memberDetail"]!);
                isMemberDetails.value=true;
                datum!["memberDetail"].isEmpty?"" :Group_5List.clear();
                datum!["memberDetail"].forEach((element) {
                  Group_5List.add({
                    "memberName": TextEditingController(text:element["memberName"] ),
                    "nakshatra": TextEditingController(text:element["nakshatra"]),
                    "rashi": TextEditingController(text:element["rashi"]),
                    "anniversaryDate": TextEditingController(text:element["anniversaryDate"]),
                    "dob": TextEditingController(text:element["dob"]),
                    "relationship": TextEditingController(text:element["relationship"])
                  });
                  update();
                });
              }

          }
        if(type==2 && title=="Services")
          {
            datum=Get.arguments['data']??[];
            setData();
            getSubDropDown(datum!["serviceCategoryTypes"],Get.context!);
          }
        if(type==2 && title=="Inventory")
        {
          datum=Get.arguments['data']??[];
          setData();
          getSubDropDown(datum!["itemCategory"],Get.context!);
        }
        if(type==2 && title=="Menu")
        {
          datum=Get.arguments['data']??[];
          setData();
          print("jbvsjkbvksd");
         print(datum);
          getSubDropDown(datum!["menuCategory"],Get.context!);
        }
        if(type==2 && title=="Expanses")
        {
          datum=Get.arguments['data']??[];
          setData();
        }
        if(type==2)
        {
          datum=Get.arguments['data']??[];
          setData();
        }
        if(type==1 && title.toLowerCase().contains("estimator"))
        {
          datum=Get.arguments['data']??[];
          setData();
        }
       isReady.value=true;

      });
    } catch(e) {
           Get.snackbar("Error", "Faild to load data", backgroundGradient: LinearGradient(colors: [
             Colors.red,
             Colors.black26,
           ]),
           borderRadius: 2,
           icon: Icon(Icons.error)

       );
    }

  }


  //Add Edit Data from filed
  addEditData() {
    isValidate=true;
    Group_4_List.forEach((element) {
      setRequestData(element);
    });
    Group_1_List.forEach((element) {
      setRequestData(element);
    });
    Group_2_List.forEach((element) {
      setRequestData(element);
    });
    Group_3_List.forEach((element) {
      setRequestData(element);
    });
    formValue["source"]="MOBILE";
    if (Platform.isAndroid) {
      formValue["deviceType"]="ANDROID";
    } else if (Platform.isIOS) {
      formValue["deviceType"]="IOS";
    }
    if(title=="Contacts" && isMemberDetails.value==true)
      {
        var memberList=[];
        Group_5List.forEach((element) {
          memberList.add({
            "memberName":element["memberName"].text,
            "nakshatra":element["nakshatra"].text,
            "rashi":element["rashi"].text,
            "relationship":element["relationship"].text,
            "dob":element["dob"].text,
            "anniversaryDate":element["anniversaryDate"].text,
          });
        });
        formValue["memberDetail"]=memberList;
      }
    bodyJsonRequest["dataJson"] = formValue;

    if(isValidate==false)
    {
      return;
    }
    if (type == 1) {
      print("sdvhukshvosidhvods");
      print(bodyJsonRequest);

      UtilMethods.addAPI(Get.context!,bodyJsonRequest).then((value) {
        if(jsonDecode(value)["statusCode"].toString().trim()=="1")
        {
          Fluttertoast.showToast(msg: jsonDecode(value)["message"]);
          Get.back();
        }
        else{
          Get.snackbar("Error",jsonDecode(value)["message"].toString().trim(),
              backgroundGradient: LinearGradient(colors: [
                Colors.red,
                Colors.black26,
              ]),
              borderRadius: 2,
              icon: Icon(Icons.error)
          );
        }
      });
    }
    else {
      bodyJsonRequest["_id"] = id;
      UtilMethods.postAPI(Get.context!,bodyJsonRequest).then((value) {
        if(jsonDecode(value)["statusCode"].toString().trim()=="1")
          {
            Fluttertoast.showToast(msg: jsonDecode(value)["message"]);
            Get.back();
          }
        else{
          Get.snackbar("Error",jsonDecode(value)["message"].toString().trim(),
              backgroundGradient: LinearGradient(colors: [
                Colors.red,
                Colors.black26,
              ]),
              borderRadius: 2,
              icon: Icon(Icons.error)
          );
        }
      });
    }
  }


  //Set All Data in form Field
  void setData() {
// print("dsvsdvbds");
// print(datum);
    Group_1_List.forEach((element) {
      if (element.fieldType == "CHECKBOX")
        {
          element.checkBoxValue = datum![element.fieldName!];
          return;
        }
      if (element.fieldType == "DROP DOWN") {
        return ;
      }
      else if(element.fieldType == "FILE"){
        print("cghvhjvhjjvh"+datum![element.fieldName!]);
        filename.value = datum![element.fieldName!];
        element.textEditingController!.text = datum![element.fieldName!]??"";
      }else if(element.fieldName!.toLowerCase().contains("email") || element.fieldName!.toLowerCase().contains("phone")){
        element.textEditingController!.text = UtilMethods.decrypt(datum![element.fieldName!]);
      }
      else{
        element.textEditingController!.text = datum![element.fieldName!].toString()??"";
      }
    });
    Group_2_List.forEach((element) {
      if (element.fieldType == "CHECKBOX")
      {
        element.checkBoxValue = datum![element.fieldName!];
        return;
      }
      if (element.fieldType == "DROP DOWN") {
        return ;
      }
      else if(element.fieldType == "FILE"){
        filename.value = datum![element.fieldName!]??"";
        element.textEditingController!.text = datum![element.fieldName!]??"";
      }else if(element.fieldName!.toLowerCase().contains("email") || element.fieldName!.toLowerCase().contains("phone")){
        element.textEditingController!.text = UtilMethods.decrypt(datum![element.fieldName!]);
      }
      else{
        element.textEditingController!.text = datum![element.fieldName!]??"";
      }
    });
    Group_3_List.forEach((element) {
      if (element.fieldType == "CHECKBOX")
      {
        element.checkBoxValue = datum![element.fieldName!];
        return;
      }
      if (element.fieldType == "DROP DOWN") {
        return ;
      }
      else if(element.fieldType == "FILE"){
        print("cghvhjvhjjvh"+datum![element.fieldName!]);
        filename.value = datum![element.fieldName!]??"";
        element.textEditingController!.text = datum![element.fieldName!]??"";
      }else if(element.fieldName!.toLowerCase().contains("email") || element.fieldName!.toLowerCase().contains("phone")){
        element.textEditingController!.text = UtilMethods.decrypt(datum![element.fieldName!]);
      }
      else{
        element.textEditingController!.text = datum![element.fieldName!]??"";
      }
    });
    Group_4_List.forEach((element) {
      if (element.fieldType == "CHECKBOX")
      {
        element.checkBoxValue = datum![element.fieldName!];
        return;
      }
      if (element.fieldType == "DROP DOWN") {
        return ;
      }
      else if(element.fieldType == "FILE"){
        print("cghvhjvhjjvh"+datum![element.fieldName!]);
        filename.value = datum![element.fieldName!];
        element.textEditingController!.text = datum![element.fieldName!]??"";
      }else if(element.fieldName!.toLowerCase().contains("email") || element.fieldName!.toLowerCase().contains("phone")){
        element.textEditingController!.text =  UtilMethods.decrypt(datum![element.fieldName!]);
      }
      else{
        element.textEditingController!.text = datum![element.fieldName!]??"";
      }
    });
  }

 // Get All Droup Down Data
  getDroupDownValue() {
    Group_1_List.forEach((element) {
      getDroupDownAllValue(element);
    });
    Group_2_List.forEach((element) {
      getDroupDownAllValue(element);
    });
    Group_3_List.forEach((element) {
      getDroupDownAllValue(element);
    });
     Group_4_List.forEach((element) {
       getDroupDownAllValue(element);
     });

  }

getDroupDownAllValue(TechnicalChildDatum element){
    if(element.fieldType=="DROP DOWN" && element.fieldName=="cityTypes" || element.fieldName=="serviceTypes")
    {
      return;
    }
    if(element.fieldType=="DROP DOWN")
    {
      requestDroupdownbody["componentConfig"] = {
        "moduleName": "Master Data Management",
        "aspectType": element.fieldName,
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
        "query": {
          "aspectType":element.fieldName
        },
        "skip": 0,
        "next": 100
      };
      UtilMethods.getDropDownData(Get.context!, requestDroupdownbody).then((
          value) {
        if(value.data==null)
          return ;
        value.data!.forEach((element1) {
          element.dropDownList!.add({"name": element1.refDataName});
          element.autoList!.add(element1.refDataName!);

        });
        if(type==1 && element.fieldName=="serviceStatus")
        {
          element.selectedDropDownValue = element.dropDownList![0];
          element.dropDownValue = element.dropDownList![0]["name"];
        }
        if(type==2) {
          try {
            int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName!]);
            if (index > -1) {
              element.selectedDropDownValue = element.dropDownList![index];
              element.dropDownValue = element.dropDownList![index]["name"];
            }
          } on Exception catch (e) {
            print("sdjvbjsbdhk"+e.toString());
          }
        }
        update();
      });

    }

}




  //Get All Sub DropDown field
  getSubDropDown(String subType,BuildContext context){
    Group_1_List.forEach((element) {
      getAllSubDropDownValue(element,subType);
    });
    Group_2_List.forEach((element) {
      getAllSubDropDownValue(element,subType);
    });
    Group_3_List.forEach((element) {
      getAllSubDropDownValue(element,subType);
    });
    Group_4_List.forEach((element) {
      getAllSubDropDownValue(element,subType);
    });
  }


getAllSubDropDownValue(TechnicalChildDatum element,String subType){

    if (element.fieldType == "DROP DOWN" && element.fieldName == "cityTypes" || element.fieldName=="serviceTypes" || element.fieldName=="refDataCode" ||element.fieldName=="assetType" ||element.fieldName=="refDataCode") {
      requestDroupdownbody["componentConfig"] = {
        "moduleName": "Master Data Management",
        "aspectType": element.fieldName=="refDataCode"?element.aspectType:element.fieldName,
        "productID": AppConstant.sharedPreference.getString(
            AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(
            AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(
            AppConstant.userName),
        "query": {
          "aspectType":  element.fieldName=="refDataCode"?element.aspectType:element.fieldName, "refDataCode": subType
        },
        "skip": 0,
        "next": 200
      };
      print("bdshbvdsbv");
      print(requestDroupdownbody);
      UtilMethods.getDropSubDownData(Get.context!, requestDroupdownbody).then((
          value) {
        element.dropDownList!.clear();
        element.selectedDropDownValue=null;
        element.dropDownValue="";
        if (value.data == null)
          return;
        value.data!.forEach((element1) {
          element.dropDownList!.add({"name": element1.refDataName});
          element.autoList!.add(element1.refDataName!);
        });
        if(type==2) {
          int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName=="refDataCode"?element.aspectType:element.fieldName]);
          print(index);
          print(datum![element.fieldName!]);
          if (index > -1) {
            element.selectedDropDownValue = element.dropDownList![index];
            element.dropDownValue = element.dropDownList![index]["name"];
          }
        }
        update();
      });

    }

}





  //Get Service Details
  getServiceNameDown(String subType,BuildContext context){
    Group_1_List.forEach((element) {
      getAllServiceRequetValue(element,subType);
    });
    Group_2_List.forEach((element) {
      getAllServiceRequetValue(element,subType);
    });
    Group_3_List.forEach((element) {
      getAllServiceRequetValue(element,subType);
    });
    Group_4_List.forEach((element) {
      getAllServiceRequetValue(element,subType);
    });

  }


  getAllServiceRequetValue(TechnicalChildDatum element,String subType)async{
    if (element.fieldType == "DROP DOWN" &&  element.fieldName=="ServiceSetup") {
        var query={"aspectType": element.fieldName, "serviceCategoryTypes": ServiceCategory,"serviceTypes":subType};
        String res= await fechApi("Service Setup",element.fieldName!,query);
        if(res.isEmpty) return;
        element.dropDownList!.clear();
        element.selectedDropDownValue=null;
        element.dropDownValue="";
        serviceDataFromJson(res).data!.forEach((element1) {
          element.dropDownList!.add({"name": element1.refDataName,"day":element1.day,"startDate":element1.startDate,"startTime":element1.startTime,"endTime":element1.endTime,"amount":element1.serviceAmount!.isEmpty?"0.0":element1.serviceAmount!});
          element.autoList!.add(element1.refDataName!);
        });

        if(type==2) {
          int index = element.dropDownList!.indexWhere((element1) => element1['name'] == datum![element.fieldName!]);
          print(datum![element.fieldName!]);
          if (index > -1) {
            element.selectedDropDownValue = element.dropDownList![index];
            element.dropDownValue = element.dropDownList![index]["name"];
          }
        }
        update();
      }

  }

  //Global image Pickeker And Download
  void pickImage(ImageSource src,TechnicalChildDatum childDatum)async{
    Get.back();
    final imagepicker=await ImagePicker().pickImage(source: src,imageQuality:80);
    if(imagepicker!.path!=null)
    {

      final bytes = File(imagepicker.path).readAsBytesSync().lengthInBytes;
      final kb = bytes / 1024;
      if(kb<500)
      {
        pickfile=Rx<File>(File(imagepicker.path));
        image.value=imagepicker.path;
        childDatum.isReady=true;
        update();
      try {
        UtilMethods.uploadSingleImage(Get.context!, image.value, "profile",imagepicker.name).then((value) {
          childDatum.textEditingController!.text=value;
          update();
        });
      } on Exception catch (e) {

      }
      }
      else{
        Get.snackbar("Size is large","Please select image size less then 500k",
            backgroundGradient: LinearGradient(colors: [
              Colors.red,
              Colors.black26,
            ]),
            borderRadius: 2,
            icon: Icon(Icons.error)
        );
      }


    }
  }
  void selectFile(TechnicalChildDatum childDatum)async{
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    PlatformFile file = result!.files.first;
    if (result != null) {
      final bytes = File(file.path!).readAsBytesSync().lengthInBytes;
      final kb = bytes / 1024;
      if(kb<500) {
        fileextension.value = file.extension!;
        filename.value = file.name;
        try {
          UtilMethods.uploadSingleImage(Get.context!, file.path!, "profile",file.name)
              .then((value) {
              childDatum.textEditingController!.text=value;
              update();
          });
        } on Exception catch (e) {
          // TODO
        }

        //updateModel();
      }
      else{
        Get.snackbar("Size is large","Please select image size less then 500k",
          icon: Icon(Icons.cancel, color: Colors.white),
          snackPosition: SnackPosition.TOP,
            backgroundGradient: LinearGradient(colors: [
              Colors.red,
              Colors.black26,
            ]),
            borderRadius: 2,

        );
      }

    } else {
      // User canceled the picker
    }
  }

  @override
  void onReady() {
    // TODO: implement onReady


    super.onReady();
  }
  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
  }

  getFilterApiCu(String membetType)async{
    var request={
      "text": membetType,
      "componentConfig": {
        "moduleName":"Contacts",
        "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
        "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
        "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      }
    };
    var response=await BaseClient().post(APIsConstant.getFilterAPI, request).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    allContactDatas.value=allContactDatasFromJson(response);
    if(allContactDatas.value.data!.isEmpty)
    {
      return;
    }
    else{
      if(membetType=="PRIEST")
        {
          final index1 =Group_1_List.indexWhere((element) => element.fieldName == "priestName");
          final index2 =Group_2_List.indexWhere((element) => element.fieldName == "priestName");
          final index3 =Group_3_List.indexWhere((element) => element.fieldName == "priestName");
          final index4=Group_4_List.indexWhere((element) => element.fieldName == "priestName");
          allContactDatas.value.data!.forEach((element2) {
            if(index1>-1)
              {
                Group_1_List[index1].dropDownList!.add({"name": element2.refDataName!,"email":element2.email!,
                  "phone":element2.phone!,"state":element2.stateTypes,
                  "city":element2.cityTypes!,"zip":element2.zip,"address":element2.address,
                });
              }
            if(index2>-1)
            {
              Group_2_List[index2].dropDownList!.add({"name": element2.refDataName!,"email":element2.email!,
                "phone":element2.phone!,"state":element2.stateTypes,
                "city":element2.cityTypes!,"zip":element2.zip,"address":element2.address,
              });
            }

            if(index3>-1)
            {
              Group_3_List[index3].dropDownList!.add({"name": element2.refDataName!,"email":element2.email!,
                "phone":element2.phone!,"state":element2.stateTypes,
                "city":element2.cityTypes!,"zip":element2.zip,"address":element2.address,
              });
            }

            if(index4>-1)
            {
              Group_4_List[index4].dropDownList!.add({"name": element2.refDataName!,"email":element2.email!,
                "phone":element2.phone!,"state":element2.stateTypes,
                "city":element2.cityTypes!,"zip":element2.zip,"address":element2.address,
              });
            }

          });
        }
      if(membetType=="DEVOTEE")
        {
          final index1 =Group_1_List.indexWhere((element) => element.fieldName == "customerName");
          final index2 =Group_2_List.indexWhere((element) => element.fieldName == "customerName");
          final index3 =Group_3_List.indexWhere((element) => element.fieldName == "customerName");
          final index4=Group_4_List.indexWhere((element) => element.fieldName == "customerName");
          allContactDatas.value.data!.forEach((element2) {
            if(index1>-1)
            {
              Group_1_List[index1].dropDownList!.add({"name": element2.refDataName!,"email":element2.email!,
                "phone":element2.phone!,"state":element2.stateTypes,
                "city":element2.cityTypes!,"zip":element2.zip,"address":element2.address,
              });
            }
            if(index2>-1)
            {
              Group_2_List[index2].dropDownList!.add({"name": element2.refDataName!,"email":element2.email!,
                "phone":element2.phone!,"state":element2.stateTypes,
                "city":element2.cityTypes!,"zip":element2.zip,"address":element2.address,
              });
            }

            if(index3>-1)
            {
              Group_3_List[index3].dropDownList!.add({"name": element2.refDataName!,"email":element2.email!,
                "phone":element2.phone!,"state":element2.stateTypes,
                "city":element2.cityTypes!,"zip":element2.zip,"address":element2.address,
              });
            }

            if(index4>-1)
            {
              Group_4_List[index4].dropDownList!.add({"name": element2.refDataName!,"email":element2.email!,
                "phone":element2.phone!,"state":element2.stateTypes,
                "city":element2.cityTypes!,"zip":element2.zip,"address":element2.address,
              });
            }

          });

        }
     update();
    }
  }
  Future<String> fechApi(String moduleName,String aspectType,var query) async{
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, getRequestJson(moduleName,aspectType,query)).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("resdsjnvjds"+response);
    if(response==null) "";
    if(jsonDecode(response)["statusCode"].toString()=="-1") "";
    if(jsonDecode(response)["data"]==null) "";
    return response;
  }
  getRequestJson(String moduleName,String aspectType,var query){
    bodyJson["componentConfig"] = {
      "moduleName":moduleName,
      "aspectType": aspectType,
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query": query,
      "skip": 0,
      "next": 100
    };
    return bodyJson;
  }
  setRequestData(TechnicalChildDatum element){
     if(element.fieldType == "CHECKBOX")
       {
         formValue[element.fieldName] = element.checkBoxValue!;
         return;
       }
    if (element.fieldType == "DROP DOWN") {
      if( element.mandatory=="YES")
      {
        if(element.dropDownValue=="")
        {
          showMessage(element.fieldName!);
          isValidate=false;

          return;
        }
        else
          {
            formValue[element.fieldName] = element.dropDownValue!.trim();
          }
      }
      else{
        formValue[element.fieldName] = element.dropDownValue!.trim();
      }

    }
    else {

        if (element.fieldName!.toLowerCase().contains("email") || element.fieldName!.toLowerCase().contains("phone")) {
          formValue[element.fieldName] = UtilMethods.encrypt(element.textEditingController!.text.trim());
          return;
        }
        formValue[element.fieldName] = element.textEditingController!.text.trim();


    }
  }
  showMessage(String msg)
  {
     Get.snackbar("Alert!", "Please Enter "+msg,borderRadius: 2,icon: Icon(Icons.warning,color:Colors.amber),
         backgroundGradient: LinearGradient(colors: [
         Colors.amber,
         Colors.black26,
         ]),
     );
  }
  checkGroupExpand(String group){
    switch(group){
      case "Group 1":
        Group1.currentState!.expand(true);
        break;
        case "Group 2":
        Group2.currentState!.expand(true);
        break;
        case "Group 3":
        Group3.currentState!.expand(true);
        break;
        case "Group 4":
        Group4.currentState!.expand(true);
        break;
    }
  }

}