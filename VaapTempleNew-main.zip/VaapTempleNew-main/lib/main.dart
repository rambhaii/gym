import 'dart:io';
import 'dart:ui';

import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/AppConstant/theme_services.dart';
import 'package:aspgen_mobile/Authentication/Login.dart';
import 'package:aspgen_mobile/Authentication/Menmberlogin.dart';
import 'package:aspgen_mobile/Authentication/NewLoginPage.dart';
import 'package:aspgen_mobile/BottomBar/dashboard_nav.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'AppConstant/AppThemes.dart';
import 'AppConstant/LocaleString.dart';
import 'CustomCalendar/CustomCalendar.dart';
import 'Notification/RecievedNotification/controller.dart';
import 'flavors.dart';
class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GlobalLoaderOverlay(
      useDefaultLoading: false,
        overlayOpacity: 0.1,
        overlayWidget:
        Center(
          child: Container(
            height: 41,
            width: 41,
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color:   Colors.white,
              shape: BoxShape.circle,
            ),
              child: CircularProgressIndicator(
                color: Colors.teal,
                strokeWidth: 3.5,
              )),
        ),
        child: GetMaterialApp(
            title: F.title,
            debugShowCheckedModeBanner: false,
            locale: const Locale('gu', 'IN'),
            translations: LocaleString(),
            scrollBehavior: MaterialScrollBehavior().copyWith(dragDevices: {PointerDeviceKind.touch},physics: BouncingScrollPhysics()),
            fallbackLocale: const Locale('en', 'US'),
            theme: Themes().lightTheme,
            darkTheme: Themes().darkTheme,
            themeMode: ThemeService().getThemeMode(),
            defaultTransition: Transition.downToUp,
            home: Routes(),
      ),
    );
  }
}
class Routes extends StatefulWidget {
  const Routes({Key? key}) : super(key: key);

  @override
  _RoutesState createState() => _RoutesState();
}

class _RoutesState extends State<Routes> {

  int count=0;

  @override
  void initState() {

    CheckInternetConnection();
    Connectivity().onConnectivityChanged.listen((ConnectivityResult result) {
      interneConnection(result);
    });
    // TODO: implement initState
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_){
      if (AppConstant.sharedPreference.getBool(AppConstant.isVerify)==true) {
      Get.offAll(()=>DashboardNavBar());
      }
      else
      {
        Get.offAll(()=>CustomerCodePage());
      }
    });
  }

  interneConnection(ConnectivityResult result)async{
    if(result==ConnectivityResult.wifi||result==ConnectivityResult.mobile)
      {
        Get.context!.loaderOverlay.hide();
        if(count!=0)
          {
            Get.snackbar("We are back...", "Internet Connected",backgroundColor: Colors.green.withOpacity(0.4),
              icon: Icon(Icons.wifi, color: Colors.white),
              snackPosition: SnackPosition.TOP,
              borderRadius: 5,
            );
          }
      }
    else{
      count=count + 1;
      Get.context!.loaderOverlay.hide();
      Get.snackbar("No Internet Connection", "Please connect to the internet",backgroundColor: Colors.red.withOpacity(0.4),
        icon: Icon(Icons.wifi_off, color: Colors.white),
        snackPosition: SnackPosition.TOP,
        borderRadius: 5,
      );
    }
  }
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
class MyHttpOverrides extends HttpOverrides{
  @override
  HttpClient createHttpClient(SecurityContext? context){
    return super.createHttpClient(context)
      ..badCertificateCallback = (X509Certificate cert, String host, int port)=> true;
  }

}
