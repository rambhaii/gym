

import 'dart:convert';
import 'dart:io';

import 'package:aspgen_mobile/BottomBar/dashboard_nav.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../AppConstant/AppConstant.dart';
import '../../Dashboard/Contact/Model/AllContactDatas.dart';
import '../../Templates/custom_expension_title.dart';
import '../../UtilMethods/BaseController.dart';
import '../../UtilMethods/Utils.dart';
import '../../UtilMethods/base_client.dart';

class ComunicationController extends GetxController{
  final formGlobalKey = GlobalKey<FormState>();
  final GlobalKey<ExpansionTileCardCustomState> expensionkey = new GlobalKey();
  TextEditingController etDate=TextEditingController();
  TextEditingController etSearch=TextEditingController();
  TextEditingController etTime=TextEditingController();
  TextEditingController etDuration=TextEditingController();
  TextEditingController etBodyOfText=TextEditingController();
  TextEditingController etAttachUrl=TextEditingController();
  TextEditingController etUrl=TextEditingController();
  TextEditingController etbtn=TextEditingController(text: "Confirm Button");
  bool confbtn=false;
  TextEditingController etSubject=TextEditingController();
  List<Map> dropDownMemberList=[
    {"name":"DEVOTEE"},
    {"name":"PRIEST"},
    {"name":"ADMINISTRATOR"},
    {"name":"GUEST"}
  ];
  List<Map> dropDownEventList=[
    {"name":"MANAGEMENT MEET"},
    {"name":"GROUP MEET"},
    {"name":"FESTIVE OFFER"}
  ];

  List<String> emailList=[];
  var selectMemberType;
  String memberType="";
  String eventTitle="";
 var selectEventTitle;
  var bodyJson={};
  RxList<ContactDatum> allContactDatas= RxList<ContactDatum>([]);
  RxList<ContactDatum> selectedList= RxList<ContactDatum>([]);
  // RxList<ContactDatum> filterContactDatas= RxList<ContactDatum>([]);
  RxList<ContactDatum> allFilterContactDatas= RxList<ContactDatum>([]);



  Duration duration = Duration(hours: 0, minutes: 0);
  RxBool isExpand=true.obs;
  RxBool isbtn=false.obs;
  RxBool isSerching=false.obs;
  RxBool isAllSelected=false.obs;
  var fileextension="".obs;
  var filename="Attach File".obs;
  void selectFile()async{
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    PlatformFile file = result!.files.first;
    if (result != null) {
      final bytes = File(file.path!).readAsBytesSync().lengthInBytes;
      final kb = bytes / 1024;
      if(kb<500) {
        fileextension.value = file.extension!;
        filename.value = file.name;
        try {
          UtilMethods.uploadSingleImage(Get.context!, file.path!, "profile",file.name)
              .then((value) {
              etAttachUrl.text=value;
          });
        } on Exception catch (e) {
          // TODO
        }

        //updateModel();
      }
      else{
        Get.snackbar("Size is large","Please select image size less then 500k",backgroundColor: Colors.red.withOpacity(0.6),
          icon: Icon(Icons.cancel, color: Colors.white),
          snackPosition: SnackPosition.TOP,
            backgroundGradient: LinearGradient(colors: [
              Colors.red,
              Colors.black26,
            ]),
            borderRadius: 2,

        );
      }

    } else {
      // User canceled the picker
    }
  }
  fetchApi(int type)async{
    bodyJson["componentConfig"]={
      "moduleName":"Contacts",
      "aspectType": "Member Directory",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{"aspectType":"Member Directory","memberTypes":memberType},
      "skip":0,
      "next":500
    };
     Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;

    if(AllContactDatas.fromJson(jsonDecode(response)).data!.isNotEmpty)
    {
      allContactDatas.value=allContactDatasFromJson(response).data!;
      allFilterContactDatas.value=allContactDatasFromJson(response).data!;
      if(type==2)
        {
          emailList.clear();
          allContactDatas.value.forEach((element) {
            emailList.add(UtilMethods.decrypt(element.email!).trim().toString());
          });
          SendEmail();
        }

    }
    else{
      Fluttertoast.showToast(msg: "No $memberType Available");
    }
  }
  void filterData(String search){
    List<ContactDatum> result=[];
    if(search.isEmpty)
    {
      result=allFilterContactDatas.value;
    }
    else{
      result=allFilterContactDatas.value.where((element) =>element.refDataName.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    allContactDatas.value=result;
  }


  SendEmail()async{
  var request={"dataJson":{
    "confirmationButton":isbtn.value,
    "eventTitle":eventTitle.toString(),
    "date":etDate.text.toString(),
    "subject":etSubject.text.toString(),
    "message":etBodyOfText.text.toString(),
    "duration":etDuration.text.toString(),
    "time":etTime.text,
    "memberType":emailList,
    "attachment":etAttachUrl.text.toString(),
    "link":etUrl.text,
  },
    "componentConfig":
    {
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
       "userName": AppConstant.sharedPreference.getString(AppConstant.userName)
    }
  };
  print("@@@@@");
  print(request);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.sendImageEmail, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    if(jsonDecode(response)["statusCode"].toString()=="1"){
      Get.snackbar("Success", "Message has been sent successfuly",icon: Icon(Icons.message_rounded),backgroundGradient: LinearGradient(colors: [
        Colors.green,
        Colors.black12
      ]),borderRadius: 2);
       Get.offAll(()=>DashboardNavBar());
    }
  }
}