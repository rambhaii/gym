import 'dart:ui';

import 'package:aspgen_mobile/Comunication/View/PreviewPage.dart';
import 'package:duration_picker/duration_picker.dart';
import 'package:expansion_tile_card/expansion_tile_card.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:fluttertoast/fluttertoast.dart';

import '../../UtilMethods/RemoteServices.dart';
import '../../Widget/DropdownButtonWidget.dart';
import '../../Widget/EditextWidget.dart';

import '../../Widget/glass_morphism.dart';
import '../Controller/ComunicationController.dart';
class ComunicationPage extends StatefulWidget {
  const ComunicationPage({Key? key}) : super(key: key);

  @override
  State<ComunicationPage> createState() => _ComunicationPageState();
}

class _ComunicationPageState extends State<ComunicationPage> {
  ComunicationController controller=Get.put(ComunicationController());
  final DateFormat formatter = DateFormat('MM/dd/yyyy');
  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        border: Border.all(color:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer);

    return Scaffold(
      appBar: AppBar(
        title: Text(
          "Comunication",
        ),
        actions: [  Padding(
          padding: const EdgeInsets.only(right: 8.0),
          child:
          RawMaterialButton(onPressed: (){
            if(controller.memberType.isEmpty)
              {
                Fluttertoast.showToast(msg: "Please Select Member Type");
                return;
              }
            if(controller.eventTitle.isEmpty)
              {
                Fluttertoast.showToast(msg: "Please Select Event title");
                return;
              }
          if(controller.formGlobalKey.currentState!.validate())
            {
              _showSimpleDialog();
              //showDialog(context: context, builder: (context)=>GlassMorphism(child: Text("Hello"),start: 10,end: 10,));
            // Get.to(()=>PreviewNotificationPage(title: 'Contacts', displayName: 'Preview Page',));
            }
          }
            ,child: Icon(Icons.send),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 40.0, minHeight: 40.0),),
        )
        ],
      ),
      body:  SingleChildScrollView(
        child: Obx(()=>Container(
            margin: EdgeInsets.only(top:15,left: 10,right: 10),
            padding: EdgeInsets.only(left: 10,right: 10),
            decoration:decoration.copyWith(border:Border.all(color:controller.isExpand.value?Colors.tealAccent:  Theme.of(context).colorScheme.primary.withOpacity(0.3),width: 0.5)),
            child:Form(
              key: controller.formGlobalKey,
              child: ExpansionTileCard(
                baseColor: Colors.transparent,
                elevation: 0,
                onExpansionChanged: (value){
                  controller.isExpand.value=value;
                },
                initiallyExpanded: controller.isExpand.value,
                expandedColor:Theme.of(context).colorScheme.onPrimaryContainer,
                key: controller.expensionkey,
                title: Text("Comunications"),
                children:[
                  Padding(
                    padding: EdgeInsets.only(top: 5,bottom: 8 ),
                    child: DropdownButtonWidget(
                      change: (value) {
                         controller.selectMemberType=value;
                         controller.memberType=controller.selectMemberType["name"];
                         controller.isExpand.refresh();
                        },
                      title: "Select Member Type",
                      list:controller.dropDownMemberList,
                      hint: "Select Member Type",
                      selectvalue:controller.selectMemberType,
                      onPress: '',
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(top: 5,bottom: 8 ),
                    child:DropdownButtonWidget(
                      change: (value) {
                        controller.selectEventTitle=value;
                        controller.eventTitle=controller.selectEventTitle["name"];
                        controller.isExpand.refresh();
                      },
                      title: "Select Event Title",
                      list:controller.dropDownEventList,
                      hint: "Select Event Title",
                      selectvalue:controller.selectEventTitle,
                      onPress: '',
                    ),

                  ),
                  SizedBox(height: 5,),
                  EditTextWidget(
                    maxLength: 100,
                    hint: "Enter Subject",
                    isPassword: false,
                    keyboardtype:  TextInputType.text,
                    label: "Subject",
                    validator: (value) {
                        if(value.toString().isEmpty)
                          {
                            return "Please enter subject";
                          }
                      return null;
                    },
                    controller: controller.etSubject,
                    maxline:1,
                  ),
                  SizedBox(height: 5,),
                  GestureDetector(
                    onTap: ()async {
                      final DateTime? picked= await  showDatePicker(
                          context: context,
                          initialDate:DateTime.now(),
                          firstDate: DateTime(2015),
                          lastDate: DateTime(2100),
                          builder: (context, child) {
                            return Theme(
                              data: ThemeData.dark().copyWith(
                                  colorScheme: const ColorScheme.dark(
                                      onPrimary: Colors.white,
                                      // selected text color
                                      onSurface: Colors.white,
                                      // default text color
                                      primary: Colors
                                          .teal // circle color
                                  ),
                                  dialogBackgroundColor: Theme
                                      .of(context)
                                      .backgroundColor,

                                  textButtonTheme: TextButtonThemeData(
                                      style: TextButton.styleFrom(
                                          textStyle: const TextStyle(
                                              color: Colors.white,
                                              fontWeight: FontWeight
                                                  .normal,
                                              fontSize: 12,
                                              fontFamily: 'Quicksand'),
                                          primary: Colors.white,
                                          // color of button's letters
                                          backgroundColor: Colors
                                              .black54,
                                          // Background color
                                          shape: RoundedRectangleBorder(
                                              side: const BorderSide(
                                                  color: Colors
                                                      .transparent,
                                                  width: 1,
                                                  style: BorderStyle
                                                      .solid),
                                              borderRadius: BorderRadius
                                                  .circular(50))))),

                              child: child!,
                            );
                          }

                      );

                      final String formatted = formatter.format(picked!);
                      controller.etDate.text=formatted;

                    },
                    child: AbsorbPointer(
                      child: EditTextWidget(
                        maxLength: 100,
                        hint: "Enter Date",
                        isPassword: false,
                        keyboardtype:  TextInputType.text,
                        label: "Date",
                        validator: (value) {

                          return null;
                        },
                        controller: controller.etDate,
                        maxline:1,
                      ),
                    ),
                  ),
                  SizedBox(height: 5,),
                  Row(
                    children: [
                      Expanded(
                        flex: 2,
                        child: GestureDetector(
                          onTap: () async {

                            TimeOfDay? time = await showTimePicker(
                                context: context,
                                initialTime: TimeOfDay.now(),
                                builder: (context, child) {
                                  return Theme(
                                    data: ThemeData.dark().copyWith(
                                        colorScheme: const ColorScheme.dark(
                                            onPrimary: Colors.white,
// selected text color
                                            onSurface: Colors.white,
// default text color
                                            primary: Colors
                                                .teal // circle color
                                        ),
                                        dialogBackgroundColor: Theme
                                            .of(context)
                                            .backgroundColor,

                                        textButtonTheme: TextButtonThemeData(
                                            style: TextButton.styleFrom(
                                                textStyle: const TextStyle(
                                                    color: Colors.white,
                                                    fontWeight: FontWeight
                                                        .normal,
                                                    fontSize: 12,
                                                    fontFamily: 'Quicksand'),
                                                primary: Colors.white,
                                                backgroundColor: Colors
                                                    .black54,

                                                shape: RoundedRectangleBorder(
                                                    side: const BorderSide(
                                                        color: Colors
                                                            .transparent,
                                                        width: 1,
                                                        style: BorderStyle
                                                            .solid),
                                                    borderRadius: BorderRadius
                                                        .circular(50))))),
                                    child: child!,
                                  );
                                }

                            );


                              controller.etTime.text = formatTimeOfDay(time!);

                          },
                          child: AbsorbPointer(
                            child: EditTextWidget(
                              maxLength: 100,
                              hint: "Enter Select Time",
                              isPassword: false,
                              keyboardtype:  TextInputType.text,
                              label: "Time",
                              validator: (value) {

                                return null;
                              },
                              controller: controller.etTime,
                              maxline:1,
                            ),
                          ),
                        ),
                      ),
                      SizedBox(width: 10,),
                      Expanded(
                        flex: 2,
                        child: GestureDetector(
                          onTap: ()async{

                            Duration? _durationResult = await
                            showDurationPicker(
                                snapToMins: 5.0,
                                context: context,
                                initialTime: Duration(
                                    hours: 0,
                                    minutes: 15,
                                    seconds: 0,
                                    milliseconds: 0));
                            if(_durationResult!=null)
                              {
                                controller.etDuration.text=_durationResult.inHours.toString()+" : "+_durationResult.inMinutes.toString();

                              }

                          },
                          child: AbsorbPointer(
                            child: EditTextWidget(
                              maxLength: 100,
                              hint: "Enter Duration",
                              isPassword: false,
                              keyboardtype:  TextInputType.text,
                              label: "Duration",
                              validator: (value) {

                                return null;
                              },
                              controller: controller.etDuration,
                              maxline:1,
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 5,),
                  EditTextWidget(
                    maxLength: 2000,
                    hint: "Enter Message",
                    isPassword: false,
                    keyboardtype:  TextInputType.text,
                    label: "Message",
                    validator: (value) {
                      if(value.toString().isEmpty)
                        {
                          return "Please Enter Message";
                        }
                      return null;
                    },
                    controller: controller.etBodyOfText,
                    maxline:5,
                  ),
                  SizedBox(height: 5,),
                  Container(
                    height: 50,
                    decoration: BoxDecoration(
                        border: Border.all(
                            color: Colors.grey, width: 1),
                        borderRadius: BorderRadius.circular(5)
                    ),
                    child: Row(
                      children: [
                        controller.fileextension.value == ""
                            ? Expanded(
                            flex: 2,
                            child: Icon(Icons.attach_file))
                            :
                        Expanded(
                            flex: 2,
                            child: Container(
                              margin: EdgeInsets.only(left: 3,
                                  right: 15,
                                  top: 3,
                                  bottom: 3),
                              decoration: BoxDecoration(
                                  color: Colors.amber.withOpacity(0.7),
                                  borderRadius: BorderRadius.circular(4)
                              ),
                              alignment: Alignment.center,
                              height: 55,
                              child: Text(
                                controller.fileextension.value
                                    .toString(), style: TextStyle(
                                  color: Colors.white.withOpacity(0.85),
                                  fontWeight: FontWeight.bold,
                                  fontSize: 20),),
                            )),
                        Expanded(
                            flex: 4,
                            child: Text(controller.filename.value
                                .toString())),
                        Expanded(
                          flex: 2,
                          child: TextButton(child: Text("Select"),
                              onPressed: () async {
                                controller.selectFile();
                              }),)
                      ],
                    ),
                  ),
                  SizedBox(height: 12,),
                  EditTextWidget(
                    maxLength: 2000,
                    hint: "Enter Link",
                    isPassword: false,
                    keyboardtype:  TextInputType.text,
                    label: "Attach Link",
                    validator: (value) {
                      return null;
                    },
                    controller: controller.etUrl,
                    maxline:1,
                  ),

                  Visibility(
                    visible: controller.isbtn.value,
                      child:  Row(
                        children: [
                      Expanded(
                        flex:9,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.teal,
                          ),
                          child: Text(controller.etbtn.text),onPressed: (){},),
                      ),
                    SizedBox(width: 10,),
                          Expanded(
                        flex: 2,
                        child: IconButton(
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.teal,
                          ),
                          icon: Icon(Icons.delete,color: Colors.red,),onPressed: (){
                          controller.isbtn.value=false;
                        },),
                      ),
                    ],
                  )),
                  SizedBox(height: 12,),
                  Visibility(
                    visible: !controller.isbtn.value,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Expanded(
                            flex: 10,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(backgroundColor: Colors.teal,
                            ),
                            child: Text(controller.etbtn.text),onPressed: (){},),
                        ),
                        SizedBox(width: 10,),
                        Expanded(
                            flex: 2,
                            child:  RawMaterialButton(onPressed: (){
                              if(controller.etbtn.text.isEmpty)
                                {
                                  Fluttertoast.showToast(msg: "Please Enter Button Name");
                                  return;
                                }
                              controller.isbtn.value=true;
                            }
                              ,child: Icon(Icons.add),fillColor: Colors.green,shape: CircleBorder(),constraints:  BoxConstraints(minWidth: 40.0, minHeight: 40.0),),


                          // ElevatedButton(
                            //   style: ElevatedButton.styleFrom(backgroundColor: Colors.teal,
                            //   ),
                            //   child: Text("+ Add"),onPressed: (){
                            //   controller.isbtn.value=true;
                            // },)
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 20,)
                ]),
            ),
            ),
        ),
      ),

    );
  }
  String formatTimeOfDay(TimeOfDay tod) {
    final now = new DateTime.now();
    final dt = DateTime(now.year, now.month, now.day, tod.hour, tod.minute);

    final format = DateFormat.jm(); // YOUR DATE GOES HERE

    return format.format(dt);
  }
  Future<void> _showSimpleDialog() async {
    await showDialog<void>(
        context: context,
        barrierColor: Colors.transparent,
        builder: (BuildContext context) {
          return SimpleDialog(
            backgroundColor: Colors.transparent,// <-- SEE HERE
            children: <Widget>[
            BackdropFilter(
              filter:ImageFilter.blur(
                sigmaX: 10.0,
                sigmaY: 10.0,
              ),
              child: Container(
                padding: EdgeInsets.all(15.0),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10)
                ),

                child:Column(
                  children: [
                    SizedBox(
                      height: 20,
                    ),
                      ElevatedButton(onPressed: (){
                       controller.fetchApi(2);
                      },
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                          child: Text("SEND All "+controller.memberType)),
                      SizedBox(
                        height: 10,
                      ),
                      ElevatedButton(onPressed: (){
                        Get.to(()=>PreviewNotificationPage(title: 'Contacts', displayName: 'Preview Page',));
                      },
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),
                          child: Text(" SELECT "+controller.memberType+" ")),
                    SizedBox(
                      height: 20,
                    ),
                  ],
                ),
              ),
            )
            ],
          );
        });
  }
// --- Button Widget --- //

}
