import 'dart:convert';
import 'dart:math';
import 'package:aspgen_mobile/AppConstant/config.dart';
import 'package:aspgen_mobile/Dashboard/Contact/Controller/contact_controller.dart';
import 'package:aspgen_mobile/Templates/Model/ListingData.dart';
import 'package:aspgen_mobile/UtilMethods/RemoteServices.dart';
import 'package:aspgen_mobile/UtilMethods/Utils.dart';
import 'package:aspgen_mobile/Widget/HiglitTextWidget.dart';
import 'package:aspgen_mobile/Widget/SearchBarWidget.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../AppConstant/APIsConstant.dart';
import '../../Dashboard/Contact/Model/AllContactDatas.dart';
import '../../Templates/fieldPageNew.dart';
import '../../Widget/FullScreenImageWidget.dart';
import '../../Widget/LoadMore.dart';
import '../Controller/ComunicationController.dart';
class PreviewNotificationPage extends StatefulWidget {
  final String title;
  final String displayName;
  const PreviewNotificationPage({Key? key,required this.title, required this.displayName}) : super(key: key);
  @override
  State<PreviewNotificationPage> createState() => _PreviewNotificationPageState();
}

class _PreviewNotificationPageState extends State<PreviewNotificationPage> {
  var contactFilterList2=[];
  AllContactDatas ?contactDatas;
  ListingData listingData=new ListingData();
  ComunicationController _controller=  Get.find();

  var bodyJson={};
  late ComponentConfig componentConfig;

  @override
  void initState() {
    _controller.selectedList.clear();
    _controller.allContactDatas.value.clear();
    _controller.allFilterContactDatas.value.clear();
    _controller.fetchApi(1);

    super.initState();
  }

  makingPhoneCall(String phone) async {
    print("ndbshfs");
    var url = 'tel:'+phone;
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("SELECT "+_controller.memberType),
        actions: [
          Center(child: Text("All")),
          Obx(()=> Checkbox(value: _controller.isAllSelected.value, onChanged: (value){
                if(value==true)
                  {
                    _controller.selectedList.clear();
                      _controller.allContactDatas.value.forEach((element) {
                        element.isSelected=true;
                        _controller.selectedList.add(element);
                      });
                      _controller.allContactDatas.refresh();
                      _controller.selectedList.refresh();
                  }
                else{
                  _controller.selectedList.value.clear();
                  _controller.allContactDatas.value.forEach((element) {
                    element.isSelected=false;
                  });
                  _controller.allContactDatas.refresh();
                  _controller.selectedList.refresh();
                }
            _controller.isAllSelected.value=value!;


          }))
        ],
      ),
      body: Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          SizedBox(height: 10,),
          GetBuilder<ComunicationController>(
            builder: (controller)=>  SearchBarWidget(
              hint: "Search",
              controller: controller.etSearch,
              onchange: (value){
                controller.filterData(value);
                //value.toString().length>3?controller.fetchFilterApi(value):value.toString().length==0?controller.fetchApi(controller.bodyJson):"";
                controller.update();
              },
              onCancel: (){
                controller.etSearch.clear();
                controller.filterData(controller.etSearch.text);
                //controller.fetchApi(controller.bodyJson);
                controller.update();
              },
            ),
          ),
          SizedBox(height: 8,),

            Obx(()=>_controller.allContactDatas.value.isNotEmpty? Expanded(

              child: RefreshIndicator(
                semanticsLabel: "Refresh",
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {
                    _controller.fetchApi(1);
                  });
                },
                child: ListView.builder(
                    itemCount:  _controller.allContactDatas.value.length,
                    physics: const AlwaysScrollableScrollPhysics(),
                    itemBuilder: (context,index){
                      final data=_controller.allContactDatas.value[index];
                      return Card(
                        color: Theme.of(context).colorScheme.onPrimaryContainer,
                        elevation: 6,
                        child:
                        Column(
                          children: [
                            Divider(
                              height: 0.5,
                              thickness: 0.5,
                              color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
                            ),
                            SizedBox(height: 10),
                            Row(
                              children: [
                                Container(
                                  width: MediaQuery.of(context).size.width * 0.2,
                                  padding: EdgeInsets.only(left: 5),
                                  child: Stack(
                                    children: [
                                      data.image==""?  CircleAvatar(
                                        backgroundColor: Color(Random().nextInt(0xffffffff)),
                                        child: Text(
                                            data.refDataName.toString().toUpperCase() ==
                                                "" ? "" : data.refDataName![0].toString().toUpperCase(),
                                            style: Theme.of(context).textTheme.headline4
                                        ),
                                        maxRadius: 27,
                                      ):
                                      ClipOval(
                                        child: GestureDetector(
                                          onTap: (){
                                            Get.to(()=>FullScreenImageWidget(path: APIsConstant.IP_Base_Url+data.image.toString(),),fullscreenDialog: true);
                                          },
                                          child: Hero(
                                            tag:"img", child: CachedNetworkImage(
                                            fit: BoxFit.cover,
                                            imageUrl:APIsConstant.IP_Base_Url+data.image.toString(),
                                            height: 55,
                                            width: 55,
                                            placeholder: (context,url)=>const CircularProgressIndicator(),
                                            errorWidget: (context,url,error)=>const Icon(Icons.error),
                                          ),
                                          ),
                                        ),
                                      ),

                                    ],
                                  ),
                                ),
                                Container(
                                  width: MediaQuery.of(context).size.width * 0.6,
                                  child: Column(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      HigliteText(textData: data.refDataName!, query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle),
                                      SizedBox(
                                        height: 9,
                                      ),
                                      HigliteText(textData:  data.memberTypes!, query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1!.copyWith(
                                          color:  data.memberTypes!.toString() == "PRIEST"
                                              ? Colors.amber
                                              :  data.memberTypes!.toString()== "DEVOTEE"
                                              ? Colors.green:
                                          data.memberTypes!.toString()== "GUEST"?Colors.purple  : Colors.lightBlue,
                                          fontSize: 11,fontWeight: FontWeight.w400
                                      )
                                      ),
                                      SizedBox(
                                        height: 3,
                                      ),
                                      InkWell(onTap: (){
                                        data.isCheckList!?data.isCheckList=false:data.isCheckList=true;
                                        _controller.allContactDatas.refresh();
                                      },
                                          child: Row(
                                            children: [
                                              Expanded(
                                                  flex:3,
                                                  child: Text(data.isCheckList!=true?"View More  ":"Less More  ",style:TextStyle(fontSize: 12,color:Colors.white54, decoration: TextDecoration.underline,))),
                                              Expanded(
                                                  flex:6,
                                                  child:Icon(data.isCheckList!=true?Icons.expand_more:Icons.expand_less,size: 20,color:Colors.white54)),
                                            ],
                                          )
                                      ),
                                      if(data.isCheckList!)   SizedBox(
                                        height: 8,
                                      ),
                                      if(data.isCheckList!) Row(
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Icon(Icons.phone,size: 16,),
                                          SizedBox(width: 8,),
                                          Expanded(child: HigliteText(textData:UtilMethods.decrypt(data.phone!), query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle)),
                                        ],
                                      ),

                                    ],
                                  ),
                                ),
                                Container(
                                  alignment: Alignment.topRight,
                                  width: MediaQuery.of(context).size.width * 0.175,
                                  child: Container(
                                    alignment: Alignment.center,

                                    child: Checkbox(
                                      value: data.isSelected,
                                      onChanged: (value){
                                        if(value==true)
                                          {
                                            _controller.selectedList.add(data);
                                          }
                                          else
                                          {
                                            _controller.selectedList.remove(data);
                                          }
                                        _controller.isAllSelected.value=false;
                                          data.isSelected=value;
                                        _controller.allContactDatas.refresh();
                                        _controller.selectedList.refresh();
                                       
                                      },
                                    )
                                  ),
                                ),
                              ],
                            ),
                            Container(
                              margin: EdgeInsets.only(left: Get.width*0.2,right: 8),
                              child: Column(children: [
                                if(data.isCheckList!)  SizedBox(
                                  height: 4,
                                ),
                                if(data.isCheckList!) Row(
                                  children: [
                                    Icon(Icons.email,size: 16,),
                                    SizedBox(width: 8,),
                                    Expanded(child: HigliteText(textData: UtilMethods.decrypt(data.email!), query: _controller.etSearch.text, textStyle:Theme.of(context).textTheme.bodyText1 as TextStyle)),
                                  ],
                                ),
                              ],),
                            ),
                            SizedBox(height: 10),
                            Divider(
                              height: 0.5,
                              thickness: 0.5,
                              color:  Theme.of(context).colorScheme.primary.withOpacity(0.24),
                            )
                          ],
                        ),
                      );
                    }),
              ),
            ): Expanded(child: Center(child: Text(_controller.isSerching.value?"We couldn't find any contact\nmatching '${_controller.etSearch.text}'  ":"",
              style: Theme.of(context).textTheme.bodyText1,
              textAlign: TextAlign.center,),

            ),
            ),
          ),
          // Obx(() => _controller.isLoadMore.value?LoadMoreData():Container())
        ],
      ),
      floatingActionButton: Badge(
        backgroundColor: Colors.green,

        padding: EdgeInsets.all(8),
        label: Obx(()=>Text(_controller.selectedList.value.length.toString(),style: TextStyle(color: Colors.white,fontSize: 14),)),
        child: Padding(
          padding: const EdgeInsets.only(top: 12,left: 12),
          child: FloatingActionButton(
            backgroundColor: Colors.teal,
            foregroundColor: Colors.white,
            onPressed: () {
              if(_controller.selectedList.value.length==0)
                  {
                   Get.snackbar("Alert !", "Please select at least one ${_controller.memberType}",borderRadius: 2,
                       icon: Icon(Icons.warning_amber),

                       backgroundGradient: LinearGradient(colors: [
                         Colors.red,
                         Colors.black26,
                       ]),

                   );
                   return;
                  }
              else{
                _controller.emailList.clear();
                _controller.selectedList.value.forEach((element) {
                  _controller.emailList.add(UtilMethods.decrypt(element.email!).trim().toString());
                });
                _controller.SendEmail();
              }


            },
           child: Icon(Icons.send,color: Colors.white,size: 30,),
          ),
        ),
      ),
    );
  }

}
