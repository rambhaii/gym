// To parse this JSON data, do
//
//     final servicesModel = servicesModelFromJson(jsonString);

import 'dart:convert';

ServicesModel servicesModelFromJson(String str) => ServicesModel.fromJson(json.decode(str));

String servicesModelToJson(ServicesModel data) => json.encode(data.toJson());

class ServicesModel {
  ServicesModel({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String ?message;
  Data ?data;

  factory ServicesModel.fromJson(Map<String, dynamic> json) => ServicesModel(
    statusCode: json["statusCode"],
    message: json["message"],
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": data!.toJson(),
  };
}

class Data {
  Data({
    this.revenue,
    this.datas,
    this.serviceDetails,
    this.serviceDetailType,
  });

  List<Revenue> ?revenue;
  List<ServiceDatum>? datas;
  List<ServiceDetails>? serviceDetails;
  List<ServiceDetailType> ?serviceDetailType;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    revenue: List<Revenue>.from(json["REVENUE"].map((x) => Revenue.fromJson(x))),
    datas: List<ServiceDatum>.from(json["Datas"].map((x) => ServiceDatum.fromJson(x))),
    serviceDetails: List<ServiceDetails>.from((json["serviceDetails"]??[]).map((x) => ServiceDetails.fromJson(x))),
    serviceDetailType: List<ServiceDetailType>.from((json["serviceDetailType"]??[]).map((x) => ServiceDetailType.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "REVENUE": List<dynamic>.from(revenue!.map((x) => x.toJson())),
    "Datas": List<dynamic>.from(datas!.map((x) => x.toJson())),
    "serviceDetails": List<dynamic>.from(serviceDetails!.map((x) => x.toJson())),
    "serviceDetailType": List<dynamic>.from(serviceDetailType!.map((x) => x.toJson())),
  };
}

class ServiceDatum {
  ServiceDatum({
    this.id,
    this.serviceCategoryTypes,
    this.serviceTypes,
    this.serviceSetup,
    this.serviceAmount,
    this.serviceDate,
    this.source,
    this.customerName,
    this.isChecked,
    this.customerEmail,
    this.customerPhone,

  });

  String? id;
  String? serviceCategoryTypes;
  String? serviceTypes;
  String? serviceSetup;
  var serviceAmount;
  String? serviceDate;
  String? source;
  String? customerName;
  String? customerEmail;
  String? customerPhone;
  bool? isChecked;

  factory ServiceDatum.fromJson(Map<String, dynamic> json) => ServiceDatum(
    id: json["_id"]??"",
    serviceCategoryTypes: json["serviceCategoryTypes"]??"",
    serviceTypes: json["serviceTypes"]??"",
    serviceSetup: json["ServiceSetup"]??"",
    serviceAmount: json["serviceAmount"]??"0.00",
    serviceDate: json["serviceDate"]??"",
    source: json["source"]??"",
    customerName: json["customerName"]??"",
    customerEmail: json["customerEmail"]??"",
    customerPhone: json["customerPhone"]??"",
    isChecked:false ,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "serviceCategoryTypes": serviceCategoryTypes,
    "serviceTypes": serviceTypes,
    "ServiceSetup": serviceSetup,
    "serviceAmount": serviceAmount,
    "serviceDate": serviceDate,
    "source": source,
    "memberName": customerName,
    "customerEmaildecrypt": customerEmail,
    "customerPhonedecrypt": customerPhone,
    "isChecked": isChecked,

  };
}

class Revenue {
  Revenue({
    this.id,
    this.sum,
    this.min,
    this.max,
    this.average,
    this.count,
    this.payment,
  });

  String ?id;
  var sum;

  var average;
  int ?count;
  double? min;
  double? max;

  List<Payment>? payment;

  factory Revenue.fromJson(Map<String, dynamic> json) => Revenue(
    id: json["_id"],
    sum: json["sum"]??"0",
    average: json["Average"]??"0",
    min:json["min"]!=null? json["min"].toDouble():0.0,
    max:json["max"]!=null? json["max"].toDouble():0.0,
    count: json["count"],


    payment: List<Payment>.from((json["payment"]??[]).map((x) => Payment.fromJson(x))),

  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "sum": sum,
    "Average": average,
    "count": count,
    "min": min,
    "max": max,

    "payment": List<dynamic>.from(payment!.map((x) => x.toJson())),
  };
}
class Payment {
  Payment({
    this.id,
    this.count,
    this.avg,
    this.sum,
    this.min,
    this.max,
  });

  String? id;
  int? count;
  double? avg;
  double? sum;
  double? min;
  double? max;

  factory Payment.fromJson(Map<String, dynamic> json) => Payment(
    id: json["_id"]??"",
    count: json["count"]??0,
    avg: json["avg"]!=null?json["avg"].toDouble():0,
    sum: json["sum"]!=null?json["sum"].toDouble():0,
    min: json["min"]!=null?json["min"].toDouble():0,
    max: json["max"]!=null?json["max"].toDouble():0,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "count": count,
    "avg": avg,
    "sum": sum,
    "min": min,
    "max": max,
  };
}
class ServiceDetails {
  ServiceDetails({
    this.id,
    this.count,
    this.avg,
    this.sum,
  });

  String? id;
  int? count;
  var avg;
  var sum;

  factory ServiceDetails.fromJson(Map<String, dynamic> json) => ServiceDetails(
    id: json["_id"],
    count: json["count"]??"0",
    avg: json["avg"]??"0.00",
    sum: json["sum"]??"0.00",
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "count": count,
    "avg": avg,
    "sum": sum,
  };
}
class ServiceDetailType {
  ServiceDetailType({
    this.id,
    this.sum,
    this.count,
  });

  String ?id;
  var sum;
  var count;

  factory ServiceDetailType.fromJson(Map<String, dynamic> json) => ServiceDetailType(
    id: json["_id"]??"",
    sum: json["sum"]??"0.00",
    count: json["count"]??"0",
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "sum": sum,
    "count": count,
  };
}