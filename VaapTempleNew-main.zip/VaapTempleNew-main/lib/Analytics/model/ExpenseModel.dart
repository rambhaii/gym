// To parse this JSON data, do
//
//     final expenseModel = expenseModelFromJson(jsonString);

import 'dart:convert';

ExpenseModel expenseModelFromJson(String str) => ExpenseModel.fromJson(json.decode(str));

String expenseModelToJson(ExpenseModel data) => json.encode(data.toJson());

class ExpenseModel {
  ExpenseModel({
    this.statusCode,
    this.message,
    this.data,
  });

  String? statusCode;
  String? message;
  Data? data;

  factory ExpenseModel.fromJson(Map<String, dynamic> json) => ExpenseModel(
    statusCode: json["statusCode"],
    message: json["message"],
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": data!.toJson(),
  };
}

class Data {
  Data({
    this.expense,
    this.datas,
  });

  List<Expense>? expense;
  List<ExpensesDatum> ?datas;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    expense: List<Expense>.from(json["EXPENSE"].map((x) => Expense.fromJson(x))),
    datas: List<ExpensesDatum>.from(json["Datas"].map((x) => ExpensesDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "EXPENSE": List<dynamic>.from(expense!.map((x) => x.toJson())),
    "Datas": List<dynamic>.from(datas!.map((x) => x.toJson())),
  };
}

class ExpensesDatum {
  ExpensesDatum({
    this.id,
    this.expenseName,
    this.expenseCode,
    this.expenseCategory,
    this.expenseType,
    this.expenseStatus,
    this.aspectType,
    this.expenseAmount,
    this.recCreDate,
    this.isChecked,
  });

  String? id;
  String? expenseName;
  String? expenseCode;
  String? expenseCategory;
  String? expenseType;
  String ?expenseStatus;
  String? aspectType;
  var expenseAmount;
  String? recCreDate;
  bool? isChecked;

  factory ExpensesDatum.fromJson(Map<String, dynamic> json) => ExpensesDatum(
    id: json["_id"],
    expenseName: json["expenseName"]??"",
    expenseCode: json["expenseCode"]??"",
    expenseCategory: json["expenseCategory"]??"",
    expenseType: json["expenseType"]??"",
    expenseStatus: json["expenseStatus"]??"",
    aspectType: json["aspectType"]??"",
    expenseAmount: json["expenseAmount"]??"0",
    recCreDate: "",
    isChecked: false,
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "expenseName": expenseName,
    "expenseCode": expenseCode,
    "expenseCategory": expenseCategoryValues.reverse[expenseCategory],
    "expenseType": expenseType,
    "expenseStatus": expenseStatus,
    "aspectType": aspectTypeValues.reverse[aspectType],
    "expenseAmount": expenseAmount,
    "recCreDate": recCreDate,
    "isChecked": isChecked,
  };
}

enum AspectType { EXPENSES }

final aspectTypeValues = EnumValues({
  "Expenses": AspectType.EXPENSES
});

enum ExpenseCategory { OPERATIONAL, UTILITIES }

final expenseCategoryValues = EnumValues({
  "OPERATIONAL": ExpenseCategory.OPERATIONAL,
  "UTILITIES": ExpenseCategory.UTILITIES
});

class Expense {
  Expense({
    this.id,
    this.sum,
    this.title,
    this.count,
    this.max,
    this.average,
    this.min,
    this.expenseDetail,
  });

  String? id;
  var sum;
  String? title;
  int? count;
  var max;
  var average;
  var min;
  List<ExpenseDetail>? expenseDetail;

  factory Expense.fromJson(Map<String, dynamic> json) => Expense(
    id: json["_id"],
    sum: json["sum"]??0,
    title: json["title"],
    count: json["count"],
    max: json["max"]??0,
    average: json["average"]??0,
    min: json["min"]??0,
    expenseDetail: List<ExpenseDetail>.from(json["expenseDetail"].map((x) => ExpenseDetail.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "_id": aspectTypeValues.reverse[id],
    "sum": sum,
    "title": title,
    "count": count,
    "expenseDetail": List<dynamic>.from(expenseDetail!.map((x) => x.toJson())),
  };
}

class ExpenseDetail {
  ExpenseDetail({
    this.id,
    this.count,
    this.avg,
    this.sum,
  });

  String? id;
  int? count;
  double? avg;
  int? sum;

  factory ExpenseDetail.fromJson(Map<String, dynamic> json) => ExpenseDetail(
    id: json["_id"],
    count: json["count"],
    avg: json["avg"].toDouble(),
    sum: json["sum"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "count": count,
    "avg": avg,
    "sum": sum,
  };
}

class EnumValues<T> {
  Map<String, T>? map;
  Map<T, String>? reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map!.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap!;
  }
}
