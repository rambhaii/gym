// To parse this JSON data, do
//
//     final topBottomFrequent = topBottomFrequentFromJson(jsonString);

import 'dart:convert';

TopBottomFrequent topBottomFrequentFromJson(String str) => TopBottomFrequent.fromJson(json.decode(str));

String topBottomFrequentToJson(TopBottomFrequent data) => json.encode(data.toJson());

class TopBottomFrequent {
  TopBottomFrequent({
    this.statusCode,
    this.message,
    this.data,
  });

  String ?statusCode;
  String? message;
  Data ?data;

  factory TopBottomFrequent.fromJson(Map<String, dynamic> json) => TopBottomFrequent(
    statusCode: json["statusCode"],
    message: json["message"],
    data: Data.fromJson(json["data"]??[]),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": data!.toJson(),
  };
}

class Data {
  Data({
    this.top,
    this.bottom,
    this.frequent,
  });

  List<Bottom> ?top;
  List<Bottom> ?bottom;
  List<Frequent>? frequent;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    top: List<Bottom>.from((json["Top"]??"").map((x) => Bottom.fromJson(x))),
    bottom: List<Bottom>.from((json["Bottom"]??"").map((x) => Bottom.fromJson(x))),
    frequent: List<Frequent>.from((json["Frequent"]??"").map((x) => Frequent.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Top": List<dynamic>.from(top!.map((x) => x.toJson())),
    "Bottom": List<dynamic>.from(bottom!.map((x) => x.toJson())),
    "Frequent": List<dynamic>.from(frequent!.map((x) => x.toJson())),
  };
}

class Bottom {
  Bottom({
    this.id,
    this.serviceRequestId,
    this.serviceCategoryTypes,
    this.serviceTypes,
    this.serviceSetup,
    this.serviceDate,
    this.startTime,
    this.endTime,
    this.colour,
    this.description,
    this.languageTypes,
    this.locationTypes,
    this.serviceStatus,
    this.serviceAmount,
    this.priestName,
    this.priestPhone,
    this.priestEmail,
    this.addtionalPriest,
    this.customerName,
    this.customerPhone,
    this.customerEmail,
    this.customerState,
    this.customerCity,
    this.customerAddress,
    this.customerZip,
    this.countryCode,

    this.clientId,
    this.productId,
    this.aspectType,
    this.isChecked,

    this.paymentStatus,

  });

  String ?id;
  String ?serviceRequestId;
  var serviceCategoryTypes;
  var serviceTypes;
  String ?serviceSetup;
  String ?serviceDate;
  String ?startTime;
  String ?endTime;
  String ?colour;
  String ?description;
  String ?languageTypes;
  String ?locationTypes;
  var serviceStatus;
  var serviceAmount;
  String? priestName;
  String ?priestPhone;
  String ?priestEmail;
  String ?addtionalPriest;
  String ?customerName;
  String ?customerPhone;
  String ?customerEmail;
  String ?customerState;
  String ?customerCity;
  String ?customerAddress;
  String ?customerZip;
  String ?countryCode;
  bool ?isChecked;

  String ?clientId;
  String ?productId;
  var aspectType;
  var paymentStatus;


  factory Bottom.fromJson(Map<String, dynamic> json) => Bottom(
    id: json["_id"],
    serviceRequestId: json["serviceRequestId"]??"",
    serviceCategoryTypes:json["serviceCategoryTypes"]??"",
    serviceTypes:json["serviceTypes"]??"",
    serviceSetup: json["ServiceSetup"]??"",
    serviceDate: json["serviceDate"]??"",
    startTime: json["startTime"]??"" ,
    endTime: json["endTime"]??"" ,
    colour: json["colour"]??"",
    description: json["description"]??"",
    languageTypes: json["languageTypes"]??"" ,
    locationTypes: json["locationTypes"]??"",
    serviceStatus: json["serviceStatus"]??"",
    serviceAmount: json["serviceAmount"]??"" ,
    priestName: json["priestName"]??"" ,
    priestPhone: json["priestPhone"]??"",
    priestEmail: json["priestEmail"]??"" ,
    addtionalPriest: json["addtionalPriest"]??"" ,
    customerName: json["customerName"]??"",
    customerPhone: json["customerPhone"]??"" ,
    customerEmail: json["customerEmail"]??"" ,
    customerState: json["customerState"]??"",
    customerCity: json["customerCity"]??"",
    customerAddress: json["customerAddress"]??"" ,
    customerZip: json["customerZip"]??"",
    countryCode: json["countryCode"]??"",

    clientId: json["clientID"]??"" ,
    productId: json["productID"]??"" ,
    aspectType: json["aspectType"]??"",
    isChecked: false,

  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "serviceRequestId": serviceRequestId == null ? null : serviceRequestId,
    "serviceCategoryTypes": serviceCategoryTypes,
    "serviceTypes": serviceTypes,
    "ServiceSetup": serviceSetup,
    "serviceDate": serviceDate,
    "startTime": startTime == null ? null : startTime,
    "endTime": endTime == null ? null : endTime,
    "colour": colour == null ? null : colour,
    "description": description == null ? null : description,
    "languageTypes": languageTypes == null ? null : languageTypes,
    "locationTypes": locationTypes == null ? null : locationTypes,
    "serviceStatus": serviceStatus == null ? null : serviceStatus,
    "serviceAmount": serviceAmount == null ? null : serviceAmount,
    "priestName": priestName == null ? null : priestName,
    "priestPhone": priestPhone == null ? null : priestPhone,
    "priestEmail": priestEmail == null ? null : priestEmail,
    "addtionalPriest": addtionalPriest == null ? null : addtionalPriest,
    "customerName": customerName == null ? null : customerName,
    "customerPhone": customerPhone == null ? null : customerPhone,
    "customerEmail": customerEmail == null ? null : customerEmail,
    "customerState": customerState == null ? null : customerState,
    "customerCity": customerCity == null ? null : customerCity,
    "customerAddress": customerAddress == null ? null : customerAddress,
    "customerZip": customerZip == null ? null : customerZip,
    "countryCode": countryCode == null ? null : countryCode,

    "clientID": clientId == null ? null : clientId,
    "productID": productId == null ? null : productId,
    "aspectType": aspectType,
    "paymentStatus": paymentStatus,
    "isChecked": isChecked,
  };
}





class Frequent {
  Frequent({
    this.id,
    this.count,
  });

  String ?id;
  var count;

  factory Frequent.fromJson(Map<String, dynamic> json) => Frequent(
    id: json["_id"]??"",
    count: json["count"]??"",
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "count": count,
  };
}


