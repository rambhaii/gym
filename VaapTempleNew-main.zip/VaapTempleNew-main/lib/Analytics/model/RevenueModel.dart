// To parse this JSON data, do
//
//     final revenueModel = revenueModelFromJson(jsonString);

import 'dart:convert';

import 'package:aspgen_mobile/Analytics/model/ServicesModel.dart';

RevenueModel revenueModelFromJson(String str) => RevenueModel.fromJson(json.decode(str));

String revenueModelToJson(RevenueModel data) => json.encode(data.toJson());

class RevenueModel {
  RevenueModel({
    this.statusCode,
    this.message,
    this.data,
  });

  String? statusCode;
  String? message;
  Data? data;

  factory RevenueModel.fromJson(Map<String, dynamic> json) => RevenueModel(
    statusCode: json["statusCode"],
    message: json["message"],
    data: Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "statusCode": statusCode,
    "message": message,
    "data": data!.toJson(),
  };
}

class Data {
  Data({
    this.revenue,
    this.datas,
  });

  List<Revenue>? revenue;
  List<DataElement>? datas;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    revenue: List<Revenue>.from(json["REVENUE"].map((x) => Revenue.fromJson(x))),
    datas: List<DataElement>.from(json["Datas"].map((x) => DataElement.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "REVENUE": List<dynamic>.from(revenue!.map((x) => x.toJson())),
    "Datas": List<dynamic>.from(datas!.map((x) => x.toJson())),
  };
}

class DataElement {
  DataElement({
    this.id,
    this.paymentType,
    this.totalAmount,
    this.source,
    this.recCreDate,
    this.serviceDetails,
    this.isChecked,
  });

  String? id;
  String? paymentType;
  double? totalAmount;
  String? source;
  DateTime ?recCreDate;
  ServiceDetail ?serviceDetails;
  bool ?isChecked;

  factory DataElement.fromJson(Map<String, dynamic> json) => DataElement(
    id: json["_id"],
    paymentType: json["paymentType"],
    totalAmount: json["totalAmount"].toDouble(),
    source: json["source"],
    isChecked: false,
    recCreDate: DateTime.parse(json["recCreDate"]),
    serviceDetails:ServiceDetail.fromJson(json["serviceDetail"]??[]),
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "paymentType": paymentTypeValues.reverse[paymentType],
    "totalAmount": totalAmount,
    "source": sourceValues.reverse[source],
    "recCreDate": recCreDate!.toIso8601String(),
   "serviceDetails": serviceDetails!.toJson(),
   "isChecked": isChecked,
  };
}

enum PaymentType { CREDIT_CARD, CASH, CHECK }

final paymentTypeValues = EnumValues({
  "CASH": PaymentType.CASH,
  "CHECK": PaymentType.CHECK,
  "CREDIT CARD": PaymentType.CREDIT_CARD
});

enum Source { WEBSITE, KIOSK, PORTAL }

final sourceValues = EnumValues({
  "KIOSK": Source.KIOSK,
  "PORTAL": Source.PORTAL,
  "WEBSITE": Source.WEBSITE
});

class Revenue {
  Revenue({
    this.id,
    this.sum,
    this.min,
    this.max,
    this.average,
    this.title,
    this.source,
    this.payment,
    this.count,
  });

  dynamic? id;
  double? sum;
  double? min;
  double? max;
  double? average;
  String? title;
  List<Payment>? source;
  List<Payment>? payment;
  int ?count;

  factory Revenue.fromJson(Map<String, dynamic> json) => Revenue(
    id: json["_id"],
    sum: json["sum"].toDouble(),
    min: json["min"].toDouble(),
    max: json["max"].toDouble(),
    average: json["Average"].toDouble(),
    title: json["title"],
    source: List<Payment>.from(json["source"].map((x) => Payment.fromJson(x))),
    payment: List<Payment>.from(json["payment"].map((x) => Payment.fromJson(x))),
    count: json["count"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "sum": sum,
    "min": min,
    "max": max,
    "Average": average,
    "title": title,
    "source": List<dynamic>.from(source!.map((x) => x.toJson())),
    "payment": List<dynamic>.from(payment!.map((x) => x.toJson())),
    "count": count,
  };
}

class Payment {
  Payment({
    this.id,
    this.count,
    this.avg,
    this.sum,
    this.min,
    this.max,
  });

  String? id;
  int? count;
  double? avg;
  double? sum;
  double? min;
  int? max;

  factory Payment.fromJson(Map<String, dynamic> json) => Payment(
    id: json["_id"],
    count: json["count"],
    avg: json["avg"].toDouble(),
    sum: json["sum"].toDouble(),
    min: json["min"].toDouble(),
    max: json["max"],
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "count": count,
    "avg": avg,
    "sum": sum,
    "min": min,
    "max": max,
  };
}

class EnumValues<T> {
  Map<String, T>? map;
  Map<T, String>? reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    if (reverseMap == null) {
      reverseMap = map!.map((k, v) => new MapEntry(v, k));
    }
    return reverseMap!;
  }
}
class ServiceDetail {
  ServiceDetail({
    this.id,
    this.memberId,
    this.customerEmail,
    this.customerPhone,
    this.priestName,
    this.priestEmail,
    this.priestPhone,
    this.serviceDate,
    this.requestDate,
    this.serviceTime,
    this.serviceLocationName,
    this.serviceSetup,
    this.serviceAmount,
    this.serviceTypes,
    this.serviceCategoryTypes,
    this.notes,
    this.languagePreferenceName,
    this.notificationEmailName,
    this.aspectType,
    this.serviceStatus,
    this.source,
    this.customerName,

  });

  String ?id;
  String ?memberId;
  String ?customerEmail;
  String ?customerPhone;
  String ?priestName;
  String ?priestEmail;
  String ?priestPhone;
  String ?serviceDate;
  String ?requestDate;
  String ?serviceTime;
  String ?serviceLocationName;
  String ?serviceSetup;
  var  serviceAmount;
  String ?serviceTypes;
  String ?serviceCategoryTypes;
  String ?notes;
  String ?languagePreferenceName;
  String ?notificationEmailName;
  String ?aspectType;
  String ?serviceStatus;
  String ?source;
  String ?customerName;

  factory ServiceDetail.fromJson(Map<String, dynamic> json) => ServiceDetail(
    id: json["_id"]??"",
    memberId: json["memberId"]??"",
    customerEmail: json["customerEmail"]??"",
    customerPhone: json["customerPhone"]??"",
    priestName: json["priestName"]??"",
    priestEmail: json["priestEmail"]??"",
    priestPhone: json["priestPhone"]??"",
    serviceDate: json["serviceDate"]??"",
    requestDate: json["requestDate"]??"",
    serviceTime: json["serviceTime"]??"",
    serviceLocationName: json["serviceLocationName"]??"",
    serviceSetup: json["ServiceSetup"]??"",
    serviceAmount: json["serviceAmount"]??"0.00",
    serviceTypes: json["serviceTypes"]??"",
    serviceCategoryTypes: json["serviceCategoryTypes"]??"",
    notes: json["notes"]??"",
    languagePreferenceName: json["languagePreferenceName"]??"",
    notificationEmailName: json["notificationEmailName"]??"",
    aspectType: json["aspectType"]??"",
    serviceStatus: json["serviceStatus"]??"",
    source: json["source"]??"",
    customerName: json["customerName"]??""
  );

  Map<String, dynamic> toJson() => {
    "_id": id,
    "memberId": memberId,
    "prsnEmail": customerEmail,
    "prsnPhone": customerPhone,
    "priestName": priestName,
    "priestEmail": priestEmail,
    "priestPhone": priestPhone,
    "serviceDate": serviceDate,
    "requestDate": requestDate,
    "serviceTime": serviceTime,
    "serviceLocationName": serviceLocationName,
    "ServiceSetup": serviceSetup,
    "serviceAmount": serviceAmount,
    "serviceTypes": serviceTypes,
    "serviceCategoryTypes": serviceCategoryTypes,
    "notes": notes,
    "languagePreferenceName": languagePreferenceName,
    "notificationEmailName": notificationEmailName,
    "aspectType": aspectType,
    "serviceStatus": serviceStatus,
    "source": source,
    "customerName": customerName,
  };
}
