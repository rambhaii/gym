import 'dart:convert';
import 'dart:math';
import 'package:aspgen_mobile/Dashboard/Menu/Model/MenuData.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
import '../model/ExpenseModel.dart';
import '../model/RevenueModel.dart';
import '../model/ServicesModel.dart';
import '../model/TopBottomFrequent.dart';

class ServiceAnalyticController extends GetxController{
  final String title;
  ServiceAnalyticController(this.title):super();
  var selectedCategory="".obs;
  var setectedType="".obs;
  var setectedStatus="".obs;
  var message="".obs;

  RxBool isExpend1=false.obs;
  RxBool isExpend2=false.obs;
  RxBool isExpend3=false.obs;
  RxInt isSelected=0.obs;

  RxString rxYear=DateTime.now().year.toString().obs;
  RxString rxServiceDate="Select Date Range".obs;
  var pickedRangeDate;
  RxString startDate="".obs;
  RxString endDate="".obs;
  var selectedYear;
  final DateFormat formatter = DateFormat('MMM dd , yyyy');
  final DateFormat formatter1 = DateFormat('MM/dd/yyyy');
  var selectedMonth;
  DateFormat formattera = DateFormat('yyyy-MM-dd');
  List<Color> colorList=[
    Colors.amber, Colors.greenAccent, Colors.deepPurpleAccent, Colors.pink, Colors.deepPurple, Colors.cyanAccent, Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,

  ];
  RxList<Map> yesrList = [
    {"name": "2020", "startDate": "2020-01-01", "endDate": "2020-12-31"},
    {"name": "2021", "startDate": "2021-01-01", "endDate": "2021-12-31"},
    {"name": "2022", "startDate": "2022-01-01", "endDate": "2022-12-31"},
    {"name": "2023", "startDate": "2023-01-01", "endDate": "2023-12-31"},
    {"name": "2024", "startDate": "2024-01-01", "endDate": "2024-12-31"},
    {"name": "2025", "startDate": "2025-01-01", "endDate": "2025-12-31"},
  ].obs;

  RxList<Map> monthList = [
    {
      "name": "January",
      "month": 01,
      "startDate": "-01-01",
      "endDate": "-01-31"
    },
    {
      "name": "February",
      "month": 02,
      "startDate": "-02-01",
      "endDate": "-02-28"
    },
    {"name": "March", "month": 03, "startDate": "-03-01", "endDate": "-03-31"},
    {"name": "April", "month": 04, "startDate": "-04-01", "endDate": "-04-30"},
    {"name": "May", "month": 05, "startDate": "-05-01", "endDate": "-05-31"},
    {"name": "June", "month": 06, "startDate": "-06-01", "endDate": "-06-30"},
    {"name": "July", "month": 07, "startDate": "-07-01", "endDate": "-07-31"},
    {"name": "August", "month": 08, "startDate": "-08-01", "endDate": "-08-31"},
    {
      "name": "September",
      "month": 09,
      "startDate": "-09-01",
      "endDate": "-09-30"
    },
    {
      "name": "October",
      "month": 10,
      "startDate": "-10-01",
      "endDate": "-10-31"
    },
    {
      "name": "November",
      "month": 11,
      "startDate": "-11-01",
      "endDate": "-11-30"
    },
    {
      "name": "December",
      "month": 12,
      "startDate": "-12-01",
      "endDate": "-12-31"
    },
  ].obs;
  var serviceModel=ServicesModel().obs;
  var serviceCategoryModel=ServicesModel().obs;
  RxList<String> caltegoryList=   RxList<String>([]);
  RxList<String> typeList= RxList<String>([]);
  RxList<Map> menuList= RxList<Map>([
    {"name":"MAX","status":false},
    {"name":"MIN","status":false},
    {"name":"AVERAGE","status":false},
    {"name":"TOP 10","status":false},
    {"name":"BOTTOM 10","status":false},
    {"name":"MOST FREQUENTLY USED","status":false},


  ]);
  RxList<String> selectedMenu=RxList<String>([]);
  RxList<ServiceDatum> serviceDatum=RxList<ServiceDatum>([]);
  RxList<ServiceDatum> filterServiceDatum=RxList<ServiceDatum>([]);
  RxList<ServiceDatum> categoryServiceDatum=RxList<ServiceDatum>([]);
  RxList<ServiceDatum> categoryfilterServiceDatum=RxList<ServiceDatum>([]);
  var topBottomFrequent=TopBottomFrequent().obs;
  TextEditingController etSearch= new TextEditingController();
  var bodyJson={};
  @override
  void onInit() {
    startDate.value="2022-01-01";
    endDate.value=formattera.format(DateTime.now());
    selectedYear=yesrList[2];
    getServiceAnalyticApi();

    super.onInit();
  }

  getServiceAnalyticApi()async{
    bodyJson = {
      "clientId":AppConstant.sharedPreference.getString(AppConstant.clientId),
      "startDate": startDate.value,
      "endDate":endDate.value,
    if(title=="BOOKINGS")  "query": {
      "\$or": [
      {
      "serviceCategoryTypes": "IN-TEMPLE"
      }, {
      "serviceCategoryTypes": "AWAY-TEMPLE"
      },
      ]
      },
      if(title=="SERVICES")  "query": {
        "\$or": [
          {
            "serviceCategoryTypes": "RENTAL"
          }, {
            "serviceCategoryTypes": "IN-TEMPLE"
          },{
            "serviceCategoryTypes": "EVENTS"
          },{
            "serviceCategoryTypes": "AWAY-TEMPLE"
          },{
            "serviceCategoryTypes": "SHARDAM"
          },
        ]
      },
      if(title=="DONATIONS")  "query": {
        "\$or": [
          {
            "serviceCategoryTypes": "DONATIONS"
          },
        ]
      },
      if(title=="OPERATIONS")  "query": {
        "\$or": [
          {
            "serviceCategoryTypes": "DAILY ORDERS"
          }, {
            "serviceCategoryTypes": "CATERING ORDERS"
          },
        ]
      }

    };
    print("dfjkdk");
    print(bodyJson);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.serviceBookingData, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print("ereterte");
    print(response);
    if(jsonDecode(response)["statusCode"].toString()=="-1") {
      serviceModel.value=ServicesModel();
      serviceDatum.value=[];
      filterServiceDatum.value=[];
      Get.snackbar("No Data!", jsonDecode(response)["message"].toString(),snackPosition: SnackPosition.TOP,borderRadius: 2,backgroundGradient:
      LinearGradient(colors: [Colors.amber,Colors.amber,Colors.black12]),
          icon: Icon(Icons.warning)
      );
      return;
    };
    serviceModel.value=servicesModelFromJson(response);
    serviceDatum.value=serviceModel.value.data!.datas!;
    filterServiceDatum.value=serviceModel.value.data!.datas!;
    getTopBottomFrequently();
  }

  getTopBottomFrequently()async{
    bodyJson = {
      "clientId":AppConstant.sharedPreference.getString(AppConstant.clientId),
      "startDate": startDate.value,
      "endDate":endDate.value,
      if(title=="BOOKINGS")  "query": {
        "\$or": [
          {
            "serviceCategoryTypes": "IN-TEMPLE"
          }, {
            "serviceCategoryTypes": "AWAY-TEMPLE"
          },
        ]
      },
      if(title=="SERVICES")  "query": {
        "\$or": [
          {
            "serviceCategoryTypes": "RENTAL"
          }, {
            "serviceCategoryTypes": "IN-TEMPLE"
          },{
            "serviceCategoryTypes": "EVENTS"
          },{
            "serviceCategoryTypes": "AWAY-TEMPLE"
          },{
            "serviceCategoryTypes": "SHARDAM"
          },
        ]
      },
      if(title=="DONATIONS")  "query": {
        "\$or": [
          {
            "serviceCategoryTypes": "DONATIONS"
          },
        ]
      },
      if(title=="OPERATIONS")  "query": {
        "\$or": [
          {
            "serviceCategoryTypes": "DAILY ORDERS"
          }, {
            "serviceCategoryTypes": "CATERING ORDERS"
          },
        ]
      }

    };
    print("dfjkdk");
    print(bodyJson);
    var response=await BaseClient().post(APIsConstant.bootomSponsorServices, bodyJson).catchError(BaseController().handleError);
    print("ereterte");
    print(response);
    if(jsonDecode(response)["statusCode"].toString()=="-1") {
      Get.snackbar("No Data!", jsonDecode(response)["message"].toString(),snackPosition: SnackPosition.TOP,borderRadius: 2,backgroundGradient:
      LinearGradient(colors: [Colors.amber,Colors.amber,Colors.black12]),
          icon: Icon(Icons.warning)
      );
      return;
    };
    topBottomFrequent.value=topBottomFrequentFromJson(response);
  }



  getServiceAnalyticByCategoryApi(String category)async{
    bodyJson = {
      "clientId":AppConstant.sharedPreference.getString(AppConstant.clientId),
      "startDate": startDate.value,
      "endDate":endDate.value,
      "query": {
        "\$or": [
          {
            "serviceCategoryTypes": category
          }
          ]
      },

    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.serviceBookingDataByCategory, bodyJson).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(jsonDecode(response)["statusCode"].toString()=="-1") {
      serviceCategoryModel.value=ServicesModel();
      categoryServiceDatum.value=[];
      categoryfilterServiceDatum.value=[];
      Get.snackbar("No Data!", jsonDecode(response)["message"].toString(),snackPosition: SnackPosition.TOP,borderRadius: 2,backgroundGradient:
      LinearGradient(colors: [Colors.amber,Colors.amber,Colors.black12]),
          icon: Icon(Icons.warning)
      );
      return;
    };
    serviceCategoryModel.value=servicesModelFromJson(response);
    categoryServiceDatum.value=serviceCategoryModel.value.data!.datas!;
    categoryfilterServiceDatum.value=serviceCategoryModel.value.data!.datas!;
  }




  getCategory()async{
    var request={};
    request["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "serviceCategoryTypes",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "serviceCategoryTypes"},
      "skip":0,
      "next":400
    };
    var response=await BaseClient().post(APIsConstant.filterAPI, request).catchError(BaseController().handleError);
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    print("bvkhbvdks");
    print(response);
    jsonDecode(response)["data"].forEach((element) {
      caltegoryList.value.add(element["refDataName"]);
    });
    caltegoryList.refresh();
  }
  getType(String refdata)async{
    var request={};
    request["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "serviceTypes",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "serviceTypes","refDataCode":refdata},
      "skip":0,
      "next":1000
    };
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, request).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;

    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      typeList.value.add(element["refDataName"]);
    });
    typeList.refresh();
  }
  void filterData(String search){
    List<ServiceDatum> result=[];
    if(search.isEmpty)
    {
      result=serviceDatum.value;
    }
    else{
      result=serviceDatum.value.where((element) =>element.serviceCategoryTypes.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    filterServiceDatum.value=result;
  }
  void categoryfilterData(String search){
    List<ServiceDatum> result1=[];
    if(search.isEmpty)
    {
      result1=categoryServiceDatum.value;
    }
    else{
      result1=categoryServiceDatum.value.where((element) =>element.serviceTypes.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    categoryfilterServiceDatum.value=result1;
  }
}