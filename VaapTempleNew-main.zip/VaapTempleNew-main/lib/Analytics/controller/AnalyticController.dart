import 'dart:convert';
import 'dart:math';
import 'package:aspgen_mobile/Dashboard/Menu/Model/MenuData.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import '../../../AppConstant/APIsConstant.dart';
import '../../../AppConstant/AppConstant.dart';
import '../../../UtilMethods/BaseController.dart';
import '../../../UtilMethods/base_client.dart';
import '../model/ExpenseModel.dart';
import '../model/RevenueModel.dart';

class AnalyticController extends GetxController {
  AnalyticController(this.titile);
  final String titile;


  var selectedCategory="FINANCIALS".obs;
  RxInt selectedSource=0.obs;
  var expenseCategory="".obs;
  var setectedType="".obs;

  var message="".obs;
  RxString rxYear=DateTime.now().year.toString().obs;
  RxString rxServiceDate="Select Date Range".obs;
  var pickedRangeDate;
  RxString startDate="".obs;
  RxString endDate="".obs;
  var selectedYear;
  var selectedMonth;
  RxList<Map> menuList= RxList<Map>([
    {"name":"MAX","status":false},
    {"name":"MIN","status":false},
    {"name":"AVERAGE","status":false},

  ]);

  DateFormat formattera = DateFormat('yyyy-MM-dd');
  var piePaySouList={"PAYMENTS","SOURCE"};
  List<Color> colorList=[];
  List<Color> colorListPayment=[
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,

  ];
  List<Color> colorListSource=[
    Color(0xfffa5468),
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,
    Colors.amber,
    Colors.greenAccent,
    Colors.deepPurpleAccent,
    Colors.pink,
    Colors.deepPurple,
    Colors.cyanAccent,

  ];
  RxString radioPiePaySouValue="PAYMENTS".obs;
  RxString radioRevenuExpenses="REVENUE".obs;
  RxList<String> caltegoryList=   RxList<String>(["FINANCIALS","OPERATIONS","BOOKINGS"]);
  RxList<String> filterListCategory=   RxList<String>(["PAYMENTS","SOURCE"]);
  RxList<String> financilaSubTypeList=   RxList<String>(["FINANCIALS","OPERATIONS","BOOKINGS"]);

   RxList<Map> yesrList = [
  {"name": "2020", "startDate": "2020-01-01", "endDate": "2020-12-31"},
  {"name": "2021", "startDate": "2021-01-01", "endDate": "2021-12-31"},
  {"name": "2022", "startDate": "2022-01-01", "endDate": "2022-12-31"},
  {"name": "2023", "startDate": "2023-01-01", "endDate": "2023-12-31"},
  {"name": "2024", "startDate": "2024-01-01", "endDate": "2024-12-31"},
  {"name": "2025", "startDate": "2025-01-01", "endDate": "2025-12-31"},
  ].obs;

  RxList<Map> monthList = [
    {
      "name": "January",
      "month": 01,
      "startDate": "-01-01",
      "endDate": "-01-31"
    },
    {
      "name": "February",
      "month": 02,
      "startDate": "-02-01",
      "endDate": "-02-28"
    },
    {"name": "March", "month": 03, "startDate": "-03-01", "endDate": "-03-31"},
    {"name": "April", "month": 04, "startDate": "-04-01", "endDate": "-04-30"},
    {"name": "May", "month": 05, "startDate": "-05-01", "endDate": "-05-31"},
    {"name": "June", "month": 06, "startDate": "-06-01", "endDate": "-06-30"},
    {"name": "July", "month": 07, "startDate": "-07-01", "endDate": "-07-31"},
    {"name": "August", "month": 08, "startDate": "-08-01", "endDate": "-08-31"},
    {
      "name": "September",
      "month": 09,
      "startDate": "-09-01",
      "endDate": "-09-30"
    },
    {
      "name": "October",
      "month": 10,
      "startDate": "-10-01",
      "endDate": "-10-31"
    },
    {
      "name": "November",
      "month": 11,
      "startDate": "-11-01",
      "endDate": "-11-30"
    },
    {
      "name": "December",
      "month": 12,
      "startDate": "-12-01",
      "endDate": "-12-31"
    },
  ].obs;


  final DateFormat formatter = DateFormat('MMM dd , yyyy');
  final DateFormat formatter1 = DateFormat('MM/dd/yyyy');

  //  Revenue
  var revenuModel= RevenueModel().obs;
  RxList<DataElement> revenueDatum=RxList<DataElement>([]);
  RxList<DataElement> filterRevenueDatum=RxList<DataElement>([]);
 
  // Expenses
  var expensesModel= ExpenseModel().obs;
  RxList<ExpensesDatum> expensesDatum=RxList<ExpensesDatum>([]);
  RxList<ExpensesDatum> filterExpensesDatum=RxList<ExpensesDatum>([]);
  RxList<String> expensesCaltegoryList=   RxList<String>([]);

  TextEditingController etSearch= new TextEditingController();
  var bodyJson={};
  @override
  void onInit() {
      startDate.value="2022-01-01";
     endDate.value=formattera.format(DateTime.now());
    // TODO: implement onInit
    getManagementRevenueData();
      selectedYear=yesrList[2];
    super.onInit();
  }

  var QUERY=[{"source": "WEBSITE"}, {"source": "KIOSK"}, {"source": "PORTAL"}];
  getManagementRevenueData()async{
     bodyJson = {
      "clientId":AppConstant.sharedPreference.getString(AppConstant.clientId),
      "startDate": startDate.value,
      "endDate":endDate.value,
      "query": {"\$or": QUERY
      }
    };
     print("@@@@@@@@");
     print(bodyJson);
     Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getRevenueAnalytics, bodyJson).catchError(BaseController().handleError);
     Get.context!.loaderOverlay.hide();
    if(response==null) return;
     if(jsonDecode(response)["statusCode"].toString()=="-1") {
       revenuModel.value=RevenueModel();
       revenueDatum.value=[];
       filterRevenueDatum.value=[];
      Get.snackbar("No Data!", jsonDecode(response)["message"].toString(),snackPosition: SnackPosition.TOP,borderRadius: 2,backgroundGradient:
      LinearGradient(colors: [Colors.amber,Colors.amber,Colors.black12]),
        icon: Icon(Icons.warning)
      );

     };
    try{
      print("vbjkdfjkdfukl");
      print(response);
       revenuModel.value=revenueModelFromJson(response);
       revenueDatum.value=revenuModel.value.data!.datas!;
       filterRevenueDatum.value=revenuModel.value.data!.datas!;
     }
     catch(e){

     }
  }


  getManagementExpensesData()async{
  var jsonrequest = {
      "clientId":AppConstant.sharedPreference.getString(AppConstant.clientId),
      "startDate": startDate.value,
      "endDate":endDate.value,
      "query":expenseCategory.value.isNotEmpty? {"expenseCategory":expenseCategory.value}:{},
    };
    print("ssdvkbdshkv");
    print(jsonrequest);
    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.getExpenseAnalytics, jsonrequest).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
        print("zvsdvdfbfdbfd");
        print(response);
    if(jsonDecode(response)["statusCode"].toString()=="-1") {
      expensesModel.value=ExpenseModel();
      expensesDatum.value=[];
      filterExpensesDatum.value=[];
      Get.snackbar("No Data!", jsonDecode(response)["message"].toString(),snackPosition: SnackPosition.TOP,borderRadius: 2,backgroundGradient:
      LinearGradient(colors: [Colors.amber,Colors.amber,Colors.black12]),
          icon: Icon(Icons.warning)
      );

    };
    try{
      expensesModel.value=expenseModelFromJson(response);
      expensesDatum.value=expensesModel.value.data!.datas!;
      filterExpensesDatum.value=expensesModel.value.data!.datas!;
      colorList.clear();
      expensesDatum.value.forEach((element) {
        colorList.add(Colors.primaries[Random().nextInt(Colors.primaries.length)]);
      });
    }catch(e){

    }
  }
  void filterData(String search){
    List<DataElement> result=[];
    if(search.isEmpty)
    {
      result=filterRevenueDatum.value;
    }
    else{
      result=filterRevenueDatum.value.where((element) =>element.paymentType.toString().toLowerCase().contains(search.toString().toLowerCase())||element.source.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    revenueDatum.value=result;
  }

  void expensesFilterData(String search){
    List<ExpensesDatum> result=[];
    if(search.isEmpty)
    {
      result=filterExpensesDatum.value;
    }
    else{
      result=filterExpensesDatum.value.where((element) =>element.expenseCategory.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    expensesDatum.value=result;
  }


  getCategory()async{
    expensesCaltegoryList.clear();
    var catrequest={};
    catrequest["componentConfig"]={
      "moduleName":"Master Data Management",
      "aspectType": "expenseCategory",
      "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
      "userName": AppConstant.sharedPreference.getString(AppConstant.userName),
      "query":{ "aspectType": "expenseCategory"},
      "skip":0,
      "next":400
    };

    Get.context!.loaderOverlay.show();
    var response=await BaseClient().post(APIsConstant.filterAPI, catrequest).catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    if(response==null) return;
    if(jsonDecode(response)["statusCode"].toString()=="-1") return;
    jsonDecode(response)["data"].forEach((element) {
      expensesCaltegoryList.value.add(element["refDataName"]);
    });
    expensesCaltegoryList.refresh();
  }


}