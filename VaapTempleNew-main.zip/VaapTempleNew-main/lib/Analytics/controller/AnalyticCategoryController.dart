import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../view/AnalyticPage.dart';
import '../view/ServicesAnalytics.dart';

class AnalyticCategoryController extends GetxController{

  Rx<TextEditingController> etSearch= new TextEditingController().obs;
  RxList<String> AnalyticList=[
    "BOOKINGS",
    "DONATIONS",
    "SERVICES",
    "FINANCIALS",
    "OPERATIONS",
  ].obs;
  List<String> filterAnalyticList=[
    "BOOKINGS",
    "DONATIONS",
    "SERVICES",
    "FINANCIALS",
    "OPERATIONS",
  ];
  filterData(String search){
    List<String> result=[];
    if(search.isEmpty)
    {
      result=filterAnalyticList;
    }
    else{
      result=filterAnalyticList.where((element) =>element.toString().toLowerCase().contains(search.toString().toLowerCase())).toList();
    }
    AnalyticList.value=result;
  }
  getRoute(String value){
    switch(value){
      case "FINANCIALS":
       Get.to(()=>AnalyticPage(title: value));
        break;
        case "BOOKINGS":
       Get.to(()=>ServicesAnalyticPage(title: value));
        break;
   case "SERVICES":
       Get.to(()=>ServicesAnalyticPage(title: value));
        break;
        case "DONATIONS":
       Get.to(()=>ServicesAnalyticPage(title: value));
        break; case "OPERATIONS":
       Get.to(()=>ServicesAnalyticPage(title: value));
        break;


    }
  }
}