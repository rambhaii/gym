import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListshowOnly.dart';
import '../controller/AnalyticController.dart';


class FinancilaListPage extends StatefulWidget {
  final String title;
  FinancilaListPage({Key? key,required this.title}) : super(key: key);
  @override
  State<FinancilaListPage> createState() => _FinancilaListPageState();
}

class _FinancilaListPageState extends State<FinancilaListPage> {


  AnalyticController controller=Get.find();

  @override
  void initState(){
   controller.filterData(widget.title);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            widget.title,
            textAlign: TextAlign.center,
          ),
        ),
        body:Obx(() => controller.revenueDatum.value!=null? ListView.builder(
            shrinkWrap: true,
            padding: EdgeInsets.only(top: 6),
            itemCount: controller.revenueDatum.value.length,
            itemBuilder: (context, index) {
              final datas=controller.revenueDatum[index];
              return CustomListShowOnlyWidget(title:datas.serviceDetails!.serviceSetup!??"",
                subTitle:amountParser(datas.serviceDetails!.serviceAmount!.toString()) ,
                subTitle2: dateParser(datas.serviceDetails!.serviceDate!.toString()),
                viewMoreWidget: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children:[
                      if(datas.serviceDetails!.customerName!.isNotEmpty)  Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                      if(datas.serviceDetails!.customerName!.isNotEmpty) viewMore("Devotee Name  ",datas.serviceDetails!.customerName.toString()??""),
                      if(datas.serviceDetails!.customerPhone!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                      if(datas.serviceDetails!.customerPhone!.isNotEmpty) viewMore("Phone  ",phoneFormatter(datas.serviceDetails!.customerPhone!).toString()??""),
                      if(datas.serviceDetails!.customerEmail!.toString().isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.3),),
                      if(datas.serviceDetails!.customerEmail!.toString().isNotEmpty) viewMore("Email ",UtilMethods.decrypt(datas.serviceDetails!.customerEmail!).toString()??""),
                    ]),
                textEditingController: controller.etSearch,
                isClicked: datas.isChecked!??false,
                onTapVieMore: (){
                  datas.isChecked=!datas.isChecked!;
                  controller.revenueDatum.refresh();
                },
                editOnTap: (){

                },
              );

            }):Container()
        )

    );
  }




}

