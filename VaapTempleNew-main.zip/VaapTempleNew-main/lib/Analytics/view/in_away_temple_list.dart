
import 'dart:convert';
import 'dart:math';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListshowOnly.dart';


import '../controller/ServicesController.dart';

class InAwayTempleListPage extends StatefulWidget {
  final String title;
  final int type;//1 for services
  InAwayTempleListPage({Key? key,required this.title, required this.type}) : super(key: key);
  @override
  State<InAwayTempleListPage> createState() => _InAwayTempleListPageState();
}

class _InAwayTempleListPageState extends State<InAwayTempleListPage> {


  ServiceAnalyticController controller=Get.find();

  @override
  void initState(){

    if(widget.type==1)
      {
        controller.categoryfilterData(widget.title);
      }
    else{
      controller.filterData(widget.title);
    }


  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title ,
          textAlign: TextAlign.center,
        ),
      ),
      body:widget.type==1? Obx(()=>controller.categoryfilterServiceDatum!=null? ListView.builder(
          shrinkWrap: true,
          padding: EdgeInsets.only(top: 6),
          itemCount: controller.categoryfilterServiceDatum.length,
          itemBuilder: (context, index) {
            final datas=controller.categoryfilterServiceDatum[index];
            return CustomListShowOnlyWidget(title: datas.serviceSetup??"",
              subTitle:amountParser(datas.serviceAmount.toString()) ,
              subTitle2: dateParser(datas.serviceDate.toString()),
              viewMoreWidget: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children:[
                    if(datas.customerName!.isNotEmpty)  Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                    if(datas.customerName!.isNotEmpty) viewMore("Devotee Name  ",datas.customerName.toString()??""),
                    if(datas.customerPhone!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                    if(datas.customerPhone!.isNotEmpty) viewMore("Phone  ",phoneFormatter(datas.customerPhone!).toString()??""),
                    if(datas.customerEmail!.toString().isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.3),),
                    if(datas.customerEmail!.toString().isNotEmpty) viewMore("Email ",UtilMethods.decrypt(datas.customerEmail!).toString()??""),
                  ]),
              textEditingController: controller.etSearch,isClicked: datas.isChecked!??false,
              onTapVieMore: (){
                datas.isChecked=!datas.isChecked!;
                controller.categoryfilterServiceDatum.refresh();
              },
              editOnTap: (){

              },
            );

          }):
      Container()):Obx(()=>controller.filterServiceDatum!=null? ListView.builder(
          shrinkWrap: true,
          padding: EdgeInsets.only(top: 6),
          itemCount: controller.filterServiceDatum.length,
          itemBuilder: (context, index) {
            final datas=controller.filterServiceDatum[index];
          
            return CustomListShowOnlyWidget(title: datas.serviceSetup??"",
              subTitle:amountParser(datas.serviceAmount.toString()) ,
              subTitle2: dateParser(datas.serviceDate.toString()),
              viewMoreWidget: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children:[
                    if(datas.customerName!.isNotEmpty)  Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                    if(datas.customerName!.isNotEmpty) viewMore("Devotee Name  ",datas.customerName.toString()??""),
                    if(datas.customerPhone!.isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                    if(datas.customerPhone!.isNotEmpty) viewMore("Phone  ",phoneFormatter(datas.customerPhone!).toString()??""),
                    if(datas.customerEmail!.toString().isNotEmpty) Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.3),),
                    if(datas.customerEmail!.toString().isNotEmpty) viewMore("Email ",UtilMethods.decrypt(datas.customerEmail!).toString()??""),
                  ]),
              textEditingController: controller.etSearch,isClicked: datas.isChecked!??false,
              onTapVieMore: (){
                datas.isChecked=!datas.isChecked!;
                controller.filterServiceDatum.refresh();
              },
              editOnTap: (){

              },
            );

          }):Container(),
      ),
    );
  }




}

