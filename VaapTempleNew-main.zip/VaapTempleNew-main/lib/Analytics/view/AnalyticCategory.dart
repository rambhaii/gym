
import 'package:aspgen_mobile/Analytics/controller/AnalyticCategoryController.dart';
import 'package:aspgen_mobile/Dashboard/Inquiry/controller/InquiryController.dart';

import 'package:aspgen_mobile/Widget/SelectionTypeWidget.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../Widget/SearchBarWidget.dart';

class AnalyticCategoryPage extends StatelessWidget {
  final String title;
   AnalyticCategoryPage({Key? key,required this.title}) : super(key: key);
  AnalyticCategoryController _controller=Get.put(AnalyticCategoryController());
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text("Select "+"Business Area"),
      ),
      body: Padding(
        padding: const EdgeInsets.only(top:8.0),
        child: Column(
          children: [
            Obx(()=> SearchBarWidget(
                hint: "Search ",
                controller:_controller.etSearch.value,
                onchange: (value){
                  _controller.filterData(value.toString());
                  },
                onCancel: (){
                  _controller.etSearch.value.clear();
                 _controller.filterData(_controller.etSearch.value.text);
                },
              ),
            ),
            SizedBox(height: 6,),
           Obx(() => _controller.AnalyticList.value!=null?Expanded(
                child: ListView.builder(
                    itemCount:_controller.AnalyticList.value.length,
                    itemBuilder: (context,index)
                    {
                      return SelectionTypeWidget(title: _controller.AnalyticList.value[index]??"", onTap: (){
                        _controller.getRoute( _controller.AnalyticList.value[index]);
                      });
                    }),
              ):Container(),
            )
              ,

          ],
        ),
      ),
    );
  }
}

