
import 'dart:convert';
import 'dart:math';
import 'package:aspgen_mobile/Analytics/model/ServicesModel.dart';
import 'package:aspgen_mobile/Analytics/view/in_away_temple_list.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';

import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListshowOnly.dart';


import '../controller/ServicesController.dart';

class ServiceCategoryListPage extends StatefulWidget {
  final String title;
  ServiceCategoryListPage({Key? key,required this.title}) : super(key: key);
  @override
  State<ServiceCategoryListPage> createState() => _ServiceCategoryListPageState();
}

class _ServiceCategoryListPageState extends State<ServiceCategoryListPage> {


  ServiceAnalyticController controller=Get.find();

  @override
  void initState(){
    controller.serviceCategoryModel.value=ServicesModel();
   controller.getServiceAnalyticByCategoryApi(widget.title);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title,
          textAlign: TextAlign.center,
        ),
      ),
      body:Obx(()=>controller.serviceCategoryModel.value.data!=null? Column(
          children: List.generate(controller.serviceCategoryModel.value.data!.serviceDetailType!.length, (index) =>
        Container(
        margin: EdgeInsets.only(top: 10,left: 10,right: 10),
        decoration: BoxDecoration(
        border: Border.all(color:Colors.grey.withOpacity(0.5),width: 0.5),
        borderRadius: BorderRadius.circular(5),
        color: Theme.of(context).colorScheme.onPrimaryContainer
        ),

    child: ListTile(
    onTap: (){
    Get.to(()=>InAwayTempleListPage(title:controller.serviceCategoryModel.value.data!.serviceDetailType![index].id! ,type: 1,));
    },
    leading:  Container(
    height: 25,
    width: 25,
    decoration: BoxDecoration(
    color: controller.colorList[index],
    borderRadius: BorderRadius.circular(3),
    boxShadow: [
    BoxShadow(
    color:controller.colorList[index].withOpacity(0.3),
    offset: const Offset(
    2.0,
    2.0,
    ),
    blurRadius: 5.0,
    spreadRadius: 1.0,
    ), //BoxShadow
    BoxShadow(
    color: Colors.black.withOpacity(0.3),
    offset: const Offset(-2.0, -2.0),
    blurRadius: 5.0,
    spreadRadius: 1.0,
    ), //B
    ]

    ),
    ),
    title: Text(controller.serviceCategoryModel.value.data!.serviceDetailType![index].id!+" ("+controller.serviceCategoryModel.value.data!.serviceDetailType![index].count!.toString()+") ",style: Theme.of(context).textTheme.bodyText1,),
    trailing:  Text(amountParser(controller.serviceCategoryModel.value.data!.serviceDetailType![index].sum!.toString()),style: Theme.of(context).textTheme.bodyText1,),
    ),
    ),

    )
    ):Container(),
      )
    );
  }




}

