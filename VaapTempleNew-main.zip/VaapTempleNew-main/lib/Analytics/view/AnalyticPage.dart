
import 'dart:convert';
import 'dart:math';
import 'package:aspgen_mobile/Analytics/view/financial_list_page.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'package:intl/intl.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/histroryWidgetRevenue.dart';
import '../controller/AnalyticController.dart';
import 'package:fl_chart/fl_chart.dart';

import 'ExpenseListPage.dart';

class AnalyticPage extends StatefulWidget {
  final String title;
  AnalyticPage({Key? key,required this.title}) : super(key: key);

  @override
  State<AnalyticPage> createState() => _AnalyticPageState();
}

class _AnalyticPageState extends State<AnalyticPage> with TickerProviderStateMixin {
  AnalyticController controller=Get.put(AnalyticController("Menu"));

  final DateFormat formatter = DateFormat('MMM dd , yyyy');
  TabController  ?_tabController;
  TextEditingController etdate= new TextEditingController();



  final formGlobalKey = GlobalKey<FormState>();

  DateTime?tempDate;

  int touchedIndex=-1;
  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2,initialIndex: 0, vsync: this);

  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title ,
          textAlign: TextAlign.center,
        ),

        actions: [
          IconButton(onPressed: (){
            FocusManager.instance.primaryFocus?.unfocus();
            showCustomDialog(context);}, icon: Icon(Icons.filter_alt_outlined)),

          PopupMenuButton<String>(
              child: Icon(Icons.more_vert_outlined),
              color: Theme.of(context).colorScheme.onPrimaryContainer.withRed(3),
              offset: Offset(10, 50),
              elevation: 5,
              itemBuilder: (context) => [
                PopupMenuItem(
                  padding: EdgeInsets.all(0),
                  child:Obx(()=> Column(
                      children: List.generate(controller.menuList.length, (index) =>
                          ListTileTheme(
                            contentPadding: EdgeInsets.all(0),
                            horizontalTitleGap: 0,
                            child: CheckboxListTile(
                                controlAffinity: ListTileControlAffinity.leading,
                                value: controller.menuList[index]["status"], title:Text(controller.menuList[index]["name"]),onChanged: (value){
                              controller.menuList[index]["status"]=value;
                              controller.menuList.refresh();
                            }),
                          ))
                  ),
                  ),
                  value:"My Profile",
                ),


              ]



          ),
          SizedBox(width: 10,)
        ],

      ),
      body:  SingleChildScrollView(
        child: Obx(()=>Container(
          margin: EdgeInsets.only(top: 8),
              child:  controller.radioRevenuExpenses.value=="REVENUE"?Revenue():Expenses(),
        ),
        ),
      ),
    );
  }

  Widget Revenue(){
    return Column(
      children: [




        if(controller.revenuModel.value.data!=null) Container(
          margin: EdgeInsets.only(left: 10,right: 10),

          height: 40,
          child: TabBar(
            isScrollable: false,
            onTap: (value){
              controller.selectedSource.value=value;
              },
            controller: _tabController,
            labelColor: Colors.black,
            unselectedLabelColor: Colors.white70,
            indicator: BoxDecoration(color: Colors.white,),
            labelStyle: const TextStyle(fontWeight: FontWeight.bold),
            unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w600,),
            overlayColor: MaterialStateColor.resolveWith((Set<MaterialState> states) {
              return Colors.transparent;
            }),
            tabs: List.generate(
              controller.filterListCategory.length,
                  (index) {
                return Tab(child:Text( controller.filterListCategory[index]) ,);
              },
            ),
          ),
        ),
        Container(
            width: Get.width,
          height: 300,
          alignment: Alignment.center,
          child: TabBarView(
            physics: NeverScrollableScrollPhysics(),
              controller: _tabController,
            children:List.generate(controller.filterListCategory.length, (index) {
              return (controller.filterListCategory[index] == "PAYMENTS" || controller.filterListCategory[index] == "SOURCE") ? Obx(() =>
              controller.revenuModel.value.data != null ? Container(
                margin: EdgeInsets.only(right: 10, left: 10),
                padding: EdgeInsets.only(bottom: 8, top: 8),
                decoration: BoxDecoration(
                    color: Theme
                        .of(context)
                        .colorScheme
                        .onPrimaryContainer,

                    border: Border.all(color: Colors.grey.withOpacity(0.8),
                        width: 0.6)
                ),
                child: Column(
                  children: [
                    Container(
                      margin: EdgeInsets.only(top: 15, bottom: 20),
                      height: 240,
                      decoration: BoxDecoration(
                        boxShadow: [
                          BoxShadow(
                            color: Colors.white.withOpacity(0.4),
                            offset: Offset(-3.0, -3.0),
                            blurRadius: 10.0,
                          ),
                          BoxShadow(
                            color: Colors.black.withOpacity(0.1),
                            offset: Offset(3.0, 3.0),
                            blurRadius: 10.0,
                          ),
                        ],
                        color: Theme
                            .of(context)
                            .colorScheme
                            .onPrimaryContainer,
                        shape: BoxShape.circle,
                      ),
                      width: Get.width,
                      child: PieChart(
                        PieChartData(
                            borderData: FlBorderData(
                              show: false,
                            ),
                            sectionsSpace: 1,
                            centerSpaceRadius: 20,
                            sections: showingRevenueChart(
                                100,
                                controller.filterListCategory[index] == "SOURCE"
                                    ? controller.revenuModel.value.data!
                                    .revenue![0].source!
                                    : controller.revenuModel.value.data!
                                    .revenue![0].payment!, "PAYMENTS")),
                        swapAnimationDuration: Duration(milliseconds: 150),
                        swapAnimationCurve: Curves.bounceIn, // Optional
                      ),
                    ),


                  ],
                ),
              ) : Container(),) : Container();
            }
            )
          ),
        ),

        Obx(()=>controller.revenuModel.value.data!=null?
        Container(
          padding: EdgeInsets.only(left: 6,right: 6,top: 10),
          child: Obx(()=> Column(
            children: [
              Row(
                children: [
                  Expanded(flex: 4,child:
                  RevenuWidget("Total ${widget.title[0].toUpperCase()+widget.title.substring(1).toLowerCase()}",controller.revenuModel.value.data!.revenue![0].count.toString(),"assets/images/booking.png")
                  ),  Expanded(flex: 4,child:
                  RevenuWidget("Total Revenue",amountParser(controller.revenuModel.value.data!.revenue![0].sum.toString()) ,"assets/images/revenue.png"),
                  ),

                ],
              ),
              if(controller.menuList[0]["status"]  || controller.menuList[1]["status"] )  SizedBox(height: 10,),
              Row(
                children: [
                  if(controller.menuList[0]["status"])    Expanded(flex: 4,child:
                  RevenuWidget("Min",amountParser(controller.revenuModel.value.data!.revenue![0].min.toString()),"assets/images/dollor.png")),
                  if(controller.menuList[1]["status"])    Expanded(
                      flex: 4,
                      child:
                      RevenuWidget("Max",amountParser(controller.revenuModel.value.data!.revenue![0].max.toString()),"assets/images/dollor.png")),

                ],
              ),
              if(controller.menuList[2]["status"])   SizedBox(height: 10,),
              if(controller.menuList[2]["status"])     Row(
                children: [
                  Expanded(flex: 4,child:
                  RevenuWidget("Average",amountParser(controller.revenuModel.value.data!.revenue![0].average!.toString()),"assets/images/revenue.png")),


                ],
              )
            ],
          ),


        )):Container(),
        ),



        Obx(()=>controller.selectedSource.value==0?controller.revenuModel.value.data!=null?Column(
          children: List.generate(controller.revenuModel.value.data!.revenue![0].payment!.length, (index) =>
              Container(
                margin: EdgeInsets.only(top: 10,left: 10,right: 10),
                decoration: BoxDecoration(
                    border: Border.all(color:Colors.grey.withOpacity(0.5),width: 0.5),
                    borderRadius: BorderRadius.circular(5),
                    color: Theme.of(context).colorScheme.onPrimaryContainer
                ),

                child: ListTile(
                  onTap: (){
                    Get.to(()=>FinancilaListPage(title: controller.revenuModel.value.data!.revenue![0].payment![index].id!,));
                  },
                  leading:  Container(
                    height: 25,
                    width: 25,

                    decoration: BoxDecoration(
                        color: controller.colorListPayment[index],
                        borderRadius: BorderRadius.circular(3),
                        boxShadow: [
                          BoxShadow(
                            color:controller.colorListPayment[index].withOpacity(0.3),
                            offset: const Offset(
                              2.0,
                              2.0,
                            ),
                            blurRadius: 5.0,
                            spreadRadius: 1.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            offset: const Offset(-2.0, -2.0),
                            blurRadius: 5.0,
                            spreadRadius: 1.0,
                          ), //B
                        ]

                    ),

                  ),
                  title: Text(controller.revenuModel.value.data!.revenue![0].payment![index].id!+" ("+controller.revenuModel.value.data!.revenue![0].payment![index].count!.toString()+")",style: Theme.of(context).textTheme.bodyText1,),
                  trailing:  Text(amountParser(controller.revenuModel.value.data!.revenue![0].payment![index].sum!.toString()),style: Theme.of(context).textTheme.bodyText1,),
                ),
              )
          ),
        ):Container()
            :controller.revenuModel.value.data!=null?Column(
          children: List.generate(controller.revenuModel.value.data!.revenue![0].source!.length, (index) =>
              Container(
                margin: EdgeInsets.only(top: 10,left: 10,right: 10),
                decoration: BoxDecoration(
                    border: Border.all(color:Colors.grey.withOpacity(0.5),width: 0.5),
                    borderRadius: BorderRadius.circular(5),
                    color: Theme.of(context).colorScheme.onPrimaryContainer
                ),

                child: ListTile(
                  onTap: (){
                    Get.to(()=>FinancilaListPage(title: controller.revenuModel.value.data!.revenue![0].source![index].id!,));

                  },
                  leading:  Container(
                    height: 25,
                    width: 25,

                    decoration: BoxDecoration(
                        color: controller.colorListSource[index],
                        borderRadius: BorderRadius.circular(3),
                        boxShadow: [
                          BoxShadow(
                            color:controller.colorListSource[index].withOpacity(0.3),
                            offset: const Offset(
                              2.0,
                              2.0,
                            ),
                            blurRadius: 5.0,
                            spreadRadius: 1.0,
                          ), //BoxShadow
                          BoxShadow(
                            color: Colors.black.withOpacity(0.3),
                            offset: const Offset(-2.0, -2.0),
                            blurRadius: 5.0,
                            spreadRadius: 1.0,
                          ), //B
                        ]

                    ),

                  ),
                  title: Text(controller.revenuModel.value.data!.revenue![0].source![index].id!+" ("+controller.revenuModel.value.data!.revenue![0].source![index].count!.toString()+")",style: Theme.of(context).textTheme.bodyText1,),
                  trailing:  Text(amountParser(controller.revenuModel.value.data!.revenue![0].source![index].sum!.toString()),style: Theme.of(context).textTheme.bodyText1,),
                ),
              )
          ),
        ):Container(),
        )
      ],
    );
  }
  Widget Expenses(){
    return Column(
      children: [



        SizedBox(height: 10,),
        Obx(()=>controller.expensesModel.value.data!=null? Container(
          margin: EdgeInsets.only(right:8,left: 8),
          padding: EdgeInsets.only(bottom: 8,top: 8),
          decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.onPrimaryContainer,
              borderRadius: BorderRadius.circular(5),
              border: Border.all(color: Colors.grey.withOpacity(0.8),width: 0.5)
          ),
          child: Column(
            children: [
              Container(
                margin: EdgeInsets.only(top: 8,bottom: 20),
                height: 240,
                decoration: BoxDecoration(
                  boxShadow: [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.4),
                      offset: Offset(-3.0, -3.0),
                      blurRadius: 10.0,
                    ),
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      offset: Offset(3.0, 3.0),
                      blurRadius: 10.0,
                    ),
                  ],
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                  shape: BoxShape.circle,
                ),
                width: Get.width,
                child: PieChart(
                  PieChartData(
                      borderData: FlBorderData(
                        show: false,
                      ),
                      sectionsSpace: 1,
                      centerSpaceRadius: 20,
                      sections: showingRevenueChart(
                          100,
                        controller.expensesModel.value.data!.expense![0].expenseDetail!, "PAYMENTS")),
                  swapAnimationDuration: Duration(milliseconds: 150),
                  // Optional
                  swapAnimationCurve: Curves.bounceIn, // Optional
                ),
              ),

              Obx(()=>controller.expensesModel.value.data!=null?
              Container(
                  padding: EdgeInsets.only(left: 6,right: 6,top: 10),
                  child: Obx(()=> Column(
                    children: [
                      Row(
                        children: [
                          Expanded(flex: 4,child:
                          RevenuWidget("# ${widget.title[0].toUpperCase()+widget.title.substring(1).toLowerCase()}",controller.expensesModel.value.data!.expense![0].count.toString(),"assets/images/booking.png")
                          ),  Expanded(flex: 4,child:
                          RevenuWidget("Total Revenue",amountParser(controller.expensesModel.value.data!.expense![0].sum.toString()),"assets/images/revenue.png"),
                          ),

                        ],
                      ),
                      if(controller.menuList[0]["status"]  || controller.menuList[1]["status"] )  SizedBox(height: 10,),
                      Row(
                        children: [
                          if(controller.menuList[0]["status"])    Expanded(flex: 4,child:
                          RevenuWidget("Min",amountParser(controller.expensesModel.value.data!.expense![0].min.toString()),"assets/images/dollor.png")),
                          if(controller.menuList[1]["status"])    Expanded(
                              flex: 4,
                              child:
                              RevenuWidget("Max",amountParser(controller.expensesModel.value.data!.expense![0].max.toString()),"assets/images/dollor.png")),
                        ],
                      ),
                      if(controller.menuList[2]["status"])   SizedBox(height: 10,),
                      if(controller.menuList[2]["status"])     Row(
                        children: [
                          Expanded(flex: 4,child:
                          RevenuWidget("Average",amountParser(controller.expensesModel.value.data!.expense![0].average!.toString()),"assets/images/revenue.png")),


                        ],
                      )
                    ],
                  ),


                  )):Container(),
              ),

              Obx(()=>controller.expensesModel.value.data!=null?Column(
                children: List.generate(controller.expensesModel.value.data!.expense![0].expenseDetail!.length, (index) =>
                    Container(
                      margin: EdgeInsets.only(top: 10,left: 10,right: 10),
                      decoration: BoxDecoration(
                          border: Border.all(color:Colors.grey.withOpacity(0.5),width: 0.5),
                          borderRadius: BorderRadius.circular(5),
                          color: Theme.of(context).colorScheme.onPrimaryContainer
                      ),

                      child: ListTile(
                        onTap: (){
                     Get.to(()=>ExpenseListPage(title: controller.expensesModel.value.data!.expense![0].expenseDetail![index].id!,));
                        },
                        leading:  Container(
                          height: 25,
                          width: 25,

                          decoration: BoxDecoration(
                              color: controller.colorListSource[index],
                              borderRadius: BorderRadius.circular(3),
                              boxShadow: [
                                BoxShadow(
                                  color:controller.colorListSource[index].withOpacity(0.3),
                                  offset: const Offset(
                                    2.0,
                                    2.0,
                                  ),
                                  blurRadius: 5.0,
                                  spreadRadius: 1.0,
                                ), //BoxShadow
                                BoxShadow(
                                  color: Colors.black.withOpacity(0.3),
                                  offset: const Offset(-2.0, -2.0),
                                  blurRadius: 5.0,
                                  spreadRadius: 1.0,
                                ), //B
                              ]

                          ),

                        ),
                        title: Text(controller.expensesModel.value.data!.expense![0].expenseDetail![index].id!+" ("+controller.expensesModel.value.data!.expense![0].expenseDetail![index].count!.toString()+")",style: Theme.of(context).textTheme.bodyText1,),
                        trailing:  Text(amountParser(controller.expensesModel.value.data!.expense![0].expenseDetail![index].sum!.toString()),style: Theme.of(context).textTheme.bodyText1,),
                      ),
                    )
                ),
              ):Container()

              ),
              // Obx(() => controller.expensesCaltegoryList.isNotEmpty?GridView.count(crossAxisCount: 2,
             //        shrinkWrap: true,
             //        physics: ClampingScrollPhysics(),
             //       padding: EdgeInsets.only(left: 12,right: 12),
             //        crossAxisSpacing: 0,
             //        mainAxisSpacing:0,
             //      childAspectRatio: (1/0.3),
             //        children:List.generate(
             //          controller.expensesCaltegoryList.length, (index) =>
             //            InkWell(
             //              onTap: (){
             //                controller.expensesFilterData( controller.expensesCaltegoryList[index]);
             //              },
             //              child: Row(
             //                crossAxisAlignment: CrossAxisAlignment.center,
             //                mainAxisAlignment: MainAxisAlignment.start,
             //                children: [
             //                  Container(
             //                    height: 25,
             //                    width: 25,
             //                    decoration: BoxDecoration(
             //                        color: controller.colorListPayment[index],
             //                        borderRadius: BorderRadius.circular(3),
             //                        boxShadow: [
             //                          BoxShadow(
             //                            color:controller.colorListPayment[index].withOpacity(0.4),
             //                            offset: const Offset(
             //                              2.0,
             //                              2.0,
             //                            ),
             //                            blurRadius: 5.0,
             //                            spreadRadius: 1.0,
             //                          ), //BoxShadow
             //                          BoxShadow(
             //                            color: Colors.black.withOpacity(0.3),
             //                            offset: const Offset(-2.0, -2.0),
             //                            blurRadius: 5.0,
             //                            spreadRadius: 1.0,
             //                          ), //B
             //                        ]
             //
             //                    ),
             //
             //                  ),
             //                  SizedBox(width: 8,),
             //                  Text(controller.expensesCaltegoryList[index],style: TextStyle(fontSize: 13,color: Theme.of(context).colorScheme.primary),)
             //                ],
             //              ),
             //            ),
             //        ),
             //    ):Container(),
             //  ),

              SizedBox(height: 15,),
            ],
          ),
        ):Container(),
        ),
      ],
    );
  }


  Widget pieListWidget(String title,Color color){
    return InkWell(
      onTap: (){
        controller.filterData(title);
      },
      child: Row(
        children: [
          Container(
            height: 25,
            width: 25,
            decoration: BoxDecoration(
                color: color,
                borderRadius: BorderRadius.circular(3),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.3),
                    offset: const Offset(
                      2.0,
                      2.0,
                    ),
                    blurRadius: 5.0,
                    spreadRadius: 1.0,
                  ), //BoxShadow
                  BoxShadow(
                    color: Colors.black.withOpacity(0.3),
                    offset: const Offset(-2.0, -2.0),
                    blurRadius: 5.0,
                    spreadRadius: 1.0,
                  ), //B
                ]

            ),

          ),
          SizedBox(width: 8,),
          Text(title,style: TextStyle(fontSize: 13,color: Theme.of(context).colorScheme.primary),)
        ],
      ),
    ) ;
  }


  List<PieChartSectionData> showingRevenueChart(
      double customRadius, list, type) {
    return List.generate(list.length, (i) {
      final isTouched = i == touchedIndex;
      final fontSize = isTouched ? 11.0 : 10.0;
      final radius = isTouched ? customRadius : customRadius - 10;
      return PieChartSectionData(
        color:controller.selectedSource.value==0? controller.colorListPayment[i]:controller.colorListSource[i],
        value: double.parse(list[i].count!.toString()),
        title: list[i].id,
        radius: radius,
        titleStyle:
        TextStyle(fontSize: fontSize, color: Colors.black),
      );
    });
  }

  void showCustomDialog(BuildContext context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (BuildContext cxt) {
        return Align(
          alignment: Alignment.center,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Material(
              color:Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              child:GlassmorphicContainer(
                borderRadius: 5,
                blur: 10,
                alignment: Alignment.topLeft,
                border: 0.6,
                linearGradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFFffffff).withOpacity(0.1),
                      Color(0xFFFFFFFF).withOpacity(0.05),
                    ],
                    stops: [
                      0.1,
                      1,
                    ]),
                borderGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFFffffff).withOpacity(0.5),
                    Color((0xFFFFFFFF)).withOpacity(0.5),
                  ],
                ),
                width: Get.width,
                height: 600,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 12,right: 12,top: 4),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                InkWell(
                                  onTap: (){
                                    Get.back();
                                  },
                                  child: Icon(Icons.close),
                                ),
                                TextButton(child: Text("Clear All",style:TextStyle(fontSize: 14,decoration: TextDecoration.underline,color: Colors.blueAccent,fontWeight: FontWeight.bold),),
                                  onPressed: (){
                                    controller.selectedCategory.value="";
                                    controller.selectedYear=null;
                                    controller.selectedMonth=null;
                                    controller.rxServiceDate.value="Select Date Range";
                                    controller.yesrList.refresh();
                                    controller.monthList.refresh();

                                  },
                                )

                              ],
                            ),
                          ),
                          Divider(thickness: 0.8,color: Colors.grey.withOpacity(0.5),)
                        ],
                      ),


                      Obx(() =>Row(
                        children: [
                          Expanded(
                            flex: 2,
                            child: RadioListTile(
                              selected:controller.radioRevenuExpenses.value=="REVENUE" ,
                              contentPadding: EdgeInsets.zero,
                              controlAffinity:ListTileControlAffinity.leading,
                              title: Text("REVENUE"),
                              value: "REVENUE", onChanged: (value){

                              controller.radioRevenuExpenses.value=value.toString();
                            }, groupValue:  controller.radioRevenuExpenses.value,),
                          ),
                          Expanded(
                            flex: 2,
                            child: RadioListTile(
                              selected: controller.radioRevenuExpenses.value=="EXPENSES",
                              contentPadding: EdgeInsets.zero,
                              controlAffinity:ListTileControlAffinity.leading,
                              title: Text("EXPENSES"),
                              value:"EXPENSES", onChanged: (value){
                              controller.getCategory();
                              controller.radioRevenuExpenses.value=value.toString();
                            }, groupValue: controller.radioRevenuExpenses.value,),
                          ),

                        ],
                      )),

                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Year :                         ",style: Theme.of(context).textTheme.bodyText1),
                            Obx(()=> DropdownButton(
                              isExpanded:true,
                              value:  controller.selectedYear,
                              hint: Text("Select Year"),
                              items: controller.yesrList.value.map((dynamic value) {
                                return DropdownMenuItem<Map>(
                                  value: value,
                                  child: Text(
                                    value["name"]??"",
                                    style: TextStyle(fontSize: 15),
                                  ),
                                );
                              }).toList(),
                              // Step 5.
                              onChanged: (dynamic? newValue) {
                                controller.selectedYear=newValue;
                                controller.rxYear.value=controller.selectedYear["name"];
                                controller.startDate.value=controller.selectedYear["startDate"];
                                controller.endDate.value=controller.selectedYear["endDate"];
                                controller.selectedMonth=null;
                                controller.monthList.refresh();
                                controller.yesrList.refresh();
                                //controller.setectedType.value=newValue!;
                              },
                            ),
                            ),
                          ],
                        ),
                        value:"My Profile",
                      ),
                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Month :                         ",style: Theme.of(context).textTheme.bodyText1),
                            Obx(()=> DropdownButton(
                              isExpanded:true,
                              value: controller.selectedMonth,
                              hint: Text("Select Month"),
                              items: controller.monthList.value.map((dynamic value) {
                                return DropdownMenuItem<Map>(
                                  value: value,
                                  child: Text(
                                    value["name"]??"",
                                    style: TextStyle(fontSize: 15),
                                  ),
                                );
                              }).toList(),
                              // Step 5.
                              onChanged: (dynamic? newValue) {
                                controller.selectedMonth=newValue;
                                controller.startDate.value=controller.rxYear.value+controller.selectedMonth["startDate"];
                                controller.endDate.value=controller.rxYear.value+controller.selectedMonth["endDate"];
                                controller.monthList.refresh();
                              },
                            ),
                            ),
                          ],
                        ),
                        value:"My Profile",
                      ),


                      Obx(() => controller.radioRevenuExpenses.value=="EXPENSES" ?PopupMenuItem(
                          enabled: false,
                          padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                          child:Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Expense Category :                         ",style: Theme.of(context).textTheme.bodyText1),
                              Obx(()=>DropdownButton<String>(
                                isExpanded:true,
                                value: controller.expenseCategory.value==""?null:controller.expenseCategory.value,
                                hint: Text("Select Expenses "),
                                items: controller.expensesCaltegoryList.value
                                    .map<DropdownMenuItem<String>>((String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(
                                      value,
                                      style: TextStyle(fontSize: 15),
                                    ),
                                  );
                                }).toList(),
                                // Step 5.
                                onChanged: (String? newValue) {
                                  controller.expenseCategory.value=newValue!;
                                },
                              ),
                              ),
                            ],
                          ),
                          value:"My Profile",
                        ):Container(),
                      ),

                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Date Range :                           ",style: Theme.of(context).textTheme.bodyText1),
                            SizedBox(height: 10,),
                            Obx(()=> Row(
                              children: [
                                Icon(Icons.date_range),
                                SizedBox(width: 10,),
                                TextButton(child: Text(controller.rxServiceDate.value,style: TextStyle(fontSize: 16,height: 1.3),),onPressed: (){
                                  dateTime();
                                },),
                              ],
                            )
                            ),
                          ],
                        ),
                        value:"My Profile",
                      ),
                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 20,bottom: 20),

                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ElevatedButton(onPressed: (){
                              if(controller.radioRevenuExpenses.value=="REVENUE")
                                {
                                  controller.getManagementRevenueData();
                                }
                               else{
                                 controller.getManagementExpensesData();
                              }
                              Get.back();
                            }, child: Text("    Apply    "),style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),),
                          ],
                        )

                        , value:"My Profile",
                      ),
                    ],
                  ),
                ),
              ),

            ),
          ),
        );
      },
    );
  }

  dateTime()async{
    DateTimeRange? picked= await  showDateRangePicker(
        context: Get.context!,
        firstDate:DateTime(DateTime.now().year-1),
        lastDate: DateTime(DateTime.now().year+2),
        initialDateRange:controller.pickedRangeDate??  DateTimeRange(
          start: DateTime.now(),
          end:DateTime.now().add(Duration(hours: 24*1)),
        ),
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
                colorScheme: const ColorScheme.dark(
                    onPrimary: Colors.white,
                    // selected text color
                    onSurface: Colors.white,
                    // default text color
                    primary: Colors
                        .teal // circle color
                ),
                dialogBackgroundColor: Theme
                    .of(context)
                    .backgroundColor,

                textButtonTheme: TextButtonThemeData(
                    style: TextButton.styleFrom(
                        textStyle: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight
                                .normal,
                            fontSize: 12,
                            fontFamily: 'Quicksand'),
                        primary: Colors.white,
                        // color of button's letters
                        backgroundColor: Colors
                            .black54,
                        // Background color
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                color: Colors
                                    .transparent,
                                width: 1,
                                style: BorderStyle
                                    .solid),
                            borderRadius: BorderRadius
                                .circular(50))))),

            child: child!,
          );
        }

    );
    if(picked!=null)
    {
      controller.selectedYear=null;
      controller.selectedMonth=null;
      controller.yesrList.refresh();
      controller.monthList.refresh();
      controller.startDate.value=controller.formattera.format(picked.start);
      controller.endDate.value=controller.formattera.format(picked.end);
      controller.pickedRangeDate=picked;
      final String start = "Start Date : "+formatter.format(picked!.start)+ "\nEnd Date   : "+formatter.format(picked!.end);
      controller.rxServiceDate.value=start;
    }



  }
  Widget RevenuWidget(String title,String value,String url){
    final txtTitle=TextStyle(fontSize: 15,fontWeight: FontWeight.w600,color: Theme.of(context).colorScheme.primary.withOpacity(0.85));
    final txtSubTitle=TextStyle(fontSize: 15,fontWeight: FontWeight.bold,color: Theme.of(context).colorScheme.primary);
    return  Container(
      margin: EdgeInsets.only(right:4,left: 4),
      padding: EdgeInsets.only(left: 8,right: 8,bottom: 8,top: 8),
      decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.onPrimaryContainer,
          borderRadius: BorderRadius.circular(5),
          border: Border.all(color: Colors.grey.withOpacity(0.8),width: 0.5)
      ),
      child: Row(
        children: [
          Image.asset(url,height: 30,width: 30),
          SizedBox(width: 8,),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,style: txtTitle,),
                SizedBox(height: 6,),
                Text(value,style: txtSubTitle,),
              ],
            ),
          ),
        ],
      ),
    );
  }


}

