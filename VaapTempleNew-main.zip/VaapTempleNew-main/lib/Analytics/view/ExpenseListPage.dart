import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListshowOnly.dart';
import '../controller/AnalyticController.dart';


class ExpenseListPage extends StatefulWidget {
  final String title;
  ExpenseListPage({Key? key,required this.title}) : super(key: key);
  @override
  State<ExpenseListPage> createState() => _ExpenseListPageState();
}

class _ExpenseListPageState extends State<ExpenseListPage> {


  AnalyticController controller=Get.find();

  @override
  void initState(){
    controller.expensesFilterData(widget.title);
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text(
            widget.title,
            textAlign: TextAlign.center,
          ),
        ),
        body:Obx(() => controller.expensesDatum.value!=null? ListView.builder(
            shrinkWrap: true,
            padding: EdgeInsets.only(top: 6),
            itemCount: controller.expensesDatum.value.length,
            itemBuilder: (context, index) {
              final datas=controller.expensesDatum[index];
              return CustomListShowOnlyWidget(title:datas.expenseName!??"",
                subTitle:"\$ "+ double.parse(datas.expenseAmount.toString()).toStringAsFixed(2) ,
                subTitle2: datas.expenseCategory,
                viewMoreWidget: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children:[
                      if(datas.expenseType!.isNotEmpty)  Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                      if(datas.expenseType!.isNotEmpty) viewMore("Type  ",datas.expenseType!),
                      if(datas.expenseCode!.isNotEmpty)  Divider(thickness: 0.2,color: Colors.grey.withOpacity(0.5),),
                      if(datas.expenseCode!.isNotEmpty) viewMore("Code  ",datas.expenseCode!),

                                ]),
                textEditingController: controller.etSearch,
                isClicked: datas.isChecked!??false,
                onTapVieMore: (){
                  datas.isChecked=!datas.isChecked!;
                  controller.expensesDatum.refresh();
                },
                editOnTap: (){

                },
              );

            }):Container()
        )

    );
  }




}

