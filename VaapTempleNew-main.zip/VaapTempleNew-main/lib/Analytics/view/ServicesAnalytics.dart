
import 'dart:convert';
import 'dart:math';
import 'package:aspgen_mobile/Analytics/view/ServiceCategoryPage.dart';
import 'package:aspgen_mobile/Analytics/view/in_away_temple_list.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'package:intl/intl.dart';
import '../../UtilMethods/Utils.dart';
import '../../Widget/CustomListshowOnly.dart';
import '../../Widget/histroryWidgetRevenue.dart';
import '../controller/AnalyticController.dart';
import 'package:fl_chart/fl_chart.dart';

import '../controller/ServicesController.dart';

class ServicesAnalyticPage extends StatefulWidget {
  final String title;
  ServicesAnalyticPage({Key? key,required this.title}) : super(key: key);
  @override
  State<ServicesAnalyticPage> createState() => _ServicesAnalyticPageState();
}

class _ServicesAnalyticPageState extends State<ServicesAnalyticPage> {


  final DateFormat formatter = DateFormat('MMM dd , yyyy');

  TextEditingController etdate= new TextEditingController();

  final formGlobalKey = GlobalKey<FormState>();

  DateTime?tempDate;

  int touchedIndex=-1;
late  ServiceAnalyticController controller;
  @override
  void initState(){
    controller=Get.put(ServiceAnalyticController(widget.title));
  }
  @override
  Widget build(BuildContext context) {
    BoxDecoration decoration=BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        border: Border.symmetric(horizontal: BorderSide(color: Theme.of(context).colorScheme.primary.withOpacity(0.1),width: 0.4)),
        color: Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.3));
    return Scaffold(
      appBar: AppBar(
        title: Text(
          widget.title ,
          textAlign: TextAlign.center,
        ),

        actions: [



          IconButton(onPressed: (){
            FocusManager.instance.primaryFocus?.unfocus();
            showCustomDialog(context);}, icon: Icon(Icons.filter_alt_outlined)),

          PopupMenuButton<String>(
              child: Icon(Icons.more_vert_outlined),
              color: Theme.of(context).colorScheme.onPrimaryContainer.withRed(3),
              offset: Offset(10, 50),
              elevation: 5,
              itemBuilder: (context) => [
                PopupMenuItem(
                  padding: EdgeInsets.all(0),
                  child:Obx(()=> Column(
                        children: List.generate(controller.menuList.length, (index) =>
                            CheckboxListTile(
                               controlAffinity: ListTileControlAffinity.leading,
                                value: controller.menuList[index]["status"], title:Text(controller.menuList[index]["name"]),onChanged: (value){
                              controller.menuList[index]["status"]=value;
                              controller.menuList.refresh();
                            })
                        )
                    ),
                  ),
                  value:"My Profile",
                ),


              ]



          ),
          SizedBox(width: 10,)
        ],

      ),
      body:  SingleChildScrollView(
        child:Column(
          children: [
            SizedBox(height: 10,),
            Obx(()=>controller.serviceModel.value.data!=null? Container(
              margin: EdgeInsets.only(right:8,left: 8),
              padding: EdgeInsets.only(bottom: 8,top: 8),
              decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.onPrimaryContainer,
                  borderRadius: BorderRadius.circular(5),
                  border: Border.all(color: Colors.grey.withOpacity(0.8),width: 0.5)
              ),
              child:
              Column(
                children: [
                  Container(
                    margin: EdgeInsets.only(top: 8,bottom: 20),
                    height: 240,
                    decoration: BoxDecoration(
                      boxShadow: [
                        BoxShadow(
                          color: Colors.white.withOpacity(0.4),
                          offset: Offset(-3.0, -3.0),
                          blurRadius: 10.0,
                        ),
                        BoxShadow(
                          color: Colors.black.withOpacity(0.1),
                          offset: Offset(3.0, 3.0),
                          blurRadius: 10.0,
                        ),
                      ],
                      color: Theme.of(context).colorScheme.onPrimaryContainer,
                      shape: BoxShape.circle,
                    ),
                    width: Get.width,
                    child: PieChart(
                      PieChartData(
                          borderData: FlBorderData(
                            show: false,
                          ),
                          sectionsSpace: 1,
                          centerSpaceRadius: 20,
                          sections: showingRevenueChart(
                              100, controller.serviceModel.value.data!.serviceDetails, "PAYMENTS")),
                      swapAnimationDuration: Duration(milliseconds: 150),
                      // Optional
                      swapAnimationCurve: Curves.bounceIn, // Optional
                    ),
                  ),
                  Obx(()=>controller.serviceModel.value.data!=null?
                  Container(
                    padding: EdgeInsets.only(left: 6,right: 6,top: 10),
                    child:Obx(()=> Column(
                        children: [
                          Row(
                            children: [
                              Expanded(flex: 4,child:
                              RevenuWidget("#   ${widget.title[0].toUpperCase()+widget.title.substring(1).toLowerCase()}",controller.serviceModel.value.data!.revenue![0].count.toString(),"assets/images/booking.png")
                              ),  Expanded(flex: 4,child:
                              RevenuWidget("Total Revenue",amountParser(controller.serviceModel.value.data!.revenue![0].sum.toString()),"assets/images/revenue.png"),
                              ),

                            ],
                          ),
                          if(controller.menuList[0]["status"]  || controller.menuList[1]["status"] )  SizedBox(height: 10,),
                          Row(
                            children: [
                              if(controller.menuList[1]["status"])    Expanded(flex: 4,child:
                              RevenuWidget("Min",amountParser(controller.serviceModel.value.data!.revenue![0].min.toString()),"assets/images/dollor.png")),
                              if(controller.menuList[0]["status"])    Expanded(
                                  flex: 4,
                                  child:
                                  RevenuWidget("Max", amountParser(controller.serviceModel.value.data!.revenue![0].max.toString()),"assets/images/dollor.png")),

                            ],
                          ),
                          if(controller.menuList[2]["status"])   SizedBox(height: 10,),
                          if(controller.menuList[2]["status"])     Row(
                            children: [
                              Expanded(flex: 4,child:
                              RevenuWidget("Average",amountParser(controller.serviceModel.value.data!.revenue![0].average!.toString()),"assets/images/revenue.png")),


                            ],
                          )
                        ],
                      ),
                    ),
                  ):Container(),
                  ),

                  Column(
                    children: List.generate(controller.serviceModel.value.data!.serviceDetails!.length!, (index) =>
                        Container(
                          margin: EdgeInsets.only(top: 10,left: 10,right: 10),
                          decoration: BoxDecoration(
                              border: Border.all(color:Colors.grey.withOpacity(0.5),width: 0.5),
                              borderRadius: BorderRadius.circular(5),
                              color: Theme.of(context).colorScheme.onPrimaryContainer
                          ),

                          child: ListTile(
                            onTap: (){
                              if(widget.title=="SERVICES"){
                                Get.to(()=>ServiceCategoryListPage(title:controller.serviceModel.value.data!.serviceDetails![index].id! ,));
                              }
                              else{
                                Get.to(()=>InAwayTempleListPage(title:controller.serviceModel.value.data!.serviceDetails![index].id! ,type: 2));

                              }
                            },
                            leading:  Container(
                              height: 25,
                              width: 25,
                              decoration: BoxDecoration(
                                  color: controller.colorList[index],
                                  borderRadius: BorderRadius.circular(3),
                                  boxShadow: [
                                    BoxShadow(
                                      color:controller.colorList[index].withOpacity(0.3),
                                      offset: const Offset(
                                        2.0,
                                        2.0,
                                      ),
                                      blurRadius: 5.0,
                                      spreadRadius: 1.0,
                                    ), //BoxShadow
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.3),
                                      offset: const Offset(-2.0, -2.0),
                                      blurRadius: 5.0,
                                      spreadRadius: 1.0,
                                    ), //B
                                  ]

                              ),
                            ),
                            title: Text(controller.serviceModel.value.data!.serviceDetails![index].id!+" ("+controller.serviceModel.value.data!.serviceDetails![index].count!.toString()+") ",style: Theme.of(context).textTheme.bodyText1,),
                            trailing:  Text(amountParser(controller.serviceModel.value.data!.serviceDetails![index].sum!.toString()),style: Theme.of(context).textTheme.bodyText1,),
                          ),
                        )
                    ),
                  )

                ],
              ),

            ):Container(),
            ),
             Obx(()=> ListView(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            key: Key('builder ${controller.isSelected.value.toString()}'),
            children:[
             if(controller.menuList[3]["status"]) Obx(()=>Container(
                margin: EdgeInsets.only(top:15,left: 5,right: 5),
                decoration:decoration.copyWith(border: Border.all(color:!controller.isExpend1.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.tealAccent)),
                child: ListTileTheme(
                  dense: true,
                  horizontalTitleGap: 15.0,
                  minLeadingWidth: 0,
                  child: ExpansionTile(
                      key: Key("0"),
                      collapsedTextColor: Colors.tealAccent,
                      textColor: Colors.tealAccent,
                      onExpansionChanged: (value){
                        controller.isExpend1.value=value;
                        controller.isExpend2.value=false;
                        controller.isExpend3.value=false;
                        controller.isSelected.value=0;
                      },
                      initiallyExpanded: controller.isExpend1.value,
                      title: Text("Top 10",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                      children:<Widget>[
                        Obx(()=> Column(
                          children: controller.topBottomFrequent.value.data!=null?List.generate(controller.topBottomFrequent.value.data!.top!.length, (index) {
                            final datas=controller.topBottomFrequent.value.data!.top![index];
                            return CustomListShowOnlyWidget(
                              title: datas.serviceSetup ?? "",
                              subTitle: amountParser(
                                  datas.serviceAmount.toString()),
                              subTitle2: dateParser(datas.serviceDate.toString()),
                              viewMoreWidget: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    if(datas.customerName!.isNotEmpty) Divider(
                                      thickness: 0.2,
                                      color: Colors.grey.withOpacity(0.5),),
                                    if(datas.customerName!.isNotEmpty) viewMore(
                                        "Devotee Name  ",
                                        datas.customerName.toString() ?? ""),
                                    if(datas.customerPhone!.isNotEmpty) Divider(
                                      thickness: 0.2,
                                      color: Colors.grey.withOpacity(0.5),),
                                    if(datas.customerPhone!.isNotEmpty) viewMore(
                                        "Phone  ",
                                        phoneFormatter(datas.customerPhone!)
                                            .toString() ?? ""),
                                    if(datas.customerEmail!
                                        .toString()
                                        .isNotEmpty) Divider(thickness: 0.2,
                                      color: Colors.grey.withOpacity(0.3),),
                                    if(datas.customerEmail!
                                        .toString()
                                        .isNotEmpty) viewMore("Email ",
                                        UtilMethods.decrypt(datas.customerEmail!)
                                            .toString() ?? ""),
                                  ]),
                              textEditingController: controller.etSearch,
                              isClicked: datas.isChecked??false,
                              onTapVieMore: () {
                                datas.isChecked = !datas.isChecked!;
                                controller.topBottomFrequent.refresh();
                              },
                              editOnTap: () {

                              },
                            );
                          }
                          ):[],
                        ),
                        )
                      ]
                  ),
                ),
              ),
              ),



              if(controller.menuList[4]["status"])  Obx(()=> Container(
                margin: EdgeInsets.only(top:15,left: 5,right: 5),
                decoration:decoration.copyWith(border: Border.all(color:!controller.isExpend2.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Color(0xEBFF448D),)),
                child: ListTileTheme(
                  dense: true,
                  horizontalTitleGap: 15.0,
                  minLeadingWidth: 0,
                  child: ExpansionTile(
                      maintainState: true,
                      collapsedTextColor: Color(0xEBFF448D),
                      textColor:Color(0xEBFF448D),
                      childrenPadding: EdgeInsets.only(left: 0,right: 0,bottom: 15),
                      onExpansionChanged: (value){
                        controller.isExpend2.value=value;
                        controller.isExpend1.value=false;
                        controller.isExpend3.value=false;
                        controller.isSelected.value=1;
                      },
                      initiallyExpanded: controller.isExpend2.value,
                      key: Key("1"),
                      title: Text("Bottom 10",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                      children:[
                       Obx(()=> Column(
                            children: controller.topBottomFrequent.value.data!=null?List.generate(controller.topBottomFrequent.value.data!.bottom!.length, (index) {
                              final datas=controller.topBottomFrequent.value.data!.bottom![index];
                              return CustomListShowOnlyWidget(
                                title: datas.serviceSetup ?? "",
                                subTitle: amountParser(
                                    datas.serviceAmount.toString()),
                                   subTitle2: dateParser(datas.serviceDate.toString()),
                                    viewMoreWidget: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      if(datas.customerName!.isNotEmpty) Divider(
                                        thickness: 0.2,
                                        color: Colors.grey.withOpacity(0.5),),
                                      if(datas.customerName!.isNotEmpty) viewMore(
                                          "Devotee Name  ",
                                          datas.customerName.toString() ?? ""),
                                      if(datas.customerPhone!.isNotEmpty) Divider(
                                        thickness: 0.2,
                                        color: Colors.grey.withOpacity(0.5),),
                                      if(datas.customerPhone!.isNotEmpty) viewMore(
                                          "Phone  ",
                                          phoneFormatter(datas.customerPhone!)
                                              .toString() ?? ""),
                                      if(datas.customerEmail!
                                          .toString()
                                          .isNotEmpty) Divider(thickness: 0.2,
                                        color: Colors.grey.withOpacity(0.3),),
                                      if(datas.customerEmail!
                                          .toString()
                                          .isNotEmpty) viewMore("Email ",
                                          UtilMethods.decrypt(datas.customerEmail!)
                                              .toString() ?? ""),
                                    ]),
                                textEditingController: controller.etSearch,
                                isClicked: datas.isChecked??false,
                                onTapVieMore: () {
                                  datas.isChecked = !datas.isChecked!;
                                  controller.topBottomFrequent.refresh();
                                },
                                editOnTap: () {

                                },
                              );
                            }
                            ):[],
                          ),
                        )
                      ]
                  ),
                ),
              ),
              ),

              if(controller.menuList[5]["status"])  Obx(() => Container(
                margin: EdgeInsets.only(top:15,left: 5,right: 5),
                decoration:decoration.copyWith(border: Border.all(color:!controller.isExpend3.value?Theme.of(context).colorScheme.primary.withOpacity(0.3):Colors.amber)),
                child: ListTileTheme(
                  dense: true,
                  horizontalTitleGap: 15.0,
                  minLeadingWidth: 0,
                  child: ExpansionTile(

                      collapsedTextColor: Colors.amber,
                      textColor: Colors.amber,
                      childrenPadding: EdgeInsets.only(left: 10,right: 10,bottom: 15),
                      onExpansionChanged: (value){
                        controller.isExpend3.value=value;
                        controller.isExpend2.value=false;
                        controller.isExpend1.value=false;
                        controller.isSelected.value=2;
                      },
                      maintainState: true,
                      initiallyExpanded: controller.isExpend3.value,
                      key: Key("2"),
                      title: Text("Most Frequently Used",style: TextStyle(fontWeight: FontWeight.bold,fontSize: 17),),
                      children:<Widget>
                      [

                        Obx(()=> Column(
                          children: controller.topBottomFrequent.value.data!=null?List.generate(controller.topBottomFrequent.value.data!.frequent!.length, (index) {
                            final datas=controller.topBottomFrequent.value.data!.frequent![index];
                            return  Container(
                              margin: EdgeInsets.only(top: 10,left: 0,right: 0),
                              decoration: BoxDecoration(
                                  border: Border.all(color:Colors.grey.withOpacity(0.5),width: 0.5),
                                  borderRadius: BorderRadius.circular(5),
                                  color: Theme.of(context).colorScheme.onPrimaryContainer
                              ),

                              child: ListTile(
                                onTap: (){
                                },
                                title: Text(datas.id!,style: Theme.of(context).textTheme.bodyText1,),
                                trailing:  Text(datas.count!.toString(),style: Theme.of(context).textTheme.bodyText1,),
                              ),
                            );
                          }
                          ):[],
                        ),
                        )
                      ]
                  ),
                ),
              ),
              ),

              SizedBox(height: 15,),
            ]
        )),
            SizedBox(height: 20,),
          ],
        ),

      ),
    );
  }

  Widget pieListWidget(String title,Color color){
    return InkWell(
      onTap: (){
     
      },
      child: Container(
        padding: EdgeInsets.all(15),
        margin: EdgeInsets.only(top: 10,left: 10,right: 10),
        decoration: BoxDecoration(
            border: Border.all(color:Colors.grey.withOpacity(0.5),width: 0.5),
            borderRadius: BorderRadius.circular(5),
            color: Theme.of(context).colorScheme.onPrimaryContainer
        ),
        child: Row(
          children: [
            Expanded(flex:1,
              child: Container(
                height: 25,
                width: 25,

                decoration: BoxDecoration(
                    color: color,
                    borderRadius: BorderRadius.circular(3),
                    boxShadow: [
                      BoxShadow(
                        color: color.withOpacity(0.3),
                        offset: const Offset(
                          2.0,
                          2.0,
                        ),
                        blurRadius: 5.0,
                        spreadRadius: 1.0,
                      ), //BoxShadow
                      BoxShadow(
                        color: Colors.black.withOpacity(0.3),
                        offset: const Offset(-2.0, -2.0),
                        blurRadius: 5.0,
                        spreadRadius: 1.0,
                      ), //B
                    ]

                ),

              ),
            ),
            SizedBox(width: 8,),
            Text(title,style: TextStyle(fontSize: 13,color: Theme.of(context).colorScheme.primary),)

          ],
        ),
      ),
    ) ;
  }


  List<PieChartSectionData> showingRevenueChart(
      double customRadius, list, type) {
    return List.generate(list.length, (i) {
      final isTouched = i == touchedIndex;
      final fontSize = isTouched ? 11.0 : 9.0;
      final radius = isTouched ? customRadius : customRadius - 10;
      return PieChartSectionData(
        color: list[i].id == "CASH"
            ? Colors.green
            : list[i].id == "CREDIT CARD"
            ? Colors.blue
            : list[i].id == "WEBSITE"
            ? Colors.amber
            : list[i].id == "PORTAL"
            ? Colors.indigo
            : list[i].id == "CHECK"
            ? Colors.purple
            : list[i].id == "KIOSK"?
        Colors.greenAccent
            : controller.colorList[i],
        //controller.colorList[i],
        value: double.parse(list[i].count!.toString()),
        title: list[i].id,
        radius: radius,
        titleStyle:
        TextStyle(fontSize: fontSize, color: Colors.black,),
      );
    });
  }

  void showCustomDialog(BuildContext context) {
    showDialog(
      barrierDismissible: false,
      context: context,
      barrierColor: Colors.black.withOpacity(0.7),
      builder: (BuildContext cxt) {
        return Align(
          alignment: Alignment.center,
          child: Padding(
            padding: EdgeInsets.all(16),
            child: Material(
              color:Colors.transparent,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(5)),
              child:GlassmorphicContainer(
                borderRadius: 5,
                blur: 10,
                alignment: Alignment.topLeft,
                border: 0.6,
                linearGradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      Color(0xFFffffff).withOpacity(0.1),
                      Color(0xFFFFFFFF).withOpacity(0.05),
                    ],
                    stops: [
                      0.1,
                      1,
                    ]),
                borderGradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [
                    Color(0xFFffffff).withOpacity(0.5),
                    Color((0xFFFFFFFF)).withOpacity(0.5),
                  ],
                ),
                width: Get.width,
                height: 400,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Column(
                        children: [
                          Padding(
                            padding: const EdgeInsets.only(left: 12,right: 12,top: 4),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                InkWell(
                                  onTap: (){
                                    Get.back();
                                  },
                                  child: Icon(Icons.close),
                                ),
                                TextButton(child: Text("Clear All",style:TextStyle(fontSize: 14,decoration: TextDecoration.underline,color: Colors.blueAccent,fontWeight: FontWeight.bold),),
                                  onPressed: (){
                                  controller.selectedCategory.value="";
                                  controller.setectedType.value="";
                                  controller.setectedStatus.value="";
                                  controller.selectedYear=null;
                                  controller.selectedMonth=null;
                                  controller.rxServiceDate.value="Select Date Range";
                                  controller.yesrList.refresh();
                                  controller.monthList.refresh();
                                  controller.startDate.value=controller.formattera.format(DateTime.now());
                                  controller.endDate.value=controller.formattera.format(DateTime.now());
                                  },
                                )

                              ],
                            ),
                          ),
                          Divider(thickness: 0.8,color: Colors.grey.withOpacity(0.5),)
                        ],
                      ),



                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Row(
                          children: [


                            Expanded(
                              flex:2,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("Year :                         ",style: Theme.of(context).textTheme.bodyText1),
                                  Obx(()=> DropdownButton(
                                    isExpanded:true,
                                    value:  controller.selectedYear,
                                    hint: Text("Select Year"),
                                    items: controller.yesrList.value.map((dynamic value) {
                                      return DropdownMenuItem<Map>(
                                        value: value,
                                        child: Text(
                                          value["name"]??"",
                                          style: TextStyle(fontSize: 15),
                                        ),
                                      );
                                    }).toList(),
                                    // Step 5.
                                    onChanged: (dynamic? newValue) {
                                      controller.selectedYear=newValue;
                                      controller.rxYear.value=controller.selectedYear["name"];
                                      controller.startDate.value=controller.selectedYear["startDate"];
                                      controller.endDate.value=controller.selectedYear["endDate"];
                                      controller.selectedMonth=null;
                                      controller.monthList.refresh();
                                      controller.yesrList.refresh();
                                      //controller.setectedType.value=newValue!;
                                    },
                                  ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        value:"My Profile",
                      ),      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Row(
                          children: [


                            Expanded(
                              flex: 2,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text("Month :                         ",style: Theme.of(context).textTheme.bodyText1),
                                  Obx(()=> DropdownButton(
                                    isExpanded:true,
                                    value: controller.selectedMonth,
                                    hint: Text("Select Month"),
                                    items: controller.monthList.value.map((dynamic value) {
                                      return DropdownMenuItem<Map>(
                                        value: value,
                                        child: Text(
                                          value["name"]??"",
                                          style: TextStyle(fontSize: 15),
                                        ),
                                      );
                                    }).toList(),
                                    // Step 5.
                                    onChanged: (dynamic? newValue) {
                                      controller.selectedMonth=newValue;
                                      controller.startDate.value=controller.rxYear.value+controller.selectedMonth["startDate"];
                                      controller.endDate.value=controller.rxYear.value+controller.selectedMonth["endDate"];
                                      controller.monthList.refresh();
                                    },
                                  ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        value:"My Profile",
                      ),


                      // Obx(() => controller.radioRevenuExpenses.value=="EXPENSES" ?PopupMenuItem(
                      //   enabled: false,
                      //   padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                      //   child:Column(
                      //     crossAxisAlignment: CrossAxisAlignment.start,
                      //     children: [
                      //       Text("Expense Category :                         ",style: Theme.of(context).textTheme.bodyText1),
                      //       Obx(()=>DropdownButton<String>(
                      //         isExpanded:true,
                      //         value: controller.expenseCategory.value==""?null:controller.expenseCategory.value,
                      //         hint: Text("Select Expenses "),
                      //         items: controller.expensesCaltegoryList.value
                      //             .map<DropdownMenuItem<String>>((String value) {
                      //           return DropdownMenuItem<String>(
                      //             value: value,
                      //             child: Text(
                      //               value,
                      //               style: TextStyle(fontSize: 15),
                      //             ),
                      //           );
                      //         }).toList(),
                      //         // Step 5.
                      //         onChanged: (String? newValue) {
                      //           controller.expenseCategory.value=newValue!;
                      //         },
                      //       ),
                      //       ),
                      //     ],
                      //   ),
                      //   value:"My Profile",
                      // ):Container(),
                      // ),

                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 10),
                        child:Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Date Range :                           ",style: Theme.of(context).textTheme.bodyText1),
                            SizedBox(height: 10,),
                            Obx(()=> Row(
                              children: [
                                Icon(Icons.date_range),
                                SizedBox(width: 10,),
                                TextButton(child: Text(controller.rxServiceDate.value,style: TextStyle(fontSize: 16,height: 1.3),),onPressed: (){
                                  dateTime();
                                },),
                              ],
                            )
                            ),
                          ],
                        ),
                        value:"My Profile",
                      ),
                      PopupMenuItem(
                        enabled: false,
                        padding: EdgeInsets.only(left: 15,right: 15,top: 20,bottom: 20),

                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            ElevatedButton(onPressed: (){
                              // if(controller.radioRevenuExpenses.value=="REVENUE")
                              // {
                              //   controller.getManagementRevenueData();
                              // }
                              // else{
                                controller.getServiceAnalyticApi();
                              // }
                              Get.back();
                            }, child: Text("    Apply    "),style: ElevatedButton.styleFrom(backgroundColor: Colors.teal),),
                          ],
                        )

                        , value:"My Profile",
                      ),
                    ],
                  ),
                ),
              ),

            ),
          ),
        );
      },
    );
  }

  dateTime()async{
    DateTimeRange? picked= await  showDateRangePicker(
        context: Get.context!,
        firstDate:DateTime(DateTime.now().year-1),
        lastDate: DateTime(DateTime.now().year+2),
        initialDateRange:controller.pickedRangeDate??  DateTimeRange(
          start: DateTime.now(),
          end:DateTime.now().add(Duration(hours: 24*1)),
        ),
        builder: (context, child) {
          return Theme(
            data: ThemeData.dark().copyWith(
                colorScheme: const ColorScheme.dark(
                    onPrimary: Colors.white,
                    // selected text color
                    onSurface: Colors.white,
                    // default text color
                    primary: Colors
                        .teal // circle color
                ),
                dialogBackgroundColor: Theme
                    .of(context)
                    .backgroundColor,

                textButtonTheme: TextButtonThemeData(
                    style: TextButton.styleFrom(
                        textStyle: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight
                                .normal,
                            fontSize: 12,
                            fontFamily: 'Quicksand'),
                        primary: Colors.white,
                        // color of button's letters
                        backgroundColor: Colors.black45,
                        // Background color
                        shape: RoundedRectangleBorder(
                            side: const BorderSide(
                                color: Colors
                                    .transparent,
                                width: 1,
                                style: BorderStyle
                                    .solid),
                            borderRadius: BorderRadius
                                .circular(50))))),

            child: child!,
          );
        }

    );
    if(picked!=null)
    {
      controller.selectedYear=null;
      controller.selectedMonth=null;
      controller.yesrList.refresh();
      controller.monthList.refresh();
      controller.startDate.value=controller.formattera.format(picked.start);
      controller.endDate.value=controller.formattera.format(picked.end);
      controller.pickedRangeDate=picked;
      final String start = "Start Date : "+formatter.format(picked.start)+ "\nEnd Date   : "+formatter.format(picked!.end);
      controller.rxServiceDate.value=start;
    }



  }
  Widget RevenuWidget(String title,String value,String url){
    final txtTitle=TextStyle(fontSize: 15,fontWeight: FontWeight.w600,color: Theme.of(context).colorScheme.primary.withOpacity(0.85));
    final txtSubTitle=TextStyle(fontSize: 15,fontWeight: FontWeight.bold,color: Theme.of(context).colorScheme.primary);
    return  Container(
      margin: EdgeInsets.only(right:4,left: 4),
      padding: EdgeInsets.only(left: 8,right: 8,bottom: 8,top: 8),
      decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.onPrimaryContainer,
          borderRadius: BorderRadius.circular(5),
          border: Border.all(color: Colors.grey.withOpacity(0.8),width: 0.5)
      ),
      child: Row(
        children: [
          Image.asset(url,height: 30,width: 30),
          SizedBox(width: 8,),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,style: txtTitle,maxLines: 1,overflow: TextOverflow.ellipsis,),
                SizedBox(height: 6,),
                Text(value,style: txtSubTitle,maxLines: 1,overflow: TextOverflow.fade),
              ],
            ),
          ),
        ],
      ),
    );
  }


}

