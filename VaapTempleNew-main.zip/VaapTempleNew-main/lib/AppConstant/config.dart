// To parse this JSON data, do
//
//     final componentConfig = componentConfigFromJson(jsonString);

import 'dart:convert';

ComponentConfig componentConfigFromJson(String str) => ComponentConfig.fromJson(json.decode(str));

String componentConfigToJson(ComponentConfig data) => json.encode(data.toJson());

class ComponentConfig {
  ComponentConfig({
    this.componentConfig,
  });

  ComponentConfigData ?componentConfig;

  factory ComponentConfig.fromJson(Map<String, dynamic> json) => ComponentConfig(
    componentConfig: ComponentConfigData.fromJson(json["componentConfig"]),
  );

  Map<String, dynamic> toJson() => {
    "componentConfig": componentConfig!.toJson(),
  };
}

class ComponentConfigData {
  ComponentConfigData({
    this.moduleName,
    this.productId,
    this.clientId,
    this.userName,
  });

  String? moduleName;
  String ?productId;
  String ?clientId;
  String ?userName;

  factory ComponentConfigData.fromJson(Map<String, dynamic> json) => ComponentConfigData(
    moduleName: json["moduleName"],
    productId: json["productID"],
    clientId: json["clientID"],
    userName: json["userName"],
  );

  Map<String, dynamic> toJson() => {
    "moduleName": moduleName,
    "productID": productId,
    "clientID": clientId,
    "userName": userName,
  };
}
