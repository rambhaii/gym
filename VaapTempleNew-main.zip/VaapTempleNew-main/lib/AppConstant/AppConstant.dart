import 'package:shared_preferences/shared_preferences.dart';

class AppConstant{
  static late SharedPreferences sharedPreference;
  static final String userName ="userName";
  static final String firstName ="firstName";
  static final String lastName ="lastName";

  static final String fullName ="fullName";
  static final String userEmail ="userEmail";
  static final String userPhone='userPhone';
  static final String userAddress='userAddress';
  static final String userZip='userZip';
  static final String userID='userID';
  static final String clientId='clientId';
  static final String clientName='clientName';
  static final String memberId='memberId';
  static final String userCity='userCity';
  static final String userState='userState';
  static final String userStatus='userStatus';
  static final String role='role';
  static final String productId='productId';
  static final String isVerify="isVerify";
  static final String isMember="isMember";
  static final String setting="setting";
  static final String language="language";
  static final String token='token';
  static final String roleId='roleId';
  static final String userAlldetails='userAlldetails';
  static final String address='address';
  //theme Constant
  static final String backgroundColorDark='backgroundColorDark';
  static final String backgroundColorLight='backgroundColorLight';
  static final String appBarDark='appBarDark';
  static final String appBarLight='appBarLight';
  static final String dailogColorLight='dailogColorLight';
  static final String dailogColorDark='dailogColorDark';
  static final String iconColorDark='iconColorDark';
  static final String iconColorLight='iconColorLight';
  static final String fontColorTitleDark='fontColorTitleDark';
  static final String fontColorTitleLight='fontColorTitleLight';
  static final String fontColorTitleSubtitleDark='fontColorTitleSubtitleDark';
  static final String fontColorTitleSubtitleLight='fontColorTitleSubtitleLight';
  static final String fontsizeHeadingLight='fontsizeHeadingLight';
  static final String fontsizeHeadingDark='fontsizeHeadingDark';
  static final String fontsizeSubTitleLight='fontsizeSubTitleLight';
  static final String fontsizeSubTitleDark='fontsizeSubTitleDark';
  static final String fontsizeTitleLight='fontsizeTitleLight';
  static final String fontsizeTitleDark='fontsizeTitleDark';
  static final String centerTitle='centerTitle';
  static final String primaryLight='primaryLight';
  static final String primaryDark='primaryDark';
  static final String secondaryLight='secondaryLight';
  static final String secondaryDark='secondaryDark';

  // int fontsizeHeading;
  // int fontsizeTitle;
  // double fontsizeSubTitle;
  // bool centerTitle;

//App Update Paramenter
  static final String forceFully="force_fully";
  static final String vaapTempleVersion="vaap_temple_version";
  static final String vaapTempleUpdate="vaapTempleUpdate";
  static final String vaapTempleUrl="vaapTempleUrl";
  static final String vaapTempleMessage="vaapTempleMessage";



  static final String profileList='profileList';


  //Dropdown List variable  //location
  static final String inventoryCategoryTypeList='categoryTypeDetails';
  static final String memberTypeList='memberTypeList';
  static final String stateList='stateList';
  static final String UOMList='UOMList';
  static final String serviceNameList='serviceNameList';
  static final String customerNameList='customerNameList';
  static final String gotraList='gotraList';
  static final String nakshatra='nakshatraList';
  static final String rashiList='rashiList';
  static final String relationList='relationList';
  static final String locationList='locationList';
  static final String languageList='languageList';
  static final String projectList='projectList';
  static final String eventList='eventList';
  static final String serviceTypeList='serviceTypeList';
  static final String serviceCategoryList='serviceCategoryList';
  static final String calendarStatusList='calendarStatusList';
  static final String priestList='priestList';
  static final String storeTypeList='storeTypeList';
  static final String inventoryItemList='inventoryItemList';
  static final String categoryList='categoryList';
  static final String storeStatusTypeList='storeStatusTypeList';
  static final String assetMemberNameList='assetMemberNameList';
  static final String assetCategoryList='assetCategoryList';
  static final String assetTypeList='assetTypeList';
  static final String assetsMakersList='assetsMakersList';
  static final String assetBrandList='assetBrandList';
  static final String assetColorList='assetColorList';
  static final String tradeTypesList='tradeTypesList';
  static final String projectTypesList='projectTypesList';
  static final String jobNameTypesList='jobNameTypesList';
  static final String reasonTypesList='reasonTypesList';
  static final String floorTypeList='floorTypeList';
  static final String roomTypeList='roomTypeList';
  static final String punchIssueTypesList='punchIssueTypesList';
  static final String punchItemList='punchItemList';
  static final String communityTypesNameList='communityTypesNameTypeList';
  static final String projectDivisionTypesList='projectDivisionTypesList';
  static final String jobOrderJobCategoryTypesList='jobOrderJobCategoryTypesList';
  static final String subContractorNameDataList='subContractorNameDataList';
}