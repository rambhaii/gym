import 'package:aspgen_mobile/AppConstant/theme_services.dart';
import 'package:aspgen_mobile/Dashboard/Model/setting.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';

class AppColor{


  //Color for dark
  static Color primaryBlue =  Color(0xff005c4b);
  static Color primaryColor =  Color(0xff005c4b);
  static Color secondaryColor =  Color(0xff005c4b);
  static Color textBlack = Color(0xff222222);
 // static Color textwhite =   Colors.white;
  static Color darkteal = Color(0xff005d4b);
  static  Color backgroundColor =Color(0xff131c23);
  static Color cardcolors = Color(0xff1e1b38);
  static Color textGrey = Color(0xff94959b);
  static Color textGreyblue = Color(0xff323234);
  static Color textWhiteGrey = Color(0xfff9f9fa);
  static Color textWhiteblueaa = Color(0xffFFE5F1FF);
  static Color appBarColor =  Color(0xff1e2b31);//1e2b31
  static Color bookingColor = Color(0xFF7030A0);
  static Color templeColor = Color(0xFF843C0C);
  static Color textWhiteblue = Color(0xfffff6b6);
  //static Color textWhiteblues = Color(0xff1e1b38);
  static Color textWhiteblues = Color(0xff1e2b31);
  static Color textblues = Color(0xff212933);
  static Color priestColor = Color(0xFF385723);
  static Color btntext = Colors.teal;
  static Color amber = Colors.amber;

  //color light
  static  Color backgroundColorLight =Color(0xffeff3fc);
  static Color appBarlitght = Color(0xff005c4b);

static Color  getColorByStatus(String status){
    switch(status){
      case "NEW":
        return Color(0xffbafcab);
        case "SCHEDULED":
        return Colors.amber;
        case "RESCHEDULED":
        return Colors.limeAccent;
        case "PROCESSING":
        return Colors.cyanAccent;
        case "CANCELED":
        return Colors.red;
        case "COMPLETED":
        return Colors.green;
      default:
        return Colors.white;
    }
  }
  static Color  getServicLoctioncolor(String location){
    switch(location){
      case "IN-TEMPLE":
        return Color(0xff8bacfd);
        case "AWAY TEMPLE":
        return Colors.pinkAccent;
        default:
        return Colors.white;

    }
  }
  static Color  getColorByServiceCategory(String location){
    switch(location){
        case "IN-TEMPLE":
        return Color(0xFF108f25);
        case "AWAY-TEMPLE":
        return Color(0xFF84158a);
        case "SHARDAM":
        return Colors.black;
        case "EVENTS":
        return Color(0xffe4550f);
        case "RENTAL":
        return Color(0xff323bae);
        default:
        return Color(0xff3d5644);

    }
  }
}
