import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/AppColors.dart';
import 'package:aspgen_mobile/AppConstant/AppThemes.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../Dashboard/Model/setting.dart';
import '../UtilMethods/Utils.dart';
import 'AppConstant.dart';

class ThemeService{
    final getStorage=GetStorage();
    final storagekey="isDarkMode";

    ThemeMode getThemeMode(){
        return isSaveDarkMode()?ThemeMode.light:ThemeMode.dark;
    }
   bool isSaveDarkMode(){
        return getStorage.read(storagekey)??false;
   }
   Future<void> saveThemeMode(bool isDarkMode){
        return getStorage.write(storagekey,isDarkMode);
   }
  void changeThemeMode(ThemeMode data){
        Get.changeThemeMode(data);
        saveThemeMode(!isSaveDarkMode());
  }
  bool isDarkMode(){
    return getThemeMode()==ThemeMode.dark?true:false;
  }

}
class ThemeController extends GetxController {
  RxBool isDarkMode = false.obs;
  RxBool isReady = false.obs;

 Rx<Color> backgroundColorDark=Rx<Color>( Colors.white);
   changeTheme() {
    Get.changeTheme(Get.isDarkMode ? ThemeData.light() : ThemeData.dark());
    isDarkMode.toggle();
  }

  @override
  void onInit() {
    // TODO: implement onInit
    //getSetting();
    super.onInit();
  }
  getSetting(){
    try {
      UtilMethods.getSetting().then((value){
        SettingModel.fromJson(json.decode(value)).result!.data![0].themeSettings!.forEach((element) async{

          if(element.platform=="Mobile" && element.theme=="dark")
          {
            backgroundColorDark.value=Colors.red;
            AppConstant.sharedPreference.setString(AppConstant.backgroundColorDark, element.desc!.backgroundColor!);
            AppConstant.sharedPreference.setString(AppConstant.appBarDark, element.desc!.appbar!);
            AppConstant.sharedPreference.setString(AppConstant.dailogColorDark, element.desc!.dailogColor!);
            AppConstant.sharedPreference.setString(AppConstant.fontColorTitleDark, element.desc!.fontColorTitle!);
            AppConstant.sharedPreference.setString(AppConstant.fontColorTitleSubtitleDark, element.desc!.fontColorSubtitle!);
            AppConstant.sharedPreference.setDouble(AppConstant.fontsizeTitleDark, element.desc!.fontsizeTitle!);
            AppConstant.sharedPreference.setDouble(AppConstant.fontsizeSubTitleDark, element.desc!.fontsizeSubTitle!);
            AppConstant.sharedPreference.setDouble(AppConstant.fontsizeHeadingDark, element.desc!.fontsizeHeading!);
            AppConstant.sharedPreference.setString(AppConstant.primaryDark, element.desc!.primaryColor!);
            AppConstant.sharedPreference.setString(AppConstant.secondaryDark, element.desc!.secondryColor!);
            AppConstant.sharedPreference.setString(AppConstant.iconColorDark, element.desc!.iconColor!);

          }
          if(element.platform=="Mobile" && element.theme=="light")
          {
            AppConstant.sharedPreference.setString(AppConstant.backgroundColorLight, element.desc!.backgroundColor!);
            AppConstant.sharedPreference.setString(AppConstant.appBarLight, element.desc!.appbar!);
            AppConstant.sharedPreference.setString(AppConstant.dailogColorLight, element.desc!.dailogColor!);
            AppConstant.sharedPreference.setString(AppConstant.fontColorTitleLight, element.desc!.fontColorTitle!);
            AppConstant.sharedPreference.setString(AppConstant.fontColorTitleSubtitleLight, element.desc!.fontColorSubtitle!);
            AppConstant.sharedPreference.setDouble(AppConstant.fontsizeTitleLight, element.desc!.fontsizeTitle!);
            AppConstant.sharedPreference.setDouble(AppConstant.fontsizeSubTitleLight, element.desc!.fontsizeSubTitle!);
            AppConstant.sharedPreference.setDouble(AppConstant.fontsizeHeadingLight, element.desc!.fontsizeHeading!);
            AppConstant.sharedPreference.setString(AppConstant.primaryLight, element.desc!.primaryColor!);
            AppConstant.sharedPreference.setString(AppConstant.secondaryLight, element.desc!.secondryColor!);
            AppConstant.sharedPreference.setString(AppConstant.iconColorLight, element.desc!.iconColor!);
          }

        });
        SettingModel.fromJson(json.decode(value)).result!.data![0].languagesSettings!.forEach((element) async{
          if(element.platform=="Mobile")
          {
            await AppConstant.sharedPreference.setStringList(AppConstant.language, element.language??[]);
          }
        });
      });
    } on Exception catch (e) {
         Get.snackbar("Error", e.toString(),backgroundGradient: LinearGradient(colors: [
           Colors.red,
           Colors.black26,
         ]),
             borderRadius: 2,
             icon: Icon(Icons.error));
    }
  }
}