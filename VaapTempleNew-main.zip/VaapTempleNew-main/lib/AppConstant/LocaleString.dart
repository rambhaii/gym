import 'package:get/get.dart';
class LocaleString extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
    'en_US': {
      'dashboard': 'Dashboard',
      'english': 'English',
      'hindi': 'Hindi',
      'language': 'Language',
      "themes":"Themes",
      "dark":"Dark",
      "light":"Light",
      "logout":"Logout",
      "myProfile":"My Profile"
    },
    'hi_IN': {
      'dashboard': 'डैशबोर्ड',
      'english': 'अंग्रेज़ी',
      'hindi': 'हिन्दी',
      'language': 'भाषा',
      "themes":"विषयों",
      "dark":"अँधेरा",
      "light":"रोशनी",
      "logout":"लॉग आउट",
      "myProfile":"मेरी प्रोफाइल"
    } ,
    'es_VE': {
      'dashboard': 'Tablero',
      'english': 'Inglesa',
      'hindi': 'हिन्दी',
      'language': 'Idioma',
      "themes":"Temas",
      "dark":"Oscura",
      "light":"Ligera",
      "logout":"Cerrar sesión",
      "myProfile":"Mi Perfil"
    }
  };
}