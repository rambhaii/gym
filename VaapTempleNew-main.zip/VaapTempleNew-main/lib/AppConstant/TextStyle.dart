import 'package:flutter/material.dart';
TextStyle heading2 = TextStyle(
  fontSize: 20,
  fontWeight: FontWeight.w700,
);
TextStyle heading7 = TextStyle(
  fontSize: 30,
  fontWeight: FontWeight.w700,
);
TextStyle heading5 = TextStyle(
  fontSize: 18,
  fontWeight: FontWeight.w600,
);
TextStyle heading4 = TextStyle(
  fontSize: 20,
  fontWeight: FontWeight.w600,
);
TextStyle signin = TextStyle(
  fontSize: 12,
  fontWeight: FontWeight.w600,
);


TextStyle heading6 = TextStyle(
  fontSize: 15,
  fontWeight: FontWeight.w600,
);TextStyle heading22 = TextStyle(
  fontSize: 20,
  fontWeight: FontWeight.w600,
);

TextStyle regular16pt = TextStyle(
  fontSize: 13,
  fontWeight: FontWeight.w400,
);
// TextStyle subTitlePhone =  TextStyle(
//    fontSize: 16
// );
// TextStyle titlePhone =  TextStyle(fontSize: 14,fontWeight: FontWeight.w500);



