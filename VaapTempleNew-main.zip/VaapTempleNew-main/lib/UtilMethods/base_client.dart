import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'package:aspgen_mobile/Authentication/Login.dart';
import 'package:aspgen_mobile/Authentication/NewLoginPage.dart';
import 'package:aspgen_mobile/UtilMethods/app_exception.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import '../AppConstant/AppConstant.dart';
import 'Utils.dart';


class BaseClient{
  static const int TIME_OUT_DURATION = 30;
  Future<dynamic> post(String url,dynamic body)async
  {
    print("API url    =>  ${url}");
    var uri=Uri.parse(url);
    var payload=jsonEncode(body);
    try {
      var response=await http.post(uri,
          headers:   {
            'Content-type': 'application/json',
            'Accept': 'application/json',
            "Authorization": "Bearer ${AppConstant.sharedPreference.getString(AppConstant.token).toString().trim()}"
          },
          body: payload).timeout(Duration(seconds: TIME_OUT_DURATION));
      print("cscbjkavbjkasva");
      print(response.body);
      print(response.statusCode);

      return _processResponse(response);
    } on SocketException {
      throw FetchDataException('No Internet connection', uri.toString());
    } on TimeoutException {
      throw ApiNotRespondingException('API not responded in time', uri.toString());
    }
  }
  dynamic _processResponse(http.Response response) {
    switch (response.statusCode) {
      case 200:
        var responseJson = utf8.decode(response.bodyBytes);
        if(jsonDecode(responseJson)['statusCode']==-3)
          {
            logout();
            Get.snackbar("Session Expired","Please Login to continue.",backgroundColor: Colors.amber.withOpacity(0.5),
              icon: Icon(Icons.warning_amber, color: Colors.white),
              snackPosition: SnackPosition.TOP,
              borderRadius: 5,
            );
            return;
          }
        return responseJson;
      case 201:
        var responseJson = utf8.decode(response.bodyBytes);
        if(jsonDecode(responseJson)['statusCode']==-3)
        {
          logout();
          Get.snackbar("Session Expired","Please Login to continue.",backgroundColor: Colors.yellow.withOpacity(0.2),
            icon: Icon(Icons.warning_amber, color: Colors.white),
            snackPosition: SnackPosition.TOP,
            borderRadius: 5,
          );
          return;
        }
        return responseJson;
      case 400:
        throw BadRequestException(utf8.decode(response.bodyBytes), response.request!.url.toString());
      case 401:
      case 403:
        throw UnAuthorizedException(utf8.decode(response.bodyBytes), response.request!.url.toString());
      case 422:
        throw BadRequestException(utf8.decode(response.bodyBytes), response.request!.url.toString());
      case 500:
      default:
        throw FetchDataException('Error occured with code : ${response.statusCode}', response.request!.url.toString());
    }
  }
}