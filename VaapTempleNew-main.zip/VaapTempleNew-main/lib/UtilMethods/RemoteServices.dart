// import 'dart:convert';
//
// import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
// import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
//
// import 'package:aspgen_mobile/ConstructionModule/ProjectProfile/Model/ProjectDetailsData.dart';
// import 'package:aspgen_mobile/ConstructionModule/PunchList/Model/AllTradeData.dart';
// import 'package:aspgen_mobile/ConstructionModule/PunchList/Model/PunchListData.dart';
// import 'package:aspgen_mobile/ConstructionModule/PunchList/PunchListPage.dart';
//
// import 'package:aspgen_mobile/ConstructionModule/projectPage.dart';
// import 'package:aspgen_mobile/Contact/Model/contact_fields_data.dart';
// import 'package:aspgen_mobile/Dashboard/AssetsManagemant/Module/asset_mgmt_data_details.dart';
// import 'package:aspgen_mobile/Dashboard/AssetsManagemant/Module/assets_mgmt_data.dart';
// import 'package:aspgen_mobile/Dashboard/AssetsManagemant/assets_page.dart';
// import 'package:aspgen_mobile/Dashboard/Contact/ContactPage.dart';
// import 'package:aspgen_mobile/Dashboard/Contact/Model/ContactData.dart';
// import 'package:aspgen_mobile/Dashboard/Model/slider_model.dart';
// import 'package:aspgen_mobile/Dashboard/Purchase/Model/purchase_list_model.dart';
// import 'package:aspgen_mobile/Dashboard/Purchase/purchase_page.dart';
// import 'package:aspgen_mobile/Dashboard/Services/Model/ServiceCategoryTypeData.dart';
// import 'package:aspgen_mobile/Dashboard/Services/Model/ServiceData.dart';
// import 'package:aspgen_mobile/Templates/Model/ListingData.dart';
// import 'package:aspgen_mobile/UtilMethods/GlobalApis.dart';
// import 'package:connectivity_plus/connectivity_plus.dart';
// import 'package:flutter/material.dart';
// import 'package:fluttertoast/fluttertoast.dart';
// import 'package:get/get.dart';
// import 'package:loader_overlay/loader_overlay.dart';
// import 'package:http/http.dart' as http;
//
// import '../Authentication/NewLoginPage.dart';
//
//
//
// import '../Dashboard/Menu/Model/MenuData.dart';
// import '../Dashboard/inventory_page/InventoryList.dart';
// import '../calendar/calendar.dart';
// Future<bool> CheckInternetConnection() async{
//   var connectivityResult = await (Connectivity().checkConnectivity());
//   if(connectivityResult==ConnectivityResult.none)
//   {
//     Get.snackbar("No Internet Connection", "Please connect to the internet",backgroundColor: Colors.red,
//       icon: Icon(Icons.wifi_off, color: Colors.white),
//       snackPosition: SnackPosition.TOP,
//       borderRadius: 5,
//       duration: Duration(milliseconds:1200)
//     );
//     return false;
//   }
//   else{
//     return true;
//   }
//
// }
// class RemoteServices{
//
//   static Future<SliderData?> getImageSlider() async {
//     var url = Uri.parse(APIsConstant.getMobileImageSlider);
//     var response = await http.post(url, body: {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//     });
//     if(response.statusCode==200)
//     {
//       var jsoneString=response.body;
//       return sliderDataFromJson(jsoneString);
//     }
//     else{
//       return null;
//     }
//   }
//   static Future<FieldData> getMobileModule(BuildContext context,String title) async {
//     var url = Uri.parse(APIsConstant.moduleSetup);
//     var response = await http.post(url, body: {
//       'productId': APIsConstant.productID,
//       'moduleName':  title,
//     });
//     try{
//       if(response.statusCode==200)
//       {
//          return fieldDataFromJson(response.body);
//       }
//       else{
//         return fieldDataFromJson(response.body);
//       }
//     }
//     catch(e)
//     {
//       return fieldDataFromJson(response.body);
//     }
//
//   }
//   static Future<bool>  getTempleDashboardMenu(String userName,String productid) async {
//     {
//       var res = await http.post(Uri.parse(APIsConstant.Base_Url+"/business/services/nonprofit/getDashboard"),
//           body: {
//             'productId':productid,
//             'username':userName,
//           });
//       if (res.statusCode == 200) {
//         if(jsonDecode(res.body)['statusCode']==-3)
//         {
//           Get.offAll(()=>NewLoginPage());
//           Get.snackbar("Session Expired","Please Login to continue.",backgroundColor: Colors.yellow.withOpacity(0.2),
//             icon: Icon(Icons.warning_amber, color: Colors.white),
//             snackPosition: SnackPosition.TOP,
//             borderRadius: 5,
//           );
//         }
//         if (json.decode(res.body)['success'] == false) {
//           Fluttertoast.showToast(
//               msg: json.decode(res.body)['message'],
//               toastLength: Toast.LENGTH_SHORT,
//               fontSize: 16.0);
//           return false;
//         }else{
//           AppConstant.sharedPreference.setString('DashboardMenu', res.body);
//           return true;
//         }
//
//       }
//       else{
//         return false;
//       }
//     }
//   }
//   static Future<ContactData> getAllContacts(BuildContext context) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getAllContacts);
//     List posts = [];
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token':APIsConstant.productToken,
//         }
//     );
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       posts = json.decode(response.body)['data'];
//       return contactDataFromJson(response.body);
//     } else {
//       context.loaderOverlay.hide();
//       return contactDataFromJson(response.body);
//     }
//   }
//   static Future<ListingData> getMobileModuleSetupListData(BuildContext context,String moduleName) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getMobileModuleSetupListData);
//     List posts = [];
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'moduleName':moduleName,
//         }
//     );
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//
//       posts = json.decode(response.body)['data'];
//       return listingDataFromJson(response.body);
//     } else {
//       context.loaderOverlay.hide();
//       return listingDataFromJson(response.body);
//     }
//   }
//
//   static void addCalendar(String serviceid, String servicename, String fromdate,
//       String todate, String fromtime
//       , String totime, String location, String address, String customername,
//       String cemail, String cmobile,
//       String priest, String pemail, String pmobile, String description,
//       String state, String city, String Zip, String eventtype,
//       String addtionalPriest,String status,String language
//       , BuildContext context) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.addCalendar);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token':  APIsConstant.productToken,
//           //'_id': serviceid,
//           'serviceName': servicename,
//           'date': fromdate,
//           'fromTime': fromtime,
//           'toTime': totime,
//           'location': location,
//           'address': address,
//           'customerName': customername,
//           'customerEmail': cemail,
//           'customerPhone': cmobile,
//           'priest': priest,
//           'priestEmail': pemail,
//           'priestPhone': pmobile,
//           'description': description,
//           'state': state,
//           'city': city,
//           'zip': Zip,
//           'addtionalPriest': addtionalPriest,
//           'eventType': eventtype,
//           'status': status,
//         'prefferedLanguage':language,
//         }
//         );
//
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//       }
//       else{
//
//         Fluttertoast.showToast(msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//
//   static void addProfileDetails(BuildContext context,
//       String contactName,String contactPhone,String contactEmail,String name,String email,String phone,
//       String zip,String city,String state,String address,String rashiName,String gotraName,
//       String age,String nakshatraName,String website,String title,String type,
//       String emailSubscriptionName,String phoneSubscriptionName,companyName,companyEmail,companyPhone,
//       String member1,String nakshatra1,String age1,String rashi1,String relationship1,
//       String member2,String nakshatra2,String age2,String rashi2,String relationship2,
//       String member3,String nakshatra3,String age3,String rashi3,String relationship3,
//       String member4,String nakshatra4,String age4,String rashi4,String relationship4,
//       String member5,String nakshatra5,String age5,String rashi5,String relationship5,
//       String member6,String nakshatra6,String age6,String rashi6,String relationship6,
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.addCalendar);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token':  APIsConstant.productToken,
//           'contactName': contactName, 'contactPhone': contactPhone, 'contactEmail': contactEmail, 'name': name, 'email': email,'phone': phone,
//           'zip': zip, 'city': city, 'state': state, 'address': address, 'rashiName': rashiName,'gotraName': gotraName,
//           'zip': zip, 'city': city, 'state': state, 'name': name, 'email': email,'phone': phone,
//           // 'address': address,
//           // 'customerName': customername,
//           // 'customerEmail': cemail,
//           // 'customerPhone': cmobile,
//           // 'priest': priest,
//           // 'priestEmail': pemail,
//           // 'priestPhone': pmobile,
//           // 'description': description,
//           // 'state': state,
//           // 'city': city,
//           // 'zip': Zip,
//           // 'addtionalPriest': addtionalPriest,
//           // 'eventType': eventtype,
//           // 'status': status,
//           // 'prefferedLanguage':language,
//         }
//     );
//
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//       }
//       else{
//
//         Fluttertoast.showToast(msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static Future<void> getProfile() async {
//     var url = Uri.parse(APIsConstant.getProfile);
//     var response = await http.post(url, body: {
//       'productId': APIsConstant.productID,
//       'username': AppConstant.sharedPreference.getString(AppConstant.userName).toString(),
//       'token': APIsConstant.productToken
//     });
//     if (response.statusCode == 200) {
//       await AppConstant.sharedPreference.setString(AppConstant.firstName, json.decode(response.body)['firstName']??"");
//       await AppConstant.sharedPreference.setString(AppConstant.lastName, json.decode(response.body)['lastName']??"");
//       await AppConstant.sharedPreference.setString(AppConstant.fullName, json.decode(response.body)['fullName']??"");
//       await AppConstant.sharedPreference.setString(AppConstant.userEmail, json.decode(response.body)['userEmail']??"");
//       await AppConstant.sharedPreference.setString(AppConstant.userPhone, json.decode(response.body)['userPhone']??"");
//       await AppConstant.sharedPreference.setString(AppConstant.userState, json.decode(response.body)['userState']??"");
//       await AppConstant.sharedPreference.setString(AppConstant.userAddress, json.decode(response.body)['userAddress']??"");
//       await AppConstant.sharedPreference.setString(AppConstant.userCity, json.decode(response.body)['userCity']??"");
//       await AppConstant.sharedPreference.setString(AppConstant.userZip, json.decode(response.body)['userZip']??"");
//       await AppConstant.sharedPreference.setString(AppConstant.userStatus, json.decode(response.body)['status']??"");
//      // AppConstant.sharedPreference.setString(AppConstant.profileList, response.body);
//     }
//   }
//   // static Future<InventoryListData> getInventryListData(BuildContext context,String contentType,String search) async {
//   //   context.loaderOverlay.show();
//   //   var url = Uri.parse(APIsConstant.getInventoryListData);
//   //   var response = await http.post(url, body: {
//   //     'productId':APIsConstant.productID,
//   //     'token': APIsConstant.productToken,
//   //   });
//   //   if(response.statusCode==200)
//   //   {context.loaderOverlay.hide();
//   //     if (json.decode(response.body)['success'] == false) {
//   //       Fluttertoast.showToast(
//   //           msg: json.decode(response.body)['message'],
//   //           toastLength: Toast.LENGTH_SHORT,
//   //       );
//   //       return InventoryListDataFromJson(response.body);
//   //     }
//   //
//   //     return InventoryListDataFromJson(response.body);
//   //
//   //   }
//   //   else{
//   //     context.loaderOverlay.hide();
//   //     return InventoryListDataFromJson(response.body);
//   //   }
//   // }
//
//
//   static Future<AllTradeData> getAllTradeData(BuildContext context) async {
//     context.loaderOverlay.show();
//     ///business/services/construction/getAllTrades
//     var url = Uri.parse(APIsConstant.getAllTrades);
//     var response = await http.post(url, body:
//     {
//       'productId':  APIsConstant.productID,
//       'token':    APIsConstant.productToken,
//     }
//     );
//     if(response.statusCode==200)
//     {context.loaderOverlay.hide();
//     if (json.decode(response.body)['success'] == false) {
//       Fluttertoast.showToast(
//         msg: json.decode(response.body)['message'],
//         toastLength: Toast.LENGTH_SHORT,
//       );
//       return allTradeDataFromJson(response.body);
//     }
//     return allTradeDataFromJson(response.body);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return allTradeDataFromJson(response.body);
//     }
//   }
//   static Future<ServiceCategoryTypeData> getServiceCategory(BuildContext context) async {
//     context.loaderOverlay.show();
//     ///business/services/construction/getAllTrades
//     var url = Uri.parse(APIsConstant.getServiceCategoryData);
//     var response = await http.post(url, body:
//     {
//       'productId':  "895892fa-127e-4dbf-941e-3e4486a834af",
//       'token':    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmb28iOiJiYXIiLCJpYXQiOjE2NjEyMzg3NTAsImV4cCI6MTY2MzgzMDc1MH0.qlOX4DSvga7KXtHWiTL-rRVANgbwjPfMJpiVV6cfxjE",
//     }
//     );
//     if(response.statusCode==200)
//     {context.loaderOverlay.hide();
//     if (json.decode(response.body)['success'] == false) {
//       Fluttertoast.showToast(
//         msg: json.decode(response.body)['message'],
//         toastLength: Toast.LENGTH_SHORT,
//       );
//       return serviceCategoryTypeDataFromJson(response.body);
//     }
//     return serviceCategoryTypeDataFromJson(response.body);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return serviceCategoryTypeDataFromJson(response.body);
//     }
//   }
//   static Future<ServiceCategoryTypeData> getServiceType(BuildContext context) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getServiceTypes);
//     var response = await http.post(url, body:
//     {
//       'productId':  "895892fa-127e-4dbf-941e-3e4486a834af",
//       'token':    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmb28iOiJiYXIiLCJpYXQiOjE2NjEyMzg3NTAsImV4cCI6MTY2MzgzMDc1MH0.qlOX4DSvga7KXtHWiTL-rRVANgbwjPfMJpiVV6cfxjE",
//
//     }
//     );
//     if(response.statusCode==200)
//     {context.loaderOverlay.hide();
//     if (json.decode(response.body)['success'] == false) {
//       Fluttertoast.showToast(
//         msg: json.decode(response.body)['message'],
//         toastLength: Toast.LENGTH_SHORT,
//       );
//       return serviceCategoryTypeDataFromJson(response.body);
//     }
//     return serviceCategoryTypeDataFromJson(response.body);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return serviceCategoryTypeDataFromJson(response.body);
//     }
//   }
//
//   // static Future<ServicesData> getServiceData(BuildContext context,String category,String serviceType) async {
//   //   context.loaderOverlay.show();
//   //   var url = Uri.parse(APIsConstant.getServiceNameData);
//   //   var response = await http.post(url, body:
//   //   {
//   //     'productId':  "895892fa-127e-4dbf-941e-3e4486a834af",
//   //     'token':    "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJmb28iOiJiYXIiLCJpYXQiOjE2NjEyMzg3NTAsImV4cCI6MTY2MzgzMDc1MH0.qlOX4DSvga7KXtHWiTL-rRVANgbwjPfMJpiVV6cfxjE",
//   //     'category':  category,
//   //     'serviceType':   serviceType,
//   //   }
//   //   );
//   //   if(response.statusCode==200)
//   //   {context.loaderOverlay.hide();
//   //
//   //   if (json.decode(response.body)['success'] == false) {
//   //     Fluttertoast.showToast(
//   //       msg: json.decode(response.body)['message'],
//   //       toastLength: Toast.LENGTH_SHORT,
//   //     );
//   //     return serviceDataFromJson(response.body);
//   //   }
//   //
//   //   return serviceDataFromJson(response.body);
//   //
//   //   }
//   //   else{
//   //     context.loaderOverlay.hide();
//   //     return serviceDataFromJson(response.body);
//   //   }
//   // }
//   //
//
//   static Future<PunchListData> getPunchListData(BuildContext context,String projectId,String trade) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getPunchListDetailsData);
//     var response = await http.post(url, body:
//     {
//       'productId':  APIsConstant.productID,
//       'token':    APIsConstant.productToken,
//       'projectId':projectId,
//       'trade':trade,
//       'date':"07/31/2021",
//     }
//     );
//     if(response.statusCode==200)
//     {context.loaderOverlay.hide();
//     if (json.decode(response.body)['success'] == false) {
//       Fluttertoast.showToast(
//         msg: json.decode(response.body)['message'],
//         toastLength: Toast.LENGTH_SHORT,
//       );
//       return punchListDataFromJson(response.body);
//     }
//     return punchListDataFromJson(response.body);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return punchListDataFromJson(response.body);
//     }
//   }
//
//
//
//   // static Future<BudgetingItemDetailsData> getProjectBudgetingDivisionData(BuildContext context,String projectId) async {
//   //   context.loaderOverlay.show();
//   //   ///common/services/construction/getBasicJobOrderData
//   //   var url = Uri.parse(APIsConstant.getProjectBudgetingDivisionData);
//   //   var response = await http.post(url, body:
//   //   {
//   //     'productId':  APIsConstant.productID,
//   //     'token':    APIsConstant.productToken,
//   //     'projectId':projectId
//   //   }
//   //   );
//   //   if(response.statusCode==200)
//   //   {context.loaderOverlay.hide();
//   //   if (json.decode(response.body)['success'] == false) {
//   //     Fluttertoast.showToast(
//   //       msg: json.decode(response.body)['message'],
//   //       toastLength: Toast.LENGTH_SHORT,
//   //     );
//   //     return projectBudgetingDivisionDataFromJson(response.body);
//   //   }
//   //
//   //   return projectBudgetingDivisionDataFromJson(response.body);
//   //   }
//   //   else{
//   //     context.loaderOverlay.hide();
//   //     return projectBudgetingDivisionDataFromJson(response.body);
//   //   }
//   // }
//   // static Future<ProjectEstimatorSelectionData> getProjectEstimatorSelectionData(BuildContext context,String projectId,String estimatorName) async {
//   //   context.loaderOverlay.show();
//   //   ///business/services/construction/getProjectEstimatorSelectionData
//   //   var url = Uri.parse(APIsConstant.getProjectEstimatorSelectionData);
//   //   var response = await http.post(url, body:
//   //   {
//   //     'productId':  APIsConstant.productID,
//   //     'token':    APIsConstant.productToken,
//   //     'projectId':projectId,
//   //     'estimatorName':estimatorName
//   //   }
//   //   );
//   //   if(response.statusCode==200)
//   //   {context.loaderOverlay.hide();
//   //   if (json.decode(response.body)['success'] == false) {
//   //     Fluttertoast.showToast(
//   //       msg: json.decode(response.body)['message'],
//   //       toastLength: Toast.LENGTH_SHORT,
//   //     );
//   //     return projectEstimatorSelectionDataFromJson(response.body);
//   //   }
//   //   return projectEstimatorSelectionDataFromJson(response.body);
//   //   }
//   //   else{
//   //     context.loaderOverlay.hide();
//   //     return projectEstimatorSelectionDataFromJson(response.body);
//   //   }
//   // }
//   // static Future<EstimatorSelectionProjectOrderData> getEstimatorSelectionProjectOrderData(BuildContext context,String projectId,String estimatorName
//   //
//   //   ,  String date,String customerName
//   //     ) async {
//   //   context.loaderOverlay.show();
//   //   ///business/services/construction/getProjectEstimatorSelectionData
//   //   var url = Uri.parse(APIsConstant.getEstimatorSelectionProjectOrderData);
//   //   var response = await http.post(url, body:
//   //   {
//   //     'productId':  APIsConstant.productID,
//   //     'token':    APIsConstant.productToken,
//   //     'projectId':projectId,
//   //     'date':date,
//   //     'customerName':customerName,
//   //     'estimatorName':estimatorName
//   //   }
//   //   );
//   //   if(response.statusCode==200)
//   //   {context.loaderOverlay.hide();
//   //   if (json.decode(response.body)['success'] == false) {
//   //     Fluttertoast.showToast(
//   //       msg: json.decode(response.body)['message'],
//   //       toastLength: Toast.LENGTH_SHORT,
//   //     );
//   //     return estimatorSelectionProjectOrderDataFromJson(response.body);
//   //   }
//   //
//   //   return estimatorSelectionProjectOrderDataFromJson(response.body);
//   //   }
//   //   else{
//   //     context.loaderOverlay.hide();
//   //     return estimatorSelectionProjectOrderDataFromJson(response.body);
//   //   }
//   // }
//   // static Future<EstimatorSelectionProjectTaskData> getEstimatorSelectionProjectTaskData(BuildContext context,String projectId,String estimatorName
//   //     ,  String date,String customerName,String orderName
//   //     ) async {
//   //   context.loaderOverlay.show();
//   //   ///business/services/construction/getProjectEstimatorSelectionData
//   //   var url = Uri.parse(APIsConstant.getEstimatorSelectionProjectTaskData);
//   //   var response = await http.post(url, body:
//   //   {
//   //     'productId':  APIsConstant.productID,
//   //     'token':    APIsConstant.productToken,
//   //     'projectId':projectId,
//   //     'date':date,
//   //     'customerName':customerName,
//   //     'estimatorName':estimatorName,
//   //     "orderName":orderName
//   //   }
//   //   );
//   //   if(response.statusCode==200)
//   //   {context.loaderOverlay.hide();
//   //   if (json.decode(response.body)['success'] == false) {
//   //     Fluttertoast.showToast(
//   //       msg: json.decode(response.body)['message'],
//   //       toastLength: Toast.LENGTH_SHORT,
//   //     );
//   //     return estimatorSelectionProjectTaskDataFromJson(response.body);
//   //   }
//   //
//   //   return estimatorSelectionProjectTaskDataFromJson(response.body);
//   //   }
//   //   else{
//   //     context.loaderOverlay.hide();
//   //     return estimatorSelectionProjectTaskDataFromJson(response.body);
//   //   }
//   // }
//   //
//   // static Future<EstimatorSelectionLaborFloorData> getEstimatorSelectionLaborFloorData(BuildContext context,String projectId,String estimatorName
//   //     ,  String date,String customerName
//   //     ) async {
//   //   context.loaderOverlay.show();
//   //   ///business/services/construction/getProjectEstimatorSelectionData
//   //   var url = Uri.parse(APIsConstant.getEstimatorSelectionLaborFloorData);
//   //   var response = await http.post(url, body:
//   //   {
//   //     'productId':  APIsConstant.productID,
//   //     'token':    APIsConstant.productToken,
//   //     'projectId':projectId,
//   //     'date':date,
//   //     'customerName':customerName,
//   //     'estimatorName':estimatorName,
//   //
//   //   }
//   //   );
//   //   if(response.statusCode==200)
//   //   {context.loaderOverlay.hide();
//   //   if (json.decode(response.body)['success'] == false) {
//   //     Fluttertoast.showToast(
//   //       msg: json.decode(response.body)['message'],
//   //       toastLength: Toast.LENGTH_SHORT,
//   //     );
//   //     return estimatorSelectionLaborFloorDataFromJson(response.body);
//   //   }
//   //
//   //   return estimatorSelectionLaborFloorDataFromJson(response.body);
//   //   }
//   //   else{
//   //     context.loaderOverlay.hide();
//   //     return estimatorSelectionLaborFloorDataFromJson(response.body);
//   //   }
//   // }
//
//
//   static Future<AssetsMgmtDataDetails> getAssetsListDataDetails(BuildContext context,String id) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getAssetsListDataDetails);
//     var response = await http.post(url, body: {
//       'productId':APIsConstant.productID,
//       '_id':id,
//     });
//     if(response.statusCode==200)
//     {context.loaderOverlay.hide();
//     if (json.decode(response.body)['success'] == false) {
//       Fluttertoast.showToast(
//         msg: json.decode(response.body)['message'],
//         toastLength: Toast.LENGTH_SHORT,
//       );
//       return assetsMgmtDataDetailsFromJson(response.body);
//     }
//
//     return assetsMgmtDataDetailsFromJson(response.body);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return assetsMgmtDataDetailsFromJson(response.body);
//     }
//   }
//
//   static Future<bool>  DeleteInventoryData(BuildContext context,String id) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.deleteInventory);
//     var response = await http.post(url, body: {
//       'productId':APIsConstant.productID,
//       '_id':id
//     });
//     if(response.statusCode==200)
//     {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//         );
//         return false;
//       }
//       else{
//         return true;
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return false;
//     }
//   }
//
//   static void addAssets(BuildContext context,
//       String assetName,String status,String  category,String type,String assetId,String modelNo,
//       String make,String brand,String  color,String year,String ownerFirstName,String ownerLastName,
//       String ownerPhone,String ownerEmail,String  ownerFax,String location,String firstRegDate,String assetAssignDate,
//       String memberName,String vendorName,String  vendorPhone,String vendorEmail,String specification
//   ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.addAssetData);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'assetName': assetName,
//           'status': status,
//           'category': category,
//           'type': type,
//           'assetId': assetId,
//           'modelNo': modelNo,
//           'make': make,
//           'brand': brand,
//           'color': color,
//           'year': year,
//            'ownerFirstName':ownerFirstName,
//           'ownerLastName': ownerLastName,
//           'ownerPhone':ownerPhone,
//           'ownerEmail': ownerEmail,
//           'ownerFax': ownerFax,
//           'location': location,
//           'firstRegDate': firstRegDate,
//           'assetAssignDate': assetAssignDate,
//           'memberName': memberName,
//           'vendorName': vendorName,
//           'vendorPhone': vendorPhone,
//           'vendorEmail': vendorEmail,
//           'specification': specification,
//         }
//
//     );
//     print(response.statusCode.toString());
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//
//   static void postAssets(BuildContext context,String id,
//       String assetName,String status,String  category,String type,String assetId,String modelNo,
//       String make,String brand,String  color,String year,String ownerFirstName,String ownerLastName,
//       String ownerPhone,String ownerEmail,String  ownerFax,String location,String firstRegDate,String assetAssignDate,
//       String memberName,String vendorName,String  vendorPhone,String vendorEmail,String specification
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.postAssetData);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           '_id':id,
//           'assetName': assetName,
//           'status': status,
//           'category': category,
//           'type': type,
//           'assetId': assetId,
//           'modelNo': modelNo,
//           'make': make,
//           'brand': brand,
//           'color': color,
//           'year': year,
//           'ownerFirstName':ownerFirstName,
//           'ownerLastName': ownerLastName,
//           'ownerPhone':ownerPhone,
//           'ownerEmail': ownerEmail,
//           'ownerFax': ownerFax,
//           'location': location,
//           'firstRegDate': firstRegDate,
//           'assetAssignDate': assetAssignDate,
//           'memberName': memberName,
//           'vendorName': vendorName,
//           'vendorPhone': vendorPhone,
//           'vendorEmail': vendorEmail,
//           'specification': specification,
//         }
//
//     );
//
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static Future<PurchaseListData> getPurchaseList(BuildContext context) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getPurchaseListData);
//     var response = await http.post(url, body:GlobalApis.bodies);
//     if(response.statusCode==200)
//     {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//             msg: " No Purchase List Data",
//             toastLength: Toast.LENGTH_SHORT,
//         );
//         return purchaseListDataFromJson(response.body);
//       }
//       else{
//         return purchaseListDataFromJson(response.body);
//       }
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return purchaseListDataFromJson(response.body);
//     }
//   }
//   static void addPurchaseList(BuildContext context,
//       String store,String title,String  status,String categoryName,String item,String qty,String description,String date,String orderNo
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.addPurchaseData);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           'store': store,
//           'title': title,
//           'status': status,
//           'categoryName': categoryName,
//           'item': item,
//           'qty': qty,
//           'description': description,
//          'date':date,
//          'orderNo':orderNo
//         }
//
//     );
//
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//         Get.to(()=>PurchasePage(title: 'Purchase List',));
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static void postPurchaseList(BuildContext context,String id,
//       String store,String title,String  status,String categoryName,String item,String qty,String description,String date,String orderNo
//
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.postPurchaseData);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           '_id': id,
//           'store': store,
//           'title': title,
//           'status': status,
//           'categoryName': categoryName,
//           'item': item,
//           'qty': qty,
//           'description': description,
//           'date': date,
//           'orderNo': orderNo,
//         }
//         );
//
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//         Get.to(()=>PurchasePage(title: 'Purchase List',));
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static Future<bool>  DeletePurchaseData(BuildContext context,String id) async {
//     context.loaderOverlay.show();
//
//     var url = Uri.parse(APIsConstant.deletePurchaseListData);
//     var response = await http.post(url, body: {
//       'productId':APIsConstant.productID,
//       '_id':id
//     });
//     if(response.statusCode==200)
//     {
//        context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//         );
//         return false;
//       }
//       else{
//         return true;
//       }
//     }
//     else{
//      context.loaderOverlay.hide();
//       return false;
//     }
//   }
//
//
//   static Future<MenuData> getMenuData(BuildContext context,String search,String category) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getMenuData);
//     var response = await http.post(url, body: {
//       'productId': APIsConstant.productID,
//       'menuGroup':category,
//     });
//     if(response.statusCode==200)
//     {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//             msg: " No Menu Item In $category",
//             toastLength: Toast.LENGTH_SHORT,
//         );
//         return menuDataFromJson(response.body);
//       }
//       else{
//         return menuDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return menuDataFromJson(response.body);
//     }
//   }
//
//   static void addCheckListData(BuildContext context,
//       String projectId,String projectName,String itemName,
//       String floorName,String roomName,String  subcontractorName,
//       String technician,String trade,String  status,String approved,String reason,
//       String mobile,String email
//
//       ) async {
//
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.addJobChecklist);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           'projectId': projectId,
//           'projectName': projectName,
//           'floorName': floorName,
//           'itemName': itemName,
//           'roomName': roomName,
//           'subcontractorName': subcontractorName,
//           'technician': technician,
//           'trade': trade,
//           'status': status,
//           'approved':approved,
//           'reason':reason,
//           'phone':mobile,
//           'email':email,
//         }
//
//     );
//     print(response.statusCode.toString());
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//         Get.to(()=>ChecklistPage(title: "Checklist", projectId: projectId,projectName: projectName,));
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static void postCheckListData(BuildContext context,String Id,
//       String projectId,String projectName,String itemName,
//       String floorName,String roomName,String  subcontractorName,
//       String technician,String trade,String  status,String approved,String reason,
//       String mobile,String email
//       ) async {
//
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.postJobCheckList);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           "_id":Id,
//           'projectId': projectId,
//           'projectName': projectName,
//           'floorName': floorName,
//           'roomName': roomName,
//           'itemName': itemName,
//           'subcontractor': subcontractorName,
//           'technician': technician,
//           'trade': trade,
//           'status': status,
//           'approved':approved,
//           'reason':reason,
//           'phone':mobile,
//           'email':email,
//         }
//
//     );
//     print(response.statusCode.toString());
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//         Get.to(()=>ChecklistPage(title: "Checklist", projectId: projectId,projectName: projectName,));
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static void postJobCheckListData(BuildContext context,String Id,
//       String projectId,String projectName,String itemName,
//       String floorName,String roomName,String  subcontractorName,
//       String technician,String trade,String  status,String approved,String reason,
//       String mobile,String email
//       ) async {
//
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.postJobCheckList);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           "_id":Id,
//           'projectId': projectId,
//           'projectName': projectName,
//           'floorName': floorName,
//           'roomName': roomName,
//           'itemName': itemName,
//           'subcontractor': subcontractorName,
//           'technician': technician,
//           'trade': trade,
//           'status': status,
//           'approved':approved,
//           'reason':reason,
//           'phone':mobile,
//           'email':email,
//         }
//
//     );
//     print(response.statusCode.toString());
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//         Get.to(()=>JobChecklistPage(title: "Checklist", projectId: projectId,projectName: projectName,));
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static Future<CheckInOutJobData> getCheckInOutJobName(BuildContext context, String projectName) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getCheckinCheckoutJobTypes);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectName':projectName,
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       print("jbdsbvsd"+response.body);
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(msg:"No job available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return checkInOutJobDataFromJson(response.body);
//       }
//       else{
//         return checkInOutJobDataFromJson(response.body);
//       }
//
//      // AppConstant.sharedPreference.setString(AppConstant.jobNameTypesList, json.encode(s["jobNameTypes"]));
//     }
//     else{
//       context.loaderOverlay.hide();
//       return checkInOutJobDataFromJson(response.body);
//     }
//   }
//   static void getCheckinCheckoutJobDetailsData(String projectName,String jobName,emailId) async {
//    //business/services/construction/getCheckinCheckoutJobDetailsData
//     var url = Uri.parse(APIsConstant.getCheckinCheckoutJobDetailsData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectName':projectName,
//       'jobName':jobName,
//       'emailId':emailId,
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//           print("kbjdsvbkjvdsbjk"+response.body);
//     }
//   }
//
//
//
//   static void addProjectProfile(BuildContext context,
//       String projectNumber,String projectName,String  squareFeet
//       ,String tradeName,String contactName,String projectType,String projectStartDate
//       ,String projectEndDate,String mobile,String zip,String city
//       ,String state,String address,String community,String email
//       ,String division,String lotNo
//       ) async {
//     print( "sacvavca");
//     print(
//         {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           'projectName': projectName,
//           'projectNumber': projectNumber,
//           'squareFeet': squareFeet,
//           'projectType': projectType,
//           'projectStartDate': projectStartDate,
//           'projectEndDate': projectEndDate,
//           'email': email,
//           'contactName':contactName,
//           'phone':mobile,
//           'lotNo':lotNo,
//           'zip':zip,
//           'city':city,
//           'state':state,
//           'address':address,
//           'community':community,
//           'division':division,
//         }
//
//     );
//     ///business/services/construction/addProjectProfile
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.addProjectProfile);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           'projectName': projectName,
//           'projectNumber': projectNumber,
//           'squareFeet': squareFeet,
//           'projectType': projectType,
//           'projectStartDate': projectStartDate,
//           'projectEndDate': projectEndDate,
//           'email': email,
//           'contactName':contactName,
//           'phone':mobile,
//           'zip':zip,
//           'city':city,
//           'state':state,
//           'address':address,
//           'community':community,
//           'division':division,
//         }
//
//     );
//     print(response.statusCode.toString());
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//         Get.to(()=>ProjectPage(title: "Project Profile"));
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static void postProjectProfile(BuildContext context,String projectId,
//       String projectNumber,String projectName,String  squareFeet
//       ,String tradeName,String contactName,String projectType,String projectStartDate
//       ,String projectEndDate,String mobile,String zip,String city
//       ,String state,String address,String community,String email
//       ,String division,String lotNo
//       ) async {
//     ///common/services/construction/postProjectProfile
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.postProjectProfile);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           'projectName': projectName,
//           'projectId': projectId,
//           'projectNumber': projectNumber,
//           'squareFeet': squareFeet,
//           'projectType': projectType,
//           'projectStartDate': projectStartDate,
//           'projectEndDate': projectEndDate,
//           'email': email,
//           'lotNo': lotNo,
//           'contactName':contactName,
//           'phone':mobile,
//           'zip':zip,
//           'city':city,
//           'state':state,
//           'address':address,
//           'community':community,
//           'division':division,
//         }
//
//     );
//
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//         Get.back();
//         Get.to(()=>ProjectPage(title: "Project Profile"));
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static Future<AvailabilityData> getAvailabilityData(BuildContext context) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getAvailabilityData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg:"No job available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return availabilityDataFromJson(response.body);
//       }
//       else{
//         return availabilityDataFromJson(response.body);
//       }
//
//       // AppConstant.sharedPreference.setString(AppConstant.jobNameTypesList, json.encode(s["jobNameTypes"]));
//     }
//     else{
//       context.loaderOverlay.hide();
//       return availabilityDataFromJson(response.body);;
//     }
//   }
//   static Future<WalkThroughTypeData> getWalkThroughTypes(BuildContext context) async {
//     ///business/services/construction/getWalkThroughTypes
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getWalkThroughTypes);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg:"No data available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return walkThroughTypeDataFromJson(response.body);
//       }
//       else{
//         return walkThroughTypeDataFromJson(response.body);
//       }
//
//       // AppConstant.sharedPreference.setString(AppConstant.jobNameTypesList, json.encode(s["jobNameTypes"]));
//     }
//     else{
//       context.loaderOverlay.hide();
//       return walkThroughTypeDataFromJson(response.body);;
//     }
//   }
//   static Future<TimelineData> getTimelineData(BuildContext context,String projectId) async {
//     //business/services/construction/getTimelineData
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getTimelineData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId': projectId,
//       'eventType': "Timeline",
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg:"No data available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return timelineDataFromJson(response.body);
//       }
//       else{
//         return timelineDataFromJson(response.body);
//       }
//
//       // AppConstant.sharedPreference.setString(AppConstant.jobNameTypesList, json.encode(s["jobNameTypes"]));
//     }
//     else{
//       context.loaderOverlay.hide();
//       return timelineDataFromJson(response.body);;
//     }
//   }
//
//   static Future<TimelineDetailsData> getTimelineDetailsData(BuildContext context ,String jobName,String projectId) async {
//     //business/services/construction/getTimelineDetailsData
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getTimelineDetailsData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId': projectId,
//       'jobName': jobName,
//       'eventType': "Timeline",
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg:"No data available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return timelineDetailsDataFromJson(response.body);
//       }
//       else{
//         return timelineDetailsDataFromJson(response.body);
//       }
//
//       // AppConstant.sharedPreference.setString(AppConstant.jobNameTypesList, json.encode(s["jobNameTypes"]));
//     }
//     else{
//       context.loaderOverlay.hide();
//       return timelineDetailsDataFromJson(response.body);;
//     }
//   }
//   static void addTimelineData(BuildContext context,String projectName,String  projectId
//       ,String jobName,String jobCategory,String jobAddress,String trade
//       ,String subcontractor,String email,String jobDescription,String status
//       ,String milestoneStartDate,String milestoneEndDate,
//       ) async {
//    //business/services/construction/addTimelineData
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.addTimelineData);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           'projectName': projectName,
//           'projectId': projectId,
//           'jobName': jobName,
//           'jobCategory': jobCategory,
//           'jobAddress': jobAddress,
//           'trade': trade,
//           'subcontractor': subcontractor,
//           'email': email,
//           'jobDescription':jobDescription,
//           'status':status,
//           'milestoneStartDate':milestoneStartDate,
//           'milestoneEndDate':milestoneEndDate,
//         }
//         );
//
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//         Get.to(()=>TimelinePage(title: "Timelines", projectName: projectName, productId: projectId,));
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static void postTimelineData(BuildContext context,
//       String id,String projectName,String  projectId
//       ,String jobName,String jobCategory,String jobAddress,String trade
//       ,String subcontractor,String email,String jobDescription,String status
//       ,String milestoneStartDate,String milestoneEndDate,
//       ) async {
//     ///business/services/construction/postTimelineData
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.postTimelineData);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           'projectName': projectName,
//           '_id': id,
//           'projectId': projectId,
//           'jobName': jobName,
//           'jobCategory': jobCategory,
//           'jobAddress': jobAddress,
//           'trade': trade,
//           'subcontractor': subcontractor,
//           'email': email,
//           'jobDescription':jobDescription,
//           'status':status,
//           'milestoneStartDate':milestoneStartDate,
//           'milestoneEndDate':milestoneEndDate,
//         }
//     );
//
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//         Get.to(()=>TimelinePage(title: "Timelines", projectName: projectName, productId: projectId,));
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static Future<DocumentData> getDocumentsData(BuildContext context,String projectId) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProjectDocumentData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId': projectId,
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg:"No data available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return documentDataFromJson(response.body);
//       }
//       else{
//         return documentDataFromJson(response.body);
//       }
//
//       // AppConstant.sharedPreference.setString(AppConstant.jobNameTypesList, json.encode(s["jobNameTypes"]));
//     }
//     else{
//       context.loaderOverlay.hide();
//       return documentDataFromJson(response.body);;
//     }
//   }
//
//   static void addProjectPunchlist(BuildContext context,
//       String projectNumber,String projectName,String  projectId
//       ,String roomName,String itemName,String status,String floorName,
//       String subcontractor,String fileName,String trade,String notes,
//       String signature,String baseCode,String issue
//
//       ) async {
//     //business/services/construction/addProjectPunchlist
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.addTimelineData);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           'projectId': projectId,
//           'roomName': roomName,
//           'itemName': itemName,
//           'status': status,
//           'floorName': floorName,
//           'subcontractor': subcontractor,
//           'fileName': fileName,
//           'trade':trade,
//           'notes':notes,
//           'issue':issue,
//           'signature':signature,
//           'baseCode':baseCode,
//           // 'milestoneStartDate':milestoneStartDate,
//           // 'milestoneEndDate':milestoneEndDate,
//         }
//     );
//
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg: json.decode(response.body)['message'],
//           toastLength: Toast.LENGTH_SHORT,
//         );
//
//       }
//       else{
//         Fluttertoast.showToast(
//             msg: json.decode(response.body)['message'],
//             toastLength: Toast.LENGTH_SHORT,
//             backgroundColor: Colors.green
//         );
//         Get.back();
//         Get.back();
//         Get.to(()=>PunchListPage(title: "Punchlist", projectName: projectName, projectId:projectId,trade: trade,));
//       }
//       // Navigator.pop(context);
//
//     }
//     else{
//       context.loaderOverlay.hide();
//     }
//   }
//   static Future<TimeCardTypeData> getTimeCardTypes(BuildContext context) async {
//     ///common/services/construction/getTimeCardTypes
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getTimeCardTypes);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg:"No data available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return timeCardTypeDataFromJson(response.body);
//       }
//       else{
//         return timeCardTypeDataFromJson(response.body);
//       }
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return timeCardTypeDataFromJson(response.body);;
//     }
//   }
//   static Future<NearbyCategoryTypeData> getnearbyCategorytypes(BuildContext context) async {
//     ///common/services/construction/getTimeCardTypes
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getAttractoionCategoryType);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg:"No data available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return nearbyCategoryTypeDataFromJson(response.body);
//       }
//       else{
//         return nearbyCategoryTypeDataFromJson(response.body);
//       }
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return nearbyCategoryTypeDataFromJson(response.body);;
//     }
//   }
//   static Future<NearbyDetailsData> getNearbyData(BuildContext context,String projectId,String category) async {
//     ///common/services/construction/getTimeCardTypes
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getAttractoionDetailsData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId':projectId,
//       'category':category
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg:"No data available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return nearbyDetailsDataFromJson(response.body);
//       }
//       else{
//         return nearbyDetailsDataFromJson(response.body);
//       }
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return nearbyDetailsDataFromJson(response.body);;
//     }
//   }
//   static Future<ProjectInvoiceSelectionData> getProjectInvoiceSelectionData(BuildContext context,String projectId) async {
//     ///common/services/construction/getTimeCardTypes
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProjectInvoiceSelectionData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId':projectId,
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg:"No data available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return projectInvoiceSelectionDataFromJson(response.body);
//       }
//       else{
//         return projectInvoiceSelectionDataFromJson(response.body);
//       }
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return projectInvoiceSelectionDataFromJson(response.body);;
//     }
//   }
//
//
//   static Future<CostPlusInvoiceData> getCostPlusInvoiceData(BuildContext context,String projectId) async {
//     ///common/services/construction/getTimeCardTypes
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getCostPlusInvoiceData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId':projectId,
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(
//           msg:"No data available",
//           toastLength: Toast.LENGTH_SHORT,
//         );
//         return costPlusInvoiceDataFromJson(response.body);
//       }
//       else{
//         return costPlusInvoiceDataFromJson(response.body);
//       }
//
//     }
//     else{
//       context.loaderOverlay.hide();
//       return costPlusInvoiceDataFromJson(response.body);;
//     }
//   }
//
//
//   static Future<ProjectInvoiceTypeData> getProjectInvoiceType(BuildContext context,String projectId,
//       String date,String customer,String invoiceNo,String status
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProjectInvoiceType);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId':projectId,
//       'date':date,
//       'customer':customer,
//       'invoiceNo':invoiceNo,
//       'status':status,
//     });
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return projectInvoiceTypeDataFromJson(response.body);
//       }
//       else{
//         return projectInvoiceTypeDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return projectInvoiceTypeDataFromJson(response.body);;
//     }
//   }
//   static Future<ProjectInvoiceDetailData> getProjectInvoiceDetailData(BuildContext context,String projectId,
//       String date,String customer,String invoiceNo,String status,String projectInvoiceTypeName
//       ) async {
//
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProjectInvoiceDetailData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId':projectId,
//       'date':date,
//       'customer':customer,
//       'invoiceNo':invoiceNo,
//       'status':status,
//       'projectInvoiceTypeName':projectInvoiceTypeName,
//     }
//     );
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return projectInvoiceDetailDataFromJson(response.body);
//       }
//       else{
//         return projectInvoiceDetailDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return projectInvoiceDetailDataFromJson(response.body);;
//     }
//   }
//
//   static Future<CostPlusInvoiceDetailsData> getCostPlusInvoiceDetailsData(BuildContext context,String projectId, String invoiceNo
//       ) async {
//
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getCostPlusInvoiceDetailsData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId':projectId,
//       'invoiceNo':invoiceNo,
//     }
//     );
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return costPlusInvoiceDetailsDataFromJson(response.body);
//       }
//       else{
//         return costPlusInvoiceDetailsDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return costPlusInvoiceDetailsDataFromJson(response.body);;
//     }
//   }
//   static Future<ProjectImagesData> getProjectImagesData(BuildContext context,String projectId, String category
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProjectImagesData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId':projectId,
//       'category':category,
//     }
//     );
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return projectImagesDataFromJson(response.body);
//       }
//       else{
//         return projectImagesDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return projectImagesDataFromJson(response.body);;
//     }
//   }
//
//
//  static void testApi(String projectId,String divisionsName,String productName)async {
//    var url = Uri.parse(APIsConstant.getProductSelectionProductListData);
//    var response = await http.post(url, body:
//    {
//      'productId': APIsConstant.productID,
//      'token': APIsConstant.productToken,
//      "projectId":projectId,
//      "divisionsName":divisionsName,
//      "product":productName
//    }
//    );
//    if (response.statusCode == 200) {
//
//
//    }
//
//  }
//   static Future<ProductSelectionDetailData> getProductSelectionProductData(BuildContext context,String projectId,
//   String divisionsName  ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProductSelectionProductData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId': projectId,
//       "divisionsName":divisionsName
//     }
//     );
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//
//       if (json.decode(response.body)['success'] == false) {
//
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return productSelectionDetailDataFromJson(response.body);
//       }
//       else{
//         return productSelectionDetailDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return productSelectionDetailDataFromJson(response.body);;
//     }
//   }
//   static Future<ProductSelectionDetailData> getProductSelectionDivisionData(BuildContext context,String projectId
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProductSelectionDivisionData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId': projectId,
//     }
//     );
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return productSelectionDetailDataFromJson(response.body);
//       }
//       else{
//         return productSelectionDetailDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return productSelectionDetailDataFromJson(response.body);;
//     }
//   }
//
//
//
//
//
//   static Future<ProjectSelectionDetailData> getProjectSelectionDetailData(BuildContext context,String projectId
//       ,String floorName,String categoryName,String roomName,String itemName
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProjectSelectionDetailData);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId': projectId,
//       'floorName':floorName,
//       "categoryName":categoryName,
//       "roomName":roomName,
//       "categoryItemName":itemName,
//     }
//     );
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return projectSelectionDetailDataFromJson(response.body);
//       }
//       else{
//         return projectSelectionDetailDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return projectSelectionDetailDataFromJson(response.body);;
//     }
//   }
//
//
//
//
//
//   static Future<ProjectSelectionFloorData> getSelectionCategorTypesName(BuildContext context,String projectId,String floorName
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProjectSelectionCategoryTypes);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId': projectId,
//       'floorName':floorName
//
//     }
//     );
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//
//       if (json.decode(response.body)['success'] == false) {
//
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return projectSelectionFloorDataFromJson(response.body);
//       }
//       else{
//         return projectSelectionFloorDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return projectSelectionFloorDataFromJson(response.body);;
//     }
//   }
//   static Future<ProjectSelectionFloorData> getProjectSelectionCategoryItemDataTypes(BuildContext context,String projectId,String floorName,String categoryName
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProjectSelectionCategoryItemDataTypes);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId': projectId,
//       'floorName':floorName,
//       "categoryName":categoryName
//     }
//     );
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//
//       if (json.decode(response.body)['success'] == false) {
//
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return projectSelectionFloorDataFromJson(response.body);
//       }
//       else{
//         return projectSelectionFloorDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return projectSelectionFloorDataFromJson(response.body);;
//     }
//   }
//   static Future<ProjectSelectionFloorData> getProjectSelectionFloorTypes(BuildContext context,String projectId
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProjectSelectionFloorTypes);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId':projectId,
//     }
//     );
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return projectSelectionFloorDataFromJson(response.body);
//       }
//       else{
//         return projectSelectionFloorDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return projectSelectionFloorDataFromJson(response.body);;
//     }
//   }
//
//   static Future<ProjectSelectionFloorData> getProjectSelectionRoomTypes(BuildContext context,String projectId,String floorName
//       ) async {
//     context.loaderOverlay.show();
//     var url = Uri.parse(APIsConstant.getProjectSelectionRoomTypes);
//     var response = await http.post(url, body:
//     {
//       'productId': APIsConstant.productID,
//       'token': APIsConstant.productToken,
//       'projectId':projectId,
//       "floorName":floorName
//     }
//     );
//     var s = json.decode(response.body);
//     if (response.statusCode == 200) {
//       context.loaderOverlay.hide();
//       if (json.decode(response.body)['success'] == false) {
//         Fluttertoast.showToast(msg:json.decode(response.body)['message'], toastLength: Toast.LENGTH_SHORT,
//         );
//         return projectSelectionFloorDataFromJson(response.body);
//       }
//       else{
//         return projectSelectionFloorDataFromJson(response.body);
//       }
//     }
//     else{
//       context.loaderOverlay.hide();
//       return projectSelectionFloorDataFromJson(response.body);;
//     }
//   }
//   static void cancelTempleCalendar(String _id, BuildContext context) async {
//     var url = Uri.parse(APIsConstant.deleteCalendarData);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           '_id': _id,
//         }
//     );
//     if (response.statusCode == 200) {
//
//
//       Fluttertoast.showToast(
//           msg: "success",
//           toastLength: Toast.LENGTH_SHORT,
//           gravity: ToastGravity.BOTTOM,
//           timeInSecForIosWeb: 1,
//           backgroundColor: Colors.green,
//           textColor: Colors.white,
//           fontSize: 16.0
//       );
//     }
//   }
//
//   static void postTempleCalendar(String status, String _id,
//       BuildContext context, String flag) async {
//       var url = Uri.parse(APIsConstant.postTempleCalendar);
//     var response = await http.post(url,
//         body: {
//           'productId': APIsConstant.productID,
//           'token': APIsConstant.productToken,
//           '_id': _id,
//           'status': status
//         }
//
//     );
//     if (response.statusCode == 200) {
//
//       if (flag == 2) {
//
//       }
//       Fluttertoast.showToast(
//           msg: "success",
//           toastLength: Toast.LENGTH_SHORT,
//           gravity: ToastGravity.BOTTOM,
//           timeInSecForIosWeb: 1,
//           backgroundColor: Colors.green,
//           textColor: Colors.white,
//           fontSize: 16.0
//       );
//     }
//   }
//  static int getDayInt(id){
//     int a;
//     switch (id)
//     {
//       case 'MONDAY':
//         a=1;
//         break;
//       case 'TUESDAY':
//         a=2;
//         break;
//       case 'WEDNESDAY':
//         a=3;
//         break;
//       case 'THRUSDAY':
//         a=4;
//         break;
//       case 'FRIDAY':
//         a=5;
//         break;
//       case 'SATURDAY':
//         a=6;
//         break;
//       case 'SUNDAY':
//         a=7;
//         break;
//       default:
//         a=9;
//         break;
//     }
//     return a;
//   }
// }