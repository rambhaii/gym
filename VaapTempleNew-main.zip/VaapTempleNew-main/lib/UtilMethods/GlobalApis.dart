import 'dart:convert';
import 'dart:math';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/Templates/Model/CityData.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:loader_overlay/loader_overlay.dart';
class GlobalApis{
  static String getFileSizeString({required int bytes, int decimals = 0}) {
    const suffixes = ["b", "kb", "mb", "gb", "tb"];
    var i = (log(bytes) / log(1024)).floor();
    return ((bytes / pow(1024, i)).toStringAsFixed(decimals));
  }
  static final bodies={
    'productId':  APIsConstant.productID,
    'token':    APIsConstant.productToken,
       };
  static void getState() async {
    var url = Uri.parse(APIsConstant.getStateType);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.stateList, json.encode(s["data"]));
    }
  }
  static void getMemberType() async {
    var url = Uri.parse(APIsConstant.getMemberType);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.memberTypeList, json.encode(s["data"]));
    }
  }
  static Future<CityData> getCity(BuildContext context,String stateName) async {
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.getCityType);
    var response = await http.post(url, body: {
      'productId':APIsConstant.productID,
      'token': APIsConstant.productToken,
      'stateName': stateName,
    });
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      context.loaderOverlay.hide();
      print("hbvhbvdsh"+response.body);
      return cityDataFromJson(response.body);
    }
    else{
      context.loaderOverlay.hide();
      return cityDataFromJson(response.body);
    }
  }
  static void getInventoryCategoryType() async {
    var url = Uri.parse(APIsConstant.getInventoryCategoryType);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    //categoryType
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.inventoryCategoryTypeList, json.encode(s["categoryTypeDetails"]));
    }
  }
  static void getUOM() async {
    var url = Uri.parse(APIsConstant.getUOM);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      // proportions
      AppConstant.sharedPreference.setString(AppConstant.UOMList, json.encode(s["data"]));
    }
  }
  static void getServiceName() async {
    var url = Uri.parse(APIsConstant.getServiceName);
    Map<String, dynamic>? BodyData = {};
    BodyData['productId']=APIsConstant.productID;
    var response = await http.post(url,
        headers: {"Content-Type": "application/json"},
        body: json.encode(BodyData));
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
     // print("ccxjbhbhs"+response.body);
      AppConstant.sharedPreference.setString(AppConstant.serviceNameList, json.encode(s["data"]));
    }
  }
 static Future<void> getCustomerDetails() async {
    var url = Uri.parse("https://temple.vaaptech.com//business/services/getCustomerDetails");
    var response = await http.post(url, body:bodies);
    if (response.statusCode == 200) {
      var s = json.decode(response.body);
      AppConstant.sharedPreference.setString(AppConstant.customerNameList, json.encode(s["data"]));
      }
    }
  static void getGotra() async {
    var url = Uri.parse(APIsConstant.getGotra);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    print("getGotra" + json.encode(s["data"]));
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.gotraList, json.encode(s["data"]));
    }
}
  static void getNakshatra() async {
    var url = Uri.parse(APIsConstant.getNakshatra);
    var response = await http.post(url, body: bodies);
    var s = json.decode(response.body);
   // print("getNakshatra" + json.encode(s["data"]));
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.nakshatra, json.encode(s["data"]));
    }
  }
  static void getRashi() async {
    var url = Uri.parse(APIsConstant.getRashi);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.rashiList, json.encode(s["data"]));
    }
  }
  static void getRelation() async {
    var url = Uri.parse(APIsConstant.getRelation);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      print("resdnsv"+response.body);
      AppConstant.sharedPreference.setString(AppConstant.relationList, json.encode(s["data"]));
    }
  }
  static void getLocation() async {
    var url = Uri.parse(APIsConstant.getLocation);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //print("resdnsv"+response.body);
      AppConstant.sharedPreference.setString(AppConstant.locationList, json.encode(s["data"]));
    }
  }
  static void getPriest() async {
    var url = Uri.parse(APIsConstant.getPriest);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      print("resdnsv"+response.body);
      AppConstant.sharedPreference.setString(AppConstant.priestList, json.encode(s["data"]));
    }
  }
  static void getCalendarStatus() async {
    var url = Uri.parse(APIsConstant.getCalendarStatus);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      print("resdnsv"+response.body);
      AppConstant.sharedPreference.setString(AppConstant.calendarStatusList, json.encode(s["data"]));
    }
  }
  static void getServiceCategory() async {
    var url = Uri.parse(APIsConstant.getServiceCategory);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.serviceCategoryList, json.encode(s["data"]));
    }
  }
  static void getServiceType() async {
    var url = Uri.parse(APIsConstant.getServiceType);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.serviceTypeList, json.encode(s["data"]));
    }
  }
  static void getEventType() async {
    var url = Uri.parse(APIsConstant.getEventType);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //print("sndvjkbasjgb"+response.body);
      AppConstant.sharedPreference.setString(AppConstant.eventList, json.encode(s["data"]));
    }
  }
  static void getLanguage() async {
    var url = Uri.parse(APIsConstant.getLanguage);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.languageList, json.encode(s["data"]));
    }
  }
  static void getAssetMemeberName() async {
    var url = Uri.parse(APIsConstant.getAssetMemberName);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.assetMemberNameList, json.encode(s["data"]));
    }
  }

  static void getStoreType() async {
    var url = Uri.parse(APIsConstant.getStroeType);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.storeTypeList, json.encode(s["data"]));
    }
  }
  static void getStoreStatusType() async {
    var url = Uri.parse(APIsConstant.getStroeStatusType);
    var response = await http.post(url, body: bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.storeStatusTypeList, json.encode(s["data"]));
    }
  }
  static void getInventoryItem() async {
    var url = Uri.parse(APIsConstant.getInventoryItem);
    var response = await http.post(url, body: bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.inventoryItemList, json.encode(s["data"]));
    }
  }
  static void getCategoryMenu(BuildContext context) async {
    var url = Uri.parse(APIsConstant.getTodaysMenuCategoryTypes);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if(response.statusCode==200)
    {
      AppConstant.sharedPreference.setString(AppConstant.categoryList, json.encode(s["data"]));
    }
  }

  static void getAssetCategory() async {
    var url = Uri.parse(APIsConstant.getAssetCategory);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.assetCategoryList, json.encode(s["data"]));
    }
  }
  static void getAssetType() async {
    var url = Uri.parse(APIsConstant.getAssetType);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.assetTypeList, json.encode(s["data"]));
    }
  }
  static void getAssetMakers() async {
    ///business/services/getAssetMakers
    var url = Uri.parse(APIsConstant.getAssetMakers);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.assetsMakersList, json.encode(s["data"]));
    }
  }
  static void getAssetBrand() async {
    // /business/services/getAssetBrand
    var url = Uri.parse(APIsConstant.getAssetBrand);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      print("jdsvbbvdbv"+response.body);
      AppConstant.sharedPreference.setString(AppConstant.assetBrandList, json.encode(s["data"]));
    }
  }
  static void getAssetColor() async {
    // /business/services/getAssetColor
    var url = Uri.parse(APIsConstant.getAssetColor);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.assetBrandList, json.encode(s["data"]));
    }
  }


  static void getTradeType() async {
    // /business/services/construction/getTradeTypes
    var url = Uri.parse(APIsConstant.getTradeType);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is tradeName
      AppConstant.sharedPreference.setString(AppConstant.tradeTypesList, json.encode(s["tradeNameData"]));
    }
  }
  static void getProjectTypeName() async {
    // /business/services/construction/getProjectTypes
    var url = Uri.parse(APIsConstant.getProjectTypes);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is projectTypeName
      AppConstant.sharedPreference.setString(AppConstant.projectTypesList, json.encode(s["projectTypeNameData"]));
    }
  }
  static void getJobCategory() async {
    // /business/services/construction/getJobOrderJobCategoryTypes
    var url = Uri.parse(APIsConstant.getJobOrderJobCategoryTypes);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is jobCategoryTypeName
      AppConstant.sharedPreference.setString(AppConstant.jobOrderJobCategoryTypesList, json.encode(s["jobCategoryTypeNameData"]));
    }
  }
  static void getJobName() async {
    ///business/services/construction/getCostPlusJobName
    var url = Uri.parse(APIsConstant.getCostPlusJobName);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is projectTypeName
      AppConstant.sharedPreference.setString(AppConstant.jobNameTypesList, json.encode(s["jobNameTypes"]));
    }
  }
  static void getReasonType() async {
    ///common/services/construction/getReasonTypes
    var url = Uri.parse(APIsConstant.getReasonTypes);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is reason
      AppConstant.sharedPreference.setString(AppConstant.reasonTypesList, json.encode(s["reasonData"]));
    }
  }
  static void getFloorType() async {
    ////business/services/getFloorTypes
    var url = Uri.parse(APIsConstant.getFloorTypes);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is floorName
      AppConstant.sharedPreference.setString(AppConstant.floorTypeList, json.encode(s["floorNameData"]));
    }
  }
  static void getRoomType() async {
    ///business/services/construction/getRoomTypes
    var url = Uri.parse(APIsConstant.getRoomTypes);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is roomName
      AppConstant.sharedPreference.setString(AppConstant.roomTypeList, json.encode(s["roomNameData"]));
    }
  }
  static void getIssueType() async {
    //common/services/construction/getPunchListIssueTypesData
    var url = Uri.parse(APIsConstant.getPunchListIssueTypesData);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is issue
      AppConstant.sharedPreference.setString(AppConstant.punchIssueTypesList, json.encode(s["punchListIssueTypesData"]));
    }
  }
  static void getPunchListItemTypesData() async {
    //common/services/construction/getPunchListItemTypesData
    var url = Uri.parse(APIsConstant.getPunchListItemTypesData);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is itemName
      AppConstant.sharedPreference.setString(AppConstant.punchItemList, json.encode(s["punchListItemData"]));
    }
  }
  static void getCommunityTypes() async {
    var url = Uri.parse(APIsConstant.getCommunityTypes);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is communityTypesName
      AppConstant.sharedPreference.setString(AppConstant.communityTypesNameList, json.encode(s["communityNameData"]));
    }
  }
  static void getProjectDivisionTypes() async {
    ///business/services/construction/getProjectDivisionTypes
    var url = Uri.parse(APIsConstant.getProjectDivisionTypes);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      //prameter is divisionTypeName
      AppConstant.sharedPreference.setString(AppConstant.projectDivisionTypesList, json.encode(s["divisionTypeNameData"]));
    }
  }
  static void getSubContractorName() async {
    var url = Uri.parse(APIsConstant.getSubContractorName);
    var response = await http.post(url, body:bodies);
    var s = json.decode(response.body);
    if (response.statusCode == 200) {
      AppConstant.sharedPreference.setString(AppConstant.subContractorNameDataList, json.encode(s["subContractorNameData"]));
    }
  }

  }
