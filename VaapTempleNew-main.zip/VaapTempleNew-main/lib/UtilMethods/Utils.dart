import 'dart:convert';

import 'package:aspgen_mobile/AppConstant/APIsConstant.dart';
import 'package:aspgen_mobile/AppConstant/AppConstant.dart';
import 'package:aspgen_mobile/Authentication/Menmberlogin.dart';
import 'package:aspgen_mobile/BottomBar/dashboard_nav.dart';
import 'package:aspgen_mobile/Dashboard/Model/setting.dart';
import 'package:aspgen_mobile/Dashboard/dashboard.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geolocator/geolocator.dart';
import 'package:http_parser/http_parser.dart';
import 'package:dart_des/dart_des.dart';
import 'package:convert/convert.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:intl/intl.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:http/http.dart' as http;
import 'package:mask_text_input_formatter/mask_text_input_formatter.dart';
import 'package:mime_type/mime_type.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:rflutter_alert/rflutter_alert.dart';
import '../AppConstant/AppColors.dart';
import '../Authentication/NewLoginPage.dart';
import '../Authentication/TwoFactorAuthentication.dart';
import '../Templates/Model/CategoryData.dart';
import 'package:http_parser/http_parser.dart';
bool isValidEmail(String email) {
  return RegExp(
      r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
      .hasMatch(email);
}

String differTime(String startTime ,String startDate,String endtime,String endDate){

  var date1=startDate;
  var date2=endDate;

  try {
    DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
    DateTime dt1 = dateFormat.parse("$date2 $endtime");
    DateTime dt2 = dateFormat.parse("$date1 $startTime");
    Duration diff = dt1.difference(dt2);

    int min =(diff.inMinutes % 60);
    String finalHour=diff.inHours>0?diff.inHours.toString():"00";
    print(finalHour);
    String finalMinute=min<10?"0"+min.toString():min.toString();
    String difftime=finalHour+" : "+finalMinute;
    return difftime;

  } on Exception catch (e) {
    // TODO
    print(e.toString());
    print("cshbkabscj");
    return "";
  }
}
String differInDayTime(String startDate,String endDate){
  var date1=startDate;
  var date2=endDate;
  try {
    DateFormat dateFormat = DateFormat("MM/dd/yyyy hh:mm a");
    DateTime dt1 = dateFormat.parse("$date2 12:00 AM");
    DateTime dt2 = dateFormat.parse("$date1 12:00 AM");
    String  diff = dt1.difference(dt2).inDays.toString();
    return diff;

  } on Exception catch (e) {
    // TODO
    print(e.toString());
    print("cshbkabscj");
    return "";
  }
}


final DateFormat formatter = DateFormat('MMM dd, yyyy');
final DateFormat formatter1 = DateFormat('MM/dd/yyyy');
String phoneFormatter(String text){
 return MaskTextInputFormatter(
      initialText:UtilMethods.decrypt(text), mask: '(###) ###-####',
      filter: {"#": RegExp(r'[0-9]')},
      type: MaskAutoCompletionType.lazy ).getMaskedText();
}
String amountParser(String text){
  try{
    return  "\$ "+double.parse(text).toStringAsFixed(2);
  }
 catch(e){
    print("amountParserException : "+e.toString() );
   return  "\$ 0.00";
 }

}
String dateParser(String date){
  try{
    return formatter.format(formatter1.parse(date));
  }
  catch(e){
    print("dateParserException : "+e.toString() );
    return "";
  }

}
int lengthParser(String txt){
  try{
    return int.parse(txt);
  }
  catch(e){
    print("dateParserException : "+e.toString() );
    return 100;
  }

}
GetStorage storage=GetStorage();

Future<bool> CheckInternetConnection() async{
  var connectivityResult = await (Connectivity().checkConnectivity());
  if(connectivityResult==ConnectivityResult.none)
  {
    Get.snackbar("No Internet Connection", "Please connect to the internet",
        backgroundGradient: LinearGradient(colors: [
      Colors.red,
      Colors.black26,
    ]),
      icon: Icon(Icons.wifi_off, color: Colors.white),
      snackPosition: SnackPosition.TOP,
      borderRadius: 5,
      duration: Duration(milliseconds:1200)
    );
    return false;
  }
  else{
    return true;
  }

}
// Future<Position> DeterminePosition() async {
//   bool serviceEnabled;
//   bool serviceRequest;
//   LocationPermission permission;
//   LocationPermission permission1;
//
//   // Test if location services are enabled.
//   serviceEnabled = await Geolocator.isLocationServiceEnabled();
//
//   if (!serviceEnabled) {
//     await Geolocator.openLocationSettings();
//     Get.snackbar("Location Permissions", "Location permissions are denied",
//         backgroundGradient: LinearGradient(colors: [Colors.red,Colors.white30],),icon: Icon(Icons.error_outline),borderRadius: 3
//     );
//     return Future.error('Location services are disabled.');
//   }
//
//   permission = await Geolocator.checkPermission();
//   if (permission == LocationPermission.denied) {
//     permission = await Geolocator.requestPermission();
//     if (permission == LocationPermission.denied) {
//       Get.snackbar("Location Permissions", "Location permissions are denied",
//           backgroundGradient: LinearGradient(colors: [Colors.red,Colors.white30],),icon: Icon(Icons.error_outline),borderRadius: 3
//       );
//       return Future.error('Location permissions are denied');
//     }
//   }
//
//   if (permission == LocationPermission.deniedForever) {
//     await Geolocator.requestPermission();
//     // Permissions are denied forever, handle appropriately.
//     Get.snackbar("Location Permissions", "Location permissions are permanently denied, we cannot request permissions.",
//      backgroundGradient: LinearGradient(colors: [Colors.red,Colors.white30],),icon: Icon(Icons.error_outline),borderRadius: 3
//     );
//     return Future.error(
//         'Location permissions are permanently denied, we cannot request permissions.');
//   }
//
//   return await Geolocator.getCurrentPosition();
// }
 logout(){
   AppConstant.sharedPreference.clear();
   GetStorage storsge=GetStorage();
   storsge.remove(AppConstant.clientId);
   storsge.remove(AppConstant.userName);
   storsge.remove(AppConstant.productId);
   storsge.remove(AppConstant.token);
   // storsge.remove("dashTitle");
   // storsge.remove("dashSubTitle");
   Get.offAll(()=>CustomerCodePage());
}

class UtilMethods{
  static urlLuncher(String url)async{
    if (await canLaunch(url)) {
    await launch(url);
    } else {
    throw 'Could not launch $url';
    }
  }

  static Future<String> getDashBoardData(BuildContext context,requestss,String token) async {

    var url = Uri.parse(APIsConstant.getAPI);
    var response = await http.post(url, headers: {
      'Content-type': 'application/json',
      'Accept': 'application/json',
      "Authorization": "Bearer ${token}"
    },body: json.encode(requestss));

    if (response.statusCode == 201) {
      if(jsonDecode(response.body)['statusCode']==-3)
      {
        Get.offAll(()=>NewLoginPage());
        Get.snackbar("Session Expired","Please Login to continue.",backgroundColor: Colors.yellow.withOpacity(0.2),
          icon: Icon(Icons.warning_amber, color: Colors.white),
          snackPosition: SnackPosition.TOP,
          borderRadius: 5,
        );
      }
      context.loaderOverlay.hide();
      return response.body;
    }else{
      context.loaderOverlay.hide();
      return response.body;
    }
  }
  static Future<String> getGenericData(BuildContext context,requestss) async {
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.getAPI);
    var response = await http.post(url, headers:
    {
      'Content-type': 'application/json',
      'Accept': 'application/json',
      "Authorization": "Bearer ${ AppConstant.sharedPreference.getString(AppConstant.token).toString().trim()}"
    }

        ,body: json.encode(requestss));

    if (response.statusCode == 201) {

      context.loaderOverlay.hide();
      return response.body;
    }else{
      context.loaderOverlay.hide();
      return response.body;
    }
  }

  static Future<String> getFilterData(BuildContext context,query) async {
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.filterAPI);
    var response = await http.post(url, headers:
    {
      'Content-type': 'application/json',
      'Accept': 'application/json',
      "Authorization": "Bearer ${ await AppConstant.sharedPreference.getString(AppConstant.token).toString().trim()}"
    }
        ,body: json.encode(
            query
    ));


    if (response.statusCode == 201) {

      context.loaderOverlay.hide();
      return response.body;
    }else{
      context.loaderOverlay.hide();
      return response.body;
    }
  }
  static Future<CategoryData> getDropDownData(BuildContext context,query) async {
    var url = Uri.parse(APIsConstant.filterAPI);
    var response = await http.post(url, headers:   {
      'Content-type': 'application/json',
      'Accept': 'application/json',
      "Authorization": "Bearer ${AppConstant.sharedPreference.getString(AppConstant.token).toString().trim()}"
    },
        body: json.encode(
        query
    ));

    if (response.statusCode == 201) {

      if(jsonDecode(response.body)["statusCode"]=="-1")
        {
         return CategoryData();
        }
      else{
        return categoryDataFromJson(response.body);
      }

    }else{
      return CategoryData();
    }
  }

  static Future<CategoryData> getDropSubDownData(BuildContext context,query) async {
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.filterAPI);
    var response = await http.post(url, headers:
    {
      'Content-type': 'application/json',
      'Accept': 'application/json',
      "Authorization": "Bearer ${ await AppConstant.sharedPreference.getString(AppConstant.token).toString().trim()}"
    }
        ,body: json.encode(
        query
    ));
    if (response.statusCode == 201) {
      print("dvsibidvs");
      print(response.body);
      context.loaderOverlay.hide();
      if(jsonDecode(response.body)["statusCode"]=="-1")
      {
        return CategoryData();
      }
      else{


        return categoryDataFromJson(response.body);
      }

    }else{
      context.loaderOverlay.hide();
      return CategoryData();
    }
  }

  static Future<String> getDynamicField(BuildContext context,String module) async {
    var url = Uri.parse(APIsConstant.getDynamicData);
    var response = await http.post(url,
        headers:  {
          'Content-type': 'application/json',
          'Accept': 'application/json',
          "Authorization": "Bearer ${ await AppConstant.sharedPreference.getString(AppConstant.token).toString().trim()}"
        }

        ,body: json.encode({
      "action":"filter",
      "productId":AppConstant.sharedPreference.getString(AppConstant.productId).toString(),
      "clientId":AppConstant.sharedPreference.getString(AppConstant.clientId).toString(),
      "moduleDescription":module
    }));
    if (response.statusCode == 201) {
       print("vhibsuidvbygs");
       print(response.body);
      return response.body;
    }else{
      return response.body;
    }
  }

  static Future<String> addAPI(BuildContext context,bodyJson) async {
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.addAPI);
    var response = await http.post(url, headers:
    {
      'Content-type': 'application/json',
      'Accept': 'application/json',
      "Authorization": "Bearer ${ await AppConstant.sharedPreference.getString(AppConstant.token).toString().trim()}"
    }, body: json.encode(bodyJson));

    if (response.statusCode == 201) {
      context.loaderOverlay.hide();
      return response.body;
    }else{
      context.loaderOverlay.hide();
      // Loader.dismiss(context);
      return response.body;
    }
  }
  static Future<String> postAPI(BuildContext context,bodyJson) async {
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.postAPI);
    var response = await http.post(url, headers:
    {
      'Content-type': 'application/json',
      'Accept': 'application/json',
      "Authorization": "Bearer ${ await AppConstant.sharedPreference.getString(AppConstant.token).toString().trim()}"
    }
        , body: json.encode(bodyJson));

    if (response.statusCode == 201) {
      context.loaderOverlay.hide();
      return response.body;
    }else{
      context.loaderOverlay.hide();
      return response.body;
    }
  }
  static Future<String> getClientInfoAPI(BuildContext context,String zip) async {
    //"226018"
    context.loaderOverlay.show();

    try {
      var url = Uri.parse(APIsConstant.getClientInfo);
      var response = await http.post(url, headers: {"Content-Type": "application/json"},
          body: json.encode({
            "zip":zip
          }));

      if (response.statusCode == 201) {

        context.loaderOverlay.hide();

       // Fluttertoast.showToast(msg:response.body);
        //print(response.body);
        return response.body;
      }else{
        context.loaderOverlay.hide();
        // Loader.dismiss(context);
        return "";
      }
    } on Exception catch (e) {
      context.loaderOverlay.hide();
      Get.snackbar("Error", e.toString());
      return "";
      // TODO
    }

  }
  static Future<String> getSignIn(BuildContext context,String zip) async {
    //"226018"
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.getClientInfo);
    var response = await http.post(url, headers: {"Content-Type": "application/json"},
        body: json.encode({
          "zip":zip
        }));

    if (response.statusCode == 201) {

      context.loaderOverlay.hide();
      // Fluttertoast.showToast(msg:response.body);


      return response.body;
    }else{
      context.loaderOverlay.hide();
      // Loader.dismiss(context);
      return "";
    }
  }
  static Future<String>  forgotPass(BuildContext context,String UserName) async {
    //"226018"
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.forgotPassAPI);
    var response = await http.post(url, headers: {"Content-Type": "application/json"},
        body: json.encode({
          "userName":UserName.trim()
        }));

    if (response.statusCode == 200) {

      context.loaderOverlay.hide();
      // Fluttertoast.showToast(msg:response.body);


      return response.body;
    }else{
      context.loaderOverlay.hide();
      // Loader.dismiss(context);
      return "";
    }
  }
  static Future<String>  forgotUsername(BuildContext context,String email) async {
    //"226018"
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.forgotUserNameAPI);
    var response = await http.post(url, headers: {"Content-Type": "application/json"},
        body: json.encode({
          "emailID":email
        }));

    if (response.statusCode == 200) {

      context.loaderOverlay.hide();
      // Fluttertoast.showToast(msg:response.body);


      return response.body;
    }else{
      context.loaderOverlay.hide();
      // Loader.dismiss(context);
      return "";
    }
  }



  static Future<String> signUp(BuildContext context,String username,String password ,String firstName,String lastName,
      String email,String phone,String address,String city,String state ,String organization,String zip,String role,
      String organizationId,String roleId,String productName,String productId,String fToken,String latLong,
      bool twoFactAuth,bool notification,bool newsletters,bool pinPassword,String pinPasswordText
      ) async {
    //"226018"

    context.loaderOverlay.show();

    var url = Uri.parse(APIsConstant.signup);
    var response = await http.post(url, headers: {"Content-Type": "application/json"},
        body: json.encode(
          {
            "firstName": firstName,
            "lastName": lastName,
            "userName": username,
            "email": email,
            "phone": phone,
            "address": address,
            "city": city,
            "state":state,
            "zip": zip,
            "organization": organization,
            "clientId": organizationId,
            "role": role,
            "roleId": roleId,
            "productName": productName,
            "productId": productId,
            "password":password,
            "firebaseToken": fToken,
            "latLong": latLong,
            "userPrefrences": {
              "twoFactorAuthentication":twoFactAuth,
              "notification": notification,
              "newsletter": newsletters,
              "pinPassword": pinPassword,
              "pinPasswordCode": pinPasswordText,
            }
          }
        ));

    if (response.statusCode == 201) {
      context.loaderOverlay.hide();

      Get.snackbar("Success", jsonDecode(response.body)["message"],backgroundColor: Colors.green,
        icon: Icon(Icons.wifi, color: Colors.white),
        snackPosition: SnackPosition.TOP,
        borderRadius: 5,
      );


      return response.body;
    }else{
      Fluttertoast.showToast(msg:response.body);
      context.loaderOverlay.hide();
      // Loader.dismiss(context);
      return "";
    }
  }
  static Future<void> SignIn(BuildContext context, String email, String password,String phone,bool isMobile,String fbToken,String latlong) async {
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.signInAPI);
    var response = await http.post(url,
        headers: {"Content-Type": "application/json"},
        body: json.encode(
            {
              "userName": email,
              "password": password,
              "phone": phone,
              "isMobile": isMobile,
              "firebaseToken":fbToken,
              "latLong": latlong
            }
        ));
    print(response.body);
    if (response.statusCode == 200) {

      context.loaderOverlay.hide();
     print("hbvkhdsvbkdsbvks");
      print(response.body);
      GetStorage storage=GetStorage();
      storage.write(AppConstant.productId, json.decode(response.body)["user"]["productId"]);
      storage.write(AppConstant.clientId, json.decode(response.body)["user"]["clientId"]);
      storage.write(AppConstant.token, json.decode(response.body)["token"]);
      storage.write( AppConstant.userName, json.decode(response.body)["user"]["userName"]);
      await AppConstant.sharedPreference
          .setString(
          AppConstant.token, json.decode(response.body)["token"]);
     await AppConstant.sharedPreference
          .setString(AppConstant.productId, json.decode(response.body)["user"]["productId"])
          .toString();
     await AppConstant.sharedPreference
          .setString(AppConstant.memberId, json.decode(response.body)["user"]["_id"])
          .toString();
  await AppConstant.sharedPreference
          .setString(AppConstant.firstName, json.decode(response.body)["user"]["firstName"])
          .toString();
  await AppConstant.sharedPreference
          .setString(AppConstant.lastName, json.decode(response.body)["user"]["lastName"])
          .toString();

     await AppConstant.sharedPreference
          .setString(AppConstant.userEmail, json.decode(response.body)["user"]["email"])
          .toString();
     await AppConstant.sharedPreference
          .setString(AppConstant.clientId, json.decode(response.body)["user"]["clientId"])
          .toString();
      AppConstant.sharedPreference
          .setString(
         AppConstant.userName, json.decode(response.body)["user"]["userName"])
          .toString();
      AppConstant.sharedPreference
          .setString(
         AppConstant.role, json.decode(response.body)["user"]["role"])
          .toString();
       AppConstant.sharedPreference
          .setString(
          AppConstant.token, json.decode(response.body)["token"])
          .toString();
     await AppConstant.sharedPreference
          .setString(
         AppConstant.userAlldetails, json.encode(response.body))
          .toString();
    //  print("bhbscbbas"+response.body);
     if(jsonDecode(response.body)["user"]["userPrefrences"]["twoFactorAuthentication"])
       {
         sendCodeAuth(context,jsonDecode(response.body)["user"]["email"] ).then((value) {
            if(jsonDecode(value)["user"]["statusCode"]==1)
              {
                Get.snackbar("Authentication",jsonDecode(value)["user"]["message"]);
                Get.to(()=>TwoFactorAuthentication(email: jsonDecode(response.body)["user"]["email"],));
              }
            else{
              Get.snackbar( "Faild Authentication",jsonDecode(value)["user"]["message"],backgroundColor: Colors.red);
            }
           });
       }
     else{
       await AppConstant.sharedPreference.setBool(AppConstant.isVerify, true);
       await AppConstant.sharedPreference.setBool(AppConstant.isMember, false);
       await Future.delayed(Duration(seconds: 1));
       Get.offAll(()=>DashboardNavBar());
     }



    } else {
      context.loaderOverlay.hide();
      Fluttertoast.showToast(
          msg: json.decode(response.body)['errors']['message']);
    }
  }
  static Future<String> sendCodeAuth(BuildContext context,String email) async {
    //"226018"
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.sendAuthCodeAPI);
    var response = await http.post(url, headers: {"Content-Type": "application/json"},
        body: json.encode({
          "emailID":email
        }));
print("vsadbvjkbsdjk.");
    print(response.body);
    if (response.statusCode == 200) {

      context.loaderOverlay.hide();
      print(response.body);
      return response.body;
    }else{
      context.loaderOverlay.hide();
      // Loader.dismiss(context);
      return "";
    }
  }
  static Future<String>  verifyAuth(BuildContext context,String email,int code) async {
    //"226018"
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.verifyAuthCodeAPI);
    var response = await http.post(url, headers: {"Content-Type": "application/json"},
        body: json.encode({
          "emailID":email,
          "code":code
        }));
    print(response.body);
    if (response.statusCode == 200) {
      print("fjkdbsbv"+response.body);
      context.loaderOverlay.hide();
      // Fluttertoast.showToast(msg:response.body);

      print(response.body);
      return response.body;
    }else{
      context.loaderOverlay.hide();
      return "";
    }
  }
  static Future<String> getSetting() async {
    var url = Uri.parse(APIsConstant.settingAPI);
    var response = await http.post(url,headers:
    {
      'Content-type': 'application/json',
      'Accept': 'application/json',
      "Authorization": "Bearer ${ await AppConstant.sharedPreference.getString(AppConstant.token).toString().trim()}"
    }
        ,
        body: json.encode(
          {
            "action": "getClientSetting",
            "productId": "62c807133d9ee4045ab78d4d",
            "clientId": "636109798c12b64690508d12"
          }
        ));
    print("vshvkddvs");
    print(   {
      "action": "getClientSetting",
      "productId": AppConstant.sharedPreference.getString(AppConstant.productId),
      "clientId": AppConstant.sharedPreference.getString(AppConstant.clientId)
    });
    if(jsonDecode(response.body)['statusCode']==-3)
    {
      Get.offAll(()=>NewLoginPage());
      Get.snackbar("Session Expired","Please Login to continue.",backgroundColor: Colors.yellow.withOpacity(0.2),
        icon: Icon(Icons.warning_amber, color: Colors.white),
        snackPosition: SnackPosition.TOP,
        borderRadius: 5,
      );
    }
    if (response.statusCode == 201) {

      GetStorage storage= GetStorage();
      print("gnbfgnfnfg");
      print(response.body);
      SettingModel.fromJson(json.decode(response.body)).result!.data![0].themeSettings!.forEach((element) async{

        if(element.platform=="Mobile" && element.theme=="dark")
        {
          storage.write(AppConstant.backgroundColorDark,  element.desc!.backgroundColor!);
          storage.write(AppConstant.backgroundColorDark, element.desc!.backgroundColor!);
          storage.write(AppConstant.appBarDark, element.desc!.appbar!);
          storage.write(AppConstant.dailogColorDark, element.desc!.dailogColor!);
          storage.write(AppConstant.fontColorTitleDark, element.desc!.fontColorTitle!);
          storage.write(AppConstant.fontColorTitleSubtitleDark, element.desc!.fontColorSubtitle!);
          storage.write(AppConstant.fontsizeTitleDark, element.desc!.fontsizeTitle!);
          storage.write(AppConstant.fontsizeSubTitleDark, element.desc!.fontsizeSubTitle!);
          storage.write(AppConstant.fontsizeHeadingDark, element.desc!.fontsizeHeading!);
          storage.write(AppConstant.primaryDark, element.desc!.primaryColor!);
          storage.write(AppConstant.secondaryDark, element.desc!.secondryColor!);
          storage.write(AppConstant.iconColorDark, element.desc!.iconColor!);
        }
        if(element.platform=="Mobile" && element.theme=="light")
        {
          storage.write(AppConstant.backgroundColorLight, element.desc!.backgroundColor!);
          storage.write(AppConstant.appBarLight, element.desc!.appbar!);
          storage.write(AppConstant.dailogColorLight, element.desc!.dailogColor!);
          storage.write(AppConstant.fontColorTitleLight, element.desc!.fontColorTitle!);
          storage.write(AppConstant.fontColorTitleSubtitleLight, element.desc!.fontColorSubtitle!);
          storage.write(AppConstant.fontsizeTitleLight, element.desc!.fontsizeTitle!);
          storage.write(AppConstant.fontsizeSubTitleLight, element.desc!.fontsizeSubTitle!);
          storage.write(AppConstant.fontsizeHeadingLight, element.desc!.fontsizeHeading!);
          storage.write(AppConstant.primaryLight, element.desc!.primaryColor!);
          storage.write(AppConstant.secondaryLight, element.desc!.secondryColor!);
          storage.write(AppConstant.iconColorLight, element.desc!.iconColor!);
        }
      });
      SettingModel.fromJson(json.decode(response.body)).result!.data![0].languagesSettings!.forEach((element) async{
        if(element.platform=="Mobile")
        {
           storage.write(AppConstant.language, element.language??[]);
        }
      });

      return response.body;

     // await storage.write(AppConstant.setting, response.body);


    }else{
      // Loader.dismiss(context);
      return response.body;
    }
  }
  static Future<String>  uploadSingleImage(BuildContext context,String image,String type,String name) async {
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.imageUploadAPI);
    var request = await http.MultipartRequest('POST', url);
    String? mimeType = mime(name);
    image!=""?request.files.add(
        await http.MultipartFile.fromPath(
          "image", image,
            contentType:  MediaType.parse(mimeType!)
        )
    ):"";
    request.fields.addAll({
      "type":type,
    });
    var res = await request.send();
    var response = await http.Response.fromStream(res);
    print("objectvjhcs"+response.body);
    if(response.statusCode==200)
    {
      print("objectvjhcs"+response.body);
      if (json.decode(response.body)['success'] == false) {
        Fluttertoast.showToast(
            msg: json.decode(response.body)['message'].toString(),
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0
        );
        return "";
      }
      else
      {
        context.loaderOverlay.hide();
        return "uploads/${type}/"+json.decode(response.body)['result']["message"]['path'].toString();
      }}
    else{

      context.loaderOverlay.hide();
      return "";
    }
  }

 static Future<String> getGenericFilterData(BuildContext context,requestss) async {
   context.loaderOverlay.show();
   var url = Uri.parse(APIsConstant.getFilterAPI);
   var response = await http.post(url, headers:   {
     'Content-type': 'application/json',
     'Accept': 'application/json',
     "Authorization": "Bearer ${ await AppConstant.sharedPreference.getString(AppConstant.token).toString().trim()}"
   },body: json.encode(requestss));
   if (response.statusCode == 201) {
     context.loaderOverlay.hide();
     return response.body;
   }else{
     context.loaderOverlay.hide();
     return response.body;
   }
 }
  // static String encrypt(text) {
  //   String key = 'abcdefghijklmnopqrstuvwx'; // 8-byte
  //   String message = text;
  //   List<int> encrypted;
  //   DES3 des3ECB = DES3(key: key.codeUnits, mode: DESMode.ECB);
  //   encrypted = des3ECB.encrypt(message.codeUnits);
  //   return base64.encode(encrypted);
  // }

  // static String decrypt(text)  {
  //   String key = 'abcdefghijklmnopqrstuvwx'; // 8-byte
  //   Uint8List a=base64.decode(text);
  //   try {
  //     DES3 des3ECB = DES3(key: key.codeUnits, mode: DESMode.ECB);
  //     List<int> encrypted;
  //     encrypted = des3ECB.decrypt(a);
  //     print("object"+utf8.decode(encrypted));
  //     return  utf8.decode(encrypted);
  //   } on Exception catch (e) {
  //     // TODO
  //       return "";
  //   }
  // }
  static String decrypt(text)  {
    String key = 'abcdefghijklmnopqrstuvwx'; // 8-byte
    try {
      var str2 = utf8.decode(base64.decode(text));
      print("str2");
      return str2;
    } on Exception catch (e) {
      // TODO
      return "";
    }
  }
  static String encrypt(text)  {
    String key = 'abcdefghijklmnopqrstuvwx'; // 8-byte
    try {
 var str2 = utf8.encode(text);
      var str3 = base64.encode(str2);
      print("str2");
      return str3;
    } on Exception catch (e) {
      // TODO
      return "";
    }
  }



  static Future<void> addRentalServiceCart(
      List<Map> Data,
      String Paymenttype,
      String bankName,
      String chequeNo,
      String chequeAmount,
      String chequeDate,
      String totalAmount,
      String transactionId,
      String memberId,
      String memberName,
      String memberEmail,
      String memberPhone,var eventDetail,var deliveryDetails,
      BuildContext context) async {
    context.loaderOverlay.show();
    var bodyJson = {
      "productId":AppConstant.sharedPreference.get(AppConstant.productId).toString(),
      "clientId": AppConstant.sharedPreference.get(AppConstant.clientId).toString(),
      "memberId": memberId,
      "memberName":memberName,
      "prsnEmail": memberEmail,
      "prsnPhone": memberPhone,
      "data": Data,
      "paymentType": Paymenttype,
      "bankName": bankName,
      "chequeNo": chequeNo,
      "chequeAmount": chequeAmount,
      "chequeDate": chequeDate,
      "eventDetail": eventDetail,
      "deliveryDetails": deliveryDetails,
      "totalAmount": totalAmount.replaceAll("\$", "").replaceAll(",", ""),
      "transactionId": transactionId,
    };


    var response = await UtilMethods.globalApiHit(
        context, "api/bookingService/addServiceCart", json.encode(bodyJson));
    context.loaderOverlay.hide();

    if (json.decode(response)['statusCode'] == "-1") {
      Fluttertoast.showToast(
          msg: json.decode(response)['message'],
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    } else {
      if (Paymenttype == "CREDIT CARD") {
        UtilMethods.updateCardStatus(
            json.decode(response)['data'][0]['_id'].toString(),
            json.decode(response)['data'][0]['invoiceNo'].toString(),
            "SCHEDULED",
            transactionId,
            context);
      }
      Alert(
        context: context,
        type: AlertType.success,
        style: AlertStyle(
          backgroundColor: AppColor.backgroundColor,
          titleStyle: TextStyle(color: Colors.white, fontSize: 24),
          descStyle: TextStyle(color: Colors.white, fontSize: 15),
        ),
        title: "Token No: " +
            json.decode(response)['data'][0]['invoiceNo'].toString(),
        desc:
        "Payment Processed Successfully. Payment Reciept sent to registered account holder.",
        buttons: [
          DialogButton(
            color: Color(0xFF005d4b),
            child: Text(
              "OK",
              style: TextStyle(color: Colors.white, fontSize: 15),
            ),
            onPressed: () => {
              Get.offAll(()=>DashboardNavBar())
              //  Get.to(() => DevoteeDash()),
            },
          )
        ],
      ).show();

      // AppConstant.alldata = [];
      // AppConstant.totalAmount = 0.00;
    }
  }



  static Future<void> addServiceCart(
      List<Map> Data,
      String Paymenttype,
      String bankName,
      String chequeNo,
      String chequeAmount,
      String chequeDate,
      String totalAmount,
      String transactionId,
      String memberId,
      String memberName,
      String memberEmail,
      String memberPhone,
      BuildContext context) async {
    print("vdsvbsjvbsdk");
    context.loaderOverlay.show();
    var bodyJson = {
      "productId":AppConstant.sharedPreference.get(AppConstant.productId).toString(),
      "clientId": AppConstant.sharedPreference.get(AppConstant.clientId).toString(),
      "memberId": memberId,
      "memberName":memberName,
      "prsnEmail": memberEmail,
      "prsnPhone": memberPhone,
      "data": Data,
      "paymentType": Paymenttype,
      "bankName": bankName,
      "chequeNo": chequeNo,
      "chequeAmount": chequeAmount,
      "chequeDate": chequeDate,

      "totalAmount": totalAmount.replaceAll("\$", "").replaceAll(",", ""),
      "transactionId": transactionId,
    };


    var response = await UtilMethods.globalApiHit(
        context, "api/bookingService/addServiceCart", json.encode(bodyJson));
    context.loaderOverlay.hide();

    if (json.decode(response)['statusCode'] == "-1") {
      Fluttertoast.showToast(
          msg: json.decode(response)['message'],
          toastLength: Toast.LENGTH_SHORT,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
    } else {
      if (Paymenttype == "CREDIT CARD") {
        UtilMethods.updateCardStatus(
            json.decode(response)['data'][0]['_id'].toString(),
            json.decode(response)['data'][0]['invoiceNo'].toString(),
            "SCHEDULED",
            transactionId,
            context);
      }
      Alert(
        context: context,
        type: AlertType.success,
        style: AlertStyle(
          backgroundColor: AppColor.backgroundColor,
          titleStyle: TextStyle(color: Colors.white, fontSize: 24),
          descStyle: TextStyle(color: Colors.white, fontSize: 15),
        ),
        title: "Token No: " +
            json.decode(response)['data'][0]['invoiceNo'].toString(),
        desc:
        "Payment Processed Successfully. Payment Reciept sent to registered account holder.",
        buttons: [
          DialogButton(
            color: Color(0xFF005d4b),
            child: Text(
              "OK",
              style: TextStyle(color: Colors.white, fontSize: 15),
            ),
            onPressed: () => {
            Get.offAll(()=>DashboardNavBar())
              //  Get.to(() => DevoteeDash()),
            },
          )
        ],
      ).show();

      // AppConstant.alldata = [];
      // AppConstant.totalAmount = 0.00;
    }
  }
  static Future<String> globalApiHit(
      BuildContext context, endPint, bodyJson) async {
    context.loaderOverlay.show();
    var url = Uri.parse(APIsConstant.IP_Base_Url + endPint);
    print(url);
    print(bodyJson);
    var response = await http.post(url,
        headers: {
          "Content-Type": "application/json",
          "Authorization": "bearer " +
              AppConstant.sharedPreference.getString(AppConstant.token).toString()
        },
        body: bodyJson);
    context.loaderOverlay.hide();
    if (response.statusCode == 201) {
      print("hbhbvhb,${response.body}");
      if (json.decode(response.body)['data'] == []) {
        Fluttertoast.showToast(
            msg: json.decode(response.body)['No Guest User Found'],
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
        return utf8.decode(response.bodyBytes);
      } else {
        return utf8.decode(response.bodyBytes);
      }
    } else if (response.statusCode == 200) {
      print("hbhbvhb,${response.body}");
      if (json.decode(response.body)['statusCode'] == -3) {
        context.loaderOverlay.hide();
        logout();
        return utf8.decode(response.bodyBytes);
      } else {
        return utf8.decode(response.bodyBytes);
      }
    } else {
      return utf8.decode(response.bodyBytes);
    }
  }

  static Future<void> updateCardStatus(String _id, String invoiceNo,
      String paymentStatus, String transactionId, BuildContext context) async {
    var url =
    Uri.parse(APIsConstant.IP_Base_Url + "/common/services/nonprofit/updatePaymentStatus");

    var response = await http.post(url, body: {
      'productId':
      AppConstant.sharedPreference.get('productId').toString(),
      'token': AppConstant.sharedPreference.get('token').toString(),
      '_id': _id,
      'invoiceNo': invoiceNo,
      'paymentStatus': paymentStatus,
      'transactionId': transactionId,
    });
    print("addServiceCart@@" + transactionId);
    print("addServiceCart,${response.body}");
    if (response.statusCode == 200) {
      print("addServiceCartstatus,${response.body}");
      if (json.decode(response.body)['success'] == false) {
        Fluttertoast.showToast(
            msg: json.decode(response.body)['message'],
            toastLength: Toast.LENGTH_SHORT,
            gravity: ToastGravity.CENTER,
            timeInSecForIosWeb: 1,
            backgroundColor: Colors.red,
            textColor: Colors.white,
            fontSize: 16.0);
      } else {
        // Alert(
        //   context: context,
        //   type: AlertType.success,
        //   style: AlertStyle(
        //     backgroundColor: backgroundColor,
        //     titleStyle: TextStyle(color: Colors.white, fontSize: 24),
        //     descStyle: TextStyle(color: Colors.white, fontSize: 15),
        //   ),
        //   title: "Token No: "+json.decode(response.body)['invoiceNo'].toString(),
        //   desc: "Payment Processed Successfully. Payment Reciept sent to registered account holder.",
        //   buttons: [
        //     DialogButton(
        //       color:  Color(0xFF005d4b),
        //       child: Text(
        //         "OK",
        //         style: TextStyle(color: Colors.white, fontSize: 15),
        //       ),
        //       onPressed: () => {
        //         Navigator.pop(context),
        //         Navigator.pop(context),
        //         Get.to(()=>DevoteeDash()),
        //       },
        //     )
        //   ],
        // ).show();

      }
    } else {
      return null;
    }
  }
  static Future<String> getrole(ProductId) async {
    var urlLogin = Uri.parse(APIsConstant.IP_Base_Url + 'api/users/RoleMaster');
    var response = await http.post(urlLogin,
        headers: {
          "Content-Type": "application/json",
        },
        body: json.encode({
          "action": "get",
          "ProductId": ProductId,
        }));
    var res = jsonDecode(response.body);
    print("@@@@@@@@@errevdfbvfdb");
    print(response.body);
    if (res['statusCode'] != "-1") {
      return response.body;
      // Get.to(() => LoginPage());
    } else {
      Fluttertoast.showToast(
          msg: "Roles not found",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.BOTTOM,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.red,
          textColor: Colors.white,
          fontSize: 16.0);
      return response.body;
    }
  }
 static int getDayInt(id){
    int a;
    switch (id)
    {
      case 'MONDAY':
        a=1;
        break;
      case 'TUESDAY':
        a=2;
        break;
      case 'WEDNESDAY':
        a=3;
        break;
      case 'THRUSDAY':
        a=4;
        break;
      case 'FRIDAY':
        a=5;
        break;
      case 'SATURDAY':
        a=6;
        break;
      case 'SUNDAY':
        a=7;
        break;
      default:
        a=9;
        break;
    }
    return a;
  }
  // static setMasterData(aspectType) async {
  //   var bodyJson={"componentConfig":
  //   {
  //     "moduleName": "Master Data Management",
  //     "productID": AppConstant.sharedPreference.getString(AppConstant.productId),
  //     "clientID": AppConstant.sharedPreference.getString(AppConstant.clientId),
  //     "aspectType":aspectType,
  //     "query": {
  //       "aspectType": aspectType
  //     },
  //     "userName": "Pankaj002",
  //     "skip": 0,
  //     "next": 700
  //   }
  //   };
  //   // Map list=await UtilMethods.getFilterData(bodyJson);
  //   print("setMasterData");
  //   print(aspectType);
  //   print(list);
  //   var newList=[];
  //   for(var data in list['data']){
  //     newList.add({"name":data['refDataName'],"refDataCode":data['refDataCode']??""});
  //   }
  //   AppConstant.sharedPreference.setString(aspectType, json.encode(newList));
  // }
}
