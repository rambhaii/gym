
// ignore_for_file: constant_identifier_names

class Images {
  static const String login = 'assets/images/splash.png';
  static const String splash = 'assets/images/splash_img.png';
  static const String camera = 'assets/images/camera.png';
  static const String default_user = 'assets/images/default_user.png';
  static const String gallery = 'assets/images/gallery.png';
  static const String defaultProfile = 'assets/images/default.png';
  static const String bikeService = 'assets/images/bike_service.jpg';
  static const String engineService = 'assets/images/engine_service.jpg';
  static const String checked = 'assets/images/checked.png';
  static const String id_image = 'https://paytmblogcdn.paytm.com/wp-content/uploads/2023/06/Blog-Voter-ID-Documents_Cover-banner_Final-800x500.webp?webp';
  static const String vin_number = 'https://sp-ao.shortpixel.ai/client/to_webp,q_glossy,ret_img,w_609,h_270/https://vinspy.eu/wp-content/uploads/2021/10/vehicle-vin-code-location.png';
  static const String random_profile = "https://s3.narvii.com/image/jf7xg7mwqyj7faxcu52wuifevriitjou_hq.jpg";
  static const String user = "https://cdn.vectorstock.com/i/preview-1x/70/84/default-avatar-profile-icon-symbol-for-website-vector-46547084.jpg";
}