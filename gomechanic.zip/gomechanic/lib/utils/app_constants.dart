
// ignore_for_file: constant_identifier_names

class AppConstants {
  static const String APP_NAME = 'GoMechanic';
  static const String FCM_TOKEN = "cqnGDTO2QkWbpzVANbh-gS:APA91bGZ6huS3cHFhjwq5oNSNSVJ1-y3Xz2VKgXuseDjTlL9iAC80yrnqNmbftSuXCT9qCVwAKYtxRHdNqDDCFFs-Vx4GC3hAbtW_vHQRVIkhjfzCLss33a97spkruyAueT0LIPibXGg";

  static const String BASE_URL = "https://www.animationmedia.org/carMechanic/";
  static const String LANGUAGE = "eng";
  static const String LOGIN_URL = "${BASE_URL}api/VendorMaster/vendorSignIn";
  static const String VERIFY_URL = "${BASE_URL}api/VendorMaster/vendorVerifyOTP";
  static const String PROFILE_UPDATE = "${BASE_URL}api/VendorMaster/vendorUpdateProfile";
  static const String SHOP_PROFILE_UPDATE = "${BASE_URL}api/VendorMaster/vendorUpdateShopDetails";
  static const String DETAILS_URL = "${BASE_URL}api/Dashboard/getBookingList";
  static const String UPDATE_CURRENT_ADDRESS = "$BASE_URL/api/UserMaster/updateCurrentAddress";


}
