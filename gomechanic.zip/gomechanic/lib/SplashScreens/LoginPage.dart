// ignore_for_file: unnecessary_null_comparison, file_names

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gomechanic/Widget/CircularButton.dart';
import 'package:gomechanic/controller/login_controller.dart';
import 'package:gomechanic/controller/notification_service.dart';
import 'package:gomechanic/utils/all_image.dart';
import 'package:gomechanic/utils/style.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  State<LoginPage> createState() => _LoginPageState();
}

NotificationServices notificationServices = NotificationServices();

class _LoginPageState extends State<LoginPage> {
  final _formKey = GlobalKey<FormState>();

  final LoginController _controller = Get.put(LoginController());
  late String deviceId;

  @override
  void initState() {
    super.initState();
    notificationServices.isTokenRefresh(); // token refresh a new token
    notificationServices.getDeviceToken().then((value) {
      if (kDebugMode) {
        _controller.FCM_TOKEN.value = value;
        // print('device token key');
        // print(value.toString());
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    double height, width;
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Builder(
      builder: (BuildContext context) {
        return Scaffold(
            backgroundColor: const Color(0xffffffff),
            body: Container(
              margin: EdgeInsets.only(left: 15.0.w, right: 15.0.w, top: 25.0.h),
              height: height,
              width: width,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text.rich(
                          TextSpan(
                            style: TextStyle(
                              fontFamily: 'Josefin Sans',
                              fontSize: 28,
                              color: const Color(0xff051ba6),
                              letterSpacing: 1.5,
                              height: 0.04.h,
                            ),
                            children: const [
                              TextSpan(
                                text: 'Go',
                                style: TextStyle(
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                              TextSpan(
                                  text: ' Mechanic',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                  )),
                            ],
                          ),
                          textHeightBehavior: const TextHeightBehavior(
                              applyHeightToFirstAscent: false),
                          softWrap: false,
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Container(
                          height: 240.0.h,
                          width: 320.0.w,
                          alignment: Alignment.center,
                          child: Image.asset(
                            Images.login.toString(),
                            height: 240.0.h,
                            width: 250.0.w,
                            fit: BoxFit.contain,
                          ),
                        ),
                      ],
                    ),
                    Text(
                      'Create an Account',
                      style: smallTextStyle.copyWith(
                        fontSize: 20.0.sp,
                        color: Colors.blue,
                      ),
                    ),
                    SizedBox(
                      height: 10.h,
                    ),
                    SizedBox(
                        width: Get.width,
                        child: Text(
                          "Enter your mobile number\n       with country code",
                          style: smallTextStyle.copyWith(fontSize: 23),
                        )),
                    const SizedBox(
                      height: 50,
                    ),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        const Spacer(
                          flex: 1,
                        ),
                        Expanded(
                            flex: 1,
                            child: TextFormField(
                              readOnly: true,
                              initialValue: "+91",
                              style: titleStyle,
                              decoration: const InputDecoration(
                                enabledBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black),
                                ),
                                focusedBorder: UnderlineInputBorder(
                                  borderSide: BorderSide(color: Colors.black),
                                ),
                                isDense: true,
                              ),
                            )),
                        const SizedBox(
                          width: 8,
                        ),
                        Expanded(
                            flex: 5,
                            child: Form(
                              key: _formKey,
                              child: TextFormField(
                                controller: _controller.etMobile,
                                keyboardType: TextInputType.number,
                                decoration: const InputDecoration(
                                  enabledBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(color: Colors.black),
                                  ),
                                  focusedBorder: UnderlineInputBorder(
                                    borderSide: BorderSide(color: Colors.black),
                                  ),
                                  counter: Offstage(),
                                  hintText: "0000000000",
                                  isDense: true,
                                  contentPadding: EdgeInsets.symmetric(
                                      horizontal: 4, vertical: 8),
                                ),
                                inputFormatters: [
                                  FilteringTextInputFormatter
                                      .digitsOnly, // Allow only digits
                                ],
                                validator: (value) {
                                  if (value.toString().isEmpty) {
                                    return "Please enter mobile No.";
                                  }
                                  if (value!.length < 10) {
                                    return 'Please enter 10 digit number';
                                  }
                                  return null;
                                },
                                maxLength: 10,
                                style: titleStyle,
                              ),
                            )),
                        SizedBox(width: 20.w),
                        Expanded(
                          flex: 2,
                          child: CircularButton(
                            onPress: () {
                              if (_formKey.currentState!.validate()) {
                                _controller.loginNetworkApi();
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ));
      },
    );
  }
}
