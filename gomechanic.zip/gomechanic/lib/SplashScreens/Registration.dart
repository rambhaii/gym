// ignore_for_file: file_names, avoid_print

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gomechanic/Widget/Color.dart';
import 'package:gomechanic/Widget/EditTextWedget.dart';
import 'package:gomechanic/controller/login_controller.dart';
import 'package:gomechanic/utils/style.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({Key? key}) : super(key: key);
  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}
class _RegistrationScreenState extends State<RegistrationScreen> {
    final formKey = GlobalKey<FormState>();
    final LoginController controller = Get.put(LoginController());

    @override
  void initState() {
     controller.GetAddressFromLatLong();
     controller.currentAddressNetworkApi();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    // controller.etAddress.text = controller.current_address.value.toString();
    double  width;
    width = MediaQuery.of(context).size.width;

    return WillPopScope(
      onWillPop: controller.onWillPop,
      child:  Scaffold(
        backgroundColor: const Color(0xffffffff),
        body: SingleChildScrollView(
          child: Container(
            width: width,
            margin: EdgeInsets.only(left: 20.0.w, right: 20.0.w, top: 20.0.w,bottom: 20.0.w),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        margin: const EdgeInsets.only(top: 20, bottom: 20),
                        height: 70.0.h,
                        width: 70.0.w,
                      ),
                      Text.rich(
                        TextSpan(
                          style: TextStyle(
                            fontFamily: 'Josefin Sans',
                            fontSize: 28.sp,
                            color: const Color(0xff051ba6),
                            letterSpacing: 1.25,
                            height: 0.04,
                          ),
                          children: const [
                            TextSpan(
                              text: 'Go ',
                              style: TextStyle(
                                fontWeight: FontWeight.w700,
                              ),
                            ),
                            TextSpan(
                              text: 'Mechanic',
                            ),
                          ],
                        ),
                        textHeightBehavior:
                            const TextHeightBehavior(applyHeightToFirstAscent: false),
                        softWrap: false,
                      ),
                    ],
                  ),
                  Text(
                    'Create an Account',
                    style: titleStyle,
                  ),
                  Padding(
                    padding: EdgeInsets.only(left: 10.0.w),
                    child: Row(
                      children: [
                        Expanded(
                            child: Form(
                          key: formKey,
                          child: Column(
                            children: [
                              SizedBox(height: 15.0.h),
                              EditTextWidget(
                                hint: 'Name',
                                label: const Text('Name'),
                                controller: controller.etName,
                                validator: (value) {
                                  if (value.toString().isEmpty) {
                                    return "Please Enter Name";
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(height: 10.0.h),
                              EditTextWidget(
                                hint: 'Mobile',
                                label: const Text('Mobile'),
                                type: TextInputType.phone,
                                controller: controller.number,
                                isRead: true,
                                inputFormatters: [
                                  FilteringTextInputFormatter
                                      .digitsOnly, // Allow only digits
                                ],
                                validator: (value) {
                                  if (value.toString().isEmpty) {
                                    return "Please enter mobile";
                                  }
                                  if (value.toString().length != 10) {
                                    return "Please enter 10 digit Number";
                                  }
                                  return null;
                                },
                                length: 10,
                              ),
                              Obx(() => DropdownButtonFormField(
                                    isExpanded: true,
                                    alignment: Alignment.center,
                                    value: controller.idProveType.value,
                                    decoration: InputDecoration(
                                      hintText: 'Select an option',
                                      label: const Text('Select an option'),
                                      hintStyle: subtitleStyle.copyWith(
                                          color: TColor.black.withAlpha(150)),
                                      labelStyle: subtitleStyle.copyWith(
                                          color: TColor.black.withAlpha(150)),
                                      enabledBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(color: TColor.black),
                                      ),
                                      focusedBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(color: TColor.black),
                                      ),
                                    ),
                                    items: [
                                      DropdownMenuItem(
                                        value: 0,
                                        child: Text(
                                          'Select Card Type',
                                          style: subtitleStyle.copyWith(
                                              color: TColor.black.withAlpha(150)),
                                        ),
                                      ),
                                      DropdownMenuItem(
                                        value: 1,
                                        child: Text(
                                          'Aadhar Card',
                                          style: subtitleStyle.copyWith(
                                              color: TColor.black.withAlpha(150)),
                                        ),
                                      ),
                                      DropdownMenuItem(
                                        value: 2,
                                        child: Text(
                                          'Voter ID',
                                          style: subtitleStyle.copyWith(
                                              color: TColor.black.withAlpha(150)),
                                        ),
                                      ),
                                      DropdownMenuItem(
                                        value: 3,
                                        child: Text(
                                          'Driving Licence',
                                          style: subtitleStyle.copyWith(
                                              color: TColor.black.withAlpha(150)),
                                        ),
                                      ),
                                      DropdownMenuItem(
                                        value: 4,
                                        child: Text(
                                          'Passport',
                                          style: subtitleStyle.copyWith(
                                              color: TColor.black.withAlpha(150)),
                                        ),
                                      ),
                                    ],
                                    onChanged: (value) {
                                      controller.idProveType.value = value as int;
                                      print(controller.idProveType.value);
                                    },
                                    validator: (value) {
                                      if (controller.idProveType.value == 0) {
                                        return "Please select your card";
                                      }
                                      return null;
                                    },
                                  ),
                              ),
                              SizedBox(height: 15.0.h),
                              Obx(() => EditTextWidget(
                                      hint: controller.idProveType.value == 0
                                          ? 'Select Card'
                                          : controller.idProveType.value == 1
                                              ? 'Aadhar Number'
                                              : controller.idProveType.value == 2
                                                  ? 'Voter ID'
                                                  : controller.idProveType.value == 3
                                                      ? 'Driving Licence'
                                                      : "Passport",
                                      controller: controller.etAadhar,
                                      label: Text(controller.idProveType.value == 0
                                          ? 'Select Card'
                                          : controller.idProveType.value == 1
                                              ? 'Aadhar Number'
                                              : controller.idProveType.value == 2
                                                  ? 'Voter ID'
                                                  : controller.idProveType.value == 3
                                                      ? 'Driving Licence'
                                                      : "Passport"),
                                      type: TextInputType.phone,
                                      inputFormatters: [
                                        FilteringTextInputFormatter
                                            .digitsOnly, // Allow only digits
                                      ],
                                      validator: (value) {
                                        if (value.toString().isEmpty) {
                                          return "Please enter Aadhar Number";
                                        }
                                        if (value.toString().length != 12) {
                                          return "Please enter 12 digit Number";
                                        }
                                        return null;
                                      },
                                      length: 12,
                                    ),
                              ),
                              SizedBox(height: 10.0.h),
                              EditTextWidget(
                                hint: 'Email',
                                label: const Text('Email'),
                                controller: controller.etEmail,
                                type: TextInputType.emailAddress,
                                validator: (value) {
                                  if (value.toString().isEmpty) {
                                    return "Please Enter Email";
                                  }
                                  if (!GetUtils.isEmail(value)) {
                                    return "Please Enter Valid Email";
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(
                                height: 10.0.h
                              ),
                              EditTextWidget(
                                hint: 'Address',
                                controller: controller.etAddress,
                                type: TextInputType.text,
                                label: const Text('Address'),
                                validator: (value) {
                                  if (value.toString().isEmpty) {
                                    return "Please enter address details";
                                  }
                                  return null;
                                },
                              ),
                              SizedBox(height: 30.0.h),
                              Container(
                                margin: const EdgeInsets.only(right: 25),
                                alignment: Alignment.centerRight,
                                width: Get.width,
                                child: RawMaterialButton(
                                  onPressed: () {
                                    if (formKey.currentState!.validate()) {
                                      controller.registrationNetworkApi(true);
                                    }
                                  },
                                  fillColor: Colors.black,
                                  padding: const EdgeInsets.all(8),
                                  shape: const CircleBorder(),
                                  constraints: const BoxConstraints(
                                      maxHeight: 54, maxWidth: 54),
                                  child: const Icon(
                                    Icons.arrow_forward,
                                    color: Colors.white,
                                    size: 30,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        )),
                      ],
                    ),
                  ),
                  SizedBox(height: 35.0.h),
                  Container(
                    padding: const EdgeInsets.only(bottom: 10.0),
                    child: Text.rich(
                      TextSpan(
                        style: smallTextStyle,
                        children: const [
                          TextSpan(
                            text:
                            'By signing in or creating an account, you agree with our \n',
                            style: TextStyle(
                                fontWeight: FontWeight.w300,
                                fontSize: 12,
                                height: 2,
                                letterSpacing: 0.2),
                          ),
                          TextSpan(
                            text: 'Term and conditions',
                            style: TextStyle(
                              color: Color(0xff006eff),
                              fontWeight: FontWeight.w300,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                          TextSpan(
                            text: ' and ',
                            style: TextStyle(
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                          TextSpan(
                            text: 'Privacy Policy',
                            style: TextStyle(
                              color: Color(0xff006eff),
                              fontWeight: FontWeight.w300,
                              decoration: TextDecoration.underline,
                            ),
                          ),
                          TextSpan(
                            text: ' ',
                            style: TextStyle(
                              color: Color(0xff006eff),
                              fontWeight: FontWeight.w300,
                            ),
                          ),
                        ],
                      ),
                      textHeightBehavior:
                      const TextHeightBehavior(applyHeightToFirstAscent: false),
                      textAlign: TextAlign.center,
                      softWrap: false,
                    )
                  ),
                  SizedBox(height: 80.0.h)
                ],
              ),
            ),
          ),
      ),
    );
  }
}
