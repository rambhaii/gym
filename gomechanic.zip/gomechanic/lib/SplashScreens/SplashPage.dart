// ignore_for_file: file_names

import 'package:flutter/material.dart';
import 'package:animated_splash_screen/animated_splash_screen.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gomechanic/SplashScreens/LoginPage.dart';
import 'package:gomechanic/Widget/Color.dart';
import 'package:gomechanic/controller/login_controller.dart';
import 'package:gomechanic/utils/all_image.dart';
import 'package:gomechanic/utils/style.dart';

class SpalshScreen extends StatelessWidget {
  const SpalshScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final LoginController controller = Get.find();
    return AnimatedSplashScreen(
      splash: Stack(children: [
        controller.isLoading.value
            ? Center(child: CircularProgressIndicator(color: TColor.grey))
            : Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      Images.splash,
                      height: 280.0.h,
                      width: 300.0.w,
                      fit: BoxFit.contain,
                    ),
                    SizedBox(
                      height: 10.0.h,
                    ),
                    Text(
                      "Go Mechanic",
                      style: robotoMedium.copyWith(
                          fontSize: 35.sp, color: Colors.cyan.shade700),
                    ),
                  ],
                ),
              ),
      ]),
      backgroundColor: Colors.white,
      nextScreen: const LoginPage(),
      splashIconSize: 450.h,
    );
  }
}
