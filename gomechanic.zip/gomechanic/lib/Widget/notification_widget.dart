import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gomechanic/Widget/Color.dart';
import 'package:gomechanic/utils/dimensions.dart';
import 'package:gomechanic/utils/style.dart';

class AllNotifications extends StatefulWidget {
  const AllNotifications({Key? key}) : super(key: key);

  @override
  State<AllNotifications> createState() => _AllNotificationsState();
}

class _AllNotificationsState extends State<AllNotifications> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TColor.themecolor,
        title: const Text('Notifications'),
      ),
      body: ListView.builder(
          itemCount: 30,
          itemBuilder: (context, index){
        return Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 5.0),
              child: Row(
                children: [
                  CircleAvatar(
                    radius: 23.0.sp,
                    backgroundColor: TColor.lightGrey.withAlpha(150),
                    child: Icon(Icons.notifications, size: 23.sp, color: Colors.black.withAlpha(180),),
                  ),
                  SizedBox(width: 5.0.w,),
                  Expanded(child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      Row(
                        children: [
                          Text('Message',style: robotoBold.copyWith(color: TColor.black,fontSize: Dimensions.fontSizeDefault2),),
                          SizedBox(width: 2.0.w,),
                          Text('Notification Description',style: robotoRegular.copyWith(color: TColor.black,fontSize: Dimensions.fontSizeDefault2),),
                        ],
                      ),
                      SizedBox(height: 3.0.h,),
                      Text('23-05-2023',style: robotoRegular.copyWith(color: TColor.greyText,fontSize: Dimensions.fontSizeDefault2),),
                    ],
                  )),
                  SizedBox(width: 3.0.w,),
                  Text('07:1$index am',style: TextStyle(color: TColor.grey),)
                ],
              ),
            ),
            const Divider(),
          ],
        );
      }),
    );
  }
}
