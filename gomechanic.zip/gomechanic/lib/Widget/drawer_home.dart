import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gomechanic/Widget/Color.dart';
import 'package:gomechanic/controller/login_controller.dart';
import 'package:gomechanic/helper/custom_list_tile.dart';
import 'package:gomechanic/helper/route_page.dart';
import 'package:gomechanic/utils/app_constants.dart';
import 'package:gomechanic/utils/dimensions.dart';
import 'package:gomechanic/utils/style.dart';

class DrawerScreen extends StatefulWidget {
  const DrawerScreen({Key? key}) : super(key: key);

  @override
  State<DrawerScreen> createState() => _DrawerScreenState();
}
  final LoginController controller = Get.find();

class _DrawerScreenState extends State<DrawerScreen> {

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width / 1.3,
      child: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            DrawerHeader(
              decoration: const BoxDecoration(color: Colors.white12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  InkWell(
                    onTap: () => Navigator.pushNamed(context, RouteHelper.profile),
                    child: Row(
                      children: [
                        Obx(
                          () => controller.rxPath.isEmpty
                              ? Container(
                                  height: 90.0,
                                  width: 95.0,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          width: 1.0.w,
                                          color: TColor.lightGrey),
                                      borderRadius:
                                          BorderRadius.circular(50.0.r),
                                      boxShadow: [
                                        BoxShadow(
                                          color: TColor.white,
                                        ),
                                        BoxShadow(
                                          color: TColor.lightGrey,
                                          spreadRadius: -12.0,
                                          blurRadius: 12.0,
                                        ),
                                      ],
                                      image: DecorationImage(
                                          image: NetworkImage(
                                              "${AppConstants.BASE_URL}/${controller.images.value}"),
                                          fit: BoxFit.cover)),
                                  child: Obx(
                                        () => controller.isLoading.value
                                        ? CircularProgressIndicator(
                                        color: TColor.grey)
                                        : const SizedBox(),
                                  ))
                              : Container(
                                  height: 90.0,
                                  width: 95.0,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          width: 1.0.w,
                                          color: TColor.lightGrey),
                                      borderRadius:
                                          BorderRadius.circular(50.0.r),
                                      image: DecorationImage(
                                          image: FileImage(
                                              File(controller.rxPath.value)),
                                          fit: BoxFit.cover)),
                                  child: Obx(
                                        () => controller.isLoading.value
                                        ? CircularProgressIndicator(
                                        color: TColor.grey)
                                        : const SizedBox(),
                                  )
                                ),
                        ),
                        Container(
                          padding: const EdgeInsets.only(left: 10),
                          width: Get.width / 2.4,
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                controller.etName.text.toString(),
                                style: robotoBold.copyWith(
                                    fontSize: Dimensions.fontSizeExtraLarge,
                                    color: TColor.Text),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                              ),
                              SizedBox(
                                height: 3.0.h,
                              ),
                              Text(
                                controller.etEmail.text.toString(),
                                style:
                                    robotoRegular.copyWith(color: TColor.black),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 2,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                children: [
                  CustomListTile(
                      onTap: () => Navigator.pop(context),
                      text: 'Dashboard',
                      icon: Icons.dashboard_outlined),
                  const Divider(),
                  CustomListTile(
                      onTap: () => Navigator.pushNamed(context, RouteHelper.profile),
                      text: 'Profile',
                      icon: Icons.person),
                  const Divider(),
                  CustomListTile(
                      onTap: () => Navigator.pushNamed(context, RouteHelper.shopDetails),
                      text: 'Shop Details',
                      icon: Icons.details_outlined),
                  const Divider(),
                  CustomListTile(
                      onTap: () => Navigator.pushNamed(context, RouteHelper.notification),
                      text: 'Notification',
                      icon: Icons.notifications_on),
                  const Divider(),
                  const CustomListTile(
                      // onTap: () => Get.toNamed("/profile"),
                      text: 'Sale',
                      icon: Icons.sell_outlined),
                  const Divider(),
                  CustomListTile(
                      onTap: () => Navigator.pushNamed(context, RouteHelper.serviceDetails),
                      text: 'Service Type',
                      icon: Icons.miscellaneous_services),
                  const Divider(),
                  const CustomListTile(
                      text: 'Setting', icon: Icons.settings_outlined),
                  const Divider(),
                  CustomListTile(
                      onTap: () => Navigator.pushNamed(context, RouteHelper.feedback),
                      text: 'Feedback',
                      icon: Icons.feedback_outlined),
                  const Divider(),
                  CustomListTile(
                      onTap: () async {
                        controller.removeData();
                        Navigator.pushNamed(context, RouteHelper.initial);
                      },
                      text: 'Logout',
                      icon: Icons.logout),
                  const Divider(),
                ],
              ),
            )
          ],
        ),
      ),
    );
  }

  void logoutDiaologBox(BuildContext context) {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        alignment: Alignment.center,
        insetPadding: const EdgeInsets.all(20),
        backgroundColor: Colors.transparent,
        child: Container(
          height: 200.h,
          width: double.infinity,
          decoration: BoxDecoration(
              color: Colors.white, borderRadius: BorderRadius.circular(10)),
          child: Padding(
            padding: const EdgeInsets.all(10),
            child: Column(
              children: [
                Text(
                  "Are you sure!",
                  style: robotoRegular.copyWith(
                    color: Colors.red,
                    fontSize: 20.0.sp,
                  ),
                ),
                SizedBox(
                  height: 10.0.h
                ),
                Container(
                  padding: const EdgeInsets.all(20),
                  child: Text(
                    "if you want to logout please press Yes otherwise No",
                    style: robotoRegular.copyWith(
                        color: Colors.red),
                    textAlign: TextAlign.center,
                  ),
                ),
                SizedBox(
                  height: 10.0.h
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 20, right: 20),
                  child: Row(
                    children: [
                      MaterialButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        shape: const RoundedRectangleBorder(
                            borderRadius:
                            BorderRadius.all(Radius.circular(10))),
                        color: Colors.green.withOpacity(0.1),
                        child: Text("No",
                            style: robotoRegular.copyWith(
                            )),
                      ),
                      const Spacer(),
                      MaterialButton(
                        onPressed: () {
                          controller.logout();
                        },
                        shape: const RoundedRectangleBorder(
                            borderRadius:
                            BorderRadius.all(Radius.circular(10))),
                        color: Colors.cyanAccent.withOpacity(0.1),
                        child: Text("Yes",
                            style: robotoRegular.copyWith(
                            )),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
