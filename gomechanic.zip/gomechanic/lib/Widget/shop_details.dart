// ignore_for_file: avoid_print, use_build_context_synchronously

import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gomechanic/AppConstent/AppConstant.dart';
import 'package:gomechanic/Widget/Color.dart';
import 'package:gomechanic/Widget/EditTextWedget.dart';
import 'package:gomechanic/controller/login_controller.dart';
import 'package:gomechanic/utils/app_constants.dart';
import 'package:gomechanic/utils/dimensions.dart';
import 'package:gomechanic/utils/style.dart';

class ShopDetails extends StatelessWidget {
  const ShopDetails({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final LoginController controller = Get.find();
    final formKey = GlobalKey<FormState>();
    ("/registrationScreen" == "/registrationScreen")
        ? null
        : controller.shopImage.value =
            controller.storage.read(AppConstant.shopPhoto);

    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: TColor.themecolor,
        title: Text(
          "Shop Details",
          style: bodyText1Style.copyWith(fontSize: 19.sp, color: Colors.white),
        ),
      ),
      body: Container(
        margin: const EdgeInsets.only(right: 0, top: 20),
        child: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20.0),
            child: Form(
              key: formKey,
              child: Column(
                children: [
                  EditTextWidget(
                    hint: 'Shop Name',
                    label: const Text('Shop Name'),
                    controller: controller.shopName,
                    validator: (value) {
                      if (value.toString().isEmpty) {
                        return "Please enter shop name";
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 10.0.h),
                  Row(
                    children: [
                      Expanded(
                        child: EditTextWidget(
                          hint: 'Open Time',
                          label: const Text('Open Time'),
                          controller: controller.startTime,
                          type: TextInputType.text,
                          onTap: () async {
                            controller.chooseTime(false);
                          },
                          isRead: true,
                          suffixIcon: InkWell(
                            onTap: () async {
                              controller.chooseTime(false);
                            },
                            child: Icon(Icons.access_time,
                                color: TColor.black.withAlpha(100)),
                          ),
                          validator: (value) {
                            if (value.toString().isEmpty) {
                              return "Please enter open time";
                            }
                            return null;
                          },
                        ),
                      ),
                      SizedBox(width: 40.0.w),
                      Expanded(
                        child: EditTextWidget(
                          hint: 'End Time',
                          label: const Text('End Time'),
                          controller: controller.endTime,
                          type: TextInputType.text,
                          onTap: () async {
                            controller.chooseTime(true);
                          },
                          isRead: true,
                          suffixIcon: InkWell(
                            onTap: () async {
                              controller.chooseTime(true);
                            },
                            child: Icon(Icons.access_time,
                                color: TColor.black.withAlpha(100)),
                          ),
                          validator: (value) {
                            if (value.toString().isEmpty) {
                              return "Please enter close time";
                            }
                            return null;
                          },
                        ),
                      ),
                    ],
                  ),
                  SizedBox(height: 10.0.h),
                  EditTextWidget(
                    hint: 'Description',
                    label: const Text('Description'),
                    controller: controller.description,
                    type: TextInputType.multiline,
                    validator: (value) {
                      if (value.toString().isEmpty) {
                        return "Please enter shop description";
                      }
                      return null;
                    },
                  ),
                  SizedBox(height: 5.0.h),
                  EditTextWidget(
                    hint: 'Service Capacity No',
                    label: const Text('Service Capacity No'),
                    controller: controller.serviceCapacity,
                    type: TextInputType.number,
                    length: 4,
                    inputFormatters: [
                      FilteringTextInputFormatter.digitsOnly,
                    ],
                    validator: (value) {
                      if (value.toString().isEmpty) {
                        return "Please enter cycle service capacity number";
                      }
                      return null;
                    },
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text('Normal CC      :',
                          style: robotoMedium.copyWith(
                              fontSize: Dimensions.fontSizeDefault)),
                      Obx(
                        () => Radio(
                          value: 1,
                          groupValue: controller.normalCc.value,
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          activeColor: Colors.green,
                          onChanged: (value) {
                            controller.normalCc.value = value!;
                          },
                        ),
                      ),
                      Text('Yes',
                          style: robotoRegular.copyWith(
                              fontSize: Dimensions.fontSizeDefault,
                              color: TColor.black.withAlpha(150))),
                      Obx(
                        () => Radio(
                          value: 0,
                          groupValue: controller.normalCc.value,
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          activeColor: Colors.red,
                          onChanged: (value) {
                            controller.normalCc.value = value!;
                            print(controller.normalCc.value);
                          },
                        ),
                      ),
                      Text('No',
                          style: robotoRegular.copyWith(
                              fontSize: Dimensions.fontSizeDefault,
                              color: TColor.black.withAlpha(150))),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text('High Pickup    :',
                          style: robotoMedium.copyWith(
                              fontSize: Dimensions.fontSizeDefault)),
                      Obx(
                        () => Radio(
                          value: 1,
                          groupValue: controller.highPickup.value,
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          activeColor: Colors.green,
                          onChanged: (value) {
                            controller.highPickup.value = value!;
                          },
                        ),
                      ),
                      Text('Yes',
                          style: robotoRegular.copyWith(
                              fontSize: Dimensions.fontSizeDefault,
                              color: TColor.black.withAlpha(150))),
                      // SizedBox(width: 5.0.w),
                      Obx(
                        () => Radio(
                          value: 0,
                          groupValue: controller.highPickup.value,
                          activeColor: Colors.red,
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          onChanged: (value) {
                            controller.highPickup.value = value!;
                            print(controller.highPickup.value);
                          },
                        ),
                      ),
                      Text('No',
                          style: robotoRegular.copyWith(
                              fontSize: Dimensions.fontSizeDefault,
                              color: TColor.black.withAlpha(150))),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text('Road Service  :',
                          style: robotoMedium.copyWith(
                              fontSize: Dimensions.fontSizeDefault)),
                      // SizedBox(width: 5.0.w),
                      Obx(
                        () => Radio(
                          value: 1,
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          groupValue: controller.roadService.value,
                          activeColor: Colors.green,
                          onChanged: (value) {
                            controller.roadService.value = value!;
                          },
                        ),
                      ),
                      Text('Yes',
                          style: robotoRegular.copyWith(
                              fontSize: Dimensions.fontSizeDefault,
                              color: TColor.black.withAlpha(150))),
                      // SizedBox(width: 5.0.w),
                      Obx(
                        () => Radio(
                          value: 0,
                          materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                          groupValue: controller.roadService.value,
                          activeColor: Colors.red,
                          onChanged: (value) {
                            controller.roadService.value = value!;
                            print(controller.roadService.value);
                          },
                        ),
                      ),
                      Text(
                        'No',
                        style: robotoRegular.copyWith(
                            fontSize: Dimensions.fontSizeDefault,
                            color: TColor.black.withAlpha(150)),
                      ),
                    ],
                  ),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text('Shop Photo     :',
                          style: robotoMedium.copyWith(
                              fontSize: Dimensions.fontSizeDefault)),
                      SizedBox(width: 15.0.w),
                      MaterialButton(
                        onPressed: () {
                          controller.chooseShopImage();
                        },
                        elevation: 0.0,
                        height: 30.0.h,
                        minWidth: 100.0.w,
                        shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(5.0.r)),
                        color: TColor.lightGrey,
                        child: Text(
                          'Choose',
                          style: robotoMedium.copyWith(
                              fontSize: Dimensions.fontSizeSmall,
                              color: Colors.black45),
                        ),
                      )
                    ],
                  ),
                  SizedBox(height: 5.0.h),
                  Obx(
                    () => controller.shopPath.isEmpty
                        ? Container(
                            height: 120.0.h,
                            width: double.infinity,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    width: 1.0.w,
                                    color: TColor.lightGrey),
                                borderRadius:
                                    BorderRadius.circular(5.0.r),
                                boxShadow: [
                                  BoxShadow(
                                    color: TColor.white,
                                  ),
                                  BoxShadow(
                                    color: TColor.lightGrey,
                                    spreadRadius: -12.0,
                                    blurRadius: 12.0,
                                  ),
                                ],
                                image: DecorationImage(
                                    image: NetworkImage(
                                        "${AppConstants.BASE_URL}/${controller.shopImage.value}"),
                                    fit: BoxFit.cover)),
                            child: Obx(
                              () => controller.isLoading.value
                                  ? CircularProgressIndicator(
                                      color: TColor.grey)
                                  : const SizedBox(),
                            ))
                        : Container(
                            height: 120.0,
                            width: double.infinity,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                                border: Border.all(
                                    width: 1.0.w,
                                    color: TColor.lightGrey),
                                borderRadius:
                                    BorderRadius.circular(5.0.r),
                                image: DecorationImage(
                                    image: FileImage(
                                        File(controller.shopPath.value)),
                                    fit: BoxFit.cover)),
                            child: Obx(
                              () => controller.isLoading.value
                                  ? CircularProgressIndicator(
                                      color: TColor.grey)
                                  : const SizedBox(),
                            ),
                          ),
                  ),
                  SizedBox(height: 50.0.h),
                  Container(
                    height: 40.0.h,
                    width: double.infinity,
                    decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(5.0.r),
                    ),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          elevation: 0.0),
                      onPressed: () {
                        if (formKey.currentState!.validate()) {
                          controller.updateShopProfile();
                        }
                      },
                      child: Text('Update Details'.tr,
                          style: robotoMedium.copyWith(
                            fontSize: Dimensions.fontSizeLarge,
                            color: TColor.white,
                            decoration: TextDecoration.none,
                          )),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
