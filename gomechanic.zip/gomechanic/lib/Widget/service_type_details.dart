// ignore_for_file: unused_local_variable

import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gomechanic/Dashbord/DileveyImages.dart';
import 'package:gomechanic/Dashbord/PickImages.dart';
import 'package:gomechanic/Widget/Color.dart';
import 'package:gomechanic/controller/details_controller.dart';
import 'package:gomechanic/controller/login_controller.dart';
import 'package:gomechanic/helper/custom_dialog.dart';
import 'package:gomechanic/helper/custom_text.dart';
import 'package:gomechanic/utils/app_constants.dart';
import 'package:gomechanic/utils/dimensions.dart';
import 'package:gomechanic/utils/style.dart';

class ServiceTypeDetails extends StatefulWidget {
  const ServiceTypeDetails({Key? key}) : super(key: key);

  @override
  State<ServiceTypeDetails> createState() => _ServiceTypeDetailsState();
}

class _ServiceTypeDetailsState extends State<ServiceTypeDetails> {
  final LoginController controller = Get.find();
  final DetailsController detailsController = Get.find();

  @override
  Widget build(BuildContext context) {
  detailsController.saveDataRegistration();
  detailsController.selectedValue.value = int.parse(detailsController.serviceModel.value.data![detailsController.detailsIndex.value].status.toString());
    double height, width;
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        backgroundColor: TColor.themecolor,
        title: Text(
          "Service Type Details",
          style: bodyText1Style.copyWith(fontSize: 19.sp, color: Colors.white),
        ),
        actions: [
          TextButton(
              onPressed: () => Get.back(),
              child: Text(
                'Save',
                style: robotoMedium.copyWith(
                    color: TColor.white, fontSize: Dimensions.fontSizeDefault2),
              )),
          SizedBox(width: 5.0.w),
        ],
      ),
      body: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 5.0),
          decoration: const BoxDecoration(),
          child: ListView(
              children: [
                SizedBox(height: 10.0.h),
                SizedBox(
                  height: 99.0.h,
                  width: double.infinity,
                  child: Row(
                    children: [
                      SizedBox(
                        width: width * 0.65,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            SizedBox(height: 2.0.h),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const CustomTitleText(text: 'Booking No : '),
                                SizedBox(width: 4.0.w),
                                Expanded(
                                  child: Obx(
                                    () => CustomSubTitleText(
                                        text: detailsController
                                                .serviceModel
                                                .value
                                                .data![detailsController
                                                    .detailsIndex.value]
                                                .bookingNo.toString()),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(height: 5.0.h),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const CustomTitleText(text: 'User : '),
                                SizedBox(width: 4.0.w),
                                Expanded(
                                  child: Obx(
                                    () => CustomSubTitleText(
                                        text: detailsController.serviceModel.value.data![detailsController.detailsIndex.value].username.toString()),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(height: 5.0.h),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const CustomTitleText(text: 'Owner : '),
                                SizedBox(width: 4.0.w),
                                Expanded(
                                  child: Obx(
                                    () => CustomSubTitleText(
                                        text: detailsController.serviceModel.value.data![detailsController.detailsIndex.value].ownerName.toString()),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(height: 5.0.h),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const CustomTitleText(text: 'Mobile No : '),
                                SizedBox(width: 4.0.w),
                                Expanded(
                                  child: Obx(
                                    () => CustomSubTitleText(
                                        text: detailsController.serviceModel.value.data![detailsController.detailsIndex.value].mobileNo.toString()),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(
                              height: 2.0.h,
                            ),
                          ],
                        ),
                      ),
                      Expanded(
                        child: Container(
                          alignment: Alignment.topRight,
                          child: InkWell(
                            onTap: () {
                              showAnimatedDialog(
                                  context,
                                  Center(
                                      child: Container(
                                    width: 320.w,
                                    height: 250.h,
                                    padding: const EdgeInsets.all(
                                        Dimensions.PADDING_SIZE_EXTRA_LARGE),
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          width: 1.0.w, color: TColor.lightGrey),
                                      borderRadius: BorderRadius.circular(
                                          Dimensions.RADIUS_EXTRA_LARGE),
                                      boxShadow: [
                                        BoxShadow(
                                          color: TColor.white,
                                        ),
                                        BoxShadow(
                                          color: TColor.lightGrey,
                                          spreadRadius: -12.0,
                                          blurRadius: 12.0,
                                        ),
                                      ],
                                      image: DecorationImage(
                                                image: NetworkImage(
                                                    "${AppConstants.BASE_URL}/${detailsController.serviceModel.value.data![detailsController.detailsIndex.value].userProfile.toString()}"),
                                                fit: BoxFit.fill)
                                    ),
                                  )),
                                  dismissible: true);
                            },
                            child: Container(
                              width: 320.w,
                              height: 250.h,
                              padding: const EdgeInsets.all(
                                  Dimensions.PADDING_SIZE_EXTRA_LARGE),
                              decoration: BoxDecoration(
                                border: Border.all(
                                    width: 1.0.w, color: TColor.lightGrey),
                                borderRadius: BorderRadius.circular(
                                    Dimensions.RADIUS_EXTRA_LARGE),
                                boxShadow: [
                                  BoxShadow(
                                    color: TColor.white,
                                  ),
                                  BoxShadow(
                                    color: TColor.lightGrey,
                                    spreadRadius: -12.0,
                                    blurRadius: 12.0,
                                  ),
                                ],
                                image: DecorationImage(
                                          image: NetworkImage(
                                              "${AppConstants.BASE_URL}/${detailsController.serviceModel.value.data![detailsController.detailsIndex.value].userProfile.toString()}"),
                                          fit: BoxFit.fill)
                              ),
                            ),
                          ),
                        ),
                      )
                    ],
                  ),
                ),
                const Divider(),
                SizedBox(height: 5.0.h),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const CustomTitleText(text: 'Service Type : '),
                    SizedBox(width: 5.0.w),
                    Expanded(
                      child: Obx(
                        () => CustomSubTitleText(
                            text: detailsController.serviceModel.value.data![detailsController.detailsIndex.value].serviceType.toString()),
                      ),
                    )
                  ],
                ),
                SizedBox(height: 5.0.h),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const CustomTitleText(text: 'Booking Date : '),
                    SizedBox(width: 5.0.w),
                    Expanded(
                      child: Obx(
                        () => CustomSubTitleText(
                            text: detailsController.serviceModel.value.data![detailsController.detailsIndex.value].addDate.toString()),
                      ),
                    )
                  ],
                ),
                SizedBox(height: 5.0.h),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const CustomTitleText(text: 'Service Date : '),
                    SizedBox(width: 5.0.w),
                    Expanded(
                      child: Obx(
                        () => CustomSubTitleText(
                            text: detailsController.serviceModel.value.data![detailsController.detailsIndex.value].serviceDate.toString()),
                      ),
                    )
                  ],
                ),
                SizedBox(height: 5.0.h),
                SizedBox(
                  width: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.44,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const CustomTitleText(text: 'Bike CC : '),
                            SizedBox(width: 4.0.w),
                            Expanded(
                              child: Obx(
                                () => CustomSubTitleText(
                                    text: detailsController.serviceModel.value.data![detailsController.detailsIndex.value].bikeCc.toString()
                                        .toString()),
                              ),
                            )
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 2.0.w,
                      ),
                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const CustomTitleText(text: 'Brand : '),
                            SizedBox(width: 4.0.w),
                            Expanded(
                              child: Obx(
                                () => CustomSubTitleText(
                                    text: detailsController.serviceModel.value.data![detailsController.detailsIndex.value].brandName.toString()
                                        .toString()),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(height: 5.0.h),
                SizedBox(
                  width: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.44,
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const CustomTitleText(text: 'Status : '),
                            SizedBox(width: 4.0.w),
                            Obx(
                              () => Text(
                                detailsController.serviceModel.value.data![detailsController.detailsIndex.value].status.toString() == "1"
                                    ? 'Pending'
                                    : "Successful",
                                style: robotoMedium.copyWith(
                                    fontSize: Dimensions.fontSizeDefault,
                                    color: detailsController.status.value == "1"
                                        ? Colors.red.shade400.withAlpha(200)
                                        : Colors.green.shade500.withAlpha(200)),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 2.0.w,
                      ),
                      Expanded(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const CustomTitleText(text: 'Slot : '),
                            SizedBox(width: 4.0.w),
                            Expanded(
                              child: Obx(
                                () => CustomSubTitleText(
                                    text: detailsController.serviceModel.value.data![detailsController.detailsIndex.value].slotId.toString()
                                        .toString()),
                              ),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(height: 5.0.h),
                SizedBox(
                  width: double.infinity,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(
                        width: width * 0.44,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const CustomTitleText(text: 'Vin Number Pic'),
                            SizedBox(height: 5.0.h),
                            Obx(
                              () => InkWell(
                                onTap: () {
                                  showAnimatedDialog(
                                      context,
                                      Center(
                                        child: Container(
                                          width: 320.w,
                                          height: 250.h,
                                          padding: const EdgeInsets.all(Dimensions
                                              .PADDING_SIZE_EXTRA_LARGE),
                                          decoration: BoxDecoration(
                                            color: Theme.of(context).cardColor,
                                            borderRadius: BorderRadius.circular(
                                                Dimensions.RADIUS_EXTRA_LARGE),
                                            // image: DecorationImage(
                                            //     image: NetworkImage(
                                            //         "${AppConstants.BASE_URL}/${detailsController.vin_image.value}"),
                                            //     fit: BoxFit.fill),
                                          ),
                                        ),
                                      ),
                                      dismissible: true);
                                },
                                child: Container(
                                    width: double.infinity,
                                    height: 100.0.h,
                                    padding: const EdgeInsets.all(
                                        Dimensions.PADDING_SIZE_EXTRA_LARGE),
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).cardColor,
                                      borderRadius: BorderRadius.circular(
                                          Dimensions.RADIUS_SMALL),
                                      boxShadow: [
                                        BoxShadow(
                                          color: TColor.white,
                                        ),
                                        BoxShadow(
                                          color: TColor.lightGrey,
                                          spreadRadius: -12.0,
                                          blurRadius: 12.0,
                                        )
                                      ],
                                      image: DecorationImage(
                                          image: NetworkImage(
                                              "${AppConstants.BASE_URL}/${detailsController.serviceModel.value.data![detailsController.detailsIndex.value].vinNoPic.toString()}"),
                                          fit: BoxFit.fill),
                                    )),
                              ),
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 10.0.w),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const CustomTitleText(text: 'Owner ID Image'),
                            SizedBox(height: 5.0.h),
                            Obx(
                              () => InkWell(
                                onTap: () {
                                  showAnimatedDialog(
                                      context,
                                      Center(
                                        child: Container(
                                            width: 320.0.w,
                                            height: 250.0.h,
                                            padding: const EdgeInsets.all(
                                                Dimensions
                                                    .PADDING_SIZE_EXTRA_LARGE),
                                            decoration: BoxDecoration(
                                              color: Theme.of(context).cardColor,
                                              borderRadius: BorderRadius.circular(
                                                  Dimensions.RADIUS_EXTRA_LARGE),
                                              // image: DecorationImage(
                                              //     image: NetworkImage(
                                              //         "${AppConstants.BASE_URL}/${detailsController.prove_image.value}"),
                                              //     fit: BoxFit.fill),
                                            )),
                                      ),
                                      dismissible: true);
                                },
                                child: Container(
                                    width: double.infinity,
                                    height: 100.0.h,
                                    padding: const EdgeInsets.all(
                                        Dimensions.PADDING_SIZE_EXTRA_LARGE),
                                    decoration: BoxDecoration(
                                      color: Theme.of(context).cardColor,
                                      boxShadow: [
                                        BoxShadow(
                                          color: TColor.white,
                                        ),
                                        BoxShadow(
                                          color: TColor.lightGrey,
                                          spreadRadius: -12.0,
                                          blurRadius: 12.0,
                                        )
                                      ],
                                      borderRadius: BorderRadius.circular(
                                          Dimensions.RADIUS_SMALL),
                                      image: DecorationImage(
                                          image: NetworkImage(
                                              "${AppConstants.BASE_URL}/${detailsController.serviceModel.value.data![detailsController.detailsIndex.value].idProve.toString()}"),
                                          fit: BoxFit.fill),
                                    )),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                SizedBox(height: 10.0.h),
                const CustomTitleText(text: 'Other Information'),
                SizedBox(height: 10.0.h),
                Container(
                  decoration: BoxDecoration(
                    color: TColor.lightGrey,
                    borderRadius: BorderRadius.circular(5.r),
                  ),
                  child: ExpansionTile(
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.r)),
                    trailing: Icon(Icons.add, size: 22.sp, color: Colors.black54,),
                    title: Text(
                      "Upload Pickup Image",
                      style: robotoRegular.copyWith(color: Colors.black),
                      textAlign: TextAlign.start,
                    ),
                    children: const [
                      PickImages(),
                    ]
                  ),
                ),
                SizedBox(height: 10.0.h),
                Container(
                  decoration: BoxDecoration(
                    color: TColor.lightGrey,
                    borderRadius: BorderRadius.circular(5.r),
                  ),
                  child: ExpansionTile(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.r)),
                      trailing: Icon(Icons.add, size: 22.sp, color: Colors.black54,),
                      title: Text(
                        "Add Service Part",
                        style: robotoRegular.copyWith(color: Colors.black),
                        textAlign: TextAlign.start,
                      ),
                      children: const [
                        DileveryImages(),
                      ]
                  ),
                ),
                SizedBox(height: 10.0.h),
                Container(
                  decoration: BoxDecoration(
                    color: TColor.lightGrey,
                    borderRadius: BorderRadius.circular(5.r),
                  ),
                  child: ExpansionTile(

                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.r)),
                      trailing: Icon(Icons.add, size: 22.sp, color: Colors.black54,),
                      title: Text(
                        "Completed Service Image",
                        style: robotoRegular.copyWith(color: Colors.black),
                        textAlign: TextAlign.start,
                      ),
                      children: const [
                        DileveryImages(),
                      ]
                  ),
                ),
                SizedBox(height: 10.0.h),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 8.0),
                  decoration: BoxDecoration(
                    color: TColor.lightGrey,
                    borderRadius: BorderRadius.circular(5.r),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: Obx(() => DropdownButton2(
                        hint: Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: Text(
                            'Upload Service Status',
                            style: robotoRegular.copyWith(color: Colors.black),
                          ),
                        ),
                        items: detailsController.serviceStatus.asMap().entries.map((entry) {
                          final int index = entry.key;
                          final String item = entry.value;
                          return DropdownMenuItem<int>(
                            value: index + 1, // Assign unique values by using the index
                            child: Padding(
                              padding: const EdgeInsets.only(left: 5.0),
                              child: Text(
                                item,
                                style: robotoRegular.copyWith(color: Colors.black),
                              ),
                            ),
                          );
                        }).toList(),
                        value: detailsController.selectedValue.value,
                        onChanged: (value) {
                          detailsController.selectedValue.value = value!;
                          print(detailsController.selectedValue.value);
                        },
                        buttonStyleData: const ButtonStyleData(
                          height: 40,
                          width: 140,
                        ),
                        menuItemStyleData: const MenuItemStyleData(
                          height: 40,
                        ),
                      ),
                    )
                  ),
                ),
                SizedBox(height: 30.0.h),
              ],
            ),
          ),
    );
  }
}
