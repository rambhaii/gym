// ignore_for_file: unused_local_variable

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gomechanic/AppConstent/AppConstant.dart';
import 'package:gomechanic/controller/details_controller.dart';
import 'package:gomechanic/controller/login_controller.dart';
import 'package:gomechanic/helper/not_found_screen.dart';
import 'package:gomechanic/helper/route_page.dart';
import 'package:gomechanic/utils/app_constants.dart';
import 'package:loader_overlay/loader_overlay.dart';

void main() async {
  await GetStorage.init();
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const MyApp());
}



class MyApp extends StatelessWidget {
  const MyApp({super.key});

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();
    final DetailsController detailsController = Get.put(DetailsController());
    final LoginController controller = Get.put(LoginController());
    return ScreenUtilInit(
      designSize: const Size(360, 690),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context, child) {
        return  GlobalLoaderOverlay(
          useDefaultLoading: false,
          overlayOpacity: 0.1,
          overlayWidget: Center(
            child: Container(
                height: 41,
                width: 41,
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
                child: const CircularProgressIndicator(
                  color: Colors.black,
                  strokeWidth: 3.5,
                )
            ),
          ),
          child: GetMaterialApp(
            debugShowCheckedModeBanner: false,
            title: AppConstants.APP_NAME,
            theme: ThemeData(
              primaryColor: Colors.white,
            ),
            navigatorKey: navigatorKey,
            initialRoute: GetStorage().read(AppConstant.userName) !=null ?
            GetStorage().read(AppConstant.userName).toString().isNotEmpty ? RouteHelper.home :
            RouteHelper.initial : RouteHelper.initial,
            getPages: RouteHelper.routes,
            unknownRoute: GetPage(name: '/not-found', page: () => const NotFoundScreen()),
            transitionDuration: const Duration(milliseconds: 500),
          )
        );
      },
    );
  }
}
