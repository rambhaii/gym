// ignore: file_names
// ignore_for_file: file_names, duplicate_ignore, constant_identifier_names

class AppConstant{

  static const String name= "name";
  static const String id= "id";
  static const String address = "address";
  static const String phone = "mobile";
  static const String fcm_token = "fcm_id";
  static const String aadhar = "id_prove_no";
  static const String idProveType = "id_prove_type";
  static const String email = "email";
  static const String profile = "profile";
  static const String latitude = "latitude";
  static const String longitude = "longitude";

  static const String booking_no = "booking_no";
  static const String booking_date = "booking_date"; // add_date
  static const String userName = "userName";
  static const String ownerName = "owner_name";
  static const String userProfile = "user_profile";
  static const String serviceType = "serviceType";
  static const String service_date = "service_date";
  static const String bike_cc = "bike_cc";
  static const String status = "status";
  static const String brandName = "brandName";
  static const String vin_no_pic = "vin_no_pic";
  static const String id_prove = "id_prove";
  static const String slot_id = "slot_id";
  static const String mobile_no = "mobile_no";

  static const String shopPhoto = "shop_photo";
  static const String store_time = "store_time";
  static const String idProvePhoto = "id_prove_photo";

  static const String isValue = "is_value";
  static const String userId = "userId";
  static const String gender = "gender";
  static const String mapAddress = "map_address";
  static const String id_photo = "id_prove_photo";
  static const String shopName = "shop_name";
  static const String normalCcByck = "normal_cc_byck";
  static const String heigh_pickup = "heigh_pickup";
  static const String is_on_road_service = "is_on_road_service";
  static const String byck_service_capicity = "byck_service_capicity";
  static const String description = "description";
}