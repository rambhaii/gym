// ignore_for_file: non_constant_identifier_names, avoid_print

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gomechanic/AppConstent/AppConstant.dart';
import 'package:gomechanic/UtilMethode/BaseClient.dart';
import 'package:gomechanic/UtilMethode/utilmethode.dart';
import 'package:gomechanic/models/service_model.dart';
import 'package:gomechanic/utils/app_constants.dart';
import 'package:gomechanic/utils/custom_snackbar.dart';

class DetailsController extends GetxController {
  var serviceModel = ServiceDetailsModel().obs;
  GetStorage storage = GetStorage();
  final ScrollController scrollController = ScrollController();
  RxBool isLoadingPage = false.obs;
  RxInt currentPage = 0.obs;

  RxBool isLoading = false.obs;
  RxInt detailsIndex = 0.obs;
  RxString bookingNo = "".obs;
  RxString booking_date = "".obs;
  RxString user_id = "".obs;
  RxString user_name = "".obs;
  RxString user_num = "".obs;
  RxString userProfile = "".obs;
  RxString ownerName = "".obs;
  RxString serviceType = "".obs;
  RxString service_date = "".obs;
  RxString bike_cc = "".obs;
  RxString status = "".obs;
  RxString brandName = "".obs;
  RxString vin_image = "".obs;
  RxString prove_image = "".obs;
  RxString slot_id = "".obs;
  RxInt selectedValue = 1.obs;

  final List<String> serviceStatus = [
    'Pending',
    'Receive',
    'Pickup',
    'Complete',
  ];

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    addItems();
  }

  saveDataRegistration() async {
    user_id.value = storage.read(AppConstant.id) ?? "";
    user_num.value = storage.read(AppConstant.mobile_no) ?? "";
    userProfile.value = storage.read(AppConstant.userProfile) ?? "";
    bookingNo.value = storage.read(AppConstant.booking_no) ?? "";
    booking_date.value = storage.read(AppConstant.booking_date) ?? "";
    user_name.value = storage.read(AppConstant.userName) ?? "";
    ownerName.value = storage.read(AppConstant.ownerName) ?? "";
    serviceType.value = storage.read(AppConstant.serviceType) ?? "";
    service_date.value = storage.read(AppConstant.service_date) ?? "";
    bike_cc.value = storage.read(AppConstant.bike_cc) ?? "";
    status.value = storage.read(AppConstant.status) ?? "";
    brandName.value = storage.read(AppConstant.brandName) ?? "";
    slot_id.value = storage.read(AppConstant.slot_id) ?? "";
    prove_image.value = storage.read(AppConstant.id_prove) ?? "";
    vin_image.value = storage.read(AppConstant.vin_no_pic) ?? "";
    storage.read(AppConstant.latitude) ?? "";
    storage.read(AppConstant.longitude) ?? "";
  }

  loader() {
    isLoading.value = true;
    Future.delayed(const Duration(seconds: 2), () {
      isLoading.value = false;
    });
  }

  getBookNetworkApi(bool isValue) async {
    var response = await BaseClient()
        .get(
            "${AppConstants.DETAILS_URL}?lng=eng?limit=${10}&page=0&searchkey=&category_id=")
        .catchError(BaseController().handleError);
    print("====== $response");
    if (jsonDecode(response)["status"] == 1) {
      // isLoadingPage.value = true;
      isValue ? isLoadingPage.value = true : null;
      serviceModel.value = serviceDetailsModelFromJson(response);
      // isValue ? null : Navigator.pushNamed(context, RouteHelper.shopDetails);
    }
  }

  addItems() async {
    scrollController.addListener(() {
      // print("pagination data");
      if (scrollController.position.maxScrollExtent ==
          scrollController.position.pixels) {
        if (isLoadingPage.value) {
          currentPage.value =
              currentPage.value + int.parse(serviceModel.value.page.toString());
          getBookingLoadingPageNetworkApi(currentPage.value);
        }
      }
    });
  }

  getBookingLoadingPageNetworkApi(int end) async {
    var response = await BaseClient()
        .get(
            "${AppConstants.DETAILS_URL}?lng=eng?limit=${10}&page=$end&searchkey=&category_id=")
        .catchError(BaseController().handleError);
    print("====== $response");
    if (jsonDecode(response)["status"] == 1) {
      if (isLoadingPage.value == true) {
        serviceModel.value.data!
            .addAll(serviceDetailsModelFromJson(response).data!);
        serviceModel.refresh();
      }
    } else {
      isLoadingPage.value = false;
      CustomAnimation().showCustomToast("No more data available !", isError: false);
    }
  }
}
