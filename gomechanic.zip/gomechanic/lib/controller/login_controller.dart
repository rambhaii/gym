// ignore_for_file: avoid_print, prefer_typing_uninitialized_variables, non_constant_identifier_names

import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gomechanic/AppConstent/AppConstant.dart';
import 'package:gomechanic/SplashScreens/OtpVerify.dart';
import 'package:gomechanic/UtilMethode/utilmethode.dart';
import 'package:gomechanic/UtilMethode/BaseClient.dart';
import 'package:gomechanic/helper/route_page.dart';
import 'package:gomechanic/utils/app_constants.dart';
import 'package:gomechanic/utils/custom_snackbar.dart';
import 'package:image_picker/image_picker.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:otp_text_field/otp_text_field.dart';

class LoginController extends GetxController {
  GetStorage storage = GetStorage();
  RxString current_address = "".obs;
  RxString Address = "".obs;
  RxInt idProveType = 0.obs;
  RxString rxPath = "".obs;
  RxInt otpValidation = 0.obs;
  RxString images = "".obs;
  RxString shopImage = "".obs;
  RxString shopPath = "".obs;
  RxString urlValue = "".obs;
  RxString FCM_TOKEN = "".obs;
  RxDouble longitude = 0.0.obs;
  RxDouble latitude = 0.0.obs;
  DateTime? currentBackPressTime;
  RxInt minutes = 1.obs;
  RxInt seconds = 0.obs;
  RxInt normalCc = 0.obs;
  RxInt highPickup = 0.obs;
  RxInt roadService = 0.obs;
  Timer? timer;
  RxBool isLoading = false.obs;
  var selectedTime = TimeOfDay.now().obs;
  RxBool isValueBtn = false.obs;

  OtpFieldController otpController = OtpFieldController();
  TextEditingController etMobile = TextEditingController();
  TextEditingController number = TextEditingController();
  TextEditingController etName = TextEditingController();
  TextEditingController etEmail = TextEditingController();
  TextEditingController etAadhar = TextEditingController();
  TextEditingController etAddress = TextEditingController();
  TextEditingController mapAddress = TextEditingController();

  TextEditingController shopName = TextEditingController();
  TextEditingController startTime = TextEditingController();
  TextEditingController endTime = TextEditingController();
  TextEditingController description = TextEditingController();
  TextEditingController serviceCapacity = TextEditingController();

  loader() {
    isLoading.value = true;
    Future.delayed(const Duration(seconds: 2), () {
      isLoading.value = false;
    });
  }

  loginNetworkApi() async {
    var bodyRequest = {
      "lng": AppConstants.LANGUAGE,
      "mobile": etMobile.text.toString(),
      "device_id": "",
      "fcm_id": FCM_TOKEN.value.toString(),
    };
    print("request >>>>>>>>>>>>> $bodyRequest");
    Get.context!.loaderOverlay.show();
    var response = await BaseClient()
        .post(AppConstants.LOGIN_URL, bodyRequest)
        .catchError(BaseController().handleError);
    print("Mobile No : ${etMobile.text}");
    print(response);
    Get.context!.loaderOverlay.hide();
    if (jsonDecode(response)["status"] == 1) {
      isLoading.value = true;
      BaseController().successSnack(jsonDecode(response)["message"] +
          " " +
          jsonDecode(response)["Data"]["otp"]);
      Get.to(() => OtpVerify(
            id: jsonDecode(response)["Data"]["id"] ?? "",
            otp: jsonDecode(response)["Data"]["otp"] ?? "",
          ));
      return;
    }
    storage.write(
        AppConstant.fcm_token, jsonDecode(response)["Data"]["fcm_id"] ?? "");
    BaseController().errorSnack(jsonDecode(response)["message"]);
    isLoading.value = false;
  }

  verifyNetworkApi(String id, String otp) async {
    try {
      var bodyRequest = {
        "lng": AppConstants.LANGUAGE,
        "id": id.toString(),
        "otp": otp.toString(),
      };
      print("body ==>>>>> $bodyRequest");
      Get.context!.loaderOverlay.show();
      var response = await BaseClient()
          .post(AppConstants.VERIFY_URL, bodyRequest)
          .catchError(BaseController().handleError);
      print("response ===>>>>>> $response");
      Get.context!.loaderOverlay.hide();
      loader();
      if (jsonDecode(response)["status"] == 1) {
        if (jsonDecode(response)["Data"].isNotEmpty) {
          if (jsonDecode(response)["Data"]["id"].toString().isNotEmpty &&
              jsonDecode(response)["Data"]["email"].toString().isNotEmpty) {
            storage.write(
                AppConstant.id, jsonDecode(response)["Data"]["id"] ?? "");
            storage.write(
                AppConstant.name, jsonDecode(response)["Data"]["name"] ?? "");
            storage.write(AppConstant.address,
                jsonDecode(response)["Data"]["address"] ?? "");
            storage.write(AppConstant.profile,
                jsonDecode(response)["Data"]["profile"] ?? "");
            storage.write(
                AppConstant.email, jsonDecode(response)["Data"]["email"] ?? "");
            storage.write(AppConstant.phone,
                jsonDecode(response)["Data"]["mobile"] ?? "");
            storage.write(AppConstant.fcm_token,
                jsonDecode(response)["Data"]["fcm_id"] ?? "");
            storage.write(AppConstant.idProvePhoto,
                jsonDecode(response)["Data"]["id_prove_photo"] ?? "");
            storage.write(AppConstant.aadhar,
                jsonDecode(response)["Data"]["id_prove_no"] ?? "");
            storage.write(AppConstant.idProveType,
                jsonDecode(response)["Data"]["id_prove_type"] ?? "");
            storage.write(AppConstant.normalCcByck,
                jsonDecode(response)["Data"]["normal_cc_byck"] ?? "");
            storage.write(AppConstant.heigh_pickup,
                jsonDecode(response)["Data"]["heigh_pickup"] ?? "");
            storage.write(AppConstant.is_on_road_service,
                jsonDecode(response)["Data"]["is_on_road_service"] ?? "");
            storage.write(AppConstant.byck_service_capicity,
                jsonDecode(response)["Data"]["byck_service_capicity"] ?? "");
            storage.write(AppConstant.description,
                jsonDecode(response)["Data"]["description"] ?? "");
            storage.write(AppConstant.shopName,
                jsonDecode(response)["Data"]["shop_name"] ?? "");
            storage.write(AppConstant.shopPhoto,
                jsonDecode(response)["Data"]["shop_photo"] ?? "");
            storage.write(AppConstant.store_time,
                jsonDecode(response)["Data"]["store_time"] ?? "");
            storage.write(AppConstant.latitude,
                jsonDecode(response)["Data"]["latitude"] ?? "");
            storage.write(AppConstant.longitude,
                jsonDecode(response)["Data"]["longitude"] ?? "");
            saveDataRegistration();
            saveDataShop();
            BaseController().successSnack(jsonDecode(response)["message"]);
            await Get.offAllNamed(RouteHelper.home);
          } else {
            removeData();
            storage
                .write(AppConstant.phone,
                    jsonDecode(response)["Data"]["mobile"] ?? "")
                .toString();
            storage.write(
                AppConstant.id, jsonDecode(response)["Data"]["id"] ?? "");
            number.text = storage.read(AppConstant.phone) ?? "";
            await Get.offAllNamed(RouteHelper.registration);
          }
        }
      } else {
        BaseController().errorSnack(jsonDecode(response)["message"]);
        return;
      }
    } catch (e) {
      print("error $e");
    }
  }

  registrationNetworkApi(bool isValue) async {
    var bodyRequest = {
      "lng": AppConstants.LANGUAGE,
      "state_id": '1',
      "zip_code": "",
      "city_id": "",
      "id_prove_type": idProveType.value.toString() ??
          "", // ignore: dead_null_aware_expression
      "id_prove_no":
          etAadhar.value.text.toString(), // ignore: dead_null_aware_expression
      "address":
          etAddress.text.toString(), // ignore: dead_null_aware_expression
      "map_address":
          mapAddress.text.toString(), // ignore: dead_null_aware_expression
      "name": etName.text.toString(), // ignore: dead_null_aware_expression
      "email": etEmail.text.toString(), // ignore: dead_null_aware_expression
      "mobile": storage.read(AppConstant.phone).toString().trim(),
      "id": storage.read(AppConstant.id).toString().trim(),
    };
    print("data body response =========>>>>>>>>");
    print(bodyRequest);
    Get.context!.loaderOverlay.show();
    var response = await BaseClient()
        .profileUpdate(
            AppConstants.PROFILE_UPDATE, bodyRequest, rxPath.value, true)
        .catchError(BaseController().handleError);

    print("==========>>>> status ${jsonDecode(response)["status"]}");
    print("data response =====>>>> $response");
    Get.context!.loaderOverlay.hide();
    if (jsonDecode(response)["status"] == 1) {
      BaseController().successSnack(jsonDecode(response)["message"]);
      storage.write(AppConstant.id, jsonDecode(response)["Data"]["id"] ?? "");
      storage.write(
          AppConstant.name, jsonDecode(response)["Data"]["name"] ?? "");
      storage.write(
          AppConstant.address, jsonDecode(response)["Data"]["address"] ?? "");
      storage.write(
          AppConstant.profile, jsonDecode(response)["Data"]["profile"] ?? "");
      storage.write(
          AppConstant.email, jsonDecode(response)["Data"]["email"] ?? "");
      storage.write(
          AppConstant.phone, jsonDecode(response)["Data"]["mobile"] ?? "");
      storage.write(AppConstant.idProvePhoto,
          jsonDecode(response)["Data"]["id_prove_photo"] ?? "");
      storage.write(AppConstant.aadhar,
          jsonDecode(response)["Data"]["id_prove_no"] ?? "");
      storage.write(AppConstant.idProveType,
          jsonDecode(response)["Data"]["id_prove_type"] ?? "");
      storage.write(
          AppConstant.latitude, jsonDecode(response)["Data"]["latitude"] ?? "");
      storage.write(AppConstant.longitude,
          jsonDecode(response)["Data"]["longitude"] ?? "");
      saveDataRegistration();
      isValue
          ? await Navigator.pushNamed(Get.context!, RouteHelper.shopDetails)
          : await Navigator.pushNamed(Get.context!, RouteHelper.home);
    }
    CustomAnimation().showCustomSnackBar(
        isValue ? jsonDecode(response)["message"] : "Registration Successfully",
        isError: false);
  }

  saveDataRegistration() async {
    number.text = storage.read(AppConstant.phone) ?? "";
    etName.text = storage.read(AppConstant.name) ?? "";
    etEmail.text = storage.read(AppConstant.email) ?? "";
    etAddress.text = storage.read(AppConstant.address) ?? "";
    String idType = storage.read(AppConstant.idProveType) ?? "";
    idProveType.value = int.parse(idType.toString());
    etAadhar.text = storage.read(AppConstant.aadhar);
  }

  saveDataShop() async {
    serviceCapacity.text =
        storage.read(AppConstant.byck_service_capicity) ?? "";
    description.text = storage.read(AppConstant.description) ?? "";
    shopName.text = storage.read(AppConstant.shopName) ?? "";
    storage.read(AppConstant.id_photo) ?? "";
    var time = storage.read(AppConstant.store_time) ?? "";
    startTime.text = time.substring(0, 7);
    endTime.text = time.substring(time.length - 7);
    serviceCapacity.text =
        storage.read(AppConstant.byck_service_capicity) ?? "";
    storage.read(AppConstant.normalCcByck.toString().trim()) == "Yes"
        ? (normalCc.value = 1)
        : (normalCc.value = 0);
    storage.read(AppConstant.heigh_pickup.toString().trim()) == "Yes"
        ? (highPickup.value = 1)
        : (highPickup.value = 0);
    roadService.value =
        int.parse(storage.read(AppConstant.is_on_road_service).trim());
    // storage.read(AppConstant.is_on_road_service.toString().trim()) == "Yes" ? (roadService.value = 1) : (roadService.value = 0);
    // normalCc.value =int.parse(storage.read(AppConstant.normalCcByck).toString().trim());
    // highPickup.value =int.parse(storage.read(AppConstant.heigh_pickup).toString().trim());
  }

  removeData() async {
    GetStorage().erase();
    storage.remove(AppConstant.phone);
    storage.remove(AppConstant.name);
    storage.remove(AppConstant.email);
    storage.remove(AppConstant.shopName);
    storage.remove(AppConstant.address);
    storage.remove(AppConstant.profile);
    storage.remove(AppConstant.idProveType);
    storage.remove(AppConstant.aadhar);
    storage.remove(AppConstant.store_time);
    storage.remove(AppConstant.description);
    storage.remove(AppConstant.byck_service_capicity);
    storage.remove(AppConstant.normalCcByck);
    storage.remove(AppConstant.heigh_pickup);
    storage.remove(AppConstant.is_on_road_service);
    storage.remove(AppConstant.shopPhoto);
    etMobile.clear();
    etName.clear();
    etEmail.clear();
    etAddress.clear();
    etAadhar.clear();
    shopName.clear();
    startTime.clear();
    endTime.clear();
    description.clear();
    serviceCapacity.clear();
  }

  logout() async {
    removeData();
    Get.delete<LoginController>();
    Get.offAllNamed(RouteHelper.initial);
  }

  updateShopProfile() async {
    var bodyRequest = {
      "lng": AppConstants.LANGUAGE,
      "id": storage.read(AppConstant.id).toString().trim(),
      "normal_cc_byck": normalCc.value.toString(),
      "heigh_pickup": highPickup.value.toString(),
      "is_on_road_service": roadService.value.toString(),
      "byck_service_capicity": serviceCapacity.text.toString(),
      "description": description.text.toString(),
      "shop_name": shopName.text.toString(),
      "store_time":
          "${startTime.text.toString()} to ${endTime.text.toString()}",
    };
    Get.context!.loaderOverlay.show();
    print("data body response =========>>>>>>>>");
    print(bodyRequest);
    var response = await BaseClient()
        .profileUpdate(AppConstants.SHOP_PROFILE_UPDATE, bodyRequest,
            shopPath.value, false)
        .catchError(BaseController().handleError);
    print("==========>>>> status ${jsonDecode(response)["status"]}");
    print("data response =====>>>> $response");
    Get.context!.loaderOverlay.hide();
    if (jsonDecode(response)["status"] == 1) {
      storage.write(AppConstant.id, jsonDecode(response)["Data"]["id"] ?? "");
      storage.write(AppConstant.normalCcByck,
          jsonDecode(response)["Data"]["normal_cc_byck"] ?? "");
      storage.write(AppConstant.heigh_pickup,
          jsonDecode(response)["Data"]["heigh_pickup"] ?? "");
      storage.write(AppConstant.is_on_road_service,
          jsonDecode(response)["Data"]["is_on_road_service"] ?? "");
      storage.write(AppConstant.byck_service_capicity,
          jsonDecode(response)["Data"]["byck_service_capicity"] ?? "");
      storage.write(AppConstant.description,
          jsonDecode(response)["Data"]["description"] ?? "");
      storage.write(AppConstant.shopName,
          jsonDecode(response)["Data"]["shop_name"] ?? "");
      storage.write(AppConstant.shopPhoto,
          jsonDecode(response)["Data"]["shop_photo"] ?? "");
      storage.write(AppConstant.idProvePhoto,
          jsonDecode(response)["Data"]["id_prove_photo"] ?? "");
      storage.write(AppConstant.store_time,
          jsonDecode(response)["Data"]["store_time"] ?? "");
      saveDataShop();
      CustomAnimation()
          .showCustomSnackBar(jsonDecode(response)["message"], isError: false);
      await Get.offAllNamed(RouteHelper.home);
    }
  }

  void startTimer() {
    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (seconds.value > 0.0) {
        seconds.value--;
      } else {
        if (minutes.value > 0.0) {
          minutes.value--;
          seconds.value = 30;
        } else {
          timer.cancel();
        }
      }
    });
  }

  void resetTimer() {
    timer?.cancel();
    minutes.value = 1;
    seconds.value = 0;
    startTimer();
    Future.delayed(const Duration(milliseconds: 500));
  }

  void setSelectedValue(int value) {
    idProveType.value = value;
  }

  Future chooseImage(bool isCamera) async {
    final ImagePicker picker = ImagePicker();
    try {
      final XFile? image = await picker.pickImage(
        source: isCamera ? ImageSource.camera : ImageSource.gallery,
        imageQuality: 60,
      );
      if (image != null) {
        rxPath.value = image.path.toString();
        loader();
        if (storage.read(AppConstant.shopName).isNullOrBlank &&
            storage.read(AppConstant.description).isNullOrBlank) {
          GetStorage().erase();
        }
        print("photo ${rxPath.value}");
      }
    } on Exception catch (e) {
      print("image response $e");
    }
  }

  chooseShopImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? image = await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 60,
    );
    if (image != null) {
      shopPath.value = image.path.toString();
      loader();
      print("shop photo ${shopPath.value}");
    }
  }

  void chooseTime(bool timeValue) async {
    var currentTime;
    var selectedTime = await showTimePicker(
      context: Get.context!,
      initialTime: TimeOfDay.now(),
    );

    if (selectedTime != null) {
      currentTime = selectedTime.format(Get.context!);
      loader();
      print(currentTime);
    }
    if (currentTime != null) {
      timeValue ? (endTime.text = currentTime) : (startTime.text = currentTime);
      CustomAnimation()
          .showCustomToast("Set time $currentTime", isError: false);
    } else {
      Fluttertoast.showToast(msg: "Please select time ! ");
      CustomAnimation().showCustomToast("Please select time ! ", isError: true);
    }
  }

  Future<bool> onWillPop() {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null ||
        now.difference(currentBackPressTime!) > const Duration(seconds: 2)) {
      urlValue.value = "";
      currentBackPressTime = now;
      CustomAnimation().showCustomToast('Press again to exit GoMechanic', isError: false);
      // ScaffoldMessenger.of(Get.context!).showSnackBar(snackBar);
      return Future.value(false);
    }
    return Future.value(true);
  }

  Future<Position> getLocation() async {
    bool serviceEnabled;
    LocationPermission permission;
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
      return Future.error('Location services are disabled.');
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }
    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
  }

  Future<void> GetAddressFromLatLong() async {
    Position position = await getLocation();
    List<Placemark> placemarks =
        await placemarkFromCoordinates(position.latitude, position.longitude);
    longitude.value = position.longitude;
    latitude.value = position.latitude;
    Placemark place = placemarks[0];
    current_address.value =
        "${place.street}, ${place.subLocality}, ${place.locality.toString()}, ${place.country}";
  }

  Future<bool> currentAddressNetworkApi() async {
    var bodyRequest = {
      "user_id": storage.read(AppConstant.id),
      "latitude": latitude.value.toString(),
      "longitude": longitude.value.toString(),
      "address": current_address.value.toString(),
    };
    print("fghfhf $bodyRequest");
    Get.context!.loaderOverlay.show();
    var response = await BaseClient()
        .post(AppConstants.UPDATE_CURRENT_ADDRESS, bodyRequest)
        .catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print(response);
    print("kdjkjhiygfvh $response");
    if (jsonDecode(response)["status"] == 1) {
      storage.write(
          AppConstant.latitude, jsonDecode(response)["Data"]["latitude"] ?? "");
      storage.write(AppConstant.longitude,
          jsonDecode(response)["Data"]["longitude"] ?? "");
      saveDataRegistration();
    }
    return false;
  }
}
