// ignore_for_file: avoid_print, deprecated_member_use, file_names

import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gomechanic/utils/style.dart';
import 'package:image_picker/image_picker.dart';

class DileveryImages extends StatefulWidget {
  const DileveryImages({Key? key}) : super(key: key);

  @override
  State<DileveryImages> createState() => _DileveryImagesState();
}

class _DileveryImagesState extends State<DileveryImages> {
  final picker = ImagePicker();
  File? uploadPhoto;
  File? uploadPhoto5;
  File? uploadPhoto6;
  File? uploadPhoto7;
  Future uploadPhoto1(context, ImageSource source) async {
    final pickedFile = await picker.getImage(source: source);
    if (pickedFile != null) {
      setState(() {
        uploadPhoto = File(pickedFile.path);
        print(uploadPhoto!.path);
      });
    }
  }

  Future uploadPhoto2(context, ImageSource source) async {
    final pickedFile1 = await picker.getImage(source: source);
    if (pickedFile1 != null) {
      setState(() {
        uploadPhoto5 = File(pickedFile1.path);
        print(uploadPhoto5!.path);
      });
    }
  }

  Future uploadPhoto3(context, ImageSource source) async {
    final pickedFile2 = await picker.getImage(source: source);
    if (pickedFile2 != null) {
      setState(() {
        uploadPhoto6 = File(pickedFile2.path);
        print(uploadPhoto6!.path);
      });
    }
  }

  Future uploadPhoto4(context, ImageSource source) async {
    final pickedFile3 = await picker.getImage(source: source);
    if (pickedFile3 != null) {
      setState(() {
        uploadPhoto7 = File(pickedFile3.path);
        print(uploadPhoto7!.path);
      });
    }
  }

  File? selectedImage;
  RxString base64Image = "".obs;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
              children: <Widget>[
                SizedBox(height: 20.0.h),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Row(
                    children: [
                      InkWell(
                        onTap: () {
                          print('love');
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text("Please upload the image"),
                                actions: <Widget>[
                                  MaterialButton(
                                    child: const Text("Camera"),
                                    onPressed: () {
                                      uploadPhoto1(context, ImageSource.camera);
                                      Navigator.pop(context);
                                    },
                                  ),
                                  MaterialButton(
                                    child: const Text("Gallery"),
                                    onPressed: () {
                                      uploadPhoto1(
                                          context, ImageSource.gallery);
                                      Navigator.pop(context);
                                    },
                                  )
                                ],
                              );
                            },
                          );
                        },
                        child: Row(
                          children: [
                            Stack(
                              children: [
                                Card(
                                  elevation: 4,
                                  shadowColor: Colors.blue,
                                  child: Container(
                                    height: 120.h,
                                    width: 120.h,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.green.shade400,
                                          width: 2),
                                    ),
                                    child: uploadPhoto == null
                                        ? Center(
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Icon(
                                                  Icons.filter_1_rounded,
                                                  color: Colors.grey,
                                                  size: 30.sp,
                                                )
                                              ],
                                            ),
                                          )
                                        : Image.file(uploadPhoto!,
                                            fit: BoxFit.fitWidth),
                                  ),
                                ),
                                Positioned(
                                    right: 0.w,
                                    top: 0.h,
                                    child: IconButton(
                                      onPressed: () {
                                        setState(() {
                                          uploadPhoto = null;
                                        });
                                      },
                                      icon: Icon(
                                        Icons.highlight_remove,
                                        size: 25.sp,
                                      ),
                                    ))
                              ],
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 20.w,
                      ),
                      InkWell(
                        onTap: () {
                          print('love');
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text("Please upload the image"),
                                actions: <Widget>[
                                  MaterialButton(
                                    child: const Text("Camera"),
                                    onPressed: () {
                                      uploadPhoto2(context, ImageSource.camera);
                                      Navigator.pop(context);
                                    },
                                  ),
                                  MaterialButton(
                                    child: const Text("Gallery"),
                                    onPressed: () {
                                      uploadPhoto2(
                                          context, ImageSource.gallery);
                                      Navigator.pop(context);
                                    },
                                  )
                                ],
                              );
                            },
                          );
                        },
                        child: Row(
                          children: [
                            Stack(
                              children: [
                                Card(
                                  elevation: 4,
                                  shadowColor: Colors.blue,
                                  child: Container(
                                    height: 120.h,
                                    width: 120.h,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.green.shade400,
                                          width: 2),
                                    ),
                                    child: uploadPhoto5 == null
                                        ? Center(
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Icon(
                                                  Icons.filter_2_rounded,
                                                  color: Colors.grey,
                                                  size: 30.sp,
                                                )
                                              ],
                                            ),
                                          )
                                        : Image.file(uploadPhoto5!,
                                            fit: BoxFit.fitWidth),
                                  ),
                                ),
                                Positioned(
                                    right: 0.w,
                                    top: 0.h,
                                    child: IconButton(
                                      onPressed: () {
                                        setState(() {
                                          uploadPhoto5 = null;
                                        });
                                      },
                                      icon: Icon(
                                        Icons.highlight_remove,
                                        size: 25.sp,
                                      ),
                                    ))
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 20.h,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 20.0),
                  child: Row(
                    children: [
                      InkWell(
                        onTap: () {
                          print('love');
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text("Please upload the image"),
                                actions: <Widget>[
                                  MaterialButton(
                                    child: const Text("Camera"),
                                    onPressed: () {
                                      uploadPhoto4(context, ImageSource.camera);
                                      Navigator.pop(context);
                                    },
                                  ),
                                  MaterialButton(
                                    child: const Text("Gallery"),
                                    onPressed: () {
                                      uploadPhoto4(context, ImageSource.gallery);
                                      Navigator.pop(context);
                                    },
                                  )
                                ],
                              );
                            },
                          );
                        },
                        child: Row(
                          children: [
                            Stack(
                              children: [
                                Card(
                                  elevation: 4,
                                  shadowColor: Colors.blue,
                                  child: Container(
                                    height: 120.h,
                                    width: 120.h,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.green.shade400, width: 2),
                                    ),
                                    child: uploadPhoto7 == null
                                        ? Center(
                                            child: Column(
                                              mainAxisAlignment:
                                                  MainAxisAlignment.center,
                                              children: [
                                                Icon(
                                                  Icons.filter_4_rounded,
                                                  color: Colors.grey,
                                                  size: 30.sp,
                                                )
                                              ],
                                            ),
                                          )
                                        : Image.file(uploadPhoto7!,
                                            fit: BoxFit.fitWidth),
                                  ),
                                ),
                                Positioned(
                                    right: 0.w,
                                    top: 0.h,
                                    child: IconButton(
                                      onPressed: () {
                                        setState(() {
                                          uploadPhoto7 = null;
                                        });
                                      },
                                      icon: Icon(
                                        Icons.highlight_remove,
                                        size: 25.sp,
                                      ),
                                    ))
                              ],
                            ),
                          ],
                        ),
                      ),
                      SizedBox(
                        width: 20.w,
                      ),
                      InkWell(
                        onTap: () {
                          print('love');
                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return AlertDialog(
                                title: const Text("Please upload the image"),
                                actions: <Widget>[
                                  MaterialButton(
                                    child: const Text("Camera"),
                                    onPressed: () {
                                      uploadPhoto3(context, ImageSource.camera);
                                      Navigator.pop(context);
                                    },
                                  ),
                                  MaterialButton(
                                    child: const Text("Gallery"),
                                    onPressed: () {
                                      uploadPhoto3(
                                          context, ImageSource.gallery);
                                      Navigator.pop(context);
                                    },
                                  )
                                ],
                              );
                            },
                          );
                        },
                        child: Row(
                          children: [
                            Stack(
                              children: [
                                Card(
                                  elevation: 4,
                                  shadowColor: Colors.blue,
                                  child: Container(
                                    height: 120.h,
                                    width: 120.h,
                                    decoration: BoxDecoration(
                                      border: Border.all(
                                          color: Colors.green.shade400,
                                          width: 2),
                                    ),
                                    child: uploadPhoto6 == null
                                        ? Center(
                                      child: Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.center,
                                        children: [
                                          Icon(
                                            Icons.filter_3_rounded,
                                            color: Colors.grey,
                                            size: 30.sp,
                                          )
                                        ],
                                      ),
                                    )
                                        : Image.file(uploadPhoto6!,
                                        fit: BoxFit.fitWidth),
                                  ),
                                ),
                                Positioned(
                                    right: 0.w,
                                    top: 0.h,
                                    child: IconButton(
                                      onPressed: () {
                                        setState(() {
                                          uploadPhoto6 = null;
                                        });
                                      },
                                      icon: Icon(
                                        Icons.highlight_remove,
                                        size: 25.sp,
                                      ),
                                    ))
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 50.h,
                ),
                Center(
                  child: Container(
                    height: 40.h,
                    width: 200.w,
                    decoration: BoxDecoration(
                      color: Colors.greenAccent,
                      borderRadius: BorderRadius.circular(30.r),
                      /*border: Border.all()*/),
                    child: Center(
                        child: Text(
                          "UPLOAD",
                          style: robotoMedium.copyWith(fontSize: 18.sp, color: Colors.black87),
                        )),
                  ),
                ),
                SizedBox(height: 20.0.h),
              ],
            );
  }
}
