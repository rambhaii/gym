// ignore_for_file: deprecated_member_use, file_names, avoid_print

import 'package:easy_stepper/easy_stepper.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gomechanic/AppConstent/AppConstant.dart';
import 'package:gomechanic/Dashbord/Conditions.dart';
import 'package:gomechanic/Widget/Color.dart';
import 'package:gomechanic/Widget/drawer_home.dart';
import 'package:gomechanic/Widget/map_screen.dart';
import 'package:gomechanic/controller/details_controller.dart';
import 'package:gomechanic/controller/login_controller.dart';
import 'package:gomechanic/helper/custom_dialog.dart';
import 'package:gomechanic/helper/route_page.dart';
import 'package:gomechanic/utils/all_image.dart';
import 'package:gomechanic/utils/dimensions.dart';
import 'package:gomechanic/utils/style.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final RxBool isLightTheme = false.obs;
  final LoginController controller = Get.find();
  final DetailsController detailsController = Get.find();
  RxInt activeStep = 0.obs;

  @override
  void initState() {
    detailsController.getBookNetworkApi(true);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _initializeMap();
    });
    super.initState();
  }

  Future<void> _initializeMap() async {
    // Ensure the plugin is initialized
    GoogleMapController.init;
    // Perform any other map initialization tasks
    // ...
  }

  @override
  Widget build(BuildContext context) {
    controller.shopImage.value = controller.storage.read(AppConstant.shopPhoto);
    controller.images.value = controller.storage.read(AppConstant.profile);
    detailsController.saveDataRegistration();
    return WillPopScope(
      onWillPop: controller.onWillPop,
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          backgroundColor: TColor.themecolor,
          title: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                "Go Mechanic",
                style:
                    bodyText1Style.copyWith(fontSize: 19.sp, color: Colors.white),
              ),
              Obx(()=> Text(controller.current_address.value.toString(),style: smallTextStyle.copyWith(fontSize: 10.sp,color: Colors.white
              ),))
            ],
          ),
          actions: [
            ObxValue(
              (data) => Switch(
                activeTrackColor: Colors.white,
                activeColor: Colors.greenAccent,
                value: isLightTheme.value,
                onChanged: (val) {
                  controller.GetAddressFromLatLong();
                  controller.currentAddressNetworkApi();
                  // isLightTheme.value = val;
                  // Get.changeThemeMode(
                  //   isLightTheme.value ? ThemeMode.dark : ThemeMode.system,
                  // );
                },
              ),
              false.obs,
            ),
          ],
          bottom: PreferredSize(
            preferredSize: const Size.fromHeight(35.0),
            child: Container(
              width: Get.width,
              height: 30.0.h,
              alignment: Alignment.center,
              color: TColor.Theme_Color,
              padding: const EdgeInsets.all(5.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  InkWell(
                      onTap: () {},
                      child: Icon(
                        Icons.account_circle_outlined,
                        color: Colors.white,
                        size: 22.sp,
                      )),
                  SizedBox(width: 5.0.w),
                  Text(
                    "${controller.storage.read(AppConstant.phone)}",
                    style: bodyText1Style.copyWith(
                        color: Colors.white, fontSize: 18.sp),
                  ),
                  const Spacer(),
                  InkWell(
                    onTap: () {},
                    child: Icon(
                      Icons.house_outlined,
                      size: 22.sp,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(width: 5.0.w),
                  Text(
                    "9696",
                    style: bodyText1Style.copyWith(
                        color: Colors.white, fontSize: 18.sp),
                  )
                ],
              ),
            ),
          ),
        ),
        body: SingleChildScrollView(
            controller: detailsController.scrollController,
            child: Obx(
              () => Column(
                children: [
                  Obx(
                    () => ListView.builder(
                      itemCount:
                          detailsController.serviceModel.value.data?.length ??
                              0,
                      physics: const NeverScrollableScrollPhysics(),
                      shrinkWrap: true,
                      itemBuilder: (context, index) {
                        if (detailsController.serviceModel.value.data != null &&
                            index <
                                detailsController
                                    .serviceModel.value.data!.length) {
                          return Container(
                            margin: const EdgeInsets.only(bottom: 10.0),
                            padding:
                                const EdgeInsets.symmetric(horizontal: 10.0),
                            width: double.infinity,
                            decoration: BoxDecoration(
                                // color: Colors.blue,
                                boxShadow: [
                                  BoxShadow(
                                    color: Theme.of(context)
                                        .disabledColor
                                        .withAlpha(100),
                                    offset: const Offset(
                                      1.0,
                                      1.0,
                                    ),
                                    blurRadius: 3.0,
                                    spreadRadius: 1.0,
                                  ),
                                  const BoxShadow(
                                    color: Colors.white,
                                    offset: Offset(0.0, 0.0),
                                    blurRadius: 0.0,
                                    spreadRadius: 0.0,
                                  )
                                ],
                                borderRadius: BorderRadius.circular(5.0)),
                            child: Column(
                              children: [
                                SizedBox(height: 5.0.h),
                                SizedBox(
                                  height: 30.0.h,
                                  width: Get.width,
                                  child: Row(
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Column(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          Row(
                                            children: [
                                              Text(
                                                "Order No       : ",
                                                style: robotoRegular.copyWith(
                                                    fontSize: Dimensions
                                                        .fontSizeDefault2),
                                              ),
                                              // SizedBox(width: 5.0.w),
                                              Text(
                                                detailsController
                                                        .serviceModel
                                                        .value
                                                        .data?[index]
                                                        .bookingNo ??
                                                    'N/A',
                                                style: robotoRegular.copyWith(
                                                    fontSize: Dimensions
                                                        .fontSizeDefault,
                                                    color: TColor.black
                                                        .withAlpha(150)),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                      const Spacer(),
                                      InkWell(
                                        onTap: () {
                                          /*showModalBottomSheet(
                                              isScrollControlled: true,
                                              context: context,
                                              builder: (context) {
                                                return const FractionallySizedBox(
                                                    heightFactor: 0.85,
                                                    child: MapViewWidget());
                                              },
                                            );*/
                                          Navigator.push(context, MaterialPageRoute(builder: (context)=> const MapScreen()));
                                        },
                                        child: Container(
                                          height: 30.0.h,
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 15.0.w),
                                          decoration: BoxDecoration(
                                              color: TColor.themecolor
                                                  .withAlpha(200),
                                              borderRadius:
                                                  BorderRadius.circular(5.r)),
                                          child: Center(
                                              child: Text(
                                            "Map View",
                                            style: robotoRegular.copyWith(
                                                color: TColor.white),
                                          )),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  height: 160.0.h,
                                  width: Get.width,
                                  decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            'Owner            : ',
                                            style: robotoRegular.copyWith(
                                                fontSize: Dimensions
                                                    .fontSizeDefault2),
                                          ),
                                          SizedBox(width: 5.0.w),
                                          Expanded(
                                              child: Text(
                                            detailsController.serviceModel.value
                                                    .data?[index].ownerName ??
                                                'N/A',
                                            style: robotoRegular.copyWith(
                                                fontSize:
                                                    Dimensions.fontSizeDefault,
                                                color: TColor.black
                                                    .withAlpha(150)),
                                            maxLines: 3,
                                          )),
                                        ],
                                      ),
                                      SizedBox(height: 2.0.h),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            'Brand             : ',
                                            style: robotoRegular.copyWith(
                                                fontSize: Dimensions
                                                    .fontSizeDefault2),
                                          ),
                                          SizedBox(width: 5.0.w),
                                          Expanded(
                                              child: Text(
                                            detailsController.serviceModel.value
                                                    .data?[index].brandName ??
                                                'N/A',
                                            style: robotoRegular.copyWith(
                                                fontSize:
                                                    Dimensions.fontSizeDefault,
                                                color: TColor.black
                                                    .withAlpha(150)),
                                            maxLines: 3,
                                          )),
                                        ],
                                      ),
                                      SizedBox(height: 2.0.h),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            'Service Date : ',
                                            style: robotoRegular.copyWith(
                                                fontSize: Dimensions
                                                    .fontSizeDefault2),
                                          ),
                                          SizedBox(width: 5.0.w),
                                          Expanded(
                                              child: Text(
                                            detailsController.serviceModel.value
                                                    .data?[index].serviceDate ??
                                                'N/A',
                                            style: robotoRegular.copyWith(
                                                fontSize:
                                                    Dimensions.fontSizeDefault,
                                                color: TColor.black
                                                    .withAlpha(150)),
                                            maxLines: 3,
                                          )),
                                        ],
                                      ),
                                      SizedBox(height: 2.0.h),
                                      Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.start,
                                        crossAxisAlignment:
                                            CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            'Slot                 :',
                                            style: robotoRegular.copyWith(
                                                fontSize: Dimensions
                                                    .fontSizeDefault2),
                                          ),
                                          SizedBox(width: 5.0.w),
                                          Expanded(
                                              child: Text(
                                            detailsController.serviceModel.value
                                                    .data?[index].slotId ??
                                                'N/A',
                                            style: robotoRegular.copyWith(
                                                fontSize:
                                                    Dimensions.fontSizeDefault,
                                                color: TColor.black
                                                    .withAlpha(150)),
                                            maxLines: 3,
                                          )),
                                        ],
                                      ),
                                      SizedBox(height: 2.0.h),
                                      Container(
                                          height: 30.0.h,
                                          width: double.infinity,
                                          alignment: Alignment.centerLeft,
                                          child: EasyStepper(
                                            activeStep: activeStep.value,
                                            lineLength: 90,
                                            lineSpace: 0,
                                            alignment: Alignment.center,
                                            lineType: LineType.normal,
                                            defaultLineColor:
                                                Colors.blue.shade200,
                                            finishedLineColor: Colors.green,
                                            activeStepTextColor: TColor.black,
                                            finishedStepTextColor: TColor.black,
                                            internalPadding: 1,
                                            showLoadingAnimation: false,
                                            stepRadius: 8,
                                            showStepBorder: false,
                                            lineDotRadius: 1.5,
                                            steps: [
                                              EasyStep(
                                                customStep: CircleAvatar(
                                                  radius: 8,
                                                  backgroundColor:
                                                      Colors.blue.shade200,
                                                  child: CircleAvatar(
                                                    radius: 8,
                                                    backgroundColor:
                                                        activeStep.value >= 0
                                                            ? Colors.green
                                                            : Colors
                                                                .blue.shade200,
                                                  ),
                                                ),
                                                title: 'Waiting',
                                              ),
                                              EasyStep(
                                                  customStep: CircleAvatar(
                                                    radius: 8,
                                                    backgroundColor:
                                                        Colors.blue.shade200,
                                                    child: CircleAvatar(
                                                      radius: 8,
                                                      backgroundColor:
                                                          activeStep.value >= 1
                                                              ? Colors.green
                                                              : Colors.blue
                                                                  .shade200,
                                                    ),
                                                  ),
                                                  title: 'Order Pack',
                                                  topTitle: false),
                                              EasyStep(
                                                customStep: CircleAvatar(
                                                  radius: 8,
                                                  backgroundColor:
                                                      Colors.blue.shade200,
                                                  child: CircleAvatar(
                                                    radius: 8,
                                                    backgroundColor:
                                                        activeStep.value >= 2
                                                            ? Colors.green
                                                            : Colors
                                                                .blue.shade200,
                                                  ),
                                                ),
                                                title: 'Order Received',
                                                topTitle: false,
                                              ),
                                              EasyStep(
                                                customStep: CircleAvatar(
                                                  radius: 8,
                                                  backgroundColor:
                                                      Colors.blue.shade200,
                                                  child: CircleAvatar(
                                                    radius: 8,
                                                    backgroundColor:
                                                        activeStep.value >= 3
                                                            ? Colors.green
                                                            : Colors
                                                                .blue.shade200,
                                                  ),
                                                ),
                                                title: 'Delivered',
                                                topTitle: false,
                                              ),
                                            ],
                                            onStepReached: (index) {
                                              activeStep.value = index;
                                            },
                                          )),
                                      InkWell(
                                        onTap: () {},
                                        child: Padding(
                                          padding: EdgeInsets.only(
                                            top: 20.h,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: [
                                              Row(
                                                children: [
                                                  Image(
                                                    image: const AssetImage(
                                                        "assets/images/send.png"),
                                                    height: 20.h,
                                                    color: Colors.blue,
                                                  ),
                                                  SizedBox(width: 5.0.h),
                                                  InkWell(
                                                    onTap: () => Navigator.push(context, MaterialPageRoute(builder: (context)=> Conditions())),
                                                    child: Text(
                                                      " Navigate",
                                                      style:
                                                          robotoMedium.copyWith(
                                                              color: TColor
                                                                  .themecolor
                                                                  .withAlpha(
                                                                      200)),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(width: 13.w),
                                              Row(
                                                children: [
                                                  Image(
                                                    image: const AssetImage(
                                                        "assets/images/info.png"),
                                                    height: 20.h,
                                                    color: Colors.greenAccent,
                                                  ),
                                                  SizedBox(width: 5.0.h),
                                                  InkWell(
                                                    onTap: () => Navigator.pushNamed(context,
                                                        "/shopDetails"),
                                                    child: Text(
                                                      "Info",
                                                      style:
                                                          robotoMedium.copyWith(
                                                              color: TColor
                                                                  .themecolor
                                                                  .withAlpha(
                                                                      200)),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(width: 13.w),
                                              Row(
                                                children: [
                                                  Image(
                                                    image: const AssetImage(
                                                        "assets/images/reject1.png"),
                                                    height: 20.h,
                                                    color: Colors.red,
                                                  ),
                                                  SizedBox(width: 5.0.h),
                                                  Text(
                                                    " Reject",
                                                    style:
                                                        robotoMedium.copyWith(
                                                            color: TColor
                                                                .themecolor
                                                                .withAlpha(
                                                                    200)),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(width: 13.w),
                                              Row(
                                                children: [
                                                  Image(
                                                    image: const AssetImage(
                                                        "assets/images/call.png"),
                                                    height: 20.h,
                                                    color: Colors.greenAccent,
                                                  ),
                                                  SizedBox(width: 5.0.h),
                                                  InkWell(
                                                    onTap: showAnimation,
                                                    child: Text(
                                                      " Call",
                                                      style:
                                                          robotoMedium.copyWith(
                                                              color: TColor
                                                                  .themecolor
                                                                  .withAlpha(
                                                                      200)),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              SizedBox(width: 13.w)
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                SizedBox(height: 5.0.h),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    InkWell(
                                      onTap: () {
                                        showModalBottomSheet(
                                            context: context,
                                            shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.only(
                                                    topRight:
                                                        Radius.circular(20.0.r),
                                                    topLeft:
                                                        Radius.circular(20.r))),
                                            builder: (BuildContext context) {
                                              return showsheet();
                                            });
                                      },
                                      child: Container(
                                        height: 30.0.h,
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 20.0.w),
                                        alignment: Alignment.center,
                                        decoration: BoxDecoration(
                                          color:
                                              TColor.themecolor.withAlpha(200),
                                          borderRadius:
                                              BorderRadius.circular(5.0.r),
                                        ),
                                        child: Text("Check List",
                                            style: robotoRegular.copyWith(
                                                color: TColor.white)),
                                      ),
                                    ),
                                    InkWell(
                                      onTap: () {
                                        detailsController.detailsIndex.value =
                                            index;
                                        print(detailsController
                                            .detailsIndex.value);
                                        detailsController
                                            .getBookNetworkApi(false);
                                        Navigator.pushNamed(context,
                                            RouteHelper.serviceDetails);
                                      },
                                      child: Container(
                                        height: 30.0.h,
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 20.0.w),
                                        decoration: BoxDecoration(
                                          color:
                                              TColor.themecolor.withAlpha(200),
                                          borderRadius:
                                              BorderRadius.circular(5.0.r),
                                        ),
                                        child: Center(
                                          child: Text("View Details",
                                              style: robotoRegular.copyWith(
                                                  color: TColor.white)),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 10.0.h),
                              ],
                            ),
                          );
                        } else {
                          return Container();
                        }
                      },
                    ),
                  ),
                  detailsController.isLoadingPage.value
                      ? Center(
                          child: CircularProgressIndicator(color: TColor.grey),
                        )
                      : const Center()
                ],
              ),
            )),
        drawer: const DrawerScreen(),
      ),
    );
  }

  void showAnimation() {
    return showAnimatedDialog(
        Get.context!,
        Center(
          child: Container(
            width: 300.w,
            height: 300.h,
            padding: const EdgeInsets.all(Dimensions.PADDING_SIZE_EXTRA_LARGE),
            decoration: BoxDecoration(
                color: Theme.of(Get.context!).cardColor,
                borderRadius:
                    BorderRadius.circular(Dimensions.RADIUS_EXTRA_LARGE)),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              Image.asset(Images.checked, width: 100, height: 100),
              const SizedBox(height: Dimensions.PADDING_SIZE_LARGE),
              const Spacer(),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  Container(
                    height: 30.0.h,
                    width: 90.0.w,
                    decoration: BoxDecoration(
                      color: Colors.green,
                      borderRadius: BorderRadius.circular(5.0.r),
                    ),
                    child: ElevatedButton(
                      style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent, elevation: 0.0),
                      onPressed: () => Get.back(),
                      child: Text('Accept'.tr,
                          style: robotoBold.copyWith(
                            fontSize: Dimensions.fontSizeDefault,
                            color: TColor.white,
                            decoration: TextDecoration.none,
                          )),
                    ),
                  ),
                  Container(
                    height: 30.0.h,
                    width: 90.0.w,
                    decoration: BoxDecoration(
                      color: Colors.red,
                      borderRadius: BorderRadius.circular(5.0.r),
                    ),
                    child: ElevatedButton(
                      onPressed: () => Get.back(),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        elevation: 0.0,
                      ),
                      child: Text('Reject'.tr,
                          style: robotoBold.copyWith(
                            fontSize: Dimensions.fontSizeDefault,
                            color: TColor.white,
                            decoration: TextDecoration.none,
                          )),
                    ),
                  ),
                ],
              ),
            ]),
          ),
        ),
        dismissible: true);
  }

  Widget showsheet() {
    RxList checklist = [
      {'title': 'INSURANCE', 'isChecked': false},
      {'title': 'POLLUTION', 'isChecked': false},
      {'title': 'RC', 'isChecked': false},
      {'title': 'OWNER ID', 'isChecked': false},
      {'title': 'LICENCE', 'isChecked': false},
    ].obs;
    return SingleChildScrollView(
      child: Container(
        height: 350.0.h,
        padding: const EdgeInsets.symmetric(
            horizontal: Dimensions.PADDING_SIZE_DEFAULT),
        decoration: BoxDecoration(
            color: Theme.of(Get.context!).cardColor,
            borderRadius: BorderRadius.circular(Dimensions.RADIUS_EXTRA_LARGE)),
        child: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(height: 5.0.h),
              Center(
                child: Container(
                  height: 3.0.h,
                  width: 60.0.w,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.r),
                    color: TColor.grey,
                  ),
                ),
              ),
              SizedBox(height: 15.0.h),
              Container(
                alignment: Alignment.center,
                child: Text(
                  'Check List',
                  style: robotoBold.copyWith(
                    fontSize: Dimensions.fontSizeExtraLarge,
                    color: TColor.Text,
                    decoration: TextDecoration.none,
                  ),
                ),
              ),
              SizedBox(height: 15.0.h),
              ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: checklist.length,
                  itemBuilder: (context, index) {
                    return Row(
                      children: [
                        Checkbox(
                          value: checklist[index]['isChecked'] ??
                              checklist[index]['isChecked']!,
                          onChanged: (bool? newValue) {
                            checklist[index]['isChecked'] = newValue!;
                            print(checklist[index]['isChecked']);
                            return;
                          },
                        ),
                        Obx(
                          () => Text(
                            checklist[index]['title'],
                            style: robotoMedium.copyWith(
                                fontSize: Dimensions.fontSizeDefault2,
                                color: TColor.black),
                          ),
                        )
                      ],
                    );
                  }),
              SizedBox(
                height: 15.0.h,
              ),
              Align(
                alignment: Alignment.centerRight,
                child: InkWell(
                  onTap: () {
                    Get.back();
                  },
                  child: Container(
                    height: 35.0.h,
                    width: 80.0.w,
                    decoration: BoxDecoration(
                      color: Colors.greenAccent,
                      border: Border.all(),
                      borderRadius: BorderRadius.circular(20.r),
                    ),
                    child: Center(
                      child: Text(
                        "Submit",
                        style: robotoRegular.copyWith(
                            fontSize: Dimensions.fontSizeSmall),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
