import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:parnamtv/Ui/Subscription.dart';

import 'Constant.dart';
class SubscriptionDailog extends StatefulWidget {
  const SubscriptionDailog({Key? key}) : super(key: key);

  @override
  _SubscriptionDailogState createState() => _SubscriptionDailogState();
}

class _SubscriptionDailogState extends State<SubscriptionDailog> {
  @override
  Widget build(BuildContext context) {
    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(Constants.padding),
      ),
      elevation: 0,
      backgroundColor: Colors.transparent,
      child: contentBox(context),
    );
  }
  contentBox(context){
    return Stack(
      children: <Widget>[
        Container(
          padding: EdgeInsets.only(left: Constants.padding,top: Constants.avatarRadius
              + Constants.padding, right: Constants.padding,bottom: Constants.padding
          ),
          margin: EdgeInsets.only(top: Constants.avatarRadius),
          decoration: BoxDecoration(
              shape: BoxShape.rectangle,
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(color:Color(0xFFff9000),offset: Offset(0,10),
                    blurRadius: 10
                ),
              ]
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(" Get Subscription ",style: TextStyle(fontSize: 22,fontWeight: FontWeight.w600),),
              SizedBox(height: 15,),
              Text("Please purchased our plan,now more information to press ok button ",style: TextStyle(fontSize: 14),textAlign: TextAlign.center,),
              SizedBox(height: 22,),
              Align(
                alignment: Alignment.center,
                child: FlatButton(
                    onPressed: (){
                      Navigator.of(context).pop();
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context)=>Subscription())
                      );

                    },
                    child: Text("GET",style: TextStyle(fontSize: 18),),
                  color: Colors.amber,

                ),

              ),
            ],
          ),
        ),
        Positioned(
          left: Constants.padding,
          right: Constants.padding,
          child: CircleAvatar(
            backgroundColor: Colors.white,
            radius: 40,
            child: ClipRRect(
                borderRadius: BorderRadius.all(Radius.circular(50)),
                child: Image.asset("assets/Images/mono.gif")
            ),
          ),
        ),
      ],
    );
  }

}
