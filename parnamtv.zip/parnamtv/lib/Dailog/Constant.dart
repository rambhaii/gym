class Constants{
  Constants._();
  static const double padding =20;
  static const double avatarRadius=45;
}