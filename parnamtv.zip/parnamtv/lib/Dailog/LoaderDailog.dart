import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
class LoaderDaiolg extends StatefulWidget {
 final bool isShowing;
  const LoaderDaiolg({Key? key,required this.isShowing}) : super(key: key);

  @override
  _LoaderDaiolgState createState() => _LoaderDaiolgState();
}

class _LoaderDaiolgState extends State<LoaderDaiolg> {
    @override
  void initState() {
      dailog();
    // TODO: implement initState
    super.initState();
  }
  Future<void> dailog() async{
        if(widget.isShowing)
          {

          }
        else
          {
            Navigator.of(context).pop();
          }
  }
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.transparent,
       content: Container(
         decoration: BoxDecoration(
           shape: BoxShape.circle,
           color: Colors.black54,


         ),
         height: 80,
         width: 80,
         child: Lottie.asset('assets/LottieAnimation/loader.json' ,height: 50,width: 50),
       ),
    );

  }
}
