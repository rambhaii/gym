class TimerHandler{
  static const twentyMillis = Duration(minutes:2);
}