

import 'dart:convert';

import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Widget/CircularLoader.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
class PaymentGatway extends StatefulWidget {
final String amount;
final String SubscriptionId;
  const PaymentGatway({Key?key,required this.amount,  required this.SubscriptionId,}) : super(key: key);

  @override
  _PaymentGatwayState createState() => _PaymentGatwayState();
}
String name="";
String imageUrl="";
String userId="";
getDatafrompref() {
  name= ParnamTv.sharedPreference.getString(ParnamTv.userName)??'';
  imageUrl= ParnamTv.sharedPreference.getString(ParnamTv.profile_img)??'';
  userId= ParnamTv.sharedPreference.getString(ParnamTv.userID)??'';
}
class _PaymentGatwayState extends State<PaymentGatway> {
 late  Razorpay _razorpay;
 bool isReady=false;


 //  var toatalamount=double.parse("${widget.amountt}");

  @override
  void initState() {


    // TODO: implement initState
      super.initState();
      getDatafrompref();
      Intilize();
       openCheckout();
      _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
      _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
      _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);

  }
  Future Intilize() async {
    setState(() {
      _razorpay = Razorpay();
      isReady=true;
    });
  }
  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    Fluttertoast.showToast(
        msg: "SUCCESS: " + response.paymentId!, toastLength: Toast.LENGTH_SHORT);
    updatePaymentStatus(response.paymentId!);
   // Navigator.pop(context);
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    Fluttertoast.showToast(
        msg: "ERROR: " + response.code.toString() + " - " + response.message!,
        toastLength: Toast.LENGTH_SHORT);
    Navigator.pop(context);
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
    Fluttertoast.showToast(
        msg: "EXTERNAL_WALLET: " + response.walletName!, toastLength: Toast.LENGTH_SHORT);
    Navigator.pop(context);
  }


  void openCheckout() async {
    var options = {
      'key': 'rzp_test_Ujd8385mQjXqFH',
      'amount':int.parse(widget.amount)*100 ,
      'name': 'Pranam Tv',
      'image':'https://pranamtv.com/pages/img/logo.png',
       'color':'#ff9000',
      'description': 'Pranam TV',
      'prefill': {'contact': '8888888888', 'email': 'test@razorpay.com'},
      'external': {
        'wallets': ['paytm']
      }
    };

    try {
      _razorpay.open(options);
    } catch (e) {
      debugPrint('Error: $e');
    }
  }
  @override
  Widget build(BuildContext context) {
    return  isReady==true?CircularLoader(): Container();
  }
  updatePaymentStatus(String transactionId) async
  {
    var url = Uri.parse('https://pranamtv.com/api/front/Users/UpdatePaymentStatus');
    var response = await http.post(url,
        body: {
          'userID': userId,
          'subscription_plan_master_id': widget.SubscriptionId,
          'transection_id':transactionId,
          'payment_status': '1',
          'amount': widget.amount
        },
        headers: {'x-api-key': 'api@pranamtv.com'}
    );
    print("resssssss,${response.body}");
    if (response.statusCode == 200) {
      var datass = jsonDecode(response.body);
      if (datass['Data']['status'] == 1) {
        ArtSweetAlert.show(
          context: context,
          barrierDismissible: false,
          artDialogArgs: ArtDialogArgs(
            confirmButtonColor: Colors.green,
            type: ArtSweetAlertType.success,
            title: "Success",
            text: datass['Data']['message'],
            confirmButtonText: ' OK ',
          ),

        );
        Navigator.pop(context);
      }
      else {
        ArtSweetAlert.show(
          context: context,
          barrierDismissible: false,
          artDialogArgs: ArtDialogArgs(
            confirmButtonColor: Colors.amberAccent,
            type: ArtSweetAlertType.warning,
            title: "Warning ! ",
            text: datass['Data']['message'],
            confirmButtonText: ' OK ',
          ),
        );
      }
    }
  }
}

