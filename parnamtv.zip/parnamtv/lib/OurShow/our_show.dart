import 'dart:convert';

import 'package:better_player/better_player.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:parnamtv/Data/ContextData.dart';
import 'package:parnamtv/Data/OurShowsData.dart';
import 'package:parnamtv/Modal/LibraryData.dart';
import 'package:http/http.dart' as http;
import 'package:parnamtv/Widget/CircularLoader.dart';
import 'package:parnamtv/Widget/DrawerMenuWidget.dart';
import 'package:parnamtv/Widget/HorizentalLine.dart';
import 'package:parnamtv/Widget/OurShowsWidget.dart';
class OurShow extends StatefulWidget {
  final VoidCallback openDrawer;
  final int?flag;
  const OurShow(
      {
        Key?key,
        required this.openDrawer, this.flag,
      }):super(key: key);
  @override
  _OurShowState createState() => _OurShowState();
}

class _OurShowState extends State<OurShow> {
 // late Future<Datum> futureData;


  late OurShowData ourShowData;
  bool isReady = false;
@override
void initState() {

  // getAllLibraryData;
  // TODO: implement initState
  print("bjkvsfnb"+widget.openDrawer.toString());
  getAllContest().whenComplete(() =>setState(() {}) );
  super.initState();
}

Future getAllContest()async{
  var url=Uri.parse("https://pranamtv.com/api/front/GetOurShows?limit=3&start=0");
  var response= await http.get(url,headers: {'x-api-key':'api@pranamtv.com'});
  if(response.statusCode==200)
  {

    setState(() {
      ourShowData=ourShowDataFromJson(response.body);
      isReady=true;
    });

  }
  else{
    isReady=false;
  }
}

  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;



    return Scaffold(
      //backgroundColor: Color(0xFF1e2125),
      appBar: AppBar(
        backgroundColor: Color(0xFF1e2125),
        title: Text("Our Shows"),
        leading: widget.flag==null? DrawerMenuWidget(onClicked: widget.openDrawer):

        InkWell(
            onTap: (){
              Get.back();
            },
            child: Icon(Icons.arrow_back)),
      ),
   body: SingleChildScrollView(
     child: Column(
       children: [
         Container(
           decoration: BoxDecoration(
             image: DecorationImage(
                 image:ExactAssetImage("assets/Images/secondSecton.jpg"),
                 fit: BoxFit.cover
             ),
           ),
          padding: EdgeInsets.all(20),
           child: AspectRatio(
             aspectRatio: 16 / 9,
             child: BetterPlayer.network(
               "https://pranamtv.com/pages/admin/uploads/ourShow/14f95d0edf6667ae76a6c317a5b4bbb9webm.mp4",
               betterPlayerConfiguration: BetterPlayerConfiguration(
                 aspectRatio: 16 / 9,
                 autoPlay: true,

               ),
             ),

           ),
         ),
         Container(
           margin: EdgeInsets.only(left: 5,top: 20,right: 5),
           child: Column(
             crossAxisAlignment: CrossAxisAlignment.start,
             children: [

               Row(
                 children: [
                   FaIcon(FontAwesomeIcons.film,color: Color(0xffda261e),),
                   Text(" OUR SHOW",style: TextStyle(color:Color(0xffda261e),
                       fontWeight: FontWeight.w500,fontSize: 20.0
                   ),
                   ),
                 ],
               ),
               SizedBox(
                 height: 5.0,
               ),
               HorizentaLine(
                 width: w*0.3,
               ),

             ],
           ),
         ),
    Container(
height: h,
    child: isReady==false?CircularLoader():
    GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 8, mainAxisSpacing: 8,
    childAspectRatio: 1/1.2,
    children:List.generate(ourShowData!.data!.length, (index) =>new OurShowsWidget(title:ourShowData.data[index].title, description:ourShowData.data[index].description,
    ImgUrl:ourShowData.data[index].poster,),
              ),
              ))

       ],
     ),
   ),
    );  }

}
// class Librarydata{
//   String id;
//   String titlel;
//   String category;
//   Librarydata(this.id, this.titlel, this.category);
//
//
// }
// class Datum{
//   Librarydata Data;
//   Datum(this.Data);
//
//   factory Datum.fromJson(dynamic json) {
//     return Datum(
//         Librarydata.fromJson(json['Data'])
//     );
//   }
//}

