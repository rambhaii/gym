import 'package:flutter/material.dart';

class RaisedGradientButton extends StatelessWidget {
  final Widget child;
  final Gradient gradient;
  final double ?width;
  final double height;
  final VoidCallback onClicked;

  const RaisedGradientButton({
    Key?key,
    required this.child,
    required this.gradient,
    this.width,
    this.height = 50.0,
    required this.onClicked,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: 40.0,
      decoration: BoxDecoration(gradient: gradient, boxShadow: [
        BoxShadow(
          color: Colors.grey,
          offset: Offset(0.0, 1.5),
          blurRadius: 1.5,
        ),

      ],
       borderRadius: BorderRadius.circular(2.0),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
            onTap: onClicked,
            child: Center(
              child: child,
            )),
      ),
    );
  }
}