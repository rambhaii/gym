import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:parnamtv/User/WinYourDream.dart';
class FreeSubscriber extends StatelessWidget {
  final String Url;
  final String yourSub;
  final String heading;
  final String description;
  final String registrationtime;
  final VoidCallback onClick;
  const FreeSubscriber({Key? key,required this.Url,required this.yourSub,required this.heading,required this.description,required this.registrationtime,required this.onClick}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Container(
      margin: EdgeInsets.all(10),
     
      child: Card(
        color: Color(0xfff5f5f5),
        elevation: 8,
        child: Container(
          padding: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
                  Container(
                    width: w,
                    height:h*0.15,
                    child: Image.asset(Url,fit: BoxFit.fill),
                  ),
              SizedBox(
                height: 10,
              ),
              Text(yourSub, style: TextStyle(color: Colors.grey,fontWeight: FontWeight.w500,
                fontSize: 18,
              ),),
              SizedBox(
                height: 10,
              ),
              Text(heading, style: TextStyle(color: Color(0xff670505),fontWeight: FontWeight.w600,
                fontSize: 23,
              ),),
              SizedBox(
                height: 10,
              ),
              Text(description, style: TextStyle(color: Color(0xff03034c),fontWeight: FontWeight.w600,
                fontSize: 20,
              ),),
              SizedBox(
                height: 10,
              ),
              Text(registrationtime, style: TextStyle(color: Colors.black87,fontWeight: FontWeight.w400,
                fontSize: 15,
              ),),
              Container(
                margin: EdgeInsets.only(top: 15),
                width: w*0.39,
                child: RaisedButton(onPressed: (){
                  Navigator.push(context, MaterialPageRoute(builder: (context)=>WinYourPrice()));
                },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(FontAwesomeIcons.info,color: Colors.white,size: 16,),
                      Expanded(
                        child: Text(" Know More >>",style: TextStyle(color: Colors.white,fontWeight: FontWeight.w400,
                          fontSize: 15,
                        ),overflow: TextOverflow.ellipsis,

                        ),
                      ),

                    ],
                  ),
                  color: Colors.red,
                ),
              )
                ],
            ),
        ),
      ),
    );
  }
}
