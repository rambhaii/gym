import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
class LibraryWidget extends StatelessWidget {
  final String Poster;
  final String Category;
  final String Title;
  final String Qulity;

  const LibraryWidget({Key?key,required this.Category,required this.Poster,required this.Title,required this.Qulity}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]

        ),
      ),

      width: w*0.4,
      child: Card(
        color: Color(0xff1e2125),
        elevation: 15,
        child: Column(
          children: [
            Image.network(Poster, height: h*0.14,
              width: w*0.4,fit: BoxFit.cover, ),
            SizedBox(
              height: 5,
            ),
        Row(
   mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Text("  "+Title,style: TextStyle(
                  fontSize: 16.0,color:Colors.white,fontWeight: FontWeight.bold
              ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,
              ),
            ),
            Text(Qulity+" ",style: TextStyle(
                fontSize: 15.0,color:Colors.white,fontWeight: FontWeight.bold
            ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,
            ),
          ],
        ),
            Row(

              children: [
                Expanded(
                  child: Text("  "+Category,style: TextStyle(
                      fontSize: 15.0,color:Colors.red,fontWeight: FontWeight.bold

                  ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,
                  ),
                ),
              ],
            ),
            Row(
             mainAxisAlignment: MainAxisAlignment.end,
              children: [
              RatingBar.builder(
              initialRating: 4,
              minRating: 1,
              direction: Axis.horizontal,
              allowHalfRating: true,
              itemCount: 4,
                itemSize: 20.0,
              itemPadding: EdgeInsets.symmetric(horizontal: 2.0),
              itemBuilder: (context, _) => Icon(
                Icons.star,
                color: Colors.amber,size: 10.0,
              ),
              onRatingUpdate: (rating) {
                print(rating);
              },
            )
              ],
            ),
          ],
        ),
      )
      ,
    );
  }
}
