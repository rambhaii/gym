import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Data/drawer_items.dart';
import 'package:parnamtv/Modal/drawer_iteam.dart';
import 'package:parnamtv/User/MyProfile/Login.dart';
import 'package:parnamtv/Utils/RemoteService.dart';
import 'package:share_plus/share_plus.dart';
class DrawerWidget extends StatelessWidget {
 final ValueChanged<DrawerIteam> onSelectedItem;
 const DrawerWidget({
   Key?key ,
   required this.onSelectedItem
}):super(key: key);
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        mainAxisSize: MainAxisSize.max,
         children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset("assets/Images/logo.png",height: MediaQuery.of(context).size.height*0.1,width: MediaQuery.of(context).size.width*0.5),
            ],
          ),
           buildDraweItems(context),

      ListTile(
        dense: true,
        contentPadding: EdgeInsets.symmetric(horizontal: 15,vertical:8),
        leading: Icon(FontAwesomeIcons.share,color: Colors.white,),
        onTap:(){
        showCupertinoDialog(context: context, builder: (context)=>earnDailog())  ;
        },
        title: Text(
         "REFER & EARN",
          style: TextStyle(color: Colors.white,fontSize: 16,fontWeight: FontWeight.w600),
        ),),
          SizedBox(height: 10,),
          Align(
            alignment: Alignment.center,
            child: RaisedButton(onPressed: ()async{
           await   ParnamTv.sharedPreference.clear();
           Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (context)=>Login()), (route) => false);
            },
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(FontAwesomeIcons.signOutAlt,color: Colors.white,),
                    Text("  Log out",
                      style: TextStyle(color: Colors.white,fontSize: 16,fontWeight: FontWeight.w600),
                    ),
                  ],
                ),
                shape: Border.all(width: 2,color: Colors.amber,),
                color: Colors.transparent,
                padding: EdgeInsets.only(left: 10,right: 10,top: 8,bottom: 8),
                splashColor: Color(0xFFda251d)
            ),

          ),

        ],
      ),
    );
  }

 Widget earnDailog(){
   return  CupertinoAlertDialog(
      title: new Text("REFER & EARN"),
      content: new Text("Now refer any of friends and Get 100 coins pre referral"),
      actions: <Widget>[
        CupertinoDialogAction(
          isDefaultAction: true,
          child:  Icon(FontAwesomeIcons.times,color: Colors.red,),
          onPressed: (){
            Get.back();
          },
        ),
        CupertinoDialogAction(
          child: Icon(FontAwesomeIcons.share,color: Colors.green,),
          onPressed: (){
            RemoteService.createDynamicLink().then((value) {
              Share.share(value);
            });
            Get.back();
          },
        )
      ],
    );
 }
  Widget buildDraweItems(BuildContext context)=>Column(

      children: DrawerItems.all
          .map(
              (item) =>
                  ListTile(
                dense: true,
                contentPadding: EdgeInsets.symmetric(horizontal: 15,vertical:8),
                leading: Icon(item.icon,color: Colors.white,),
                 title: Text(
                   item.title,
                   style: TextStyle(color: Colors.white,fontSize: 16,fontWeight: FontWeight.w600),
                 ),
        onTap: ()=>onSelectedItem(item),
      ),
      ).toList(),

  );
}
