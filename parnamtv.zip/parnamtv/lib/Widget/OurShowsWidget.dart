import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
class OurShowsWidget  extends StatelessWidget {
  final String ImgUrl;
  final String title;
  final String description;
 const OurShowsWidget({Key?key,
   required this.ImgUrl,
   required this.title,
   required this.description}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    final Shader linearGradient = LinearGradient(
      colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
    ).createShader(new Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

    return Card(
       elevation: 10,
      color: Color(0xff1e2125),
      child: Container(
          width: w,
          height: h*0.15,
          child:Container(
            padding: EdgeInsets.all(10),
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: w,
              height: h*0.13,
                padding: EdgeInsets.all(5),
                 decoration: BoxDecoration(
                 gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]
                 ),
                 ),
                child: Image.network(ImgUrl,
                 fit: BoxFit.cover, ),
            ),
            SizedBox(
              height: 8,
            ),
            Text(
              title,
              style: new TextStyle(
                  fontSize: 15.0,
                  fontWeight: FontWeight.w700,
                  foreground: new Paint()..shader = linearGradient),textAlign: TextAlign.start,maxLines: 1,overflow: TextOverflow.ellipsis,
            ),
            SizedBox(
              height: 8,
            ),
            Text(
              description,
              style: new TextStyle(
                  fontSize: 14.0,
                  fontWeight: FontWeight.w500,
                  color: Colors.white),textAlign: TextAlign.start,maxLines: 1,overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      )
      ),
    );
  }
}
