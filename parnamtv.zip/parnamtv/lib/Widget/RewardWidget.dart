import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
class RewardWidget extends StatefulWidget {
 //
 final String productTitle;
 final String description;
 final String price ;
 final String points ;
 final String url;
 final String url1;
 final String url2;
 final String url3;
  const RewardWidget({
    Key? key,
    required this.productTitle,
    required this.description,
    required this.price,
    required this.points,
    required this.url,
    required this.url1,
    required this.url2,
    required this.url3,
  }) : super(key: key);

  @override
  _RewardWidgetState createState() => _RewardWidgetState();
}

class _RewardWidgetState extends State<RewardWidget> {

  @override
  Widget build(BuildContext context) {

    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Container(

      margin: EdgeInsets.all(10),
      width: w,
      child: Card(

        child: Container(
          decoration: BoxDecoration(
              // gradient: LinearGradient(
              //
              //   colors: [Colors.black,Colors.white,],
              //   begin: Alignment.bottomLeft,
              //   end: Alignment.center,
              //
              // )
          ),
          padding: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

                 Container(
                   child:Image.asset(widget.url,width: w,height:h*0.3,),
                 ),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  InkWell(
                 onTap: (){
                   changephoto(widget.url);
                 },
                    child: Container(
                      height: 60,
                      width: 60,
                      padding: EdgeInsets.all(3.0),
                      decoration:BoxDecoration(
                        gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]
                        ),
                      ),
                      child: Image.asset(widget.url),
                    ),
                  ),

                  InkWell(
                    onTap: (){
                      changephoto(widget.url1);
                    },
                    child: Container(
                      height: 60,
                      width: 60,
                      padding: EdgeInsets.all(3.0),
                      decoration:BoxDecoration(
                        gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]
                        ),
                      ),
                      child: Image.asset(widget.url1),
                    ),
                  ),
                  InkWell(
                    onTap:(){
                      changephoto(widget.url2);
                    },
                    child: Container(
                      height: 60,
                      width: 60,
                      padding: EdgeInsets.all(3.0),
                      decoration:BoxDecoration(
                        gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]
                        ),
                      ),
                      child: Image.asset(widget.url2),
                    ),
                  ),
                  InkWell(
                    onTap: (){
                      changephoto(widget.url3);
                    },
                    child: Container(
                      height: 60,
                      width: 60,
                      padding: EdgeInsets.all(3.0),
                      decoration:BoxDecoration(
                        gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]
                        ),
                      ),
                      child: Image.asset(widget.url3),
                    ),
                  )
                ],
              ),
              SizedBox(
                height: 10,
              ),
              Text(widget.productTitle,style: TextStyle(
                  fontSize: 18.0,color:Colors.black,fontWeight: FontWeight.w500
              ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,
              ),
              Row(
                children: [
                  Text("MRP : ",style: TextStyle(
                      fontSize: 18.0,color:Colors.black,fontWeight: FontWeight.w500
                  ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,
                  ),
                  Text(widget.price,style: TextStyle(
                      fontSize: 18.0,color:Color(0xffff9f1a),fontWeight: FontWeight.w500
                  ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,
                  ),
                ],
              ),
              Row(
                children: [
                  Text("REQUIRED POINTS : ",style: TextStyle(
                      fontSize: 18.0,color:Colors.black,fontWeight: FontWeight.w500
                  ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,

                  ),
                  Text(widget.points,style: TextStyle(
                      fontSize: 18.0,color:Color(0xffff9f1a),fontWeight: FontWeight.w500
                  ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,
                  ),
                ],
              ),
             ExpansionTile(

                  title: Text(("Know More >>")),
                  children: [
                    ListTile(
                        title:Text("Superior listening experience with JBL Pure Bass sound",
                    style: TextStyle(
                    fontSize: 14.0,color:Colors.black,fontWeight: FontWeight.w300
                ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,

                        ),
                      leading: Icon(FontAwesomeIcons.arrowAltCircleRight,size: 20,)
                    ) ,ListTile(
                        title:Text("Superior listening experience with JBL Pure Bass sound",
                          style: TextStyle(
                              fontSize: 14.0,color:Colors.black,fontWeight: FontWeight.w300
                          ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,
                        ),
                      leading: Icon(FontAwesomeIcons.arrowAltCircleRight,size: 20,),
                    ), ListTile(
                        title:Text("Superior listening experience with JBL Pure Bass sound",
                          style: TextStyle(
                              fontSize: 14.0,color:Colors.black,fontWeight: FontWeight.w300
                          ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,
                        ),

                      leading: Icon(FontAwesomeIcons.arrowAltCircleRight,size: 20,

                      ),
                    ) ,ListTile(
                        title:Text("Superior listening experience with JBL Pure Bass sound",
                          style: TextStyle(
                              fontSize: 14.0,color:Colors.black,fontWeight: FontWeight.w300
                          ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,
                        ),
                      leading: Icon(FontAwesomeIcons.arrowAltCircleRight,size: 20,),
                    ),ListTile(
                        title:Text("Superior listening experience with JBL Pure Bass sound",
                          style: TextStyle(
                              fontSize: 14.0,color:Colors.black,fontWeight: FontWeight.w300
                          ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,
                        ),
                      leading: Icon(FontAwesomeIcons.arrowAltCircleRight,size: 20,),
                    ),

                  ],
                ),
           
              RaisedButton(onPressed: (){
                Fluttertoast.showToast(msg: "Your Point less 2000",toastLength:Toast.LENGTH_LONG);
              },
                padding: EdgeInsets.all(14),
                child: Text(" REDEEM NOW ",style: TextStyle(color:Colors.white),),
                  color:Color(0xffff9f1a)
              )
            ],
          ),
        ),
      ),
    );
  }

  void changephoto(String s) {
    setState(() {
    // widget.url=s;
    });

  }
}

