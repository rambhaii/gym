import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:lottie/lottie.dart';
class CirculerShowWidget extends StatefulWidget {
  final String title;
  final String description;
  final String Imgurl;
  final double height;
  final double width;
 const CirculerShowWidget({Key?key ,
   required  this.Imgurl,required this.title,required this.description, required this.height, required this.width
 }) : super(key: key);

  @override
  _CirculerShowWidgetState createState() => _CirculerShowWidgetState();
}

class _CirculerShowWidgetState extends State<CirculerShowWidget> with SingleTickerProviderStateMixin {
  late AnimationController controller;

  @override
  void initState() {
    super.initState();
    controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 400),
      reverseDuration: Duration(milliseconds: 400),
    );
  }


  @override
  Widget build(BuildContext context) {

    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Column(
      children: [
        Container(
           height: 125,
          width:125,
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]
            ),
                shape: BoxShape.circle),
          child: Center(
            child: Lottie.asset(widget.Imgurl ,height: widget.height,width: widget.width),
          ),
        ),
        SizedBox(
          height: 15,
        ),
        Text(widget.title,textAlign: TextAlign.center,style: TextStyle(
            color: Color(0xffda261e),fontWeight: FontWeight.w500,fontSize: 20,
        ),),
        Container(
          margin: EdgeInsets.all(20),
          child: Text(widget.description,textAlign: TextAlign.center,style: TextStyle(
            color: Colors.white,fontWeight: FontWeight.w300,fontSize: 16,
          ),),
        )
      ],
    );
  }
}
