import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:parnamtv/Data/SubscriptionData.dart';
class SubscriptionWidget extends StatelessWidget {
  final Color color;
  final String heading;
  final String rupees;
  final VoidCallback onClick;
  final String status;
 final List<PlanInfoDatum> planInfoData;
  const SubscriptionWidget({Key?key,required this.color, required this.heading,required this.rupees,required this.onClick,required this.planInfoData,required this.status}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
   //   Fluttertoast.showToast(msg:status,toastLength: Toast.LENGTH_LONG);
    return Container(
        width: w,
        height:h* 0.6,
    margin: EdgeInsets.only(),
        child:Card(
        elevation: 10.0,
        shape: Border.all(width: 2, color:color),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipPath(
              clipper: MovieTicketBothSidesClipper(),
              child: Container(
                width: w,
                height: 90,
                color:color,
                child:Center(
                  child: Text(heading,
                      style: TextStyle(
                          fontSize: 25.0,fontWeight: FontWeight.w600,
                        color: Colors.white

                      ),
              ),
                ),
            ),

        ),
            Container(
              width: w,
              margin: EdgeInsets.only(top: 10),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("\u{20B9}"+' '+rupees,
                    style: TextStyle(
                      fontSize: 25.0,fontWeight: FontWeight.w600
                    ),
                  ),
                Text(" / year",
                  style: TextStyle(
                      fontSize: 20.0,fontWeight: FontWeight.w300
                  ),
                  ),
                ],
              ),

            ),
         Expanded(
           child: ListView.builder(
                 itemCount: planInfoData.length,
                   itemBuilder: (BuildContext context, int index)=>new
                   ListTile(
                     leading: Icon(FontAwesomeIcons.solidCheckCircle,color:color,size: 25,),
                     title: Text(planInfoData[index].planInfo!, textAlign: TextAlign.start,
                       style:  TextStyle(
                           fontSize: 14.0
                       ),),

                   ),
               ),
         ),


            Visibility(

              child:status=="0"? RaisedButton(

                  onPressed: (){
                  onClick();
                  },

                child: Text("SELECT PLAN",style: TextStyle(color: Colors.white),),
                 color: color,
              ):Text("You have already Buy this  plan",style: TextStyle(color: Colors.green,fontWeight: FontWeight.w500,),

            ),),
            SizedBox(
              height: 15,
            )
          ],
        ),
      )
    );
  }

}
