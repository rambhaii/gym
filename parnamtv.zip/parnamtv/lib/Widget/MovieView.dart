import 'package:flutter/material.dart';
class MovieView extends StatelessWidget {
  final String moviename;
  final String imageUrl;
  final String releasing;
  final String starcost;
  final String Plot;
 const MovieView({Key?key,required this.moviename, required this.imageUrl,required this.releasing,required this.starcost,required this.Plot}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    final Shader linearGradient = LinearGradient(
      colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
    ).createShader(new Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

    return Card(
      elevation: 10,
      color: Color(0xff1e2125),
      child:
      Container(
          width: w*0.2,
          height: h*0.36,

          child:Container(

            padding: EdgeInsets.only(left: 10,right: 10,top: 5,bottom: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
            //     Text(moviename,
            // style: new TextStyle(
            //     fontSize: 14.0,
            //     fontWeight: FontWeight.w500,
            //     color: Colors.white),textAlign: TextAlign.start,maxLines: 3,overflow: TextOverflow.ellipsis,
            //     ),
                SizedBox(
                  height: 5,
                ),
                Container(
                  width: w,
                  height: h*0.17,
                  padding: EdgeInsets.all(5),
                  child: Image.network(imageUrl,
                    fit: BoxFit.cover, ),
                ),
                SizedBox(
                  height: 5,
                ),
               Text('Releasing : '+releasing,
                   style: new TextStyle(
                   fontSize: 13.0,
                   fontWeight: FontWeight.w400,
                   color: Colors.white),textAlign: TextAlign.start,maxLines: 1,overflow: TextOverflow.ellipsis,
               ),
                SizedBox(
                  height: 3,
                ),
                Text(
                  "Star Cast : "+starcost,
                  style: new TextStyle(
                      fontSize: 13.0,
                      fontWeight: FontWeight.w400,
                      color: Colors.white),textAlign: TextAlign.start,maxLines: 1,overflow: TextOverflow.ellipsis,
                ),
                SizedBox(
                  height: 3,
                ),
                Text(
                  "Plot : "+Plot,
                  style: new TextStyle(
                      fontSize: 12.0,
                      fontWeight: FontWeight.w400,
                      color: Colors.white),textAlign: TextAlign.start,maxLines: 3,overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          )
      ),
    );
  }
}
