import 'package:flutter/material.dart';
class HorizentaLine extends StatelessWidget {
  final double width;
 const HorizentaLine({
  Key?key,
  this.width= double.infinity
 }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 3.5,

        width: width,
        decoration: BoxDecoration(
        gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]

    ),
        )
    );
  }
}
