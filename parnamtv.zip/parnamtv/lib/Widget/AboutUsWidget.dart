import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'HorizentalLine.dart';
class AboutUsWidget extends StatelessWidget {
  final String Imgpath;
  final String name;
  final String departemnt;
  final String Aboutus;
  final String gradienttext;
  const AboutUsWidget({Key?key,required this.Imgpath,required this.name,required this.departemnt, required this.Aboutus,required this.gradienttext

  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    final Shader linearGradient = LinearGradient(
      colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
    ).createShader(new Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

    return Container(
      child: Column(
        children: [

          Center(
            child: Container(
              width: w*0.45,
              height: h*0.3,
              margin: EdgeInsets.only(top: 10),
              padding: EdgeInsets.all(5.0),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]
                ),
              ),
              child:Image.asset(Imgpath ,fit: BoxFit.cover,),
            ),
          ),
          SizedBox(
           height: 15,
          ),
          Text(name
          ,style: TextStyle(
              fontSize: 23,color: Color(0xFFda261e),fontWeight: FontWeight.w600
            ),
          ),
          SizedBox(
            height: 10,
          ),
          Text(departemnt
            ,style: TextStyle(
                fontSize: 15,color: Color(0xFFff9000),fontWeight: FontWeight.w400
            ),
          ),
         Card(
           color: Color(0xFF191A19),
   elevation: 10.0,
           margin: EdgeInsets.only(top: 10,left: 15,right: 15,bottom: 10),
           child: Container(
             margin: EdgeInsets.only(top: 10,left: 15,right: 15,bottom: 10),
             child: Column(
               crossAxisAlignment: CrossAxisAlignment.start,
                 children: [
                   Row(
                     children: [
                       Text("About Us"
                         ,style: TextStyle(
                             fontSize: 22,color: Color(0xFFda261e),fontWeight: FontWeight.w600
                         ),
                       ),

                     ],
                   ),
                   SizedBox(
                     height: 5,
                   ),
                   HorizentaLine(width: w*0.2,),

               Container(
                   width: w,
                  decoration: BoxDecoration(
                 gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]
                 ),
                 borderRadius: BorderRadius.circular(5)
               ),
               margin:EdgeInsets.all(8),
               padding: EdgeInsets.all(10),
               child:
                    Text(gradienttext
                      ,style: TextStyle(
                          fontSize: 17,color: Colors.white,fontWeight: FontWeight.w300
                      ),textAlign: TextAlign.justify,
                    )
               ),
                   Container(
                     margin:EdgeInsets.all(8),
                     child: Column(
                       children: [
                         Text(Aboutus
                           ,style: TextStyle(
                               fontSize: 15,color: Colors.white,fontWeight: FontWeight.w300
                           ),textAlign: TextAlign.justify,
                         ),

                       ],
                     ),
                   )
                 ],
               ),
           ),
           ),

        ],
      ),

    );
  }
}
