import 'package:flutter/material.dart';
class OurSpecialization extends StatelessWidget {
  final String url;
  final String title;
 const OurSpecialization({Key?key,required this.url,required this.title}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Container(

      child: Container(

          decoration: BoxDecoration(
         borderRadius: BorderRadius.circular(5),
            image: DecorationImage(
              image: NetworkImage(url),
              fit: BoxFit.fill
            ),
            boxShadow: [
              BoxShadow(
              color: Colors.grey.withOpacity(0.4),
                offset: const Offset(
                  0.0,
                  5.0,
                ),
                blurRadius: 10.0,
                spreadRadius: 2.0,
              ), //BoxShadow
            ],
          ),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
            gradient: LinearGradient(
              colors: [Colors.transparent,Colors.black.withOpacity(0.7)],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
              stops: [0.3, 1],
            )
          ),
          padding: EdgeInsets.all(10),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [

              SizedBox(
              height: 5,
              ),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.videocam,color:Color(0xFFff9000) ,),
                  Expanded(
                    child: Text(title,style: TextStyle(
                      fontSize: 15.0,color:Color(0xFFff9000),fontWeight: FontWeight.bold
                    ),overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      )
      ,
    );
  }
}
