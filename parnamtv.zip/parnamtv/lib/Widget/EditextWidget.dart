
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class EditTextWidget extends StatelessWidget {
  final String hint;
  final String label;
  final IconData icon;
  final int maxLength;
  final bool isPassword;
  final TextInputType keyboardtype;
   final FormFieldValidator validator;
  final TextEditingController?controller;
  final bool?isdisable;
  const EditTextWidget({Key?key,required this.hint,required this.label, required this.icon,required this.validator, required this.keyboardtype,required this.maxLength,required this.isPassword, this.controller, this.isdisable}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;

    return Container(
      width: w,
      child:TextFormField(
         readOnly: isdisable==null?false:true,
        decoration: InputDecoration(
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(color: Colors.grey)
        ),
          focusedBorder:  OutlineInputBorder(
        borderSide: BorderSide(color: Colors.deepOrangeAccent)
      ),
          errorBorder:   OutlineInputBorder(
              borderSide: BorderSide(color: Colors.deepOrangeAccent)
          ),
          focusedErrorBorder: OutlineInputBorder(
              borderSide: BorderSide(color: Colors.deepOrangeAccent)
          ),
          counter: Offstage(),
          hintText: hint,
            hintStyle: TextStyle(
              color: Colors.white60
            ),
            labelText:label,
            prefixIcon: Icon(icon,color: Colors.deepOrangeAccent,),
          // icon: Icon(Icons.person),
            contentPadding: const EdgeInsets.all(15.0),
            labelStyle: TextStyle(color: Colors.deepOrangeAccent)
        ),
        controller: controller,
        keyboardType: keyboardtype,
        maxLength: maxLength,
        obscureText: isPassword,
        validator:validator,
        style:TextStyle(color:Colors.white),
      ),
    );
  }
}
