import 'package:flutter/material.dart';

import 'RaisedGradientButtonwidget.dart';
class ShowWidget extends StatelessWidget {
//  const ShowWidget({Key key}) : super(key: key);
   final String Src;
   final String btnName;
   final VoidCallback onClicked;
  const ShowWidget({Key?key, required this.Src,
    required this.onClicked,
    required this.btnName
  }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Container(
      height: h*0.2,
      width: w*0.4,
      child: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
                image: DecorationImage(
                  image:NetworkImage(Src),
                  fit: BoxFit.cover,
                ),
                borderRadius: BorderRadius.circular(5.0)
            ),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5.0),
                gradient: LinearGradient(
                  begin:Alignment.topLeft,
                  end: Alignment(0.3,0.0),
                  tileMode: TileMode.repeated,
                  colors: [
                    Color(0xFFff251d).withOpacity(0.5)
                    , Color(0xFFff9000).withOpacity(0.5),
                  ],
                ),
              ),

          ),
          ),
          Center(
            child: Container(
              width: w*0.22,
              height: 35,

              child: RaisedGradientButton(
                child: Text(
                      btnName,
                  style: TextStyle(color: Colors.white,
                      fontSize: 13,fontWeight: FontWeight.w300
                  ),textAlign: TextAlign.center,
                ),
                gradient: LinearGradient(
                  colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
                ),
                onClicked: () {
                    onClicked();
                },
              ),
            ),
          ),
        ],
      ),
    );

  }
}
