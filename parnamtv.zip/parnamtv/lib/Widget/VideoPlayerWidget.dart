
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
class VideoPlayerWidget extends StatefulWidget {
  final String Url;
  const VideoPlayerWidget({Key? key, required this.Url}) : super(key: key);

  @override
  _VideoPlayerWidgetState createState() => _VideoPlayerWidgetState();
}

class _VideoPlayerWidgetState extends State<VideoPlayerWidget> {
  late VideoPlayerController videoPlayerController;
  bool showFull = false;

  @override
  void initState() {
      videoPlayerController=VideoPlayerController.network(widget.Url);
      videoPlayerController.play();
      videoPlayerController.initialize();
      videoPlayerController.setLooping(true);
      videoPlayerController.setVolume(1);
      super.initState();

  }
    @override
    void dispose() {
      videoPlayerController.dispose();

      super.dispose();
    }
    @override
    Widget build(BuildContext context) {
      return VideoPlayer(videoPlayerController);

    }
  }

