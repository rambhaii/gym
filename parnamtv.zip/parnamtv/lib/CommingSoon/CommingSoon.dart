import 'package:better_player/better_player.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:parnamtv/User/UserDashboard.dart';
import 'package:parnamtv/Widget/DrawerMenuWidget.dart';
import 'package:parnamtv/Widget/EditextWidget.dart';

import '../Config/Configration.dart';
import '../DashBoard/CommentModalBottomsheet.dart';
import '../User/NavigationDrawer.dart';
class CommingSoon extends StatefulWidget {
  final VoidCallback openDrawer;
  const CommingSoon(
      {
        Key?key,
        required this.openDrawer,
      }):super(key: key);
  @override
  _CommingSoonState createState() => _CommingSoonState();
}

class _CommingSoonState extends State<CommingSoon> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(

      appBar: AppBar(
        backgroundColor: Color(0xFF1e2125),
        title: Text("Live TV"),
        leading:  DrawerMenuWidget(onClicked: widget.openDrawer),

      ),
      body:Container(

        child: Column(
          children: [
            Image.asset("assets/Images/topad.png"),

            AspectRatio(
              aspectRatio: 16 / 9,
              child: BetterPlayer.network(
                "https://pranamtv.com/pages/admin/uploads/ourFrontShow/ce62abf774b53262b5eb6c7b841b9ffb.mp4",
                betterPlayerConfiguration: BetterPlayerConfiguration(
                  aspectRatio: 16 / 9,
                  autoPlay: true,
                ),
              ),

            ),

          ],
        ),
      ),
      bottomSheet:  Container(

        margin: EdgeInsets.only(left: 15,right: 15),
        child: Container(
            decoration: BoxDecoration(
                color: Color(0xFFf9c600),
                borderRadius: BorderRadius.only(topLeft: Radius.circular(30),topRight: Radius.circular(30))

            ),
            padding: EdgeInsets.only(bottom: 8,top: 8),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                RaisedButton(onPressed: (){
                  ModalSheet();
                },
                  color:Color(0xff045002) ,
                  shape: StadiumBorder(),
                  child: Text("Suggestion",textAlign: TextAlign.center,style:TextStyle(
                      color: Colors.white
                  )),
                  splashColor: Color(0xff092408),

                ),
                RaisedButton(onPressed: (){
                  Get.to(()=>UserNavigation());

                },

                  color:Color(0xffcc3204) ,
                  shape: StadiumBorder(),
                  child: Text("Dashboard",textAlign: TextAlign.center,style:TextStyle(
                    color: Colors.white,

                  )),
                  splashColor: Color(0xff521d04),


                )
              ],
            )
        ),
      ),
    );
  }
 Future ModalSheet(){
    return  showModalBottomSheet(
        context: context,
        builder: (context) {
          return Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              SizedBox(height: 5,),
              Padding(
              padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                child: ListTile(
                  leading:CircleAvatar(
               backgroundImage: NetworkImage(ParnamTv.sharedPreference.getString(ParnamTv.profile_img).toString()),
          ),
                  title:TextFormField(
                    decoration: InputDecoration(
                 hintText: "Comment Here...."

                    ),
                    autofocus: true,

                  ),
                  trailing: InkWell(
                    onTap: (){
                      Get.back();
                    },
                    child: CircleAvatar(
                      backgroundColor: Colors.blue,
                      child: Icon(Icons.send,color: Colors.white,),
                    ),
                  ),
                  onTap: () {

                    Navigator.pop(context);
                  },
                ),
              ),

              SizedBox(height: 5,),

            ],
          );
        });
   }
}
