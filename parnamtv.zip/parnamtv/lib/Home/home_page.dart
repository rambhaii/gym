import 'dart:async';
import 'dart:ui';

import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:better_player/better_player.dart';
import 'package:carousel_slider/carousel_slider.dart';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:lottie/lottie.dart';
import 'package:parnamtv/Animation/AnimationWidget.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Contest/Contest.dart';
import 'package:parnamtv/Dailog/SubscriptionDailog.dart';
import 'package:parnamtv/Dailog/TimeHandler.dart';
import 'package:parnamtv/DashBoard/Controller/HomeController.dart';
import 'package:parnamtv/DashBoard/OurSchedule.dart';
import 'package:parnamtv/DashBoard/VotingShowPage.dart';
import 'package:parnamtv/Data/OurSpecilization.dart';
import 'dart:convert';
import 'package:parnamtv/Home/LiveStreming.dart';
import 'package:parnamtv/OurShow/our_show.dart';
import 'package:parnamtv/Service/Services.dart';
import 'package:fab_circular_menu/fab_circular_menu.dart';
import 'package:parnamtv/Ui/Library.dart';
import 'package:parnamtv/Ui/Subscription.dart';
import 'package:parnamtv/User/MyProfile/Login.dart';
import 'package:parnamtv/User/NavigationDrawer.dart';
import 'package:parnamtv/User/Rewards.dart';
import 'package:parnamtv/User/MyProfile/Signup.dart';
import 'package:parnamtv/User/UserDashboard.dart';
import 'package:parnamtv/User/MyProfile/profile.dart';
import 'package:parnamtv/User/WinYourDream.dart';
import 'package:parnamtv/Utils/Loader.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:parnamtv/ViewWin/ViewWin.dart';
import 'package:parnamtv/Widget/CircleShowWidget.dart';
import 'package:parnamtv/Widget/CircularLoader.dart';
import 'package:parnamtv/Widget/DrawerMenuWidget.dart';
import 'package:parnamtv/Widget/HorizentalLine.dart';
import 'package:parnamtv/Widget/OurSpecializationWidget.dart';
import 'package:parnamtv/Widget/RaisedGradientButtonwidget.dart';
import 'package:parnamtv/Widget/ShowWidget.dart';
import 'package:parnamtv/Widget/VideoPlayerWidget.dart';

import '../Utils/RemoteService.dart';
class HomePage extends StatefulWidget {
     final VoidCallback openDrawer;
     const HomePage(
     {
       Key?key,
       required this.openDrawer,
}):super(key: key);
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {

  late OurSpecilizationData ourSpecilizationData;
  late HomeController homeController;
  int _current=0;
  var IntroVideo = "";
   bool isReady=false;
  List Hedaing=[
    "A platform that celebrates talent in the field of performing arts, literature, poetry and culture!!",
    "A web channel that is focused on showcasing the rich culture and heritage of Uttar Pradesh",
    "A web channel that will promote upcoming content makers and shall provide them a platform to showcase their content",
    "Do join  Pranam TV family and be a part of this exciting  journey. Pranam TV exclusively created for YOU!!",
  ];
  List imagepath=[
     "assets/Images/banner.jpg",
     "assets/slider/slide2.jpg",
     "assets/slider/slide3.jpg",
     "assets/slider/slide4.jpg",
  ];
  List<T> map<T>(List list,Function handler)
  {
    List<T> result=[];
    for(var i=0;i < list.length;i++)
      {
        result.add(handler(i,list[i]));
      }
    return result;
  }
  String name="";
  String imageUrl="";
  String userId="";
  getDatafrompref() {

      name= ParnamTv.sharedPreference.getString(ParnamTv.userName)??'';
      imageUrl= ParnamTv.sharedPreference.getString(ParnamTv.profile_img)??'';
      userId= ParnamTv.sharedPreference.getString(ParnamTv.userID)??'';
      print("hhggghg,$imageUrl");
  }
  @override
  void initState() {

   homeController =Get.put(HomeController());
    Timer(TimerHandler.twentyMillis, () {
      showDialog(context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return SubscriptionDailog(
            );
          });
    });

    getDatafrompref();
    // TODO: implement initState
    super.initState();
  }


  @override
  Widget build(BuildContext context) {
    print("dnvljndlkjvnldjvn");
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    final Shader linearGradient = LinearGradient(
      colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
    ).createShader(new Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));
    return Scaffold(
      extendBody: true,
      extendBodyBehindAppBar: true,
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Color(0xFF1e2125).withOpacity(0.5),

        title: AnimationWidget(
            sec: 2,
            LRdir: 0.0,
            UDdir: 2.0,
            child:Image.asset("assets/Images/logo.png",height: 40,)
        ),
        // leading:
        leading: BackdropFilter(
          filter: new ImageFilter.blur(sigmaX: 10.0, sigmaY:10.0),
          child: Container(
            child: AnimationWidget(
              sec: 2,
              LRdir: -2.0,
              UDdir: 0.0,
              child:  DrawerMenuWidget(onClicked: widget.openDrawer),
            ),
          ),
        ),

        actions: [

          AnimationWidget(
             sec: 3,
             LRdir: 2.0,
             UDdir: 0.0,
             child: InkWell(

               onTap: (){
                 getDatafrompref();
                 if(userId=="")
                         {
                           Navigator.push(context, MaterialPageRoute(builder: (context)=>Login()));
                         }
                       else{
                         Navigator.push(context, MaterialPageRoute(builder: (context)=>UserNavigation()));
                       }
               },

                 //child:userId!=""? new Image.network(imageUrl,fit: BoxFit.fill,):Icon(Icons.person_add_alt_1,size: 24,color: Colors.black54,) ,


                  child:imageUrl!=""?CircleAvatar(
                   radius: 21,
                   backgroundColor: Colors.transparent,
                  backgroundImage:NetworkImage(imageUrl),
                  ):CircleAvatar(
                    radius: 21,
                    backgroundColor: Colors.white,
                    backgroundImage:AssetImage("assets/Images/noimage.png"),
                  )

      ),
           ),
          SizedBox(width: 10,),
         ],
         ),

      body: Container(
        decoration: BoxDecoration(
    color: Colors.black45,
    image: DecorationImage(
    image:ExactAssetImage("assets/Images/whyus-bg.jpg"),
    fit: BoxFit.cover
    ),
      ),
        child: SingleChildScrollView(
          child: Column(
            children: [
           SizedBox(height: 75,),
              Container(

                child: Column(
                  children: [

                    Obx(()=> Stack(
                        children: [
                          AspectRatio(
                            aspectRatio: 16/9,
                            child: Image(image: AssetImage("assets/Images/banner.jpg"),),
                          ),
                          CarouselSlider(
                                  options: CarouselOptions(
                                    aspectRatio: 16/9,
                                    viewportFraction:0.92,
                                    initialPage: 0,
                                    height: 190,
                                    enableInfiniteScroll: true,
                                    reverse: false,
                                    autoPlay: true,
                                    autoPlayInterval: Duration(seconds: 3),
                                    autoPlayAnimationDuration: Duration(milliseconds: 1000),
                                    autoPlayCurve: Curves.easeInSine,
                                    enlargeCenterPage: true,
                                    scrollDirection: Axis.horizontal,
                                    onPageChanged:(index, reason){
                                      homeController.onChangePage(index);

                                    },
                                  ),
                            items: imagepath.map((imagepath) {
                                    return Builder(
                                      builder: (BuildContext context) {

                                        return Container(
                                        margin: EdgeInsets.only(top: 40),
                                           width: w,


                                            child:
                                              Column(
                                                 mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  Text("SWITCH TO PRANAM TV\nTODAY!",style: TextStyle(
                                                   color: Color(0xFFff9000),
                                                    fontSize: 18,
                                                    fontWeight: FontWeight.w600,
                                                  ),
                                                       textAlign:TextAlign.center,
                                                  ),
                                                  SizedBox(
                                                    height: 5,
                                                  ),
                                                  Text(Hedaing[_current],style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 13,
                                                      fontWeight: FontWeight.w300,
                                                  ),
                                                    textAlign:TextAlign.center,
                                                  )
                                                ],
                                              ),


                                        );
                                      },
                                    );
                                  }).toList(),
                                ),

                          Positioned(
                            bottom: 60,
                            left: 0,
                            right: 0,
                            child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children:map<Widget>(
                                    imagepath,(Index,url){
                                  return Container(
                                    width: 10.0,
                                    height: 10.0,
                                    margin:EdgeInsets.symmetric(vertical: 10.0,horizontal: 2.0) ,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        color: homeController.index.value==Index?Colors.grey:Colors.grey.withOpacity(0.5)
                                    ),
                                  );
                                }
                                )
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.only(top:180),
                            color: Colors.black,
                            child:
                            Text("एक आम आदमी को ख़ास  बनाने की कोशिश",textAlign: TextAlign.center,
                              style: TextStyle(color: Colors.white
                                  ,fontSize: 23,fontStyle: FontStyle.italic,fontWeight: FontWeight.bold
                              ),overflow: TextOverflow.ellipsis,
                              maxLines: 2,
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
              //  margin: EdgeInsets.all(30),

                child: Column(
                  children: [

                    Container(
                      margin: EdgeInsets.only(top:20,left: 15,right: 15,bottom: 20),
                      child: AspectRatio(
                        aspectRatio: 16 / 9,
                        child: VideoPlayerWidget(Url:"https://pranamtv.com/uploads/ourShow/ce62abf774b53262b5eb6c7b841b9ffb.mp4"),

                      ),
                    ),

            Text(
              'FUN\nUNLIMITED',
              style: new TextStyle(
                  fontSize: 30.0,
                  fontWeight: FontWeight.w800,
                  foreground: new Paint()..shader = linearGradient),textAlign: TextAlign.center,
               ),
                    SizedBox(
                      height: 5,
                    ),
                    HorizentaLine(width: w*0.25,),
                    SizedBox(
                      height: 15,
                    ),
                    Text("With Pranam TV subscription, you will not only have an access to LIVE TV, but will also get an opportunity to win exciting prizes by being a part of our interactive shows",textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white
                          ,fontSize: 16.0,fontWeight: FontWeight.w400
                      ),overflow: TextOverflow.ellipsis,
                      maxLines: 4,
                    ),
                    SizedBox(height: 10,),
                    Container(
                      width: 55,
                      height: 55,
                      decoration: BoxDecoration(
                          gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]),
                        borderRadius: BorderRadius.circular(100)
                      ),
                      child:IconButton(
                        onPressed: (){

                              Navigator.push(context,
                              MaterialPageRoute(builder: (context)=>Subscription())
                              );

                        }
                        ,
                        icon: Icon(Icons.arrow_forward_outlined,size: 30,color: Colors.white,),
                      )


                      // child: RaisedGradientButton(
                      //   child: Text(
                      //     'Get Started',
                      //     style: TextStyle(color: Colors.white,
                      //         fontSize: 16,fontWeight: FontWeight.w600
                      //     ),
                      //   ),
                      //   gradient: LinearGradient(
                      //     colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
                      //   ), onClicked: () {
                      //     Navigator.push(context,
                      //     MaterialPageRoute(builder: (context)=>Subscription())
                      //     );
                      // },
                      //
                      // ),
                    ),
                    SizedBox(height: 10,),

                  ],
                ),
              ),
              Container(
                color: Colors.black,
                child: Column(
                  children: [
                    SizedBox(
                     height: 25,
                    ),
                    Text(
                      'ONE SUBSCRIPTION\nMANY BENEFITS!',
                      style: new TextStyle(
                          fontSize: 28.0,
                          fontWeight: FontWeight.w800,
                          foreground: new Paint()..shader = linearGradient),textAlign: TextAlign.center,
                    ),
                    SizedBox(
                      height: 5,

                    ),
                    HorizentaLine(width: w*0.3,),
                    SizedBox(
                      height: 25,
                    ),
                    Text("With Pranam TV subscription, you will not only have an access to LIVE TV, but will also get an opportunity to win exciting prizes by being a part of our interactive shows",textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.white
                          ,fontSize: 16.0,fontWeight: FontWeight.w400
                      ),overflow: TextOverflow.ellipsis,
                      maxLines: 5,

                    ),

                    Row(
                      children: [
                         Obx(() =>  Expanded(
                              child: Padding(
                                padding: const EdgeInsets.all(15.0),
                                child: homeController.OneSubModel.value.length!=null?
                                GridView.count(
                                      crossAxisCount: 2,
                                      shrinkWrap: true,
                                      physics: NeverScrollableScrollPhysics(),
                                      scrollDirection: Axis.vertical,
                                      crossAxisSpacing: 15,
                                      mainAxisSpacing: 15,
                                      children:List.generate(homeController.OneSubModel.value.length, (index) =>

                                      new ShowWidget(Src: homeController.OneSubModel.value[index].banner??"", onClicked: () {
                                           switch(homeController.OneSubModel.value[index].clickLink!.split("/").last){
                                             case "archive":
                                               Get.to(()=>Library());
                                               break;
                                               case "subscription":
                                                 Get.to(()=>Subscription());
                                               break;
                                               case "pranamtv":
                                                 Get.to(()=>OurShow(openDrawer:(){},flag: 2,));
                                               break;
                                               case "contents":
                                                Get.to(()=>Contest(openDrawer: (){},flag: 3,));
                                               break;


                                           }
                                        print("nkfnbfd"+homeController.OneSubModel.value[index].clickLink!.split("/").last);
                                      }, btnName: homeController.OneSubModel.value[index].title??"",),
                                      ),

                                ):Container(),
                                ),
                              ),
                       ),


                      ],
                    ),

                    // Row(
                    //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    //   children: [
                    //     ShowWidget(Src: 'assets/Images/slider3.jpg', onClicked: () { print("hellow");  }, btnName: 'Events & All The Jazz',),
                    //     ShowWidget(Src: 'assets/Images/slider4.jpg', onClicked: () { print("hellow");  }, btnName: 'In The Library',),
                    //   ],
                    // ),
                    SizedBox(
                      height: 30.0,
                    ),
                  ],
                ),
              ),
              Container(

          margin: EdgeInsets.all(20.0),
          child: Column(
            children: [
              Text(
                'WHY PRANAM TV',
                style: new TextStyle(
                    fontSize: 28.0,
                    fontWeight: FontWeight.w800,
                    foreground: new Paint()..shader = linearGradient),textAlign: TextAlign.center,
              ),
              SizedBox(
                height: 5,

              ),
              HorizentaLine(width: w*0.3,),
              SizedBox(
                height: 25,

              ),
              InkWell(
                  onTap: (){
                    Get.to(()=>OurShedule());
                  },
                  child: CirculerShowWidget(Imgurl:'assets/LottieAnimation/calenders.json' ,title: "OUR\nSCHEDULE", description: 'Get Schedule and Watch Your Favorite Programm.', width: 90,height: 90,)),
              //CirculerShowWidget(Imgurl:'assets/LottieAnimation/rewards.json' ,title: "JOIN US\nFREE AND WIN", description: 'Watch & Participate To Win Exciting Gifts.', width: 170,height: 170),
              Column(
                children: [
                  InkWell(
                    onTap: (){
                      Get.to(()=>Subscription());
                    },
                    child: Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          height: 125,
                          width:125,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]
                              ),
                              shape: BoxShape.circle),
                        ),
                        Positioned(
                          right: 43,
                            bottom: 20,
                            child: Lottie.asset("assets/LottieAnimation/rewards.json" ,height: 100,width: 100,fit: BoxFit.cover)),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 15,
                  ),
                  Text("JOIN US",textAlign: TextAlign.center,style: TextStyle(
                    color: Color(0xffda261e),fontWeight: FontWeight.w500,fontSize: 20,
                  ),),
                  Container(
                    margin: EdgeInsets.all(20),
                    child: Text("Win Your Dream.",textAlign: TextAlign.center,style: TextStyle(
                      color: Colors.white,fontWeight: FontWeight.w300,fontSize: 16,
                    ),),
                  )
                ],
              ),

              //CirculerShowWidget(Imgurl:'assets/LottieAnimation/winner.json' ,title: "VOTE AND\nGET REWARD", description: 'Get a chance to be rewarded by voting.', width: 190,height: 190),
              InkWell(
                onTap: (){
                  Get.to(()=>VotingShowPage());
                },
                child: Column(
                  children: [
                    Stack(
                      alignment: Alignment.center,
                      children: [
                        Container(
                          height: 125,
                          width:125,
                          decoration: BoxDecoration(
                              gradient: LinearGradient(colors: [Color(0xffda251d) ,Color(0xffff9000)]
                              ),
                              shape: BoxShape.circle),
                        ),
                        Positioned(
                            bottom: 25,
                            child: Lottie.asset("assets/LottieAnimation/winner.json" ,height: 150,width: 150,fit: BoxFit.cover)),
                      ],
                    ),
                    SizedBox(
                      height: 15,
                    ),
                    Text("VOTE AND\nGET REWARD",textAlign: TextAlign.center,style: TextStyle(
                      color: Color(0xffda261e),fontWeight: FontWeight.w500,fontSize: 20,
                    ),),
                    Container(
                      margin: EdgeInsets.all(20),
                      child: Text("Get a chance to be rewarded by voting.",textAlign: TextAlign.center,style: TextStyle(
                        color: Colors.white,fontWeight: FontWeight.w300,fontSize: 16,
                      ),),
                    )
                  ],
                ),
              ),
            ],

          ),
        ),


              Container(
                width: w,
                color: Colors.black,
                child: Column(
                  children: [


                    SizedBox(
                      height: 25,

                    ),
                    Text(
                      'OUR SPECIALIZATIONS',
                      style: new TextStyle(
                          fontSize: 28.0,
                          fontWeight: FontWeight.w800,
                          foreground: new Paint()..shader = linearGradient),textAlign: TextAlign.center,
                    ),
                    HorizentaLine(width: w*0.3,),
                    Container(
                      margin: EdgeInsets.all(20),
                      child: Text("The Film production categories we are specialized in",textAlign: TextAlign.center,style: TextStyle(
                        color: Colors.white,fontWeight: FontWeight.w300,fontSize: 16,
                      ),),
                    ),
                    // The Film production categories we are specialized in

                  Row(
                     mainAxisSize: MainAxisSize.max,
                     children: [
                       Obx(() =>homeController.specilizationModel.value!=null? Expanded(
                           child: Padding(
                             padding: const EdgeInsets.all(8.0),
                             child: GridView.count(
                                 crossAxisCount: 2,
                                 shrinkWrap: true,
                                 physics: NeverScrollableScrollPhysics(),
                                 scrollDirection: Axis.vertical,
                                crossAxisSpacing: 15,
                               mainAxisSpacing: 15,
                               children:List.generate(homeController.specilizationModel.value.length, (index) =>new OurSpecialization(url: homeController.specilizationModel.value[index].poster, title:  homeController.specilizationModel.value[index].title,),
                               ),
                             ),
                           ),
                         ):Container(),
                       ),
                     ],
                   ),
                    SizedBox(
                      height: 25,
                    ),
                    Container(
                      margin: EdgeInsets.all(20),
                      child: Text("It is a matter of pride for us to have a team of people having grounded values and strong principles "
                          "thus converting the same into collective growth and progress. We welcome entrepreneurs having great ideas "
                          "and contemporary thoughts but not having a mentor to guide and provide peer direction to them. Our production"
                          " house will help such talented people and integrate their proposal. In fact we will be more than happy to "
                          "get more such talents as we are passionate to paint the sky with meaningful messages through our work.",
                      textAlign: TextAlign.center,
                        style: TextStyle(color: Colors.white
                            ,fontSize: 15.0,fontWeight: FontWeight.w400
                        ),overflow: TextOverflow.ellipsis,
                       maxLines: 7,
                      ),
                    ),
                    SizedBox(
                      height: 25,
                    ),
                    Container(
                      width: w*0.5,
                      height: 41,
                      child: RaisedGradientButton(
                        child: Text(
                          'Get A Quote Now',
                          style: TextStyle(color: Colors.white,
                              fontSize: 16,fontWeight: FontWeight.w600
                          ),
                        ),
                        gradient: LinearGradient(
                          colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
                        ), onClicked: () {

                         Navigator.push(context, MaterialPageRoute(builder: (context)=>Services(openDrawer: () {  },flag: 2,))) ;

                      },

                      ),
                    ),
                    SizedBox(
                      height: 25,

                    ),
                  ],
                ),
              ),
              Stack(
                children: [
                  AspectRatio(
                    aspectRatio: 16/5.3,
                    child: Image(image: AssetImage("assets/Images/sing_banner.jpeg"),fit:BoxFit.fill,),
                  ),

                  Container(
                    margin: EdgeInsets.only(top: 80),
                    alignment: Alignment.center,
                    child: Container(
                        width: 100,
                        height: 25,
                        child: RaisedGradientButton(
                          child: Text(
                            '  KNOW MORE  ',
                            style: TextStyle(color: Colors.white,
                                fontSize: 12,fontWeight: FontWeight.w600
                            ),
                          ),
                          gradient: LinearGradient(
                            colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
                          ), onClicked: () {

                          Navigator.push(context, MaterialPageRoute(builder: (context)=>WinYourPrice())) ;

                        },

                        ),
                      ),
                  )
                ],
              ),
              SizedBox(height: 10,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [

                  RawMaterialButton(onPressed: (){
                    lunchInBrowser(facebookLink);
                  },
                    constraints: BoxConstraints(minWidth: 25,minHeight: 25),
                    child: Icon(FontAwesomeIcons.facebookF,color: Color(0xffff9000),size: 18,),
                    splashColor: Color(0xffff3300),
                    focusColor: Colors.amberAccent,
                    fillColor: Colors.black87,
                    shape:CircleBorder(),
                    elevation: 8,
                    padding: EdgeInsets.all(12),

                  ),

                  RawMaterialButton(onPressed: (){
                    lunchInBrowser(lunchurltwitter);
                  },
                    constraints: BoxConstraints(minWidth: 25,minHeight: 25),
                    child: Icon(FontAwesomeIcons.twitter,color: Color(0xffff9000),size: 18,),
                    splashColor: Color(0xffff3300),
                    focusColor: Colors.amberAccent,
                    fillColor: Colors.black87,
                    shape:CircleBorder(),
                    elevation: 8,
                    padding: EdgeInsets.all(12),

                  ),
                  RawMaterialButton(onPressed: (){
                    lunchInBrowser(linkedinUrl);
                  },
                    constraints: BoxConstraints(minWidth: 25,minHeight: 25),
                    child: Icon(FontAwesomeIcons.linkedinIn,color: Color(0xffff9000),size: 18,),
                    splashColor: Color(0xffff3300),
                    focusColor: Colors.amberAccent,
                    fillColor: Colors.black87,
                    shape:CircleBorder(),
                    elevation: 8,
                    padding: EdgeInsets.all(12),


                  ),
                  RawMaterialButton(onPressed: (){
                    lunchInBrowser(instagramUrl);
                  },
                    constraints: BoxConstraints(minWidth: 25,minHeight: 25),
                    child: Icon(FontAwesomeIcons.instagram,color: Color(0xffff9000),size: 18,),
                    splashColor: Color(0xffff3300),
                    focusColor: Colors.amberAccent,
                    fillColor: Colors.black87,
                    shape:CircleBorder(),
                    elevation: 8,
                    padding: EdgeInsets.all(12),

                  ),
                  RawMaterialButton(onPressed: (){
                    lunchInBrowser(pinterestUrl);
                  },
                    constraints: BoxConstraints(minWidth: 25,minHeight: 25),
                    child: Icon(FontAwesomeIcons.pinterest,color: Color(0xffff9000),size: 18,),
                    splashColor: Color(0xffff3300),
                    focusColor: Colors.amberAccent,
                    fillColor: Colors.black87,
                    shape:CircleBorder(),
                    elevation: 8,
                    padding: EdgeInsets.all(12),

                  ),
                ],
              ),
              SizedBox(height: 10,),

            ],

          ),
        ),
      ),




    );
  }

}
