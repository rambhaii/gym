
import 'dart:async';
import 'dart:math';
import 'package:confetti/confetti.dart';
import 'package:flutter/material.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/DashBoard/Dashboard.dart';
import 'package:parnamtv/User/MyProfile/Login.dart';

class Splash extends StatefulWidget {

  @override
  _SplashState createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      // Replace the 3 second delay with your initialization code:
         future: Future.delayed(Duration(seconds: 4)),
         builder: (context, AsyncSnapshot snapshot) {
        // Show splash screen while waiting for app resources to load:
        if (snapshot.connectionState == ConnectionState.waiting) {
          return MaterialApp(
              debugShowCheckedModeBanner: false,
              home:Splash1());
        } else {
          // Loading is done, return the app:
          return MaterialApp(
              debugShowCheckedModeBanner: false,
              home: ParnamTv.sharedPreference.getString(ParnamTv.userID)==null?
              Login():Dashboard(),

          );
        }
      },
    );
  }
  }

class Splash1 extends StatefulWidget {

  @override
  State<Splash1> createState() => _Splash1State();
}

class _Splash1State extends State<Splash1> with TickerProviderStateMixin {
  AnimationController ?_controller;
  ConfettiController? confController;

  @override
  void initState() {
    super.initState();
    confController = ConfettiController(duration: Duration(seconds: 3));
    confController!.play();
    _controller = AnimationController(duration: const Duration(seconds:1), vsync: this);
    _controller!.forward();
  }
  @override
  void dispose(){
    super.dispose();
    confController!.dispose();
    this._controller!.dispose();
  }
  @override
  Widget build(BuildContext context) {

    return Scaffold(

      //backgroundColor: Color(0xFF1e2125),
      body: Stack(
        children: [

          Container(
            decoration: BoxDecoration(

              image: DecorationImage(
                  image:ExactAssetImage("assets/Images/whyus-bg.jpg"),
                  fit: BoxFit.cover
                    ),
                  ),

                ),

                ScaleTransition(
                  scale: Tween(begin: 0.1, end: 1.0)
                      .animate(CurvedAnimation(
                      parent: _controller!,
                      curve: Curves.easeInCirc
                     // curve: Curves.elasticIn
                  )
                  ),
                  child: Center(
                    child:Image.asset("assets/Images/logo.png" ,height: MediaQuery.of(context).size.height*0.25,width: MediaQuery.of(context).size.width*0.65,)
                  ),
                ),
          Positioned(
            top: 100,
            right: 40,
            child: ConfettiWidget(
              confettiController: confController!, //attach object created
              shouldLoop: true,
              blastDirection: -3.45 / 2,
              colors: [Colors.orange, Colors.red, Colors.green],
              gravity: 0.2,
              numberOfParticles: 10,
              createParticlePath: drawStar,
            ),
          ),
          Positioned(
            top: 100,
            left: 40,
            child: ConfettiWidget(
              confettiController: confController!, //attach object created
              shouldLoop: true,
              blastDirection: -3.45 / 2,
              colors: [Colors.orange, Colors.red, Colors.green],
              gravity: 0.2,
              numberOfParticles: 10,
              createParticlePath: drawStar,
            ),
          ),
          Positioned(
            bottom:100,
            right: 40,
            child: ConfettiWidget(
              confettiController: confController!, //attach object created
              shouldLoop: true,
              blastDirection: -3.45 / 2,
              colors: [Colors.orange, Colors.red, Colors.green],
              gravity: 0.2,
              numberOfParticles: 10,
              createParticlePath: drawStar,
            ),
          ),
          Positioned(
            bottom:100,
            left: 40,

            child: ConfettiWidget(
              confettiController: confController!, //attach object created
              shouldLoop: true,
              blastDirection: -2.8 / 2,
              colors: [Colors.orange, Colors.red, Colors.green],
              gravity: 0.2,
              numberOfParticles: 10,
              createParticlePath: drawStar,
            ),
          ),
          // ConfettiWidget(
          //   confettiController: confController!,
          //   blastDirectionality: BlastDirectionality.explosive,
          //   particleDrag: 0.05,
          //   emissionFrequency: 0.05,
          //   numberOfParticles: 50,
          //   gravity: 0.1,
          //   shouldLoop: true,
          //   colors: const [
          //     Colors.green,
          //     Colors.blue,
          //     Colors.pink,
          //     Colors.orange,
          //     Colors.purple
          //   ], // manually specify the colors to be used
          // ),
                 ],
      ),
    );
  }
  Path drawStar(Size size) {
    // Method to convert degree to radians
    double degToRad(double deg) => deg * (pi / 180.0);
    const numberOfPoints = 5;
    final halfWidth = size.width / 2;
    final externalRadius = halfWidth;
    final internalRadius = halfWidth / 2.5;
    final degreesPerStep = degToRad(360 / numberOfPoints);
    final halfDegreesPerStep = degreesPerStep / 2;
    final path = Path();
    final fullAngle = degToRad(360);
    path.moveTo(size.width, halfWidth);
    for (double step = 0; step < fullAngle; step += degreesPerStep) {
      path.lineTo(halfWidth + externalRadius * cos(step),
          halfWidth + externalRadius * sin(step));
      path.lineTo(halfWidth + internalRadius * cos(step + halfDegreesPerStep),
          halfWidth + internalRadius * sin(step + halfDegreesPerStep));
    }
    path.close();
    return path;
  }
}