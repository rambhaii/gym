// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

ViewAndWinData viewAndWinDataFromJson(String str) => ViewAndWinData.fromJson(json.decode(str));

String viewAndWinDataToJson(ViewAndWinData data) => json.encode(data.toJson());

class ViewAndWinData {
  ViewAndWinData({
    this.data,
  });

  List<Datum>?data;

  factory ViewAndWinData.fromJson(Map<String, dynamic> json) => ViewAndWinData(
    data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.viewWinCateId,
    this.viewWinCateTitle,
    this.list,
  });

  String?viewWinCateId;
  String?viewWinCateTitle;
  List<ListElement>?list;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    viewWinCateId: json["viewWinCateID"],
    viewWinCateTitle: json["viewWinCateTitle"],
    list: List<ListElement>.from(json["list"].map((x) => ListElement.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "viewWinCateID": viewWinCateId,
    "viewWinCateTitle": viewWinCateTitle,
    "list": List<dynamic>.from(list!.map((x) => x.toJson())),
  };
}

class ListElement {
  ListElement({
    this.id,
    this.viewWinCategoryMasterId,
    this.title,
    this.poster,
    this.releasingDate,
    this.starCast,
    this.plot,
    this.videoFile,
    this.producedBy,
    this.directedBy,
    this.writingCredits,
    this.status,
    this.createdAt,
  });

  String?id;
  String?viewWinCategoryMasterId;
  String?title;
  String?poster;
  String?releasingDate;
  String?starCast;
  String?plot;
  String?videoFile;
  String?producedBy;
  String?directedBy;
  String?writingCredits;
  String?status;
  dynamic?createdAt;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
    id: json["id"],
    viewWinCategoryMasterId: json["view_win_category_master_id"],
    title: json["title"],
    poster: json["poster"],
    releasingDate: json["releasing_date"],
    starCast: json["star_cast"],
    plot: json["plot"],
    videoFile: json["video_file"],
    producedBy: json["produced_by"],
    directedBy: json["directed_by"],
    writingCredits: json["writing_credits"],
    status: json["status"],
    createdAt: json["created_at"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "view_win_category_master_id": viewWinCategoryMasterId,
    "title": title,
    "poster": poster,
    "releasing_date": releasingDate,
    "star_cast": starCast,
    "plot": plot,
    "video_file": videoFile,
    "produced_by": producedBy,
    "directed_by": directedBy,
    "writing_credits": writingCredits,
    "status": status,
    "created_at": createdAt,
  };
}
