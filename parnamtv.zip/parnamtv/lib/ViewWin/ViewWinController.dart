import 'package:get/get.dart';

class ViewWinController extends GetxController{



}