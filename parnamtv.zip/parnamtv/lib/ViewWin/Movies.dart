import 'package:better_player/better_player.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
class Movies extends StatefulWidget {
  final String id;
  final String name;
  final String url;
  final String sortdescription;
  final String releasingdate;
  final String description;

   const Movies({Key?key,
    required this.id,
     required this.name,
     required this.url,
     required this.sortdescription,
     required this.releasingdate,required this.description}) : super(key: key);

  @override
  _MoviesState createState() => _MoviesState();
}

class _MoviesState extends State<Movies> {
  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Scaffold(

      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text(widget.name),
      ),
      body: SingleChildScrollView(
         child: Column(
           crossAxisAlignment: CrossAxisAlignment.start,
           children: [
             Container(
               margin: EdgeInsets.all(10),
               
               child: AspectRatio(
                 aspectRatio: 16 / 9,
                 child: BetterPlayer.network(
                   widget.url,
                   betterPlayerConfiguration: BetterPlayerConfiguration(
                     aspectRatio: 16 / 9,
                     autoPlay: true,

                   ),
                 ),

               ),
             ),

             Card(
               margin: EdgeInsets.only(top: 2,left: 10,right: 10),

               child: Container(
                 width: w,
                 height: h,
                 padding: EdgeInsets.all(10),
                 child:SingleChildScrollView(
                   child: Column(
                     crossAxisAlignment: CrossAxisAlignment.start,
                     children: [
                       Text(widget.name, style:TextStyle( fontSize: 22.0,color:Colors.black,fontWeight: FontWeight.bold
                       ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,),
                       SizedBox(
                         height: 10,
                       ),
                       Text(widget.sortdescription, style:TextStyle( fontSize: 16.0,color:Colors.black,fontWeight: FontWeight.w300
                       ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 3,),
                       SizedBox(
                         height: 10,
                       ),
                       Container(
                         child: Divider(
                           color: Colors.black,
                           height: 5,
                         ),
                       ),
                       SizedBox(
                         height: 10,
                       ),
                       Text('Realese Date : '+widget.releasingdate, style:TextStyle( fontSize: 14.0,color:Colors.black,fontWeight: FontWeight.w300
                       ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 1,),
                       SizedBox(
                         height: 5,
                       ),
                       Text('Description : '+widget.description, style:TextStyle( fontSize: 14.0,color:Colors.black,fontWeight: FontWeight.w300
                       ),overflow: TextOverflow.ellipsis,textAlign: TextAlign.start,maxLines: 10,),
                     ],
                   ),
                 )
                
               ),
             ),
         
           ],
         ),
      ),
    );
  }
}
