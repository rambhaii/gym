import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:parnamtv/Data/MoviesData.dart';
import 'package:parnamtv/Data/TvSeriseData.dart';
import 'package:parnamtv/ViewWin/Data/ViewAndWindata.dart';
import 'package:parnamtv/ViewWin/Movies.dart';
import 'package:parnamtv/Widget/CircularLoader.dart';
import 'package:http/http.dart' as http;
import 'package:parnamtv/Widget/DrawerMenuWidget.dart';
import 'package:parnamtv/Widget/HorizentalLine.dart';
import 'package:parnamtv/Widget/MovieView.dart';

import '../DashBoard/Controller/SliderController.dart';
class ViewWin extends StatefulWidget {
  final VoidCallback openDrawer;
  const ViewWin(
      {
        Key?key,
        required this.openDrawer,
      }):super(key: key);
  @override
  _ViewWinState createState() => _ViewWinState();
}

class _ViewWinState extends State<ViewWin> {
  int _current=0;
  SliderController sliderController=Get.put(SliderController());



  bool isReady =false;
  bool isReady1 =false;
  late ViewAndWinData viewAndWinData;
  List<T> map<T>(List list,Function handler)
  {
    List<T> result=[];
    for(var i=0 ;i < list.length; i++)
    {
      result.add(handler(i,list[i]));
    }
    return result;
  }

     Future getAllData() async{
         var url=Uri.parse('https://pranamtv.com/api/front/Subscription/GetViewWins??offset=0&limit=4');
         var response=await http.get(url,headers: {'x-api-key':'api@pranamtv.com'});
        // print("viewandresponse${response.body}");
         if(response.statusCode==200)
           {
             setState(() {
               viewAndWinData=viewAndWinDataFromJson(response.body);
               isReady=true;
             });
           }
     }
  // Future getAllTvShow() async{
  //   var url=Uri.parse("https://pranamtv.com/api/front/Upcoming/GetTvSeries?limit=10&start=0");
  //   var response=await http.get(url,headers: {'x-api-key':'api@pranamtv.com'});
  //   if(response.statusCode==200)
  //   {
  //      print("tvShow,${response.body}");
  //       setState(() {
  //       tvshowdata=tvSeriseDataFromJson(response.body);
  //       isReady1=true;
  //     });
  //   }
  // }
     @override
  void initState() {
    // TODO: implement initState
       sliderController.getSlider("1");
    super.initState();
    getAllData();
   // getAllTvShow();
  }
  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Scaffold(
    backgroundColor: Colors.black,
      appBar: AppBar(
        title: Text("View & Win"),
        backgroundColor: Colors.black,
        leading:  DrawerMenuWidget(onClicked: widget.openDrawer),

      ),
      body:SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.max,
          children: [
            Obx(() =>sliderController.sliderList.value!=null? Stack(
              children: [
                CarouselSlider(
                  options: CarouselOptions(
                    height: h*0.2,
                    aspectRatio: 16/9,
                    viewportFraction: 0.85,
                    initialPage: 0,
                    enableInfiniteScroll: true,
                    reverse: false,
                    autoPlay: true,
                    autoPlayInterval: Duration(seconds: 2),
                    autoPlayAnimationDuration: Duration   (milliseconds: 1500),
                    autoPlayCurve: Curves.fastOutSlowIn,
                    enlargeCenterPage: true,
                    scrollDirection: Axis.horizontal,
                    onPageChanged:(index, reason){
                      sliderController.onChangePage(index);
                    },

                  ),


                  items: sliderController.sliderList.map((imgUrl) {
                    return Builder(
                      builder: (BuildContext context) {
                        return Container(
                          width:w,
                          //margin: EdgeInsets.symmetric(horizontal: 0.0),
                          decoration: BoxDecoration(
                            color: Colors.black45,

                          ),
                          child: Image.network(imgUrl.poster??"",fit: BoxFit.cover,),
                        );
                      },
                    );
                  }).toList(),
                ),
                Container(
                  margin: EdgeInsets.only(top: h*0.2),
                  child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children:map<Widget>(
                          sliderController.sliderList,(Index,url){
                        return Container(
                          width: 10.0,
                          height: 10.0,
                          margin:EdgeInsets.symmetric(vertical: 10.0,horizontal: 2.0) ,
                          decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              color: sliderController.index.value==Index?Colors.amberAccent:Colors.red
                          ),
                        );
                      }
                      )
                  ),
                ),

              ],
            ):Container(),
            ),
            isReady==true? Row(
              children: [
                Expanded(
                  child: ListView.builder(
                  itemCount: viewAndWinData.data!.length,
                  physics: NeverScrollableScrollPhysics(),
                  shrinkWrap: true,
                  itemBuilder: (context,index){
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            FaIcon(FontAwesomeIcons.film,color: Color(0xffda261e),),
                            Text("  "+viewAndWinData.data![index].viewWinCateTitle!,style: TextStyle(color:Color(0xffda261e),
                                fontWeight: FontWeight.w500,fontSize:20.0)),
                          ],

                        ),
                        SizedBox(
                          height: 5.0,
                        ),
                        HorizentaLine(
                          width: w*0.3,
                        ),
                        Container(
                             width: w,
                          height: h*0.31,
                          margin: EdgeInsets.all(10),
                          child: GridView.builder(
                            gridDelegate: new SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:  1,
                              childAspectRatio: 0.9/0.72
                            ),
                            scrollDirection: Axis.horizontal,
                            itemCount:viewAndWinData.data![index].list!.length,
                            itemBuilder: (BuildContext context, int index2) =>new
                              InkWell(
                                onTap: ()
                                {
                                  Navigator.push(context,
                                    MaterialPageRoute(builder: (context)=>Movies(
                                      releasingdate: viewAndWinData.data![index].list![index2].releasingDate!,
                                      id: viewAndWinData.data![index].list![index2].id!,
                                      url: viewAndWinData.data![index].list![index2].videoFile!,
                                      description:viewAndWinData.data![index].list![index2].plot!,
                                      name:  viewAndWinData.data![index].list![index2].title!,
                                      sortdescription: viewAndWinData.data![index].list![index2].starCast!,
                                    ))
                                  );
                                },
                                child: MovieView(
                                  Plot:viewAndWinData.data![index].list![index2].plot!,
                                  moviename:  viewAndWinData.data![index].list![index2].title!,
                                  releasing:  viewAndWinData.data![index].list![index2].releasingDate!,
                                  starcost: viewAndWinData.data![index].list![index2].starCast!,
                                  imageUrl:  viewAndWinData.data![index].list![index2].poster!,
                                ),
                              ),
                            ),
                        )
                      ],
                    );
                      },
                    ),
                ),
              ],
            ):CircularLoader(),

          ],
        ),
      ),
    );  }
}
