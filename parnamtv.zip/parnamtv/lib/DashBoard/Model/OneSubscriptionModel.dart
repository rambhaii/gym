// To parse this JSON data, do
//
//     final oneSubscriptionModel = oneSubscriptionModelFromJson(jsonString);

import 'dart:convert';

OneSubscriptionModel oneSubscriptionModelFromJson(String str) => OneSubscriptionModel.fromJson(json.decode(str));

String oneSubscriptionModelToJson(OneSubscriptionModel data) => json.encode(data.toJson());

class OneSubscriptionModel {
  OneSubscriptionModel({
    this.data,
  });

  Data ?data;

  factory OneSubscriptionModel.fromJson(Map<String, dynamic> json) => OneSubscriptionModel(
    data: Data.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Data": data!.toJson(),
  };
}

class Data {
  Data({
    this.status,
    this.message,
    this.list,
  });

  int? status;
  String ?message;
  List<ListElement>? list;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    status: json["status"],
    message: json["message"],
    list: List<ListElement>.from(json["list"].map((x) => ListElement.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "list": List<dynamic>.from(list!.map((x) => x.toJson())),
  };
}

class ListElement {
  ListElement({
    this.id,
    this.title,
    this.banner,
    this.clickLink,
  });

  String ?id;
  String ?title;
  String ?banner;
  String ?clickLink;

  factory ListElement.fromJson(Map<String, dynamic> json) => ListElement(
    id: json["id"],
    title: json["title"],
    banner: json["banner"],
    clickLink: json["click_link"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "banner": banner,
    "click_link": clickLink,
  };
}
