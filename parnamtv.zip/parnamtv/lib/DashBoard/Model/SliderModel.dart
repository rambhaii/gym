// To parse this JSON data, do
//
//     final sliderModule = sliderModuleFromJson(jsonString);

import 'dart:convert';

SliderModule sliderModuleFromJson(String str) => SliderModule.fromJson(json.decode(str));

String sliderModuleToJson(SliderModule data) => json.encode(data.toJson());

class SliderModule {
  SliderModule({
    this.data,
  });

  Data ?data;

  factory SliderModule.fromJson(Map<String, dynamic> json) => SliderModule(
    data: Data.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Data": data!.toJson(),
  };
}

class Data {
  Data({
    this.status,
    this.message,
    this.list,
  });

  int ?status;
  String ?message;
  List<SliderDatum>? list;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    status: json["status"],
    message: json["message"],
    list: List<SliderDatum>.from(json["list"].map((x) => SliderDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "list": List<dynamic>.from(list!.map((x) => x.toJson())),
  };
}

class SliderDatum {
  SliderDatum({
    this.id,
    this.title,
    this.pageUrl,
    this.poster,
  });

  String? id;
  String ?title;
  String ?pageUrl;
  String ?poster;

  factory SliderDatum.fromJson(Map<String, dynamic> json) => SliderDatum(
    id: json["id"],
    title: json["title"],
    pageUrl: json["page_url"],
    poster: json["poster"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "page_url": pageUrl,
    "poster": poster,
  };
}
