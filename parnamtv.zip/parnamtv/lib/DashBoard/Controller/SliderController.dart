import 'package:get/get.dart';
import 'package:parnamtv/DashBoard/Model/OneSubscriptionModel.dart';
import 'package:parnamtv/DashBoard/Model/SliderModel.dart';
import 'package:parnamtv/Data/ContextData.dart';
import 'package:parnamtv/Data/OurSpecilization.dart';
import 'package:parnamtv/Utils/RemoteService.dart';



class SliderController extends GetxController{
  RxList<SliderDatum> sliderList=RxList<SliderDatum>([]);
  RxList<ContestDatum> contestData=RxList<ContestDatum>();
  RxInt index=RxInt(0);

  getSlider(String id){
    RemoteService.getSlider(id).then((valuedata) {
      sliderList.value=valuedata.data!.list!;
    });
  }
  onChangePage(int currentPage){
    index.value=currentPage;
  }

  getContest(){
    RemoteService.getAllContest().then((value){
      contestData.value=value.data!;
    });
  }
}