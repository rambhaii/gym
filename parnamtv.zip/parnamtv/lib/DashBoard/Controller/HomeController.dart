import 'package:firebase_remote_config/firebase_remote_config.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:parnamtv/DashBoard/Model/OneSubscriptionModel.dart';
import 'package:parnamtv/Data/OurSpecilization.dart';
import 'package:parnamtv/Utils/RemoteService.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';



class HomeController extends GetxController{
   RxList<ListElement> OneSubModel=RxList<ListElement>([]);

   RxInt index=RxInt(0);
   RxList<SpecilizationDatum> specilizationModel=RxList<SpecilizationDatum>([]);
  @override
  void onInit()async {

    setupRemoteConfig();
    //checkDaiolog(newVersion);
    fetchApi();
    getOneSubscriptionApi();
    super.onInit();
  }
  fetchApi(){
    RemoteService.getOneSubscription().then((valuedata) {
      OneSubModel.value=valuedata!.data!.list!;
    });
  }
   getOneSubscriptionApi(){
     RemoteService.geturSpecilization().then((valuedata) {
       specilizationModel.value=valuedata.data;
     });
   }
   onChangePage(int currentPage){
     index.value=currentPage;
   }

    setupRemoteConfig() async {
     PackageInfo packageInfo = await PackageInfo.fromPlatform();
      String version = packageInfo.version;
      String buildNumber = packageInfo.buildNumber;
      print(version+"  dbvbhbhvbhv  "+buildNumber);
     final  remoteConfig = FirebaseRemoteConfig.instance;
     remoteConfig.setConfigSettings(
      RemoteConfigSettings(fetchTimeout: Duration(seconds: 10), minimumFetchInterval: Duration.zero)
     );
    await remoteConfig.fetch();
    await remoteConfig.activate();
    if(remoteConfig.getValue('PranamTv').asBool())
        {
       if(version!=remoteConfig.getValue('version').asString())
         {
           _update(remoteConfig.getString('pranamtv_url'));
         }
        }

    //  print(remoteConfig.getValue('version').asString());

   }
   void _update(String url) {
     showCupertinoDialog(
         context: Get.context!,
         builder: (BuildContext ctx) {
           return CupertinoAlertDialog(
             title: const Text('Update ! '),
             content: const Text('New Update is Available'),
             actions: [
               // The "Yes" button
               CupertinoDialogAction(
                 onPressed: () {
                   Get.back();
                   },
                 child: const Text('May be later'),
                 isDefaultAction: true,
                 isDestructiveAction: true,
               ),
               // The "No" button
               CupertinoDialogAction(
                 onPressed: () {
                   _lunchInBrowser(url);
                 },
                 child: const Text('Install'),
                 isDefaultAction: false,
                 isDestructiveAction: false,
               )
             ],
           );
         });
   }
   Future<void> _lunchInBrowser(String url) async
   {
     if(await canLaunch(url))
     {
       await launch(url,forceSafariVC: false,forceWebView: false,
           headers: <String,String>{"headesr_key":  "headers_value"}
       );

     }
     else{
       throw "url not lunched $url";
     }
   }
}
