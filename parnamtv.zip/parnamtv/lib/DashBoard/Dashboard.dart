
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:parnamtv/CommingSoon/CommingSoon.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Contest/Contest.dart';
import 'package:parnamtv/DashBoard/about_us.dart';
import 'package:parnamtv/Home/home_page.dart';
import 'package:parnamtv/Data/drawer_items.dart';
import 'package:parnamtv/Modal/drawer_iteam.dart';
import 'package:parnamtv/OurShow/our_show.dart';
import 'package:parnamtv/Service/Services.dart';
import 'package:parnamtv/User/MyProfile/Login.dart';
import 'package:parnamtv/ViewWin/ViewWin.dart';
import 'package:parnamtv/Widget/Drawer_widget.dart';
import 'package:parnamtv/themes/app_theme.dart';
class Dashboard extends StatefulWidget {

  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  late double xOffset;
  late double yOffset;
  late   double scaleFactor ;
  late bool  isDrawerOpen;
  bool isDragging=false;
  int index =2;
  DrawerIteam item=DrawerItems.home;
  @override
  void initState() {
    // TODO: implement initState
    closedrawer();
    super.initState();
  }
  void openDrawer()
  {
    setState(() {
      xOffset=230;
       yOffset= 150;
       scaleFactor=0.6;
       isDrawerOpen=true;
    });
  }
  void closedrawer()
  {
    setState(() {
      xOffset=0;
       yOffset= 0;
       scaleFactor=1;
      isDrawerOpen=false;

    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     backgroundColor: Colors.transparent,

      body:Stack(
        children: [
          Container(
            decoration: BoxDecoration(

              // color: Colors.black45,
              image: DecorationImage(
                  image:ExactAssetImage("assets/Images/whyus-bg.jpg"),
                  fit: BoxFit.cover
              ),
            ),
          ),
          buildDrawer(),
          buildPage(),

        ],
      ),

    );
  }
  Widget buildDrawer()=>Container(
    width: xOffset,

    child: SafeArea(
      child: SingleChildScrollView(child:
      Column(
        mainAxisSize: MainAxisSize.max,
        children: [
          DrawerWidget(
            onSelectedItem: (item){
              setState(()=>this.item=item);
              closedrawer();
            },
          ),

       

        ],

      ),
      ),
    ),
  );
  Widget buildPage(){

    return WillPopScope(
      onWillPop: ()async{
        if(isDrawerOpen)
          {
            closedrawer();
            return false;
          }
        else{
          return true;
        }
      },
      child: GestureDetector(
        onTap: closedrawer,
        onHorizontalDragStart: (details)=>isDragging=true,
        onHorizontalDragUpdate: (details){
          if(!isDragging) return;
          const delta=1;
          if(details.delta.dx>delta){
            openDrawer();
          }else if(details.delta.dx < -delta)
            {
              closedrawer();
            }
          isDragging=false;
        },
        child: AnimatedContainer(
          transform: Matrix4.translationValues(xOffset, yOffset, 0)..scale(scaleFactor),
            duration: Duration(milliseconds: 250),
            child: AbsorbPointer(
              absorbing: isDrawerOpen,
                child: ClipRRect(
                  borderRadius:BorderRadius.circular(isDrawerOpen?20:0) ,
                  child: Container(
                    color: isDrawerOpen?Colors.amberAccent:Theme.of(context).primaryColor,
                      child: getDrawerPage(),
                  ),
                )
            )
        ),
      ),
    );
  }
  Widget getDrawerPage(){
    switch(item)
    {
      case DrawerItems.About:
        return AboutUs(openDrawer:openDrawer);
      case DrawerItems.OurService:
        return Services(openDrawer:openDrawer);
      case DrawerItems.Commmingshow:
        return CommingSoon(openDrawer:openDrawer);
      case DrawerItems.contest:
        return Contest(openDrawer:openDrawer);
      case DrawerItems.viewwin:
        return ViewWin(openDrawer:openDrawer);
      case DrawerItems.ourshows:
        return OurShow(openDrawer:openDrawer);
        default:
        return HomePage(openDrawer: openDrawer);
    }
  }

  void logout() {
    ParnamTv.sharedPreference.clear();
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Login()));
   // Navigator.pop(context);
  }

}
