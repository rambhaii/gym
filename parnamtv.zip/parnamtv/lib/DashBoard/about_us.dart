import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:parnamtv/Data/OurSpecilization.dart';
import 'package:http/http.dart' as http;
import 'package:parnamtv/Widget/AboutUsWidget.dart';
import 'package:parnamtv/Widget/DrawerMenuWidget.dart';
import 'package:parnamtv/Widget/OurSpecializationWidget.dart';
class AboutUs extends StatefulWidget {
  final VoidCallback openDrawer;
  const AboutUs(
      {
        Key?key,
        required this.openDrawer,
      }):super(key: key);
  @override
  _AboutUsState createState() => _AboutUsState();
}

class _AboutUsState extends State<AboutUs> {
  var ourSpecilizationData;

  @override
  void initState() {
    // callapi();
//  callApis();
   // ourSpecilizationData;
    getOurSpecilization();

    // TODO: implement initState
    super.initState();
  }
 Future  getOurSpecilization() async{
    var url=Uri.parse('https://pranamtv.com/api/front/GetOurSpecialization?limit=10&start=0');
    var response = await http.get(url,headers: {'x-api-key':'api@pranamtv.com'});
    if(response.statusCode==200)
    {
       ourSpecilizationData=ourSpecilizationDataFromJson(response.body);
      print("jfdsjjgfdj,${ourSpecilizationData.data[0].poster}");
    }
    else{

    }
    // OurSpecilizationData ourSpecilizationData=OurSpecilizationData.fromJson(jsonDecode(response.body));
    // print('datttta,${ourSpecilizationData.data}');
  }
  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Scaffold(
    backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Color(0xFF1e2125),
          title: Text("About Us"),
          leading:  DrawerMenuWidget(onClicked: widget.openDrawer),
        ),
      body: SingleChildScrollView(
        child: Column(
         children: [
           Container(
             width: w,
               height: h*0.2,
               margin: EdgeInsets.all(10),
               child: Image.asset("assets/Images/aboutus.jpg",fit: BoxFit.fill,)
           ),
           AboutUsWidget(gradienttext: '"Being a 24 X7 web entertainment channel and media service provider, our vision is to be the culturally rich Entertainment Company with a motto of entertaining and enriching the life of every national and international viewer’s through sustained innovation."',
             Aboutus: 'I am proud to introduce my strength - “All the members of Pranam team” - together we are putting our efforts to help out and guide the people in exploring Uttar Pradesh.As mentioned earlier that Uttar Pradesh is very rich in its heritage and cultural values. And we being quite touchy for our state are committed to show people the actual value of our state.\n\n'
                 "In addition to this, Pranam TV Network is also committed to provide platform through our shows to singers actors directors etc, to provide support to new film makers, local support for shooting in any city of Uttar Pradesh, bring out the hidden talents of our state and provide them a platform by which they can show there talents to the world. \n\n"
                 "This initiative struck us from the point that many people have great executable thoughts and vision but they do not get the right platform and required resources to achieve it. ",
             Imgpath:'assets/Images/chairman.jpg' ,
             name: 'Parneet Chaturvedi',
             departemnt: 'Founder & CEO',

           ),
           AboutUsWidget(gradienttext: 'Harish Kumar is an Indian film director and producer, screenplay writer in Bollywood. He directed his first movie Muzaffarnagar the burning love (Released 2017) which is quite controversial and banned in Uttar Pradesh, Uttar Khand staring Dev Sharma, Aishwarya Devan, Mursaleem Qureshi and song sung by Mohit chahuan and Nakaj Aziz, He also produced the very successful Marathi movie Pakada Pakadi (2011) staring Ashok Saraf, Tejaswini Pandit, Prasad oak.',
             Imgpath:'assets/Images/harish.jpg' ,
             name: 'Harish Kumar',
             departemnt: 'Vice President',
             Aboutus: 'He started his career as art director and worked on Journey Bombay to goa (2007),Desire a journey of a women (2010-11), mumbai cutting(2015) ,31 October  starting Soha ali khan , Veer Das and Do Aur Do Panch (2011) staring Salman khan , Arbaaz Khan but unfortunately it is not released.'
                 '\n\nHe is known for making independent films. He also worked as a creative director and director for many ad films and music videos. ',

           ),
           AboutUsWidget(gradienttext: '"He is a youth icon for new singing and acting talents in India. He has a very creative mind and helped many big directors and producers with his new innovative ideas. "',
             Aboutus: 'We are very thankfull to him, because he is a part of our new venture PRANAM TV. ',
             Imgpath:'assets/Images/mayank.jpg' ,
             name: 'Mayank Verma',
             departemnt: 'Vice President',

           ),
           AboutUsWidget(gradienttext: '"Being a 24 X7 web entertainment channel and media service provider, our vision is to be the culturally rich Entertainment Company with a motto of entertaining and enriching the life of every national and international viewer’s through sustained innovation."',
             Imgpath:'assets/Images/rajendra.jpg' ,
             name: 'Rajendra Varman',
             departemnt: 'Programming Head',
             Aboutus: 'An alumni of the prestigious Film Institute - FTII, Pune, Rajendra Varman has more than 20 years of experience in Film and Television production in the film & Television Industries of Mumbai and South India.\n\n'
                 "As part of the Hindi film Industry, he has been associated with the films of many big names of the Industry like, Aziz Mirza, Kalpana Lajmi, Jatin Lalit, Dr. Bhupen Hazarika, Santosh Sivan, Pradeep Kishen in films like, 'Yes Boss', Phir bhi dil hai Hindustani', 'Kyon' etc \n\n"
                 "He has also written and Directed Short films, Documentaries, Television Programmes, Public service advertisements for  various Producers, Television Channels and Government Departments \n\n"
                 "Currently he is engaged as the Associate Professor in the Screenplay & Direction Department of the K R Narayanan National Institute of Visual Science and Arts, Kerala.",

           ),
           AboutUsWidget(gradienttext: '“It’s our endeavor to put together shows that are laced with the earthiness of Uttar Pradesh as well as a reflection of the rich culture and heritage. A web platform that will give you a chance to hone your talent and will also encourage you to be yourself. All in all, for us, it’s all about Entertainment!! Entertainment!! Entertainment!!”',
             Imgpath:'assets/Images/salil.jpg' ,
             name: 'Salil Arunkumar Sand',
             departemnt: 'CCO – Chief Creative Officer',
             Aboutus: 'With over two decades of experience in writing, directing and creating some of Indian television’s highest rated and impactful fiction and non-fiction, Salil Arunkumar Sand is also a reputed entertainment journalist and a television and film analysts.\n\n'
                 "Some of the shows in which he demonstrated his creative prowess, that millions of viewers have enjoyed over the years, include Tara, Antakshari, Hum Paanch, Sa Re Ga Ma Pa, Indian Idol, Jassi Jaise Koi Nahin, Kyunki Saas Bhi Kabhi Bahu Thi, Kahin Toh Hoga, CID, Boogie Woogie and many more.\n\n"
                 "In the past, Salil has worked with leading media companies including Zee Entertainment, Sony Entertainment Television, B.A.G. Network, Balaji Telefilms, and Reliance Big Synergy. ",

           ),
           AboutUsWidget(gradienttext: 'Since over four decades he is a Business man in Europe. A Restaurant owner, import-export business from India and also working as a Yoga, Mental training instructor. He is also a lover of indian artists and want to help new talents to grow.',
             Imgpath:'assets/Images/rakesh.jpg' ,
             name: 'Rakesh Sood',
             departemnt: 'International associate Austria (Europe)',
             Aboutus: '  ',

           ),
         ],

          ),
      ),



    );
  }
}
