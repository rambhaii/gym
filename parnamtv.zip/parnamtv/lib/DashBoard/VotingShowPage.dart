import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:parnamtv/DashBoard/OurSchedule.dart';
import 'package:parnamtv/Home/LiveStreming.dart';
import 'package:parnamtv/User/Schedule.dart';
import 'package:parnamtv/Widget/FreeSubscriberWidget.dart';

import '../User/WinYourDream.dart';
import '../Widget/RaisedGradientButtonwidget.dart';

class VotingShowPage extends StatefulWidget {
  const VotingShowPage({Key? key}) : super(key: key);

  @override
  State<VotingShowPage> createState() => _VotingShowPageState();
}

class _VotingShowPageState extends State<VotingShowPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Voting Show"),
      ),
      body: Container(
        height: 450,
        child: FreeSubscriber(Url: "assets/Images/sing_banner.jpeg", yourSub: " 07:00 PM to 08:30 PM, Sunday to Sunday", heading: "Bollywood Breaking Gossips", description: "It is the show about the latest trends in Bollywood, gossips about stars and Current ...", registrationtime: "", onClick: (){}),
      ),
      bottomSheet: Container(
        color: Colors.black87,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Container(
              margin: EdgeInsets.all(12),
              width: 100,
              height: 33,
              child: RaisedGradientButton(
                child: Text(
                  '  LIVE  ',
                  style: TextStyle(color: Colors.white,
                      fontSize: 15,fontWeight: FontWeight.w600
                  ),
                ),
                gradient: LinearGradient(
                  colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
                ), onClicked: () {

                Navigator.push(context, MaterialPageRoute(builder: (context)=>LiveStream())) ;

              },

              ),
            ),
            Container(
              margin: EdgeInsets.all(12),
              width: 100,
              height: 33,
              child: RaisedGradientButton(
                child: Text(
                  '  SCHEDULED  ',
                  style: TextStyle(color: Colors.white,
                      fontSize: 15,fontWeight: FontWeight.w600
                  ),
                ),
                gradient: LinearGradient(
                  colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
                ), onClicked: () {

                Navigator.push(context, MaterialPageRoute(builder: (context)=>OurShedule())) ;

              },

              ),
            ),

          ],
        ),
      ),
    );
  }
}
