import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class OurShedule extends StatefulWidget {
  const OurShedule({Key? key}) : super(key: key);

  @override
  State<OurShedule> createState() => _OurSheduleState();
}

class _OurSheduleState extends State<OurShedule> {


  final DateFormat formatter = DateFormat('EEEE');
  final DateFormat formatterdate = DateFormat('dd-MM-yyyy');
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Our Schedule"),
      ),
      body: Container(
        margin: EdgeInsets.all(10),
        child: GridView.count(
            crossAxisCount: 2,
            crossAxisSpacing: 4.0,
            mainAxisSpacing: 8.0,
            childAspectRatio: 1/.5,
            children: List.generate(7, (ind) {
        DateTime date = DateTime.now();
        var data=date.subtract(new Duration(days: -(ind)));

        return Card(
          color: ind==0?Colors.blue:Colors.orange,
          elevation: 10,
          child: ListTile(
            onTap: (){

            },
      title: Text(formatter.format(data).toString(),style: TextStyle(color:Colors.white),),
            subtitle: Text(formatterdate.format(data).toString(),style:  TextStyle(color:Colors.white70),),
    ));

    }),
    //   itemBuilder: (context,ind){
          //     DateTime date = DateTime.now();
          //     var data=date.subtract(new Duration(days: -(ind)));
          //
          //     return Card(
          //       color: ind==0?Colors.blue:Colors.orange,
          //       elevation: 10,
          //       child: ListTile(
          //         onTap: (){
          //
          //         },
          //   title: Text(formatter.format(data).toString(),style: TextStyle(color:Colors.white),),
          //         subtitle: Text(formatterdate.format(data).toString(),style:  TextStyle(color:Colors.white70),),
          // ),
          //     );
        ),
      ),
    );
  }
}
