// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

LibraryData libraryDataFromJson(String str) => LibraryData.fromJson(json.decode(str));

String libraryDataToJson(LibraryData data) => json.encode(data.toJson());

class LibraryData {
  LibraryData({
    required this.data,
  });

  Data data;

  factory LibraryData.fromJson(Map<String, dynamic> json) => LibraryData(
    data: Data.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Data": data.toJson(),
  };
}

class Data {
  Data({
    required this.id,
    required  this.title,
    required this.category,
    required this.subcategory,
    required  this.quality,
    required  this.releaseYear,
    required  this.country,
    required  this.runningTime,
    required  this.bannerImg,
    required this.showDesc,
    required this.createdDate,
    required  this.status,
  });

  String id;
  String title;
  String category;
  String subcategory;
  String quality;
  String releaseYear;
  String country;
  String runningTime;
  String bannerImg;
  String showDesc;
  DateTime createdDate;
  String status;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    title: json["title"],
    category: json["category"],
    subcategory: json["subcategory"],
    quality: json["quality"],
    releaseYear: json["release_year"],
    country: json["country"],
    runningTime: json["running_time"],
    bannerImg: json["banner_img"],
    showDesc: json["show_desc"],
    createdDate: DateTime.parse(json["created_date"]),
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "category": category,
    "subcategory": subcategory,
    "quality": quality,
    "release_year": releaseYear,
    "country": country,
    "running_time": runningTime,
    "banner_img": bannerImg,
    "show_desc": showDesc,
    "created_date": createdDate.toIso8601String(),
    "status": status,
  };
}
