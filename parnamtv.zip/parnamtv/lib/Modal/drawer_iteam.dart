import 'package:flutter/material.dart';
class DrawerIteam{
  final String title;
  final IconData icon;
  const DrawerIteam({
    required this.title,
    required this.icon
});
}