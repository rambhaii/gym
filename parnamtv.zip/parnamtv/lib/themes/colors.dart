import 'package:flutter/material.dart';
@immutable
class AppColors{
  final white=const Color(0xFFFFFFFF);
  final black=const Color(0xFF000000);
  final mainBlue=const Color(0xFF003A6B);
  final coinGold=const Color(0xFFEFCB00);
  final green=const Color(0xFF00Df00);
  final primaryColor=const Color(0xFFff9000);
  final primaryDarkColor=const Color(0xFFda251d);
  final solidblue=const Color(0xFF051BA6);
  final black55=const Color(0xFFBFBFBF);

  const AppColors();
}