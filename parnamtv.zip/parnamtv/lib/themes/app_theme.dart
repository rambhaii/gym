import 'package:flutter/material.dart';

import 'colors.dart';


@immutable
class AppThem {
        static const colors= AppColors();
        const AppThem._();
        static ThemeData define(){
                return ThemeData(
                    primaryColor: Color(0xffd52a67),
                    accentColor: Color(0xffD5422A) ,
                    focusColor: Color(0xfee54b0)
                );
        }
}