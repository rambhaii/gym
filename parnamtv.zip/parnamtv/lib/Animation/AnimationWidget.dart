import 'package:flutter/material.dart';
class AnimationWidget extends StatefulWidget {
  final Widget child;
  final int sec;
  final double LRdir;
  final double UDdir;

  const AnimationWidget({Key? key, required this.child,required this.sec,required this.LRdir,required this.UDdir}) : super(key: key);

  @override
  _AnimationWidgetState createState() => _AnimationWidgetState();
}

class _AnimationWidgetState extends State<AnimationWidget> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  @override
  void initState() {
    // TODO: implement initState
    _controller =
        AnimationController(duration: Duration(seconds: widget.sec), vsync: this);
    _controller.forward();
    super.initState();
  }
  @override
  void dispose() {
    // TODO: implement dispose
    _controller.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) {
    return SlideTransition(
        position: Tween(
            begin: Offset(widget.LRdir,widget.UDdir),
            end: Offset(0.0, 0.0))
            .animate(CurvedAnimation(parent: _controller, curve: Curves.fastOutSlowIn)),
      child: widget.child,
    );
  }
}
