// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

OurShowData ourShowDataFromJson(String str) => OurShowData.fromJson(json.decode(str));

String ourShowDataToJson(OurShowData data) => json.encode(data.toJson());

class OurShowData{
  OurShowData({
    required this.data,
  });

  List<Datum> data;

  factory OurShowData.fromJson(Map<String, dynamic> json) => OurShowData(
    data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.id,
    required this.title,
    required this.poster,
    required this.description,
    required this.about,
    required this.url,
    required this.time,
  });

  String id;
  String title;
  String poster;
  String description;
  String about;
  String url;
  String time;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    title: json["title"],
    poster: json["poster"],
    description: json["description"],
    about: json["about"],
    url: json["url"],
    time: json["time"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "poster": poster,
    "description": description,
    "about": about,
    "url": url,
    "time": time,
  };
}
