// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

SubscriptionData SubscriptionDataFromJson(String str) => SubscriptionData.fromJson(json.decode(str));

String SubscriptionDataToJson(SubscriptionData data) => json.encode(data.toJson());

class SubscriptionData {
  SubscriptionData({
    this.data,
  });

  List<Datum>?data;

  factory SubscriptionData.fromJson(Map<String, dynamic> json) => SubscriptionData(
    data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.subscriptionPlanMasterId,
    this.subscriptionName,
    this.subscriptionPurchaseStatus,
    this.subscriptionPrice,
    this.days,
    this.color,
    this.description,
    this.planInfoData,
  });

  String?subscriptionPlanMasterId;
  String?subscriptionName;
  String?subscriptionPrice;
  String?days;
  String?color;
  String?description;
  int?subscriptionPurchaseStatus;
  List<PlanInfoDatum>?planInfoData;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    subscriptionPlanMasterId: json["subscription_plan_master_id"],
    subscriptionName: json["subscription_name"],
    subscriptionPrice: json["subscription_price"],
    days: json["days"],
    color: json["color"],
    description: json["description"],
    subscriptionPurchaseStatus: json["subscription_purchase_status"],
    planInfoData: List<PlanInfoDatum>.from(json["plan_info_data"].map((x) => PlanInfoDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "subscription_plan_master_id": subscriptionPlanMasterId,
    "subscription_name": subscriptionName,
    "subscription_price": subscriptionPrice,
    "days": days,
    "color": color,
    "description": description,
    "subscription_purchase_status":subscriptionPurchaseStatus,
    "plan_info_data": List<dynamic>.from(planInfoData!.map((x) => x.toJson())),
  };
}

class PlanInfoDatum {
  PlanInfoDatum({
    this.id,
    this.planInfo,
    this.status,
    this.createdAt,
    this.updatedAt,
    this.infoPointsId,
    this.point,
  });

  String?id;
  String?planInfo;
  String?status;
  String?createdAt;
  String?updatedAt;
  String?infoPointsId;
  String?point;

  factory PlanInfoDatum.fromJson(Map<String, dynamic> json) => PlanInfoDatum(
    id: json["id"],
    planInfo: json["plan_info"],
    status: json["status"],
    createdAt:json["created_at"],
    updatedAt: json["updated_at"],
    infoPointsId: json["info_points_id"],
    point: json["point"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "plan_info": planInfo,
    "status": status,
    "created_at": createdAt,
    "updated_at": updatedAt,
    "info_points_id": infoPointsId,
    "point": point,
  };
}


