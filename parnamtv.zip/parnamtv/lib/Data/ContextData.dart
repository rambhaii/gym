import 'dart:convert';

ContestData contestDataFromJson(String str) => ContestData.fromJson(json.decode(str));

String welcomeToJson(ContestData data) => json.encode(data.toJson());

class ContestData {
  ContestData({
     this.data,
  });

  List<ContestDatum> ?data;

  factory ContestData.fromJson(Map<String, dynamic> json) => ContestData(
    data: List<ContestDatum>.from(json["Data"].map((x) => ContestDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class ContestDatum {
  ContestDatum({
     this.id,
     this.title,
     this.poster,
     this.description,
     this.url,
  });

  String ?id;
  String ?title;
  String ?poster;
  String ?description;
  String ?url;

  factory ContestDatum.fromJson(Map<String, dynamic> json) => ContestDatum(
    id: json["id"],
    title: json["title"],
    poster: json["poster"],
    description: json["description"],
    url: json["url"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "poster": poster,
    "description": description,
    "url": url,
  };
}
