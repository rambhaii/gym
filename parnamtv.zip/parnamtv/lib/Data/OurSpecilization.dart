// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

OurSpecilizationData ourSpecilizationDataFromJson(String str) => OurSpecilizationData.fromJson(json.decode(str));

String ourSpecilizationDataToJson(OurSpecilizationData data) => json.encode(data.toJson());

class OurSpecilizationData {
  OurSpecilizationData({
    required this.data,
  });

  List<SpecilizationDatum> data;

  factory OurSpecilizationData.fromJson(Map<String, dynamic> json) => OurSpecilizationData(
    data: List<SpecilizationDatum>.from(json["Data"].map((x) => SpecilizationDatum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class SpecilizationDatum {
  SpecilizationDatum({
    required this.id,
    required this.title,
    required this.portfolioImage,
    required this.poster,
  });

  String id;
  String title;
  String portfolioImage;
  String poster;

  factory SpecilizationDatum.fromJson(Map<String, dynamic> json) => SpecilizationDatum(
    id: json["id"],
    title: json["title"],
    portfolioImage: json["portfolio_image"],
    poster: json["poster"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "portfolio_image": portfolioImage,
    "poster": poster,
  };
}
