// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

TvSeriseData tvSeriseDataFromJson(String str) => TvSeriseData.fromJson(json.decode(str));

String tvSeriseDataToJson(TvSeriseData data) => json.encode(data.toJson());

class TvSeriseData {
  TvSeriseData({
    required this.data,
  });

  List<Datum> data;

  factory TvSeriseData.fromJson(Map<String, dynamic> json) => TvSeriseData(
    data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.id,
    required this.seriesName,
    required this.releasingDate,
    required this.poster,
    required this.starCast,
    required this.videoFile,
    required this.plot,
    required this.producedBy,
    required  this.directedBy,
    required  this.writingCredits,
  });

  String id;
  String seriesName;
  String releasingDate;
  String poster;
  String starCast;
  String videoFile;
  String plot;
  String producedBy;
  String directedBy;
  String writingCredits;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    seriesName: json["series_name"],
    releasingDate:json["releasing_date"],
    poster: json["poster"],
    starCast: json["star_cast"],
    videoFile: json["video_file"],
    plot: json["plot"],
    producedBy: json["produced_by"],
    directedBy: json["directed_by"],
    writingCredits: json["writing_credits"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "series_name": seriesName,
    "releasing_date": releasingDate,
    "poster": poster,
    "star_cast": starCast,
    "video_file": videoFile,
    "plot": plot,
    "produced_by": producedBy,
    "directed_by": directedBy,
    "writing_credits": writingCredits,
  };
}
