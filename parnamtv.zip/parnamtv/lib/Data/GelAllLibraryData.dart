// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

GetAllLibraryData getAlllibraryDataFromJson(String str) => GetAllLibraryData.fromJson(json.decode(str));

String getAlllibraryDataToJson(GetAllLibraryData data) => json.encode(data.toJson());

class GetAllLibraryData {
  GetAllLibraryData({
    required this.data,
  });

  List<Datum> data;

  factory GetAllLibraryData.fromJson(Map<String, dynamic> json) => GetAllLibraryData(
    data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );



  Map<String, dynamic> toJson() => {
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    required this.id,
    required  this.title,
    required this.category,
    required this.subcategory,
    required this.quality,
    required this.releaseYear,
    required this.country,
    required this.runningTime,
    required  this.bannerImg,
    required  this.showDesc,
    required this.createdDate,
    required  this.status,
  });

  String id;
  String title;
  String category;
  String subcategory;
  String quality;
  String releaseYear;
  String country;
  String runningTime;
  String bannerImg;
  String showDesc;
  String createdDate;
  String status;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    title: json["title"],
    category: json["category"],
    subcategory: json["subcategory"],
    quality: json["quality"],
    releaseYear: json["release_year"],
    country: json["country"],
    runningTime: json["running_time"],
    bannerImg: json["banner_img"],
    showDesc: json["show_desc"],
    createdDate: json["created_date"],
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "category": category,
    "subcategory": subcategory,
    "quality": quality,
    "release_year": releaseYear,
    "country": country,
    "running_time": runningTime,
    "banner_img": bannerImg,
    "show_desc": showDesc,
    "created_date": createdDate,
    "status": status,
  };
}
