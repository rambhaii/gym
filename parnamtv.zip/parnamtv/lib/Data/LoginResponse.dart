// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

LoginResponse loginResponseFromJson(String str) => LoginResponse.fromJson(json.decode(str));

String loginResponseToJson(LoginResponse data) => json.encode(data.toJson());

class LoginResponse {
  LoginResponse({
  required  this.data,
  });

  Data data;

  factory LoginResponse.fromJson(Map<String, dynamic> json) => LoginResponse(
    data: Data.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Data": data.toJson(),
  };
}

class Data {
  Data({
    this.userId,
    this.subId,
    this.fname,
    this.lname,
    this.dob,
    this.gender,
    this.userName,
    this.profileImg,
    this.userEmail,
    this.userPass,
    this.usertype,
    this.menuId,
    this.address1,
    this.address2,
    this.country,
    this.state,
    this.city,
    this.zip,
     this.userMobile,
    this.otp,
    this.userStatus,
    this.tokenCode,
    this.status,
    this.message,
  });

  String?userId;
  dynamic?subId;
  String?fname;
  String?lname;
  dynamic?dob;
  dynamic?gender;
  String?userName;
  String?profileImg;
  String?userEmail;
  String?userPass;
  String?usertype;
  dynamic?menuId;
  dynamic?address1;
  dynamic?address2;
  dynamic?country;
  dynamic?state;
  dynamic?city;
  dynamic?zip;
  String?userMobile;
  dynamic?otp;
  String?userStatus;
  dynamic?tokenCode;
  int?status;
  String?message;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    userId: json["userID"],
    subId: json["sub_id"],
    fname: json["fname"],
    lname: json["lname"],
    dob: json["dob"],
    gender: json["gender"],
    userName: json["userName"],
    profileImg: json["profile_img"],
    userEmail: json["userEmail"],
    userPass: json["userPass"],
    usertype: json["usertype"],
    menuId: json["menu_id"],
    address1: json["address1"],
    address2: json["address2"],
    country: json["country"],
    state: json["state"],
    city: json["city"],
    zip: json["zip"],
    userMobile: json["userMobile"],
    otp: json["otp"],
    userStatus: json["userStatus"],
    tokenCode: json["tokenCode"],
    status: json["status"],
    message: json["message"],
  );

  Map<String, dynamic> toJson() => {
    "userID": userId,
    "sub_id": subId,
    "fname": fname,
    "lname": lname,
    "dob": dob,
    "gender": gender,
    "userName": userName,
    "profile_img": profileImg,
    "userEmail": userEmail,
    "userPass": userPass,
    "usertype": usertype,
    "menu_id": menuId,
    "address1": address1,
    "address2": address2,
    "country": country,
    "state": state,
    "city": city,
    "zip": zip,
    "userMobile": userMobile,
    "otp": otp,
    "userStatus": userStatus,
    "tokenCode": tokenCode,
    "status": status,
    "message": message,
  };
}
