 import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:parnamtv/Modal/drawer_iteam.dart';
class DrawerItems{
  static const home=DrawerIteam(title: "HOME", icon:FontAwesomeIcons.home );
  static const OurService=DrawerIteam(title: "SERVICES", icon:FontAwesomeIcons.servicestack );
  static const contest=DrawerIteam(title: "CONTESTS", icon:FontAwesomeIcons.confluence );
  static const ourshows=DrawerIteam(title: "OUR SHOWS", icon:FontAwesomeIcons.globeAfrica);
  static const viewwin=DrawerIteam(title: "FOR YOU", icon:FontAwesomeIcons.trophy );
  static const Commmingshow=DrawerIteam(title: "WATCH LIVE TV", icon:FontAwesomeIcons.userTag );
  static const About=DrawerIteam(title: "ABOUT US", icon:FontAwesomeIcons.addressBook );

  static final List<DrawerIteam> all=[
  home,OurService,Commmingshow,contest,ourshows,viewwin,About
  ];

}