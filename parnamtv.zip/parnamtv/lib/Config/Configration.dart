import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
class ParnamTv{
     static late SharedPreferences sharedPreference;
     static final String userName ="name";

     static final String userEmail='email';
     static final String userID='userID';
     static final String firstname='firstname';
     static final String lastname='lastname';
     static final String dob='dob';
     static final String gender='gender';
     static final String profile_img='profile_img';
     static final String mobile='mobile';
     static final String city='city';
     static final String state='state';
     static final String country='country';
     static final String address='address';

}
const String BASE_URL ="https://pranamtv.com";