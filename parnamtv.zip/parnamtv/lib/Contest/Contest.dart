import 'package:better_player/better_player.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:parnamtv/Data/ContextData.dart';
import 'package:parnamtv/Widget/CircularLoader.dart';
import 'package:parnamtv/Widget/DrawerMenuWidget.dart';
import 'package:http/http.dart' as http;
import 'package:parnamtv/Widget/HorizentalLine.dart';
import 'package:parnamtv/Widget/OurShowsWidget.dart';

import '../DashBoard/Controller/SliderController.dart';
class Contest extends StatefulWidget {
  final VoidCallback openDrawer;
  final int ?flag;
  const Contest(
      {
        Key?key,
        required this.openDrawer,  this.flag,
      }):super(key: key);
  @override
  _ContestState createState() => _ContestState();
}

class _ContestState extends State<Contest> {
  SliderController sliderController=Get.put(SliderController());
  late ContestData contestData;
  bool isReady = false;
  int _current=0;

  List<T> map<T>(List list,Function handler)
  {
    List<T> result=[];
    for(var i=0;i < list.length;i++)
    {
      result.add(handler(i,list[i]));
    }
    return result;
  }
  @override
  void initState() {
      sliderController.getSlider("2");
      sliderController.getContest();
      super.initState();
  }


  
  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Color(0xFF1e2125),
          title: Text("Contest"),
          leading: widget.flag==null? DrawerMenuWidget(onClicked: widget.openDrawer):

          InkWell(
              onTap: (){
                Navigator.pop(context);
              },
              child: Icon(Icons.arrow_back)),


          //DrawerMenuWidget(onClicked: widget.openDrawer),

        ),
        body: SingleChildScrollView(
          child: Column(
            children: [
              SizedBox(
                height: 5,
              ),
              Obx(() =>sliderController.sliderList.value!=null? Stack(
                  children: [
                    CarouselSlider(
                      options: CarouselOptions(
                        height: h*0.2,
                        aspectRatio: 16/9,
                        viewportFraction: 0.85,
                        initialPage: 0,
                        enableInfiniteScroll: true,
                        reverse: false,
                        autoPlay: true,
                        autoPlayInterval: Duration(seconds: 2),
                        autoPlayAnimationDuration: Duration(milliseconds: 1500),
                        autoPlayCurve: Curves.fastOutSlowIn,
                        enlargeCenterPage: true,
                        scrollDirection: Axis.horizontal,
                        onPageChanged:(index, reason){
                            sliderController.onChangePage(index);
                        },

                      ),


                      items: sliderController.sliderList.map((imgUrl) {
                        return Builder(
                          builder: (BuildContext context) {
                            return Container(
                              width:w,
                              //margin: EdgeInsets.symmetric(horizontal: 0.0),
                              decoration: BoxDecoration(
                                color: Colors.black45,

                              ),
                              child: Image.network(imgUrl.poster??"",fit: BoxFit.cover,),
                            );
                          },
                        );
                      }).toList(),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: h*0.2),
                      child: Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children:map<Widget>(
                              sliderController.sliderList,(Index,url){
                            return Container(
                              width: 10.0,
                              height: 10.0,
                              margin:EdgeInsets.symmetric(vertical: 10.0,horizontal: 2.0) ,
                              decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  color: sliderController.index.value==Index?Colors.amberAccent:Colors.red
                              ),
                            );
                          }
                          )
                      ),
                    ),

                  ],
                ):Container(),
              ),
              Container(
                margin: EdgeInsets.all(10.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        FaIcon(FontAwesomeIcons.film,color: Color(0xffda261e),),
                        Text(" Upcoming Contests",style: TextStyle(color:Color(0xffda261e),
                            fontWeight: FontWeight.w500,fontSize: 20.0
                        )
                        ),
                      ],
                    ),
                    SizedBox(
                      height: 5.0,
                    ),
                    HorizentaLine(
                      width: w*0.3,
                    ),

                Row(
                  children: [
                    Expanded(
                   child:Obx(()=>sliderController.contestData.value!=null?GridView.count(
                               shrinkWrap: true,
                               crossAxisCount: 2,
                               crossAxisSpacing: 10,
                               mainAxisSpacing: 10,
                               childAspectRatio:1.0/1.3,
                             children:List.generate(sliderController.contestData.value.length, (index)  =>new OurShowsWidget(title:sliderController.contestData.value[index].title??"", description:sliderController.contestData.value![index].description??"",
                                 ImgUrl:sliderController.contestData.value[index].poster??"",),
                             ),
                           ):Container(),
                           ),
                      ),
                  ],
                ),

                  ],
                ),
              )
            ],
          ),
        )


    );

  }
}
