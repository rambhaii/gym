import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:get/get.dart';

import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Contest/Contest.dart';
import 'package:parnamtv/Dailog/SubscriptionDailog.dart';
import 'package:parnamtv/Dailog/TimeHandler.dart';
import 'package:parnamtv/DashBoard/Dashboard.dart';
import 'package:parnamtv/DashBoard/OurSchedule.dart';
import 'package:parnamtv/Home/home_page.dart';
import 'package:parnamtv/Splash.dart';
import 'package:parnamtv/User/MyProfile/EditProfile.dart';
import 'package:parnamtv/Utils/RemoteService.dart';
import 'package:parnamtv/ViewWin/ViewWin.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  ParnamTv.sharedPreference=await SharedPreferences.getInstance();
  await Firebase.initializeApp();
   RemoteService.initDynamicLink();
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    systemNavigationBarColor: Colors.black, // navigation bar color
    statusBarColor: Colors.black, // status bar color
  ));
  runApp(MyApp(),);

 // configLoading();
}


class MyApp extends StatelessWidget {

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {

    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      home: Splash(),
      themeMode: ThemeMode.dark,
      builder: EasyLoading.init(),

    );
  }
}


