


import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:parnamtv/DashBoard/Model/OneSubscriptionModel.dart';
import 'package:parnamtv/Data/ContextData.dart';
import 'package:parnamtv/Data/GelAllLibraryData.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

import '../Config/Configration.dart';
import '../DashBoard/Model/SliderModel.dart';
import '../Data/OurSpecilization.dart';
import '../User/Data/coin_data.dart';
String facebookLink="https://www.facebook.com/pranamtvofficial/";
String lunchurltwitter="https://pranamtv.com/pages/twitterAPI/index.php";
String lunchurlgoogle="https://pranamtv.com/pages/googleAPI/index.php";
String linkedinUrl="https://www.linkedin.com/company/pranam-tv-network-pvt-ltd/";
String instagramUrl="https://www.instagram.com/pranamtv/";
String pinterestUrl="https://in.pinterest.com/pranamtv/";
Future<void> lunchInBrowser(String url) async
{
  if(await canLaunch(url))
  {
    await launch(url,forceSafariVC: false,forceWebView: false,
        headers: <String,String>{"headesr_key":  "headers_value"}
    );

  }
  else{
    throw "url not lunched $url";
  }
}

class RemoteService {
  // static var client=http.Client();
  static Future<GetAllLibraryData?> fetchlibrary() async {
    var url = Uri.parse(
        "https://pranamtv.com/api/front/GetLibraryList?limit=10&start=0");
    var response = await http.get(
        url, headers: {'x-api-key': 'api@pranamtv.com'});
    if (response.statusCode == 200) {
      return getAlllibraryDataFromJson(response.body);
    }
    else {
      return null;
    }
  }

  static Future<OneSubscriptionModel?> getOneSubscription() async {
    var url = Uri.parse(
        BASE_URL + "/api/front/GetOurSpecialization/getOneSubscription");
    var response = await http.get(
        url, headers: {'x-api-key': 'api@pranamtv.com'});
    if (response.statusCode == 200) {
      print("xbkjsbvk" + response.body);
      return oneSubscriptionModelFromJson(response.body);
    }
    else {
      return null;
    }
  }

  static Future<OurSpecilizationData> geturSpecilization() async {
    var url = Uri.parse(
        BASE_URL + '/api/front/GetOurSpecialization?limit=10&start=0');
    var response = await http.get(
        url, headers: {'x-api-key': 'api@pranamtv.com'});
    if (response.statusCode == 200) {
      print("bc jhxbjxc"+response.body);
      return ourSpecilizationDataFromJson(response.body);
    }
    else {
      return ourSpecilizationDataFromJson(response.body);
      //   ourSpecilizationData=null;
    }
  }

  static Future<SliderModule> getSlider(String id) async {
    var url = Uri.parse(BASE_URL +
        '/api/front/GetOurSpecialization/GetSliderByCategory?showsliderCategoryID=$id');
    var response = await http.get(
        url, headers: {'x-api-key': 'api@pranamtv.com'});
    if (response.statusCode == 200) {
      return sliderModuleFromJson(response.body);
    }
    else {
      return sliderModuleFromJson(response.body);
      //   ourSpecilizationData=null;
    }
  }
 static Future<ContestData> getAllContest()async{
    var url=Uri.parse("https://pranamtv.com/api/front/GetUpcomingContests?limit=10&start=0");
    var response= await http.get(url,headers: {'x-api-key':'api@pranamtv.com'});
    if(response.statusCode==200)
    {
     return contestDataFromJson(response.body);
    }
    else{
      return contestDataFromJson(response.body);
    }
  }


  static Future<String> createDynamicLink()async{
    final dynamicLinkParams = DynamicLinkParameters(
      link: Uri.parse("https://pranamtv.com?id=${ParnamTv.sharedPreference.getString(ParnamTv.userID).toString()})"),
      uriPrefix: "https://pranamtv.page.link",
      androidParameters: const AndroidParameters(
        packageName: "com.app.pranamtv",
        minimumVersion: 5,
      ),
      iosParameters: const IOSParameters(
        bundleId: "com.app.pranamtv",
        appStoreId: "123456789",
        minimumVersion: "1.0.1",
      ),

    );
    final dynamicLink = await FirebaseDynamicLinks.instance.buildShortLink(dynamicLinkParams);
    Uri url=dynamicLink.shortUrl;
    return url.toString();
  }
  static  initDynamicLink()async {
    print("nfdvbhdbhc");
    final PendingDynamicLinkData? initialLink = await FirebaseDynamicLinks.instance.getInitialLink();
    final Uri deeplink =initialLink!.link;
    var isId=deeplink.pathSegments.contains("id");
    print("nfdvbhdbhc");
    print(initialLink.link);
      if(deeplink!=null)
        {
          referAndEarn(isId.toString());
         print("jkdvjkv"+isId.toString());
        }
      else
        {
          print("deeplink Not Available ");
        }

  }
  static  referAndEarn(String id)async{
    var url=Uri.parse(BASE_URL+"/api/front/Users/postRefferEarn");
    var response= await http.post(url,headers: {'x-api-key':'api@pranamtv.com'},
    body: {
      "userID":ParnamTv.sharedPreference.getString(ParnamTv.userID).toString(),
      "shareuserID":id
    }
    );
    if(response.statusCode==200)
    {
     print(response.body);
    }
    else{

    }
  }
  static Future<UserCoinsData> getCoinsData(String id)async{
    var url=Uri.parse(BASE_URL+"/api/front/Users/getUserPoints?userID=${id}");
    var response= await http.get(url,headers: {'x-api-key':'api@pranamtv.com'},
    );
    if(response.statusCode==200)
    {
      print("dcnkvbj"+response.body);
      return userCoinsDataFromJson(response.body);
    }
    else{
      return userCoinsDataFromJson(response.body);
    }
  }
}