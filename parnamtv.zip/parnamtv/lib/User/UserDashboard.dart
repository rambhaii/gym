import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

import 'package:parnamtv/DashBoard/Dashboard.dart';
import 'package:parnamtv/User/MyProfile/My%20Transaction.dart';
import 'package:parnamtv/User/MyRewards.dart';
import 'package:parnamtv/User/Schedule.dart';
import 'package:parnamtv/User/MyProfile/Signup.dart';
import 'package:parnamtv/User/MyProfile/profile.dart';
class UserDashboard extends StatefulWidget {
  const UserDashboard({Key? key}) : super(key: key);

  @override
  _UserDashboardState createState() => _UserDashboardState();
}

class _UserDashboardState extends State<UserDashboard> {

  int _selectedIndex = 0;
  static const TextStyle optionStyle =
  TextStyle(fontSize: 30, fontWeight: FontWeight.w600);
  static const List<Widget> _widgetOptions = <Widget>[
     //Profile(),
    // MyTrasaction(),
     MyRewards(),
     Schedule()
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     backgroundColor: Colors.black,
      body:_widgetOptions.elementAt(_selectedIndex),
          bottomNavigationBar: Container(
            decoration: BoxDecoration(
              color: Colors.black,
              boxShadow: [
                BoxShadow(
                  blurRadius: 20,
                  color: Colors.black.withOpacity(.1),
                )
              ],
              image:DecorationImage(
                image:ExactAssetImage("assets/Images/whyus-bg.jpg" ),
                fit: BoxFit.cover
              )
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 6),

              ),
            ),
          ),

    );

  }
}
