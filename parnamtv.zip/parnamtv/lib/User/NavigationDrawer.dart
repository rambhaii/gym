import 'dart:convert';
import 'dart:io';

import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:image_picker/image_picker.dart';
import 'package:parnamtv/CommingSoon/CommingSoon.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Contest/Contest.dart';
import 'package:parnamtv/DashBoard/about_us.dart';
import 'package:parnamtv/Data/drawer_items.dart';
import 'package:parnamtv/Home/home_page.dart';
import 'package:parnamtv/Modal/drawer_iteam.dart';
import 'package:parnamtv/OurShow/our_show.dart';
import 'package:parnamtv/Service/Services.dart';
import 'package:http/http.dart' as http;
import 'package:parnamtv/User/Data/UserDrawerItems.dart';
import 'package:parnamtv/User/Data/user_drawer_iteam.dart';
import 'package:parnamtv/User/MyProfile/My%20Transaction.dart';
import 'package:parnamtv/User/MyProfile/MyPlan.dart';
import 'package:parnamtv/User/Ui/UserDrawerwidget.dart';
import 'dart:math';

import 'package:parnamtv/User/MyProfile/profile.dart';
import 'package:parnamtv/ViewWin/ViewWin.dart';
import 'package:parnamtv/Widget/Drawer_widget.dart';
class UserNavigation extends StatefulWidget {
  const UserNavigation({Key? key}) : super(key: key);

  @override
  _UserNavigationState createState() => _UserNavigationState();
}

class _UserNavigationState extends State<UserNavigation> {
  double value = 0;
  late bool isDrawerOpen;
  late double xOffset;
  late   double scaleFactor ;
  late double yOffset;
  String name ="";
  String email="";
  String userId="";
  String imageUrl="";
  String filepath="";
  bool isDragging = false;
  UserDrawerIteam item=UserDrawerItems.Profile;
  @override
  void initState() {
    // TODO: implement initState
    getDatafrompref();
    closedrawer();
    super.initState();
  }
  getDatafrompref() async{
    name= ParnamTv.sharedPreference.getString(ParnamTv.userName)??'';
    imageUrl= ParnamTv.sharedPreference.getString(ParnamTv.profile_img)??'';
    userId= ParnamTv.sharedPreference.getString(ParnamTv.userID)??'';
  }
  void openDrawer() {
    setState(() {
      xOffset=230;
      yOffset= 140;
      scaleFactor=0.65;
      isDrawerOpen = true;

    });
  }

  void closedrawer() {
    setState(() {
      xOffset=0;
      yOffset= 0;
      scaleFactor=1;
      isDrawerOpen = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Container(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    colors: [Color(0xFFCE2A2A), Color(0xfff8952b)],
                    begin: Alignment.bottomCenter,
                    end: Alignment.topCenter
                )
            ),
          ),
          SafeArea(
              child: Container(
                width: 250.0,
                padding: EdgeInsets.all(8.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    DrawerHeader(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Stack(
                              children: [
                                CircleAvatar(
                                  // radius: 50,
                                  // backgroundColor: Colors.brown.shade800,
                                  backgroundImage:FileImage(File(filepath)),
                                  //child: imageUrl==""?:)
                                  radius: 42,
                                  backgroundColor: Colors.brown.shade800,
                                  child: CircleAvatar(
                                    backgroundColor: Colors.transparent,
                                    radius: 40,
                                    backgroundImage:NetworkImage(imageUrl),
                                  ),
                                ),

                                Positioned(
                                  top: 47,
                                  left: 43,
                                  child: IconButton(onPressed: () async{

                                    final ImagePicker _picker = ImagePicker();
                                    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
                                    print("filepath,${image!.path}");
                                    setState(() {
                                      filepath=image.path;
                                    });
                                    updatephotoprofile(filepath);
                                  }, icon: Icon(FontAwesomeIcons.camera,size: 20,color: Colors.brown.shade800,)
                                  ),
                                )
                              ],
                            ),
                            SizedBox(height: 10,),
                            Text(
                              name, style: TextStyle(color: Colors
                                .white, fontSize: 15),maxLines: 1,overflow:TextOverflow.clip,),
                          ],
                        )
                    ),
                    Expanded(
                      child:  SingleChildScrollView(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            UserDrawerwidget(
                              onSelectedItem: (item){
                                setState(()=>this.item=item);
                                closedrawer();
                              },
                            ),
                          ],

                        ),
                      ),
                      
                        )

                  ],
                ),
              )
          ),
          // TweenAnimationBuilder(
          //     tween: Tween<double>(begin: 0, end: value),
          //     duration: Duration(milliseconds: 500),
          //     builder: (_, double val, __) {
          //       return (
          //           Transform(
          //             alignment: Alignment.center,
          //             transform: Matrix4.identity()
          //               ..setEntry(3, 2, 0.001)
          //               ..setEntry(0, 3, 200 * val)
          //               ..rotateY((pi / 6) * val),
          //             child: Scaffold(
          //               appBar: AppBar(
          //                 title: Text("3D drower"),
          //               ),
          //               body: Center(
          //                 child: Text("swip rigt to left"),
          //               ),
          //             ),
          //           )
          //       );
          //     }),
          GestureDetector(
            onTap: closedrawer,
            onHorizontalDragStart: (details)=>isDragging=true,
            onHorizontalDragUpdate: (details){
              if(!isDragging) return;
              const delta=1;
              if(details.delta.dx>delta){
                openDrawer();
              }else if(details.delta.dx < -delta)
              {
                closedrawer();
              }
              isDragging=false;
                            },
                    child: AnimatedContainer(
                        alignment: Alignment.center,
                    transform: Matrix4.translationValues(xOffset, yOffset, 0)
                      ..scale(scaleFactor),

                    duration: Duration(milliseconds: 650),
                    child: AbsorbPointer(
                    absorbing: isDrawerOpen,
                    child: ClipRRect(
                    borderRadius:BorderRadius.circular(isDrawerOpen?10:0) ,
                    child: Container(
                    color: isDrawerOpen?Colors.pinkAccent:Theme.of(context).primaryColor,
                    child: getDrawerPage(),
                    ),
                    )
                    )
                    ),
                    ),



                            // onHorizontalDragUpdate: (e) {
            //   if (e.delta.dx > 0) {
            //     setState(() {
            //       value = 1;
            //     });
            //   }
            //   else {
            //     setState(() {
            //       value = 0;
            //     });
            //   }
            // },
            // onTap: (){
            //   setState(() {
            //     value==0?value=1:value=0;
            //   });
            // },

         // WillPopScope()
        ],

      ),
    );
  }
  Widget getDrawerPage(){
    switch(item)
    {
      case UserDrawerItems.Profile:
        return Profile(openDrawer:openDrawer);
      case UserDrawerItems.MyPlan:
        return MyPlan(openDrawer:openDrawer);
      case UserDrawerItems.MyTrasaction:
        return MyTrasaction(openDrawer:openDrawer);

      default:
        return Profile(openDrawer: openDrawer);
    }
  }
  updatephotoprofile(String filename) async
  {
    EasyLoading.show(status: 'loading...');
    var url=Uri.parse('https://pranamtv.com/api/front/Users/UploadProfile');
    var request= await  http.MultipartRequest('POST',url);
    request.files.add(
        await http.MultipartFile.fromPath(
          'profile_pic',
          filename,
        )

    );
    request.fields.addAll({'userID': userId});
    request.headers.addAll({'x-api-key':'api@pranamtv.com'});
    var res = await request.send();
    var response=await http.Response.fromStream(res);
    // print('responsesss,${response.body}');
    var datass=jsonDecode(response.body);
    if(response.statusCode==200)
    {
      EasyLoading.dismiss();
      if(datass['Data']['status']==1)
      {
        ArtSweetAlert.show(
          context: context,
          barrierDismissible: false,
          artDialogArgs: ArtDialogArgs(
            confirmButtonColor: Colors.green,
            type: ArtSweetAlertType.success,
            title:"Success",
            text: datass['Data']['message'],
            confirmButtonText: ' OK ',
          ),
        );
         ParnamTv.sharedPreference.setString(ParnamTv.profile_img,datass['Data']['profile_img']);
      }
      else
      {
        ArtSweetAlert.show(
          context: context,
          barrierDismissible: false,
          artDialogArgs: ArtDialogArgs(
            confirmButtonColor: Colors.green,
            type: ArtSweetAlertType.warning,
            title:"Warning",
            text: datass['Data']['message'],
            confirmButtonText: ' OK ',
          ),
        );
      }

    }
    else{
      EasyLoading.dismiss();
      ArtSweetAlert.show(
        context: context,
        barrierDismissible: false,
        artDialogArgs: ArtDialogArgs(
          confirmButtonColor: Colors.green,
          type: ArtSweetAlertType.danger,
          title:"Failed",
          text:response.body,
          confirmButtonText: ' OK ',
        ),
      );
    }

    //  Fluttertoast.showToast(msg: "${response.body}",toastLength: Toast.LENGTH_LONG);
  }
}