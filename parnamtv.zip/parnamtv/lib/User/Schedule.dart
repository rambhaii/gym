import 'package:flutter/material.dart';
class Schedule extends StatefulWidget {
  const Schedule({Key? key}) : super(key: key);

  @override
  _ScheduleState createState() => _ScheduleState();
}

class _ScheduleState extends State<Schedule> {
  var now = DateTime.now();
  DateTime dateToday = DateTime(DateTime.now().year, DateTime.now().month, DateTime.now().day) ;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(

          child:Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("date$dateToday")

            ],
          )
      ),
    );
  }
}
