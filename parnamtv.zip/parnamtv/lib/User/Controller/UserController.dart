import 'package:get/get.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Utils/RemoteService.dart';

class UserController extends GetxController{
  var viewPoint= "0".obs;
  var sharePoint= "0".obs;
  var reviewPoint= "0".obs;
  var totalPoint="0".obs;
  @override
  void onInit() {
    // TODO: implement onInit
    fetchApi();
    super.onInit();
  }
  fetchApi(){
    RemoteService.getCoinsData(ParnamTv.sharedPreference.getString(ParnamTv.userID).toString()).then((value) {
             viewPoint.value=value.data!.votingPints!.totalPoint!;
             sharePoint.value=value.data!.sharingPints!.totalPoint!;
             reviewPoint.value=value.data!.reviewPints!.totalPoint!;
             totalPoint.value=value.data!.totalPoints!.totalPoint!;
    });
  }
}