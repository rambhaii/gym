import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:parnamtv/Data/drawer_items.dart';
import 'package:parnamtv/Modal/drawer_iteam.dart';
import 'package:parnamtv/User/Data/UserDrawerItems.dart';
import 'package:parnamtv/User/Data/user_drawer_iteam.dart';
class UserDrawerwidget extends StatelessWidget {
  final ValueChanged<UserDrawerIteam> onSelectedItem;
  const UserDrawerwidget({
    Key?key ,
    required this.onSelectedItem
  }):super(key: key);
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Column(
        children: [
          buildDraweItems(context),
        ],
      ),
    );
  }
  Widget buildDraweItems(BuildContext context)=>Column(
    mainAxisSize: MainAxisSize.min,
    children: UserDrawerItems.all
        .map(
          (item) =>

              ListTile(
              contentPadding: EdgeInsets.symmetric(vertical: 0,horizontal: 0),
                visualDensity: VisualDensity(horizontal: 0, vertical: -4),
                leading: Icon(item.icon,color: Colors.white,size: 18,),
        title: Text(
          item.title,
          style: TextStyle(color: Colors.white,fontSize: 17),
        ),
        onTap: ()=>onSelectedItem(item),
      ),
    ).toList(),

  );
}
