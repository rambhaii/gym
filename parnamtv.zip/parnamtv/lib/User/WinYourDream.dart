import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:parnamtv/Widget/HorizentalLine.dart';
class WinYourPrice extends StatefulWidget {
  const WinYourPrice({Key? key}) : super(key: key);

  @override
  _WinYourPriceState createState() => _WinYourPriceState();
}

class _WinYourPriceState extends State<WinYourPrice> {
  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
           backgroundColor: Colors.black,
           title: Text("Win Your Dream"),
         ),
      body: SingleChildScrollView(
        child: Container(
          margin: EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
             Container(
               height: h*0.15,
               child: Image.asset("assets/Images/banner3.jpg",fit: BoxFit.fill,),
             ),
              SizedBox(
                height: 10.0,
              ),
              Row(
                children: [
                  FaIcon(FontAwesomeIcons.trophy,color: Color(0xffda261e),),
                  Text("  WIN YOUR DREAMS",style: TextStyle(color:Color(0xffda261e),
                      fontWeight: FontWeight.w500,fontSize: 20.0
                  )
                  ),



                ],

              ),
              SizedBox(
                height: 5.0,
              ),
              HorizentaLine(
                width: w*0.3,
              ),
              Card(
                margin: EdgeInsets.only(left: 20,right: 20,top: 15),
                color: Colors.black,
                child: Column(
                  children: [
                    SizedBox(height: 15,),
                    Container(
                      width: w,
                      height: h*0.31,
                        child: Image.asset("assets/Images/price1.png"
                        )),
                    Text("Prize Worth", style: TextStyle(color: Color(0xffff9000),fontWeight: FontWeight.w600,
                      fontSize: 23,
                    ),),
                    SizedBox(height: 10,),
                    Text("1,00,000", style: TextStyle(color: Color(0xffff9000),fontWeight: FontWeight.w600,
                      fontSize: 23,
                    ),),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              Card(
                margin: EdgeInsets.only(left: 20,right: 20,top: 15),
                color: Colors.black,
                child: Column(
                  children: [
                    SizedBox(height: 15,),
                    Container(
                      width: w,
                      height: h*0.31,
                        child: Image.asset("assets/Images/price2.png"
                        )),
                    Text("Prize Worth", style: TextStyle(color: Color(0xffff9000),fontWeight: FontWeight.w600,
                      fontSize: 23,
                    ),),
                    SizedBox(height: 10,),
                    Text("50,000", style: TextStyle(color: Color(0xffff9000),fontWeight: FontWeight.w600,
                      fontSize: 23,
                    ),),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
              Card(
                margin: EdgeInsets.only(left: 20,right: 20,top: 15),
                color: Colors.black,
                child: Column(
                  children: [
                    SizedBox(height: 15,),
                    Container(
                      width: w,
                      height: h*0.31,
                        child: Image.asset("assets/Images/price3.png"
                        )),
                    Text("Prize Worth", style: TextStyle(color: Color(0xffff9000),fontWeight: FontWeight.w600,
                      fontSize: 23,
                    ),),
                    SizedBox(height: 10,),
                    Text("25,000", style: TextStyle(color: Color(0xffff9000),fontWeight: FontWeight.w600,
                      fontSize: 23,
                    ),),
                    SizedBox(height: 20,),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
