// To parse this JSON data, do
//
//     final userCoinsData = userCoinsDataFromJson(jsonString);

import 'dart:convert';

UserCoinsData userCoinsDataFromJson(String str) => UserCoinsData.fromJson(json.decode(str));

String userCoinsDataToJson(UserCoinsData data) => json.encode(data.toJson());

class UserCoinsData {
  UserCoinsData({
    this.data,
  });

  Data ?data;

  factory UserCoinsData.fromJson(Map<String, dynamic> json) => UserCoinsData(
    data: Data.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Data": data!.toJson(),
  };
}

class Data {
  Data({
    this.status,
    this.message,
    this.reviewPints,
    this.sharingPints,
    this.votingPints,
    this.totalAvailabelPoint,
    this.totalRedeemPoints,
    this.totalPoints,
  });

  int? status;
  String ?message;
  Ints? reviewPints;
  Ints? sharingPints;
  Ints? votingPints;
  TotalAvailabelPoint? totalAvailabelPoint;
  Ints ?totalRedeemPoints;
  Ints ?totalPoints;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    status: json["status"]??0,
    message: json["message"]??"",
    reviewPints: Ints.fromJson(json["reviewPints"]??[]),
    sharingPints: Ints.fromJson(json["sharingPints"]??[]),
    votingPints: Ints.fromJson(json["votingPints"]??[]),
    totalAvailabelPoint: TotalAvailabelPoint.fromJson(json["totalAvailabelPoint"]??[]),
    totalRedeemPoints: Ints.fromJson(json["totalRedeemPoints"]??[]),
    totalPoints: Ints.fromJson(json["totalPoints"]??[]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "reviewPints": reviewPints!.toJson(),
    "sharingPints": sharingPints!.toJson(),
    "votingPints": votingPints!.toJson(),
    "totalAvailabelPoint": totalAvailabelPoint!.toJson(),
    "totalRedeemPoints": totalRedeemPoints!.toJson(),
    "totalPoints": totalPoints!.toJson(),
  };
}

class Ints {
  Ints({
    this.totalPoint,
  });

  String ?totalPoint;

  factory Ints.fromJson(Map<String, dynamic> json) => Ints(
    totalPoint: json["totalPoint"]??"0",
  );

  Map<String, dynamic> toJson() => {
    "totalPoint": totalPoint,
  };
}

class TotalAvailabelPoint {
  TotalAvailabelPoint({
    this.points,
  });

  String? points;

  factory TotalAvailabelPoint.fromJson(Map<String, dynamic> json) => TotalAvailabelPoint(
    points: json["points"]??"",
  );

  Map<String, dynamic> toJson() => {
    "points": points,
  };
}
