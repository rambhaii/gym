// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

MyPlanData  myPlanDataFromJson(String str) => MyPlanData.fromJson(json.decode(str));

String myPlanDataToJson(MyPlanData data) => json.encode(data.toJson());

class MyPlanData {
  MyPlanData({
 required   this.data,
  });

  List<Datum>data;

  factory MyPlanData.fromJson(Map<String, dynamic> json) => MyPlanData(
    data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "Data": List<dynamic>.from(data.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.id,
    this.userId,
    this.subscriptionPlanMasterId,
    this.transectionId,
    this.paymentStatus,
    this.amount,
    this.createdAt,
    this.updatedAt,
    this.subscriptionName,
  });

  String?id;
  String?userId;
  String?subscriptionPlanMasterId;
  String?transectionId;
  String?paymentStatus;
  String?amount;
  String?createdAt;
  String?updatedAt;
  String?subscriptionName;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    userId: json["userID"],
    subscriptionPlanMasterId: json["subscription_plan_master_id"],
    transectionId: json["transection_id"],
    paymentStatus: json["payment_status"],
    amount: json["amount"],
    createdAt: json["created_at"],
    updatedAt: json["updated_at"],
    subscriptionName: json["subscription_name"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "userID": userId,
    "subscription_plan_master_id": subscriptionPlanMasterId,
    "transection_id": transectionId,
    "payment_status": paymentStatus,
    "amount": amount,
    "created_at": createdAt,
    "updated_at": updatedAt,
    "subscription_name": subscriptionName,
  };
}
