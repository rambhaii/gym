import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:parnamtv/Modal/drawer_iteam.dart';
import 'package:parnamtv/User/Data/user_drawer_iteam.dart';
import 'package:parnamtv/User/MyProfile/My%20Transaction.dart';
class UserDrawerItems{
  static const Profile=UserDrawerIteam(title: "Profile", icon:FontAwesomeIcons.userCircle );
  static const MyPlan=UserDrawerIteam(title: "My Plan", icon:FontAwesomeIcons.sitemap );
  static const MyTrasaction=UserDrawerIteam(title: "My Transaction", icon:FontAwesomeIcons.creditCard );
  static const Wallet=UserDrawerIteam(title: "Wallet", icon:FontAwesomeIcons.wallet );
  static const Earnings=UserDrawerIteam(title: "Earnings", icon:FontAwesomeIcons.rupeeSign );
  static const Archives=UserDrawerIteam(title: "Archives", icon:FontAwesomeIcons.archive );
  static const WinYourDream=UserDrawerIteam(title: "WinYourDreamMy ", icon:FontAwesomeIcons.trophy );
  static const MeriFilm=UserDrawerIteam(title: "Meri Film", icon:FontAwesomeIcons.film );
  static const MomsRasoi=UserDrawerIteam(title: "Mom's Rasoi", icon:FontAwesomeIcons.graduationCap );


  static final List<UserDrawerIteam> all=[
    Profile,MyPlan,MyTrasaction,Wallet,Earnings,Archives,WinYourDream,MeriFilm,MomsRasoi
  ];

}