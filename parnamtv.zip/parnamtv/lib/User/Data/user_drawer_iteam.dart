import 'package:flutter/material.dart';
class UserDrawerIteam{
  final String title;
  final IconData icon;
  const UserDrawerIteam({
    required this.title,
    required this.icon
});
}