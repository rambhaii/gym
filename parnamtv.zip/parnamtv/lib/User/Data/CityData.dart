// To parse this JSON data, do
//
//     final welcome = welcomeFromJson(jsonString);

import 'dart:convert';

CityData cityDataFromJson(String str) => CityData.fromJson(json.decode(str));

String cityDataToJson(CityData data) => json.encode(data.toJson());

class CityData {
  CityData({
    this.data,
  });

  Data?data;

  factory CityData.fromJson(Map<String, dynamic> json) => CityData(
    data: Data.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "Data": data!.toJson(),
  };
}

class Data {
  Data({
    this.status,
    this.message,
    this.data,
  });

  int?status;
  String?message;
  List<Datum>?data;

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    status: json["status"],
    message: json["message"],
    data: List<Datum>.from(json["data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  Datum({
    this.locationId,
    this.name,
    this.locationType,
    this.parentId,
    this.isVisible,
  });

  String?locationId;
  String?name;
  String?locationType;
  String?parentId;
  String?isVisible;

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    locationId: json["location_id"],
    name: json["name"],
    locationType: json["location_type"],
    parentId: json["parent_id"],
    isVisible: json["is_visible"],
  );

  Map<String, dynamic> toJson() => {
    "location_id": locationId,
    "name": name,
    "location_type": locationType,
    "parent_id": parentId,
    "is_visible": isVisible,
  };
}
