import 'dart:convert';

import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Widget/EditextWidget.dart';
import 'package:http/http.dart' as http;
import 'package:parnamtv/Widget/RaisedGradientButtonwidget.dart';
class ChangePassword extends StatefulWidget {
  const ChangePassword({Key? key}) : super(key: key);

  @override
  _ChangePasswordState createState() => _ChangePasswordState();
}

class _ChangePasswordState extends State<ChangePassword> {
  final formGlobalKey = GlobalKey<FormState>();
  String oldpassword = "";
  String newPassword = "";
  String cPassword = "";

  String name = "";
  String imageUrl = "";
  String userId = "";

  getDatafrompref() {
    name = ParnamTv.sharedPreference.getString(ParnamTv.userName) ?? '';
    imageUrl = ParnamTv.sharedPreference.getString(ParnamTv.profile_img) ?? '';
    userId = ParnamTv.sharedPreference.getString(ParnamTv.userID) ?? '';
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getDatafrompref();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Change Password "),
      ),
      body: Center(
        child: SingleChildScrollView(

          child: Container(
            decoration: new BoxDecoration(
              boxShadow: [
                new BoxShadow(
                  color: Colors.red,
                  blurRadius: 8.0,
                ),
              ],
            ),
            margin: EdgeInsets.all(15),
            child: Card(
              color: Colors.black,
              margin: EdgeInsets.all(5),
              elevation: 5,
              child: Container(

                child: Form(
                    key: formGlobalKey,
                    child: Column(
                      children: [
                        ClipPath(
                          clipper: DiagonalPathClipperOne(),
                          child: Container(
                            decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: <Color>[
                                    Color(0xFFda251d),
                                    Color(0xFFff9000)
                                  ],
                                )
                            ),
                            height: 100,
                            //color: Colors.deepOrange,
                          ),
                        ),

                        SizedBox(
                          height: 15,
                        ),

                        Container(
                          margin: EdgeInsets.all(15),
                          child: Column(

                            children: [


                              EditTextWidget(
                                label: 'Old Password',
                                hint: 'Enter password',
                                icon: Icons.person,

                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please enter password';
                                  }
                                  else {
                                    setState(() {
                                      oldpassword = value;
                                    });
                                  }
                                },
                                maxLength: 20,
                                keyboardtype: TextInputType.text,
                                isPassword: true,
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              EditTextWidget(
                                label: 'New Password',
                                hint: 'Enter New Password',
                                icon: Icons.person,

                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter New  Password';
                                  }
                                  else {
                                    setState(() {
                                      newPassword = value;
                                    });
                                  }
                                },
                                maxLength: 20,
                                keyboardtype: TextInputType.text,
                                isPassword: true,
                              ),
                              SizedBox(
                                height: 10,
                              ),
                              EditTextWidget(
                                label: 'Confirm Password',
                                hint: 'Enter Confirm Password',
                                icon: Icons.person,

                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return 'Please Enter Confirm Password';
                                  }
                                  else {
                                    setState(() {
                                      cPassword = value;
                                    });
                                  }
                                },
                                maxLength: 20,
                                keyboardtype: TextInputType.text,
                                isPassword: true,
                              ),
                              SizedBox(
                                height: 15,
                              ),
                              RaisedGradientButton(
                                child: Text(
                                  'Change Password',
                                  style: TextStyle(color: Colors.white,
                                      fontSize: 16, fontWeight: FontWeight.w600
                                  ),
                                ),
                                gradient: LinearGradient(
                                  colors: <Color>[
                                    Color(0xFFda251d),
                                    Color(0xFFff9000)
                                  ],
                                ), onClicked: () {
                                if (formGlobalKey.currentState!.validate()) {
                                  changepassword();
                                }
                              },

                              ),
                              SizedBox(
                                height: 20,
                              ),

                            ],
                          ),
                        )


                      ],
                    )
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void changepassword() async {
    EasyLoading.show(status: 'loading...');
    var url = Uri.parse('https://pranamtv.com/api/front/Users/ChangePassword');
    var response = await http.post(url,
        body: {
          'oldPassword': oldpassword,
          'newPassword': newPassword,
          'userID': userId
        },
        headers: {'x-api-key': 'api@pranamtv.com'}
    );
    print("resssssss,${response.body}");
    if (response.statusCode == 200) {
      EasyLoading.dismiss();
      var datass = jsonDecode(response.body);
      if (datass['Data']['status'] == 1) {
        ArtSweetAlert.show(
          context: context,
          barrierDismissible: false,
          artDialogArgs: ArtDialogArgs(
            confirmButtonColor: Colors.green,
            type: ArtSweetAlertType.success,
            title: "Success",
            text: datass['Data']['message'],
            confirmButtonText: ' OK ',
          ),

        );
        Navigator.pop(context);
      }
      else {
        ArtSweetAlert.show(
          context: context,
          barrierDismissible: false,
          artDialogArgs: ArtDialogArgs(
            confirmButtonColor: Colors.amberAccent,
            type: ArtSweetAlertType.warning,
            title: "Warning ! ",
            text: datass['Data']['message'],
            confirmButtonText: ' OK ',
          ),
        );
      }
    }
    else
      {
        EasyLoading.dismiss();
      }
  }
}
