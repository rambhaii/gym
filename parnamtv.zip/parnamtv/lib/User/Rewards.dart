import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:parnamtv/Widget/RewardWidget.dart';
class Rewards extends StatefulWidget {
  const Rewards({Key? key}) : super(key: key);

  @override
  _RewardsState createState() => _RewardsState();
}

class _RewardsState extends State<Rewards> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Color(0xffee4b28),
        title: Text(" Your Points:"),
       // leading: Icon(FontAwesomeIcons.trophy),
      ),
      body: SingleChildScrollView(
        child: Container(
          child: Column(
            children: [
                 RewardWidget(
                   productTitle: 'JBL T460BT Extra Bass Wireless On-Ear Headphones with Mic',
                   description: 'ghgy',
                   points: '2000',
                   price: '₹ 3,499.00',
                   url2: 'assets/Images/img02.jpg',
                   url: 'assets/Images/jblheadphone.jpg',
                   url1: 'assets/Images/img03.jpg',
                   url3: 'assets/Images/img04.jpg',
                 ),
              RewardWidget(
                productTitle: 'JBL T460BT Extra Bass Wireless On-Ear Headphones with Mic',
                description: 'hbjbhjb',
                points: '2000',
                price: '₹ 3,499.00',
                url2: 'assets/Images/img02.jpg',
                url: 'assets/Images/jblheadphone.jpg',
                url1: 'assets/Images/img03.jpg',
                url3: 'assets/Images/img04.jpg',
              ),
              RewardWidget(
                productTitle: 'JBL T460BT Extra Bass Wireless On-Ear Headphones with Mic',
                description: '',
                points: '2000',
                price: '₹ 3,499.00',
                url2: 'assets/Images/img02.jpg',
                url: 'assets/Images/jblheadphone.jpg',
                url1: 'assets/Images/img03.jpg',
                url3: 'assets/Images/img04.jpg',
              ),
              RewardWidget(
                productTitle: 'JBL T460BT Extra Bass Wireless On-Ear Headphones with Mic',
                description: '',
                points: '2000',
                price: '₹ 3,499.00',
                url2: 'assets/Images/img02.jpg',
                url: 'assets/Images/jblheadphone.jpg',
                url1: 'assets/Images/img03.jpg',
                url3: 'assets/Images/img04.jpg',
              )

              ],
          ),
        ),
      ),
    );
  }
}
