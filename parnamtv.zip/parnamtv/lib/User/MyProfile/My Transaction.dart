import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/User/Data/UserDrawerMenuWidget.dart';
import 'package:parnamtv/User/Data/plan_data.dart';
class MyTrasaction extends StatefulWidget {
  final VoidCallback openDrawer;

  const MyTrasaction({Key? key,required this.openDrawer}) : super(key: key);

  @override
  _MyTrasactionState createState() => _MyTrasactionState();
}

class _MyTrasactionState extends State<MyTrasaction> {
 MyPlanData?myPlanData;
 bool isReady=false;
  @override
  void initState() {
    // TODO: implement initState
    getTransaction();
    super.initState();
  }
  Future getTransaction() async{
    var url=Uri.parse('https://pranamtv.com/api/front/Users/TransectionHistory?userID=${ParnamTv.sharedPreference.getString(ParnamTv.userID)}');
    var response=await http.get(url,
        headers: {'x-api-key':'api@pranamtv.com'}
    );
    if(response.statusCode==200)
      {
        print("jhcdsfdgdfhghfd,${response.body}");
           setState(() {
             myPlanData= myPlanDataFromJson(response.body);
             isReady=false;
           });
      }
  }

  @override
  Widget build(BuildContext context) {
      final double w=MediaQuery.of(context).size.width;
      final double h=MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.black,
      appBar:AppBar(title: Text("My Transaction "),
          backgroundColor: Colors.black87,
          brightness: Brightness.dark,
          leading:  UserDrawerMenuWidget(onClicked: widget.openDrawer)
      ),
      body:ListView.builder(
          itemCount: myPlanData!.data.length,
          itemBuilder: (context,index){
        return Card(
        elevation: 10.0,
        shape: Border.all(width: 2, color:Colors.amber),
        child: Column(
        children: [
        ClipPath(
        clipper: MovieTicketBothSidesClipper(),
        child: Container(
        width: w,
        height: 90,
        color:Colors.red,
        child:Center(
        child: Text(myPlanData!.data[index].subscriptionName!,
        style: TextStyle(
        fontSize: 25.0,fontWeight: FontWeight.w600,
        color: Colors.white

        ),
        ),
        ),
        ),

        ),
        Container(

        margin: EdgeInsets.only(top: 10),
        child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
        Text("\u{20B9}"+' '+myPlanData!.data[index].amount!,
        style: TextStyle(
        fontSize: 25.0,fontWeight: FontWeight.w600
        ),
        ),
        Text(" / year",
        style: TextStyle(
        fontSize: 20.0,fontWeight: FontWeight.w300
        ),
        ),
        ],
        ),

        ),





        Text("You have Buy this  plan",style: TextStyle(color: Colors.green,fontWeight: FontWeight.w500,),

        ), Text("You have buy on Date : "+myPlanData!.data[index].createdAt!,style: TextStyle(color: Colors.green,fontWeight: FontWeight.w500,),

        ),
        SizedBox(
        height: 15,
        )
        ],
        ),
        );
      })


    );
  }
}
