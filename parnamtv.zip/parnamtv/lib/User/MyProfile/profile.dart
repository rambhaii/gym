import 'dart:convert';
import 'dart:io';

import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:blinking_text/blinking_text.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';

import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:marquee/marquee.dart';
import 'package:http/http.dart' as http;
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Home/LiveStreming.dart';
import 'package:parnamtv/User/ChangePassword.dart';
import 'package:parnamtv/User/Data/UserDrawerMenuWidget.dart';
import 'package:parnamtv/User/Data/user_drawer_iteam.dart';
import 'package:parnamtv/User/MyProfile/EditProfile.dart';
import 'package:parnamtv/User/Rewards.dart';
import 'package:parnamtv/User/Ui/UserDrawerwidget.dart';
import 'package:parnamtv/Widget/DrawerMenuWidget.dart';
import 'package:parnamtv/Widget/FreeSubscriberWidget.dart';

import '../Controller/UserController.dart';
class Profile extends StatefulWidget {
  final VoidCallback openDrawer;
  const Profile({Key? key,required this.openDrawer}) : super(key: key);

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile>{

  ScrollController _scrollController = ScrollController();
  String name ="";
  String email="";
  String userId="";
  String imageUrl="";
  String filepath="";
  UserController userController=Get.put(UserController());
  // _scrollToBottom() {
  //   _scrollController.jumpTo(_scrollController.position.maxScrollExtent);
  // }
  @override
  void initState() {
    // TODO: implement initState
    getDatafrompref();
   // reverseLists();

    super.initState();
  }
      getDatafrompref() async{
        name= ParnamTv.sharedPreference.getString(ParnamTv.userName)??'';
        imageUrl= ParnamTv.sharedPreference.getString(ParnamTv.profile_img)??'';
        userId= ParnamTv.sharedPreference.getString(ParnamTv.userID)??'';
        print("dsjvvus"+userId);
  }

 reverseLists() async{
     await Future.delayed(const Duration(milliseconds: 300));
     SchedulerBinding.instance.addPostFrameCallback((_) {
       _scrollController.animateTo(
             _scrollController.position.maxScrollExtent,
              duration: const Duration(milliseconds:1000),
               curve: Curves.fastOutSlowIn);

       }
     );
     reverseLists();
         }
  @override
  Widget build(BuildContext context) {

    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    final items = List<String>.generate(10, (i) => "Item $i");

    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xFF1e2125),
          backwardsCompatibility: false,

          title: Text("Profile"),
          leading:  UserDrawerMenuWidget(onClicked: widget.openDrawer),
        ),
    body:Container(

      child:SingleChildScrollView(
        child: Column(
          children: [
            Container(
              width: w,
              decoration: BoxDecoration(
                image: DecorationImage(
                    image: ExactAssetImage("assets/Images/userbg.jpg"),
                    fit: BoxFit.fill),
              ),
              child: Column(
                children: [
                  SizedBox(
                    height: 10,
                  ),
                   Stack(
                    children: [
                      CircleAvatar(
                        // radius: 50,
                        // backgroundColor: Colors.brown.shade800,

                        //child: imageUrl==""?:)
                          radius: 52,
                        backgroundColor: Colors.brown.shade800,
                          child:filepath==""? ClipOval(
                            child: CachedNetworkImage(
                              fit: BoxFit.fill,
                              imageUrl: imageUrl,
                              height: 120,
                              width: 120,
                              placeholder: (context,url)=>const CircularProgressIndicator(),
                              errorWidget: (context,url,error)=>const Icon(Icons.error),
                            ),
                          ):CircleAvatar(
                            backgroundColor: Colors.transparent,
                            radius: 50,
                            backgroundImage:FileImage(File(filepath)),
                          )
                   ),
                      Positioned(
                        top: 60,
                        left: 65,
                        child: IconButton(onPressed: () async{
                          final ImagePicker _picker = ImagePicker();
                          final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
                          print("filepath,${image!.path}");
                           setState(() {
                            filepath=image.path;
                           });
                           updatephotoprofile(filepath);
                        }, icon: Icon(FontAwesomeIcons.camera,size: 20,color: Colors.white,)
                        ),
                      )
                    ],
                  ),
                    Container(
                    margin: EdgeInsets.all(20),
                    child: Column(
                      children: [
                        Text(name,style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,
                            fontSize: 20
                        ),),
                        Text("FREE USER",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,
                            fontSize: 15,
                          height: 2

                        ),),
                        SizedBox(
                          height: 5.0,
                        ),
                        Text("SUBSCRIPTION ID: rz_test1234",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,
                            fontSize: 17,
                        ),),
                        Container(
                          margin: EdgeInsets.only(top: 15),
                          width: w*0.35,
                          child: RaisedButton(onPressed: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context)=>EditProfile()));
                          },
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(FontAwesomeIcons.userEdit,color: Colors.white,size: 15,),
                                Text("  Edit Profile",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,
                                  fontSize: 13,
                                ),),

                              ],
                            ),
                           color: Colors.red,
                          ),
                        ),
                        Container(
                          alignment: Alignment.bottomRight,
                          child: InkWell(
                            onTap: (){
                               Navigator.push(context, MaterialPageRoute(builder: (context)=>ChangePassword()));
                            },
                            child: Text("Change Password",style: TextStyle(color: Colors.blue,fontWeight: FontWeight.w500,
                              fontSize: 13,decoration : TextDecoration.underline
                            ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        )

                      ],
                    ),

                  )

                ],
              ),
            ),
            Container(
              margin: EdgeInsets.all(10),
              width: w,
              child: Card(
                elevation: 6,

                child: Column(
                  children: [
                    Container(
                      width: w,
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                            begin: Alignment.topLeft,
                            end: Alignment.bottomRight,
                            colors: [Color(0xffF8C300),Color(0xffEF9A48)],
                        ),
                      ),
                      child: Row(
                        
                        children: [
                          Icon(FontAwesomeIcons.listAlt,size: 18,),
                          Text("  NewsUpdates ",
                            style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                          BlinkText(
                            'New',
                            style: TextStyle(fontSize: 20.0, color: Colors.white,fontWeight: FontWeight.bold,fontStyle:FontStyle.italic),
                            duration: Duration(seconds: 1),
                            endColor: Colors.red,
                          ),
                        ],
                      ),
                    ),
                    Container(
                      width: w,
                      height: h*0.2,
                      child:ListView.builder(
                        itemCount: 1,
                        controller: _scrollController,
                        reverse: true,
                        shrinkWrap: true,
                        itemBuilder: (context, index) {
                          return ListTile(
                            title: Text(''),
                            // title: AutoSizeText(_listViewData[index], maxLines: 2),
                          //  dense: true,
                          );
                        },
                      ),

                    )

                  ],
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.all(10),
              width: w,
              child: Obx(()=>Card(
                  child: Column(
                    children: [
                      Container(
                        width: w,
                        padding: EdgeInsets.all(16),
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Color(0xffF8C300),Color(0xffEF9A48)],

                            )
                        ),
                        child: Row(

                          children: [
                            Icon(FontAwesomeIcons.trophy,size: 18,),
                            Text("  Your Earnings",
                              style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),


                          ],
                        ),
                      ),
                      Container(
                        width: w,
                        margin: EdgeInsets.all(15),

                         child: Column(
                           children: [
                                 Row(
                                   mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                   children: [
                                       Row(

                                         children: [
                                           Icon(FontAwesomeIcons.tv,color: Colors.red,),
                                           Text("    TV Viewing",
                                             style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,
                                               fontSize: 18,
                                             ),
                                           ),
                                         ],
                                       ),

                                     //  Text()
                                   Row(
                                     children: [
                                       Text(userController.viewPoint.value??"",

                                         style: TextStyle(color: Colors.red,fontWeight: FontWeight.w600,
                                           fontSize: 25,
                                         ),
                                       ), Text(" pts",
                                         style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,
                                           fontSize: 14,
                                         ),
                                       )
                                     ],
                                   )

                                   ],
                                 ),
                           SizedBox(
                            height:6 ,
                           ),
                             Row(
                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
                               children: [
                                 Row(

                                   children: [
                                     Icon(FontAwesomeIcons.share,color: Colors.red,),
                                     Text("    Sharing",
                                       style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,
                                         fontSize: 18,
                                       ),
                                     ),
                                   ],
                                 ),

                                 //  Text()
                                 Row(
                                   children: [
                                     Text(userController.sharePoint.value??"",

                                       style: TextStyle(color: Colors.red,fontWeight: FontWeight.w600,
                                         fontSize: 25,
                                       ),
                                     ), Text(" pts",
                                       style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,
                                         fontSize: 14,
                                       ),
                                     )
                                   ],
                                 )

                               ],
                             ),
                             SizedBox(
                               height:6 ,
                             ),
                             Row(
                               mainAxisAlignment: MainAxisAlignment.spaceBetween,
                               children: [
                                 Row(

                                   children: [
                                     Icon(FontAwesomeIcons.comments,color: Colors.red,),
                                     Text("    Review",
                                       style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,
                                         fontSize: 18,
                                       ),
                                     ),
                                   ],
                                 ),

                                 //  Text()
                                 Row(
                                   children: [
                                     Text(userController.reviewPoint.value??"",

                                       style: TextStyle(color: Colors.red,fontWeight: FontWeight.w600,
                                         fontSize: 25,
                                       ),
                                     ), Text(" pts",
                                       style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,
                                         fontSize: 14,
                                       ),
                                     )
                                   ],
                                 )

                               ],
                             )
                           ],
                         ),

                      ),
                      Container(
                        decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [Color(0xffF8C300),Color(0xffEF9A48)],

                            )
                        ),
                        padding: EdgeInsets.all(15),
                        child:Column(
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(

                                  children: [

                                    Text("Total Earning",
                                      style: TextStyle(color: Colors.black,fontWeight: FontWeight.w600,
                                        fontSize: 25,
                                      ),
                                    ),
                                  ],
                                ),

                                //  Text()
                                Row(
                                  children: [
                                    Text(userController.totalPoint.value??"",

                                      style: TextStyle(color: Colors.red,fontWeight: FontWeight.w600,
                                        fontSize: 35,
                                      ),
                                    ), Text(" pts",
                                      style: TextStyle(color: Colors.black,fontWeight: FontWeight.w400,
                                        fontSize: 25,
                                      ),
                                    )
                                  ],
                                )

                              ],
                            ),
                            Container(
                              margin: EdgeInsets.only(top: 15),
                              width: w*0.4,
                              child: RaisedButton(onPressed: (){
                                Navigator.push(context, MaterialPageRoute(builder: (context)=>Rewards()));
                              },
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(FontAwesomeIcons.trophy,color: Colors.white,size: 16,),
                                    Text("   Reddem Now",style: TextStyle(color: Colors.white,fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                    ),overflow: TextOverflow.ellipsis,

                                    ),

                                  ],
                                ),
                                color: Colors.red,
                              ),
                            )
                          ],

                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
            FreeSubscriber(
              yourSub: "Your Subscription",
              registrationtime:"Registration open from 15 jan 2019 to 01 feb 2019",
              onClick: () {  },
              Url:"assets/Images/banner3.jpg",
              heading: "Free TV Subscriber",
              description: '"If You have singing talent and your age is 40+, then Participate in a Singing Talent Show"',
            ),
            FreeSubscriber(
              yourSub: "",
              registrationtime:"   ",
              onClick: () {  },
              Url:"assets/Images/banner4.jpg",
              heading: "",
              description: '"If You have a good eye for film making, Make a Movie and Submit here. You would be a Winner and earn lot of money"',
            )

          ],
        ),
      ),
    )


    );
  }

  updatephotoprofile(String filename) async
  {
    EasyLoading.show(status: 'loading...');
    var url=Uri.parse('https://pranamtv.com/api/front/Users/UploadProfile');
       var request= await  http.MultipartRequest('POST',url);
       request.files.add(
           await http.MultipartFile.fromPath(
               'profile_pic',
               filename,
           )

       );
       request.fields.addAll({'userID': userId});
       request.headers.addAll({'x-api-key':'api@pranamtv.com'});
       var res = await request.send();
       var response=await http.Response.fromStream(res);
      print('responsesss,${response.body}');
    var datass=jsonDecode(response.body);
       if(response.statusCode==200)
         {
           EasyLoading.dismiss();
           if(datass['Data']['status']==1)
             {
               ArtSweetAlert.show(
                 context: context,
                 barrierDismissible: false,
                 artDialogArgs: ArtDialogArgs(
                   confirmButtonColor: Colors.green,
                   type: ArtSweetAlertType.success,
                   title:"Success",
                   text: datass['Data']['message'],
                   confirmButtonText: ' OK ',
                 ),
               );
               ParnamTv.sharedPreference.setString(ParnamTv.profile_img,datass['Data']['profile_img']);
             }
           else
             {
               ArtSweetAlert.show(
                 context: context,
                 barrierDismissible: false,
                 artDialogArgs: ArtDialogArgs(
                   confirmButtonColor: Colors.green,
                   type: ArtSweetAlertType.warning,
                   title:"Warning",
                   text: datass['Data']['message'],
                   confirmButtonText: ' OK ',
                 ),
               );
             }

         }
       else{
         EasyLoading.dismiss();
         ArtSweetAlert.show(
           context: context,
           barrierDismissible: false,
           artDialogArgs: ArtDialogArgs(
             confirmButtonColor: Colors.green,
             type: ArtSweetAlertType.danger,
             title:"Failed",
             text:response.body,
             confirmButtonText: ' OK ',
           ),
         );
       }

     //  Fluttertoast.showToast(msg: "${response.body}",toastLength: Toast.LENGTH_LONG);
  }


}


