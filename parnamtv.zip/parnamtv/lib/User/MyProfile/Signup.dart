import 'dart:convert';

import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:parnamtv/Animation/AnimationWidget.dart';
import 'package:parnamtv/User/MyProfile/Login.dart';
import 'package:http/http.dart' as http;
import 'package:parnamtv/Widget/EditextWidget.dart';
import 'package:parnamtv/Widget/RaisedGradientButtonwidget.dart';
class Signup extends StatefulWidget {
  const Signup({Key? key}) : super(key: key);

  @override
  _SignupState createState() => _SignupState();
}

class _SignupState extends State<Signup> {

   String firstname="";
   String lasttname="";
   String displayname="";
   String email="";
   String mobile="";
   String password="";
   String cpassword="";
   String pattern = r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
    TextEditingController etfirstname=new TextEditingController();
    TextEditingController etlastname=new TextEditingController();
    TextEditingController etdisplayname=new TextEditingController();
    TextEditingController etemail=new TextEditingController();
    TextEditingController etmobile=new TextEditingController();
    TextEditingController etpassword=new TextEditingController();
    TextEditingController etcpassword=new TextEditingController();

   final formGlobalKey=GlobalKey<FormState> ();


@override
  void initState() {

    // TODO: implement initState
    super.initState();
  }
  Future<void> signup() async{
    EasyLoading.show(status: 'loading...');
       var url=Uri.parse('https://pranamtv.com/api/front/Users/SignUp');
       var response=await http.post(url,
          body: {
            'fname':firstname,
            'lname':lasttname,
            'userName':displayname,
            'userEmail':email,
            'mobile':mobile,
            'password':password,
            'confirmPassword':cpassword,
          },
           headers: {'x-api-key':'api@pranamtv.com'}
       );
       if(response.statusCode==200)
         {
           EasyLoading.dismiss();
         // Fluttertoast.showToast(msg: response.body,toastLength: Toast.LENGTH_LONG);
          var datass=jsonDecode(response.body);
           if(datass['Data']['status']==1)
             {
               ArtSweetAlert.show(
                 context: context,
                 barrierDismissible: false,
                 artDialogArgs: ArtDialogArgs(
                   confirmButtonColor: Colors.green,
                   type: ArtSweetAlertType.success,
                   title:"Success",
                   text: datass['Data']['message'],
                   confirmButtonText: ' OK ',
                 ),

               );
               Navigator.pushReplacement(context,MaterialPageRoute(builder: (context)=>Login()));
             }
           else
             {
               ArtSweetAlert.show(
                 context: context,
                 barrierDismissible: false,
                 artDialogArgs: ArtDialogArgs(
                   confirmButtonColor: Colors.amberAccent,
                   type: ArtSweetAlertType.warning,
                   title: "Warning ! ",
                   text:  datass['Data']['message'],
                   confirmButtonText: ' OK ',
                 ),
               );
             }
         }
       else
         {
           EasyLoading.dismiss();
           Fluttertoast.showToast(msg: response.body,toastLength: Toast.LENGTH_LONG);

         }
  }


   @override
  Widget build(BuildContext context) {
    return Scaffold(

      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(image: AssetImage("assets/Images/whyus-bg.jpg"),
                fit: BoxFit.cover
            )
        ),
        child: Center(
          child: SingleChildScrollView(

            child: Container(
              decoration: new BoxDecoration(
                boxShadow: [
                  new BoxShadow(
                    color: Colors.red.withOpacity(0.6),
                    blurRadius: 5.0,

                  ),
                ],
              ),
              margin: EdgeInsets.all(10),
              child: Card(
                color: Colors.black,
                margin: EdgeInsets.all(5),
                elevation: 5,
                child: Container(
                  margin: EdgeInsets.all(15),
                  child: Form(
                    key: formGlobalKey,
                      child: Column(
                        children: [
                          SizedBox(
                           height: 15,
                          ),
                          EditTextWidget(

                            label: 'Name',
                            hint: 'Enter Name',
                            icon: Icons.person,
                            validator: (value){
                              if (value == null || value.isEmpty) {
                                return 'Please enter your name';
                              }
                              else{
                                setState(() {
                                  firstname=value;
                                });
                              }
                              return null;
                            },
                            maxLength: 20,
                            keyboardtype: TextInputType.text,
                            isPassword: false,
                          ),

                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            label: 'Last Name',
                            hint: 'Enter Last Name',
                            icon: Icons.person,
                            validator: (value){
                              if (value == null || value.isEmpty) {
                                return 'Please enter your last name';
                              }
                              else{
                                setState(() {
                                  lasttname=value;
                                });
                              }
                              },
                            maxLength: 50,
                            keyboardtype: TextInputType.text,
                            isPassword: false,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            label: 'Display Name',
                            hint: 'Enter Display Name',
                            icon: Icons.person,
                            validator: (value){
                              if (value == null || value.isEmpty) {
                                return 'Please enter your display name';
                              }
                              else{
                                setState(() {
                                  displayname=value;
                                });
                              }
                              },
                            maxLength: 50,
                            keyboardtype: TextInputType.text,
                            isPassword: false,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            label: 'Email',
                            hint: 'Enter Email',
                            icon: Icons.email,

                            validator: (value){
                              RegExp regex = new RegExp(pattern);
                              if(value==null|| value.isEmpty)
                              {
                                return "Please Enter Your email";
                              }
                              else  if (!(regex.hasMatch(value))) {
                                return "Invalid Email";
                              }
                              else{
                                setState(() {
                                  email=value;
                                });
                              }

                            },
                            maxLength: 40,
                            keyboardtype: TextInputType.emailAddress,
                            isPassword: false,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            label: 'Mobile No',
                            hint: 'Enter mobile number',
                            icon: Icons.person,

                            validator: (value){
                              if (value == null || value.isEmpty) {
                                return 'Please enter your Mobile number';
                              }
                              else{
                                setState(() {
                                  mobile=value;
                                });
                              }

                            },
                            maxLength: 10,
                            keyboardtype: TextInputType.phone,
                            isPassword: false,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            label: 'Password',
                            hint: 'Enter password',
                            icon: Icons.person,
                            validator: (value){
                              if (value == null || value.isEmpty) {
                                return 'Please enter password';
                              }
                              else{
                                setState(() {
                                  password=value;
                                });
                              }

                            },
                            maxLength: 20,
                            keyboardtype: TextInputType.text,
                            isPassword: true,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            label: 'Confirm Password',
                            hint: 'Enter Confirm password',
                            icon: Icons.person,

                            validator: (value){
                              if (value == null || value.isEmpty) {
                                return 'Please enter confirm password';
                              }
                              else{
                                setState(() {
                                  cpassword=value;
                                });
                              }

                            },
                            maxLength: 20,
                            keyboardtype: TextInputType.text,
                            isPassword: true,
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          AnimationWidget(

                            LRdir: 0.0,
                            sec: 2, UDdir: 2.0,
                            child: RaisedGradientButton(
                              child: Text(
                                'Sign Up',
                                style: TextStyle(color: Colors.white,
                                    fontSize: 16,fontWeight: FontWeight.w600
                                ),
                              ),
                              gradient: LinearGradient(
                                colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
                              ), onClicked: () {

                              if(formGlobalKey.currentState!.validate())
                              {
                                // Fluttertoast.showToast(
                                //     msg: "name$firstname\nlastname$lasttname\ndispalayname$displayname"
                                //         "email$email\n password$password cpassword$cpassword ",
                                //     toastLength: Toast.LENGTH_LONG);
                                signup();
                              }
                               },

                            ),
                          ),
                             SizedBox(
                               height: 20,
                              ),
                         Row(
                           mainAxisAlignment: MainAxisAlignment.center,
                           children :[
                             Text("You have Already Account ? ",style:TextStyle(
                                  color: Colors.white,fontSize: 15.0,fontWeight:FontWeight.bold
                                ),
                             ),
                             TextButton(
                               onPressed: (){
                                 Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Login()));
                               },
                               child: Text(
                                 " LogIn ",style:TextStyle(
                                   color: Colors.deepOrange,fontSize: 15.0,fontWeight:FontWeight.bold,
                                   decoration: TextDecoration.underline
                                  ),
                                ),
                              ),
                           ],
                         )
                        ],
                      )
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
