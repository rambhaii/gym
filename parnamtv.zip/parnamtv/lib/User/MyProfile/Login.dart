import 'dart:convert';
import 'package:flutter_login_facebook/flutter_login_facebook.dart';
import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:parnamtv/Animation/AnimationWidget.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Dailog/LoaderDailog.dart';
import 'package:parnamtv/DashBoard/Dashboard.dart';
import 'package:parnamtv/Data/LoginResponse.dart';
import 'package:parnamtv/User/MyProfile/Signup.dart';
import 'package:http/http.dart' as http;
import 'package:parnamtv/User/UserDashboard.dart';
import 'package:parnamtv/Widget/EditextWidget.dart';
import 'package:parnamtv/Widget/RaisedGradientButtonwidget.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
   late SharedPreferences pref;
   late Future<void> _launced;
        String _lunchurlfacebook="https://www.facebook.com/pranamtvofficial/";
        String _lunchurltwitter="https://pranamtv.com/pages/twitterAPI/index.php";
        String _lunchurlgoogle="https://pranamtv.com/pages/googleAPI/index.php";


  String email="";
  String password="";
  String pattern = r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';

  final formGlobalKey=GlobalKey<FormState> ();
  late LoginResponse loginResponse;
     Future<void> _lunchInBrowser(String url) async
     {
        if(await canLaunch(url))
          {
            await launch(url,forceSafariVC: false,forceWebView: false,
                headers: <String,String>{"headesr_key":  "headers_value"}
            );

          }
        else{
          throw "url not lunched $url";
        }
     }



  @override
  Widget build(BuildContext context) {
   final double w=MediaQuery.of(context).size.width;
   final double h=MediaQuery.of(context).size.height;
    return Scaffold(
      body: Container(
           decoration: BoxDecoration(
             image: DecorationImage(image: AssetImage("assets/Images/whyus-bg.jpg"),
               fit: BoxFit.cover
             )
           ),
        child: Center(
          child: SingleChildScrollView(
            child: Column(
              children: [
                AnimationWidget(
                    sec: 2,
                    UDdir: -2.0,
                    LRdir: 0.0,
                    child: Image.asset("assets/Images/logo.png",height: 70,width: 250,)),
               SizedBox(
               height: 30,
               )
                ,Container(
                  decoration: new BoxDecoration(
                    boxShadow: [
                      new BoxShadow(
                        color: Colors.red.withOpacity(0.6),
                        blurRadius: 8.0,
                      ),
                    ],
                  ),
                  margin: EdgeInsets.all(15),
                  child: Card(
                    color: Colors.black,
                    margin: EdgeInsets.all(5),
                    elevation: 5,
                    child: Container(

                      child: Form(
                          key: formGlobalKey,
                          child: Column(
                            children: [
                              ClipPath(
                                clipper: DiagonalPathClipperOne(),
                                child: Container(
                                  decoration: BoxDecoration(
                                      gradient: LinearGradient(
                                        colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
                                      )
                                  ),
                                  height: 100,
                                  //color: Colors.deepOrange,
                                  ),
                                ),

                              SizedBox(
                                height: 15,
                              ),

                      Container(
                        margin: EdgeInsets.all(15),
                        child: Column(

                          children: [
                            EditTextWidget(
                              label: 'Email',
                              hint: 'Enter Email',
                              icon: Icons.email,

                              validator: (value){
                                RegExp regex = new RegExp(pattern);
                                if(value==null|| value.isEmpty)
                                {
                                  return "Please Enter Your email";
                                }
                                else  if (!(regex.hasMatch(value))) {
                                  return "Invalid Email";
                                }
                                else{
                                  setState(() {
                                    email=value;
                                  });
                                }

                              },
                              maxLength: 60,
                              keyboardtype: TextInputType.emailAddress,
                              isPassword: false,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            EditTextWidget(
                              label: 'Password',
                              hint: 'Enter password',
                              icon: Icons.person,

                              validator: (value){
                                if (value == null || value.isEmpty) {
                                  return 'Please enter password';
                                }
                                else{
                                  setState(() {
                                    password=value;
                                  });
                                }
                                },
                              maxLength: 50,
                              keyboardtype: TextInputType.text,
                              isPassword: true,
                            ),
                            SizedBox(
                              height: 10,
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            AnimationWidget(
                              LRdir: 0.0,
                              sec: 3, UDdir: 1.0,
                              child: RaisedGradientButton(
                                child: Text(
                                  'Log In',
                                  style: TextStyle(color: Colors.white,
                                      fontSize: 16,fontWeight: FontWeight.w600
                                  ),
                                ),
                                gradient: LinearGradient(
                                  colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
                                ), onClicked: () {

                                if(formGlobalKey.currentState!.validate())
                                {
                                  // Fluttertoast.showToast(
                                  //     msg: "email$email\n password$password ",
                                  //     toastLength: Toast.LENGTH_LONG);

                                  Login();
                                }
                              },

                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children :[
                                Text("Create Account ?",style:TextStyle(
                                    color: Colors.white,fontSize: 15.0,fontWeight:FontWeight.bold
                                ),
                                ),
                                TextButton(
                                  onPressed: (){
                                    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>Signup()));
                                  },
                                  child: Text(
                                    "Register",style:TextStyle(
                                      color: Colors.deepOrange,fontSize: 15.0,fontWeight:FontWeight.bold,
                                      decoration: TextDecoration.underline
                                  ),
                                  ),
                                ),


                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                              children: [
                                Container(
                                  width: w*0.23,
                                  child: Divider(
                                    height: 4.0,
                                    color: Colors.grey,
                                  ),
                                ),
                                Container(
                                  width: w*0.32,
                                  child: Text("OR CONNECT WITH",
                                    style:TextStyle(
                                        color: Colors.grey,fontSize: 12.0,fontWeight:FontWeight.w500,

                                    ),textAlign: TextAlign.center,
                                  ),
                                ),
                                Container(
                                  width: w*0.23,
                                  child: Divider(
                                    height: 4.0,
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                IconButton(onPressed: (){
                                  signinWithGoogle();
                                },
                                  icon: Icon(FontAwesomeIcons.google,color: Color(0xffff9000),size: 18,),
                                  splashColor: Color(0xffff3300),
                                ),
                                   IconButton(onPressed: ()async{
                                     _lunchInBrowser(_lunchurlfacebook);
                                   },
                                     icon: Icon(FontAwesomeIcons.facebookF,color: Color(0xffff9000),size: 18,),
                                     splashColor: Color(0xffff3300),
                                   ),

                                IconButton(onPressed: (){
                                  _lunchInBrowser(_lunchurltwitter);
                                  },
                                  icon: Icon(FontAwesomeIcons.twitter,color: Color(0xffff9000),size: 18,),
                                 splashColor: Color(0xffff3300),
                                  focusColor: Colors.amberAccent,
                                ),


                              ],
                            )
                          ],
                        ),
                      )


                            ],
                          )
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
    Future<void> Login() async{

      EasyLoading.show(status: 'loading...');

      var url=Uri.parse('https://pranamtv.com/api/front/Users/Signin');
           var response=await http.post(url,
               body: {'userEmail':email,'password':password},
           headers: {'x-api-key':'api@pranamtv.com'}
               );
           print("resssssss,${response.body}");
           if(response.statusCode==200) {
            // Navigator.of(LoaderDaiolg()).pop();
            EasyLoading.dismiss();
                 var datass=json.decode(response.body);

           // Fluttertoast.showToast(msg:loginResponse.data.message,toastLength: Toast.LENGTH_LONG);

             if (datass['Data']['status'] == 1) {
               loginResponse = loginResponseFromJson(response.body);
               await ParnamTv.sharedPreference.setString(
                   ParnamTv.userName, loginResponse.data.userName!);
               await ParnamTv.sharedPreference.setString(
                   ParnamTv.firstname, loginResponse.data.fname!);
               await ParnamTv.sharedPreference.setString(
                   ParnamTv.lastname, loginResponse.data.lname!);
               await ParnamTv.sharedPreference.setString(
                   ParnamTv.userEmail, loginResponse.data.userEmail!);
               await ParnamTv.sharedPreference.setString(
                   ParnamTv.mobile, loginResponse.data.userMobile!);
               await ParnamTv.sharedPreference.setString(
                   ParnamTv.userID, loginResponse.data.userId!);
               await ParnamTv.sharedPreference.setString(
                   ParnamTv.profile_img, loginResponse.data.profileImg!);

               ArtSweetAlert.show(
                 context: context,
                 barrierDismissible: false,
                 artDialogArgs: ArtDialogArgs(
                   confirmButtonColor: Colors.green,
                   type: ArtSweetAlertType.success,
                   title:"Success",
                   text: datass['Data']['message'],
                   confirmButtonText: ' OK ',
                 ),
               );
               Navigator.pushReplacement(context,
                   MaterialPageRoute(builder: (context) => Dashboard()
                   ));
               //Navigator.pop(context);
             }
             else {
               ArtSweetAlert.show(
                 context: context,
                 barrierDismissible: false,
                 artDialogArgs: ArtDialogArgs(
                   confirmButtonColor: Colors.amberAccent,
                   type: ArtSweetAlertType.warning,
                   title: "Warning ! ",
                   text:  datass['Data']['message'],
                   confirmButtonText: ' OK ',
                 ),
               );
             }
           }
           else
             {
               print("resssssss,${response.body}");
             }
    }
   Future<void> signinWithGoogle() async {
    // const GOOGLE_CLIENT_DEV_KEY = '341661003983-jj420nakbv4992l9cn3c2aufkhp3eth8.apps.googleusercontent.com'; // This is a fake key. Please use a correct key.
     final GoogleSignIn _googleSignIn = new GoogleSignIn();
     try {
       var googleUserAccount = await _googleSignIn.signIn();
       print(googleUserAccount!.displayName);
      // Fluttertoast.showToast(msg: googleUserAccount.displayName.toString());
       SocialLogin(googleUserAccount.email.toString(),googleUserAccount.displayName.toString(),googleUserAccount.photoUrl.toString(),"");
     } catch (error) {
       print("jgvjgvj");
       print(error);
     }
   }
   Future<void> facebookAuth() async {
    // const GOOGLE_CLIENT_DEV_KEY = '341661003983-jj420nakbv4992l9cn3c2aufkhp3eth8.apps.googleusercontent.com'; // This is a fake key. Please use a correct key.


   }
   Future<void> SocialLogin(String email,String name,String profilepic,String mobile) async{

     EasyLoading.show(status: 'loading...');

     var url=Uri.parse('https://pranamtv.com/api/front/Users/SocialLogin');
     var response=await http.post(url,
         body: {
         "fname": name,
         "lname": name,
         "userName": name,
         "userEmail": email,
         "password":"",
         "confirmPassword":"",
         "mobile": mobile,
         "social_type":"1",//type 1=google,2=facebook,3=twitter
         "profile_img":profilepic,
         },
         headers: {'x-api-key':'api@pranamtv.com'}
     );
     print("resssssss,${response.body}");
     if(response.statusCode==200) {
       // Navigator.of(LoaderDaiolg()).pop();
       EasyLoading.dismiss();
       var datass=json.decode(response.body);

       // Fluttertoast.showToast(msg:loginResponse.data.message,toastLength: Toast.LENGTH_LONG);

       if (datass['Data']['status'] == 1) {
         loginResponse = loginResponseFromJson(response.body);
         await ParnamTv.sharedPreference.setString(
             ParnamTv.userName, loginResponse.data.userName!);
         await ParnamTv.sharedPreference.setString(
             ParnamTv.firstname, loginResponse.data.fname!);
         await ParnamTv.sharedPreference.setString(
             ParnamTv.lastname, loginResponse.data.lname!);
         await ParnamTv.sharedPreference.setString(
             ParnamTv.userEmail, loginResponse.data.userEmail!);
         await ParnamTv.sharedPreference.setString(
             ParnamTv.mobile, loginResponse.data.userMobile!);
         await ParnamTv.sharedPreference.setString(
             ParnamTv.userID, loginResponse.data.userId!);
         await ParnamTv.sharedPreference.setString(
             ParnamTv.profile_img, loginResponse.data.profileImg!);

         ArtSweetAlert.show(
           context: context,
           barrierDismissible: false,
           artDialogArgs: ArtDialogArgs(
             confirmButtonColor: Colors.green,
             type: ArtSweetAlertType.success,
             title:"Success",
             text: datass['Data']['message'],
             confirmButtonText: ' OK ',
           ),
         );
         Navigator.pushReplacement(context,
             MaterialPageRoute(builder: (context) => Dashboard()
             ));
         //Navigator.pop(context);
       }
       else {
         ArtSweetAlert.show(
           context: context,
           barrierDismissible: false,
           artDialogArgs: ArtDialogArgs(
             confirmButtonColor: Colors.amberAccent,
             type: ArtSweetAlertType.warning,
             title: "Warning ! ",
             text:  datass['Data']['message'],
             confirmButtonText: ' OK ',
           ),
         );
       }
     }
     else
     {
       print("resssssss,${response.body}");
     }
   }
}
