import "package:flutter/material.dart";
import 'package:parnamtv/User/Data/UserDrawerMenuWidget.dart';
class MyPlan extends StatefulWidget {
  final VoidCallback openDrawer;
  const MyPlan({Key? key,required this.openDrawer}) : super(key: key);

  @override
  _MyPlanState createState() => _MyPlanState();
}

class _MyPlanState extends State<MyPlan> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:AppBar(title: Text("My Plan "),
          backgroundColor:Colors.black87,
          leading:  UserDrawerMenuWidget(onClicked: widget.openDrawer)
      ),
      body: Container(
        child: Column(
          children: [

          ],
        ),
      ),
    );
  }
}
