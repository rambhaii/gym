
import 'dart:convert';


import 'package:art_sweetalert/art_sweetalert.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:parnamtv/Animation/AnimationWidget.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Data/LoginResponse.dart';
import 'package:parnamtv/User/Data/CityData.dart';
import 'package:parnamtv/Widget/EditextWidget.dart';
import 'package:parnamtv/Widget/RaisedGradientButtonwidget.dart';
import "package:http/http.dart" as http;

import 'package:parnamtv/themes/app_theme.dart';
class EditProfile extends StatefulWidget {
  const EditProfile({Key? key}) : super(key: key);

  @override
  _EditProfileState createState() => _EditProfileState();
}

class _EditProfileState extends State<EditProfile> {
  TextEditingController etfirstname = new TextEditingController(text:ParnamTv.sharedPreference.getString(ParnamTv.firstname));
  TextEditingController etlastname = new TextEditingController(text:ParnamTv.sharedPreference.getString(ParnamTv.lastname));
  TextEditingController etdisplayname = new TextEditingController(text:ParnamTv.sharedPreference.getString(ParnamTv.userName));
  TextEditingController etemail = new TextEditingController(text:ParnamTv.sharedPreference.getString(ParnamTv.userEmail));
  TextEditingController etmobile = new TextEditingController(text:ParnamTv.sharedPreference.getString(ParnamTv.mobile));

  TextEditingController etdob = TextEditingController(text:ParnamTv.sharedPreference.getString(ParnamTv.dob));
  TextEditingController etsubscription = TextEditingController(text: "Free User");
  TextEditingController etaddress = TextEditingController(text:ParnamTv.sharedPreference.getString(ParnamTv.address));
  String pattern = r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$';
  String?countryValue;
  String?stateValue;
  String?cityValue;
  var currentSelectedValue;
  var selectcontryvalue="India";
  var selectstatevalue="Uttar Pradesh";
  var setectcityvalue;
  List<String> genders = ["Male", "Female", "Transgender"];
  List<String> country = ["India"];
  List<String> state = ["Uttar Pradesh"];
  List<Map> city=[];
  String selectedcountryid="100";
  String selectedstateid="755";
  String selectecityid="";
  final formGlobalKey = GlobalKey<FormState>();

  DateTime selectedDate = DateTime.now();
  @override
  void initState() {
    // TODO: implement initState
    getAllCity();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final double w = MediaQuery
        .of(context)
        .size
        .width;
    final double h = MediaQuery
        .of(context)
        .size
        .height;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text("Edit Profile"),
        centerTitle: true,
        elevation: 0,
        backgroundColor: Colors.black87,
      ),
      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/Images/whyus-bg.jpg"),
                fit: BoxFit.cover
            )
        ),
        child: Center(
          child: SingleChildScrollView(

            child: Container(
              margin: EdgeInsets.only(top: 100, bottom: 10, left: 10, right: 10),
              decoration: new BoxDecoration(
                boxShadow: [
                  new BoxShadow(
                    color: Colors.red.withOpacity(0.6),
                    blurRadius: 5.0,

                  ),
                ],
              ),

              child: Card(
                color: Colors.black,
                margin: EdgeInsets.all(5),
                elevation: 5,
                child: Container(
                  margin: EdgeInsets.all(15),
                  child: Form(
                      key: formGlobalKey,
                      child: Column(
                        children: [
                          SizedBox(
                            height: 15,
                          ),
                          EditTextWidget(
                            controller: etfirstname,
                            label: 'Name',
                            hint: 'Enter Name',
                            icon: Icons.person,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please enter your name';
                              }
                              return null;
                            },
                            maxLength: 20,
                            keyboardtype: TextInputType.text,
                            isPassword: false,
                          ),

                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            controller: etlastname,
                            label: 'Last Name',
                            hint: 'Enter Last Name',
                            icon: Icons.person,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please Enter Your Last Name';
                              }
                            },
                            maxLength: 50,
                            keyboardtype: TextInputType.text,
                            isPassword: false,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            controller: etdisplayname,
                            label: 'Display Name',
                            hint: 'Enter Display Name',
                            icon: Icons.person,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please Enter Your Display Name';
                              }
                            },
                            maxLength: 50,
                            keyboardtype: TextInputType.text,
                            isPassword: false,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          GestureDetector(
                              onTap: () => _selectDate(),
                              child: AbsorbPointer(
                                child: EditTextWidget(
                                  controller: etdob,
                                  label: 'Date Of Birth',
                                  hint: 'Date Of Birth',
                                  icon: Icons.person,
                                  validator: (value) {
                                    if (value == null || value.isEmpty) {
                                      return 'Please Enter Your Date Of Birth';
                                    }
                                  },
                                  maxLength: 50,
                                  keyboardtype: TextInputType.text,
                                  isPassword: false,
                                ),

                              )),

                          SizedBox(
                            height: 10,
                          ),
                          Container(
                            padding: EdgeInsets.only(left: 10, right: 10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                border: Border.all(width: 1, color: Colors.grey)
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton(
                                value: currentSelectedValue,
                                items: genders.map((String item) {
                                  return DropdownMenuItem<String>(
                                    child: Text("$item"),
                                    value: item,
                                  );
                                }).toList(),
                                onChanged: (value) {
                                  setState(() {
                                    currentSelectedValue = value;
                                    print("$currentSelectedValue");
                                  });
                                },
                                hint: Text("Select Gender", style: TextStyle(
                                    color: Colors.deepOrangeAccent),),
                                disabledHint: Text("Disabled"),
                                elevation: 8,
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                                icon: Icon(Icons.arrow_drop_down_circle),
                                iconDisabledColor: Colors.red,
                                iconEnabledColor: Colors.white,
                                isExpanded: true,
                                dropdownColor: Colors.black.withOpacity(0.8),
                              ),
                            ),
                          ),

                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            controller: etemail,
                            label: 'Email',
                            hint: 'Enter Email',
                            icon: Icons.email,
                            isdisable: false,
                            validator: (value) {
                              RegExp regex = new RegExp(pattern);
                              if (value == null || value.isEmpty) {
                                return "Please Enter Your Email";
                              }
                              else if (!(regex.hasMatch(value))) {
                                return "Invalid Email";
                              }
                            },
                            maxLength: 40,
                            keyboardtype: TextInputType.emailAddress,
                            isPassword: false,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            controller: etsubscription,
                            label: 'Subscription Type',
                            hint: 'Enter Subscription',
                            icon: Icons.person,
                            isdisable: false,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please Enter Your Mobile Number';
                              }
                            },
                            maxLength: 10,
                            keyboardtype: TextInputType.text,
                            isPassword: false,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            controller: etmobile,
                            label: 'Mobile No',
                            hint: 'Enter Mobile Number',
                            icon: Icons.person,
                            validator: (value) {
                              if (value == null || value.isEmpty) {
                                return 'Please Enter Your Mobile Number';
                              }
                            },
                            maxLength: 10,
                            keyboardtype: TextInputType.phone,
                            isPassword: false,
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          EditTextWidget(
                            controller: etaddress,
                            label: 'Address Line 1',
                            hint: 'Enter Your Address',
                            icon: Icons.person,

                            maxLength: 220,
                            keyboardtype: TextInputType.text,
                            isPassword: false,
                            validator: (value) {
                              return null;
                            },
                          ),
                          SizedBox(
                            height: 10,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: w * 0.4,
                                padding: EdgeInsets.only(left: 10, right: 10),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    border: Border.all(
                                        width: 1, color: Colors.grey)
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton(
                                    value: selectcontryvalue,
                                    items: country.map((String item) {
                                      return DropdownMenuItem<String>(
                                        child: Text("$item"),
                                        value: item,
                                      );
                                    }).toList(),
                                    onChanged: (value) {
                                      setState(() {
                                        //selectcontryvalue = value;
                                        selectedcountryid="100";
                                        print("$selectcontryvalue");
                                      });
                                    },
                                    hint: Text("Select Country",
                                      style: TextStyle(
                                          color: Colors.deepOrangeAccent),),
                                    disabledHint: Text("Disabled"),

                                    style: TextStyle(
                                        color: Colors.white, fontSize: 13),

                                    iconDisabledColor: Colors.red,
                                    iconEnabledColor: Colors.white,
                                    isExpanded: true,
                                    dropdownColor: Colors.grey,
                                  ),
                                ),
                              ),
                              Container(
                                width: w * 0.4,
                                padding: EdgeInsets.only(left: 10, right: 10),
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(5),
                                    border: Border.all(
                                        width: 1, color: Colors.grey)
                                ),
                                child: DropdownButtonHideUnderline(
                                  child: DropdownButton(
                                    value: selectstatevalue,
                                    items: state.map((String item) {
                                      return DropdownMenuItem<String>(
                                        child: Text("$item"),
                                        value: item,
                                      );
                                    }).toList(),
                                    onChanged: (value) {
                                      setState(() {
                                       // selectstatevalue = value;
                                        selectedstateid="755";
                                        print("$selectstatevalue");
                                      });
                                    },
                                    hint: Text("Select State",
                                      style: TextStyle(
                                          color: Colors.deepOrangeAccent,
                                          fontSize: 13),),
                                    disabledHint: Text("Disabled"),
                                    style: TextStyle(
                                        color: Colors.white, fontSize: 14),

                                    iconDisabledColor: Colors.red,
                                    iconEnabledColor: Colors.white,
                                    isExpanded: true,
                                    dropdownColor: Colors.grey,
                                  ),
                                ),
                              ),
                            ],
                          ),

                          SizedBox(
                            height: 10,
                          ),
                          Container(

                            padding: EdgeInsets.only(left: 10, right: 10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                border: Border.all(
                                    width: 1, color: Colors.grey)
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton(
                                value: setectcityvalue,
                                items: city.map((dynamic item) {

                                  return DropdownMenuItem<Map>(
                                    child: Text("${item["name"]}"),
                                    value: item,
                                  );
                                }).toList(),
                                onChanged: (value) {
                                  setState(() {
                                    setectcityvalue = value;
                                    selectecityid=setectcityvalue["location_id"];
                                    print("${setectcityvalue["location_id"]}");
                                  });
                                },
                                hint: Text("Select City",
                                  style: TextStyle(
                                      color: Colors.deepOrangeAccent,
                                      fontSize: 13),),
                                disabledHint: Text("Disabled"),
                                style: TextStyle(
                                    color: Colors.white, fontSize: 14),

                                iconDisabledColor: Colors.red,
                                iconEnabledColor: Colors.white,
                                isExpanded: true,
                                dropdownColor: Colors.grey,
                              ),
                            ),
                          ),

                          SizedBox(
                            height: 15,
                          ),
                          AnimationWidget(

                            LRdir: 0.0,
                            sec: 2, UDdir: 2.0,
                            child: RaisedGradientButton(
                              child: Text(
                                'Update Profile',
                                style: TextStyle(color: Colors.white,
                                    fontSize: 16, fontWeight: FontWeight.w600
                                ),
                              ),
                              gradient: LinearGradient(
                                colors: <Color>[
                                  Color(0xFFda251d),
                                  Color(0xFFff9000)
                                ],
                              ), onClicked: ()async {
                                   if(formGlobalKey.currentState!.validate()) {
                                     print("validatess s dhvhshg");
                                     var url = Uri.parse("https://pranamtv.com/api/front/Users/UpdateProfileDetails");
                                     var response = await http.post(
                                         url, headers: {
                                       'x-api-key': 'api@pranamtv.com'
                                     },
                                       body: {
                                         "userID":ParnamTv.sharedPreference.getString(ParnamTv.userID),
                                         "fname":etfirstname.text,
                                         "lname":etlastname.text,
                                         "userName":etdisplayname.text,
                                         "dob":etdob.text,
                                         "gender":"1",
                                         "userMobile":etmobile.text,
                                         "address1":etaddress.text,
                                         "country":selectedcountryid,
                                         "state":selectedstateid,
                                         "city":selectecityid

                                       },
                                     );
                                     if (response.statusCode == 200) {
                                       var datass=jsonDecode(response.body);

                                       if(datass['Data']['status']==1)
                                       {
                                         LoginResponse   loginResponse = loginResponseFromJson(response.body);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.userName, loginResponse.data.userName!);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.firstname, loginResponse.data.fname!);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.lastname, loginResponse.data.lname!);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.userEmail, loginResponse.data.userEmail!);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.mobile, loginResponse.data.userMobile!);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.userID, loginResponse.data.userId!);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.city, loginResponse.data.city!);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.state, loginResponse.data.state!);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.country, loginResponse.data.country!);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.dob, loginResponse.data.dob!);
                                         await ParnamTv.sharedPreference.setString(
                                             ParnamTv.address, loginResponse.data.address1!);
                                         ArtSweetAlert.show(
                                           context: context,
                                           barrierDismissible: false,
                                           artDialogArgs: ArtDialogArgs(
                                             confirmButtonColor: Colors.green,
                                             type: ArtSweetAlertType.success,
                                             title:"Success",
                                             text: datass['Data']['message'],
                                             confirmButtonText: ' OK ',
                                           ),

                                         );

                                       }
                                       else{
                                         print("refbhhfv");
                                       }
                                       }
                                     }
                                   }



                            ),
                          ),

                          SizedBox(height: 20.0,),


                        ],
                      )
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  _selectDate() async {
    DateTime?pickedDate = await showModalBottomSheet<DateTime>(
      context: context,
      builder: (context) {
        DateTime?tempPickedDate;
        return Container(
          height: 250,
          child: Column(
            children: <Widget>[
              Container(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    CupertinoButton(
                      child: Text('Cancel'),
                      onPressed: () {
                        Navigator.of(context).pop();
                      },
                    ),
                    CupertinoButton(
                      child: Text('Done'),
                      onPressed: () {
                        Navigator.of(context).pop(tempPickedDate);
                      },
                    ),
                  ],
                ),
              ),
              Divider(
                height: 0,
                thickness: 1,
              ),
              Expanded(
                child: Container(
                  child: CupertinoDatePicker(
                    mode: CupertinoDatePickerMode.date,
                    onDateTimeChanged: (DateTime dateTime) {
                      tempPickedDate = dateTime;
                    },
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );

    if (pickedDate != null && pickedDate != selectedDate) {
      setState(() {
        selectedDate = pickedDate;
        etdob.text = pickedDate.toString().split(" ")[0];
        ;
      });
    }
  }

  Future<void> getAllCity() async
  {
    var url = Uri.parse("https://pranamtv.com/api/front/Users/GetCity");
    var response = await http.get(
        url, headers: {'x-api-key': 'api@pranamtv.com'});
    if (response.statusCode == 200) {
   CityData cityData=cityDataFromJson(response.body);
   print("dhsfsdhvjd,${cityData.data!.data![0].name}");
    for(int i=0;cityData.data!.data!.length>0;i++)
      {
        setState(() {
          city.add({"name":cityData.data!.data![i].name,"location_id":cityData.data!.data![i].locationId});

        });
      }

    }
  }
}
