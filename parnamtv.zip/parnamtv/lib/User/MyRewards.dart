import 'package:flutter/material.dart';
class MyRewards extends StatefulWidget {
  const MyRewards({Key? key}) : super(key: key);

  @override
  _MyRewardsState createState() => _MyRewardsState();
}

class _MyRewardsState extends State<MyRewards> {
  @override
  Widget build(BuildContext context) {
    double w=MediaQuery.of(context).size.width;
    double h=MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Container(
          width: w,
            margin: EdgeInsets.all(10),
            child: Card(
              child: SingleChildScrollView(
                child: Container(
                  padding: EdgeInsets.all(10),
                  child: Column(
                  children: [
                    Text("Terms & Conditions For Redeem Your Points",style: TextStyle(color: Colors.black,fontSize: 20,fontWeight: FontWeight.w400,fontStyle: FontStyle.italic,),),
                    SizedBox(
                      height: 15,
                    ),
                    Text("If you have greater than 500 points then you redeem your points and get Gifts.\n"
                        "You can redeem your point-between 1 to 7th date of anymonth.\n"
                        "Your received rewards is issue on 20 to 30th date of everymonth ."
                      ,style: TextStyle(color: Colors.black54,fontSize: 18,fontWeight: FontWeight.w400,height: 1.5)),
                    SizedBox(
                      height: 15,
                    ),
                  ],
                  ),
                ),
              ),
            )
        ),
      ),
    );
  }
}
