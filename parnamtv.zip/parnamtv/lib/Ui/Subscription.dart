import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:parnamtv/Config/Configration.dart';
import 'package:parnamtv/Dailog/TimeHandler.dart';
import 'package:parnamtv/Data/SubscriptionData.dart';

import 'package:parnamtv/PaymentGateway/Payment.dart';
import 'package:http/http.dart'as http;
import 'package:parnamtv/User/MyProfile/Login.dart';
import 'package:parnamtv/Widget/CircularLoader.dart';

import 'package:parnamtv/Widget/SubscriptionWidget.dart';
class Subscription extends StatefulWidget {
  //const Subscription({Key key}) : super(key: key);

  @override
  _SubscriptionState createState() => _SubscriptionState();
}
    
class _SubscriptionState extends State<Subscription> {
 SubscriptionData?subscriptionData;
  bool isReady=false;
  String userId="";
@override
  void initState() {
    // TODO: implement initState
     userId=ParnamTv.sharedPreference.getString(ParnamTv.userID)??"";
   getPrescriptionData();
    super.initState();
  }

  void  getPrescriptionData() async  {
    EasyLoading.show(status: 'loading...');
      var url=Uri.parse("https://pranamtv.com/api/front/Subscription/SubscriptionPlan?userID=$userId");
      var response = await http.get(url,headers: {'x-api-key':'api@pranamtv.com'});
    print("subssssss${response.body}");
      if(response.statusCode==200)
        {
          EasyLoading.dismiss();
          setState(() {
            subscriptionData=SubscriptionDataFromJson(response.body);
            isReady=true;
          });

          print("subssssss${response.body}");
        }
      else
        {
          EasyLoading.dismiss();
        }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Subscription Plan"),

      ),
      body:isReady==true?
              ListView.builder(
                  itemCount:subscriptionData!.data!.length ,
                  itemBuilder:(context,index) =>Container(
                    margin: EdgeInsets.all(15),
                      child: new SubscriptionWidget(heading:subscriptionData!.data![index].subscriptionName! ,
                          rupees: subscriptionData!.data![index].subscriptionPrice!,
                          color:Color(int.parse("0xff"+subscriptionData!.data![index].color!)), onClick: () {
                       userId==""?Navigator.push(context, MaterialPageRoute(builder: (BuildContext context) =>Login())):
                       subscriptionData!.data![index].subscriptionPurchaseStatus==0?
                      Navigator.push(context, MaterialPageRoute(builder: (context)=>PaymentGatway(amount: subscriptionData!.data![index].subscriptionPrice!,
                        SubscriptionId: subscriptionData!.data![index].subscriptionPlanMasterId!,))):null;
                      }, planInfoData:subscriptionData!.data![index].planInfoData!,
                        status: subscriptionData!.data![index].subscriptionPurchaseStatus!.toString(),),
                  ),

              ): Container()

    );
  }
}
