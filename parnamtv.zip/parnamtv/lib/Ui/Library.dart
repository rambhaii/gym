import 'package:flutter/material.dart';
import 'package:flutter_easyloading/flutter_easyloading.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';

import 'package:http/http.dart' as http;
import 'package:parnamtv/Dailog/LoaderDailog.dart';
import 'package:parnamtv/Data/GelAllLibraryData.dart';
import 'package:parnamtv/Utils/Loader.dart';
import 'package:parnamtv/Widget/CircularLoader.dart';
import 'package:parnamtv/Widget/LibraryWidget.dart';
class Library extends StatefulWidget {
 // const Library({Key key}) : super(key: key);

  @override
  _LibraryState createState() => _LibraryState();
}

class _LibraryState extends State<Library> {
  //var getAllLibraryData;
 // final LibraryController libraryController =Get.put(LibraryController());
  var result;
 late GetAllLibraryData getAllLibraryData;
 bool isReady=false;
  @override
  void initState() {
    // getAllLibraryData;
    // TODO: implement initState
    getAllLibrary();
    super.initState();
  }
     Future getAllLibrary() async{
       EasyLoading.show(status: 'loading...');
         var url=Uri.parse("https://pranamtv.com/api/front/GetLibraryList?limit=20&start=0");
         var response=await http.get(url,headers: {'x-api-key':'api@pranamtv.com'});
         if(response.statusCode==200)
           {
            EasyLoading.dismiss();
             setState(() {
               getAllLibraryData=getAlllibraryDataFromJson(response.body);
               isReady=true;
             });
             print("jfdsjjgfdjfff,${getAllLibraryData.data[0].bannerImg},${getAllLibraryData.data[0].quality},${getAllLibraryData.data[0].category},${getAllLibraryData.data[0].title}",);
           }
         else{
           isReady=false;
         //  getAllLibraryData=getAlllibraryDataFromJson(null);
         }
     }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
     backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        title: Text("Library"),

      ),
      body: Container(
        margin: EdgeInsets.all(15),
        child:isReady!=false? GridView.count(
            crossAxisCount: 2,
            crossAxisSpacing: 10,
            mainAxisSpacing: 10,
            children:List.generate(getAllLibraryData.data.length, (index) =>new LibraryWidget(Poster:getAllLibraryData.data[index].bannerImg,
              Qulity: getAllLibraryData.data[index].quality, Category:getAllLibraryData.data[index].category, Title: getAllLibraryData.data[index].title ,
            ),

        )):Container(),
      ),


    );
  }

}
