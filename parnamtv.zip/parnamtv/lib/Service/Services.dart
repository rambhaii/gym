import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:parnamtv/Animation/AnimationWidget.dart';
import 'package:parnamtv/Widget/DrawerMenuWidget.dart';
import 'package:parnamtv/Widget/HorizentalLine.dart';
class Services extends StatefulWidget {
  final VoidCallback openDrawer;
  final int?flag;
  const Services(
      {
        Key?key,
        required this.openDrawer, this.flag,
      }):super(key: key);

  @override
  _ServicesState createState() => _ServicesState();
}

class _ServicesState extends State<Services> {
  final Shader linearGradient = LinearGradient(
    colors: <Color>[Color(0xFFda251d), Color(0xFFff9000)],
  ).createShader(new Rect.fromLTWH(0.0, 0.0, 200.0, 70.0));

  @override
  Widget build(BuildContext context) {
    final double w=MediaQuery.of(context).size.width;
    final double h=MediaQuery.of(context).size.height;
    return Scaffold(
      backgroundColor: Colors.black,
   extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.black,
        brightness: Brightness.dark,
        elevation: 0,
        title: AnimationWidget(
            sec: 2,
            LRdir: 0.0,
            UDdir: 2.0,
            child: Text("Services")),
        leading: widget.flag==null? DrawerMenuWidget(onClicked: widget.openDrawer):

        InkWell(
            onTap: (){
             Navigator.pop(context);
            },
            child: Icon(Icons.arrow_back)),

      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            SizedBox(height: 90,),
            Container(
              margin: EdgeInsets.all(10),
              child:Image.asset("assets/Images/umbrella.jpg",  height: h*0.2,width: w,fit: BoxFit.fill,) ,
            ),
            Container(
              margin: EdgeInsets.only(left: 5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      FaIcon(FontAwesomeIcons.film,color: Color(0xffda261e),),
                      Text(" OUR SERVICES",style: TextStyle(color:Color(0xffda261e),
                          fontWeight: FontWeight.w500,fontSize: 20.0
                      )
                      ),
                    ],
                  ),
                 SizedBox(
                   height: 5.0,
                 ),
                 HorizentaLine(
                   width: w*0.3,
                 )


                ],
              ),
            ),
            Container(
              height: h*0.45,
              width: w,
          
              margin: EdgeInsets.all(5),
              child: Card(
                elevation: 15.0,
                color: Color(0xff1e2125),
                
                child: Container(
                  padding: EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [

                      Text(
                        'Introduction',
                        style: new TextStyle(
                            fontSize: 25.0,
                            fontWeight: FontWeight.w600,
                            foreground: new Paint()..shader = linearGradient),textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 10,),
                      Text("The Pranam team has enforced its pool of "
                          "talent to give quality and enjoyable entertainment to the people. Thus pushing their team to traverse extra "
                          "miles to fulfill the commitment.  ",style: TextStyle(color: Colors.white,
                        fontSize:14,
                      ),
                        maxLines: 4,overflow: TextOverflow.ellipsis,
                      ),
                      SizedBox(height: 10,),
                      Text("To keep the promises we have brought in well equipped world acclaimed technology in film "
                          "production with experienced and competent professionals thus reinforcing the trust in the film fraternity "
                          "and among the clients. Our Umbrella provides the complete solution to its clients from "
                          "location search to the final product. We have no wavering in sa"
                          "ying that “You come with an idea and go out with total solution”. After"
                          " all it is a matter of repute for us too.  ",style: TextStyle(color: Colors.white
                          ,fontSize:14,
                      ),
                        maxLines: 10,overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),

              ),
            ),
            SizedBox(
              height: 20,
            ),
            Container(
              margin: EdgeInsets.only(right: 5.0,left: 5.0),
              child: HorizentaLine(
                width: w,
              ),
            ),
      Container(
        margin: EdgeInsets.only(left: 5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                FaIcon(FontAwesomeIcons.film,color: Color(0xffda261e),),
                Container(
                  child: Text("  The Film Production categories we\n are specialized",style: TextStyle(color:Color(0xffda261e),
                      fontWeight: FontWeight.w500,fontSize: 20.0
                  ),maxLines: 2,overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            SizedBox(
              height: 5.0,
            ),
            HorizentaLine(
              width: w*0.3,
            )


          ],
        ),
      ),
       SizedBox(
         height: 15,
       ),
            Container(
              height: h*0.25,
              width: w,

              margin: EdgeInsets.all(5),
              child: Card(
                elevation: 15.0,
                color: Color(0xff1e2125),

                child: Container(
                  padding: EdgeInsets.all(10),


                  ),
                ),

              ),
            Container(
              margin: EdgeInsets.only(left: 5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 20,
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      FaIcon(FontAwesomeIcons.film,color: Color(0xffda261e),),
                      Expanded(
                        child: Text("  Pranam believes in collective growth & progress",style: TextStyle(color:Color(0xffda261e),
                            fontWeight: FontWeight.w500,fontSize: 20.0
                        ),maxLines: 2,overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  SizedBox(
                    height: 5.0,
                  ),
                  HorizentaLine(
                    width: w*0.3,
                  ),
                  Container(

                    width: w,

                    margin: EdgeInsets.all(5),
                    child: Card(
                      elevation: 15.0,
                      color: Color(0xff1e2125),

                      child: Container(
                        padding: EdgeInsets.all(10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("It is a matter of pride for us to have a team of people having grounded values and strong "
                                "principles thus converting the same into collective growth and progress. "
                                "We welcome entrepreneurs having great ideas and contemporary thoughts but not having a mentor to"
                                " guide and provide peer direction to them. Our production house will help such talented people "
                                "and integrate their proposal. In fact we will be more than happy to get more such talents as we"
                                " are passionate to paint the sky with meaningful messages through our work.  ",style: TextStyle(color: Colors.white
                              ,fontSize:14,
                            ),
                           maxLines: 15,overflow: TextOverflow.ellipsis,
                            ),

                          ],
                        ),
                      ),

                    ),
                  ),



                ],
              ),
            ),

          ],
        ),
      ),
    );
  }
}
