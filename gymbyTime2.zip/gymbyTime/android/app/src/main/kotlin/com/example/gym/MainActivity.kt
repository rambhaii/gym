package com.gymbytime.gym

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
