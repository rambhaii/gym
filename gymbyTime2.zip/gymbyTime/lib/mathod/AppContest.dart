class AppConstant{
  static final String userName="name";
  static final String id="id";
  static final String gym_id="gym_id";
  static final String phone ="phone";
  static final String email ="email";
  static final String userId="userId";
  static final String profileImg ="profile";
  static final String age ="age";
  static final String height ="height";
  static final String weight ="weight";
  static final String gender ="gender";
  static final String wallet_amount ="wallet_amount";
  static final String CategoryId="category_id";

  static final String offerId="id";
  static final String offertitle="title";
  static final String offeramount="amount";
  static final String offercouon_code="couon_code";
  static final String offerdescription="description";
  static final String offerstatus="status";
  static final String offeradd_date="add_date";
  static final String stafflogin="login";
  static final String gym_name="gym_name";
  static final String userType="1";
}