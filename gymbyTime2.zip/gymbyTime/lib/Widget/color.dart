import 'dart:ui';
import 'package:flutter/material.dart';
class TColor{
  static Color themecolor=Color(0xff000000);
  static Color WHITE=Colors.white;
  static Color box=Color(0xff3c3c3d);
  static Color Theme_Color=Color(0xff013d0d);
  static Color Background_Color=Color(0xffE7FAFA);
  static Color D=Color(0xff8dbc71);
  static Color P=Color(0xffff6565);
  static Color H=Color(0xfff6d06c);
  static Color R=Color(0xff6880ff);
  static Color red= Colors.red;
  static Color white=Colors.white;
  static Color grey=Colors.grey;
  static const Color PRIMARY = Color(0xffab47bc);
  static const Color MAIN_BG=Color(0xffd1d1d6);
  static const Color SECONDARY = Color(0xffce93d8);
  static const Color BUTTON_Color=Color(0xff04132d);
  static const Color RED = Color(0xFFD32F2F);
  static Color black=Colors.black;
}