import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:gym/FontStyle.dart';
class LoadingWidget extends StatelessWidget {
  const LoadingWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CupertinoActivityIndicator(color: Colors.white,),SizedBox(width: 15,),
          Text("Loading...",style: smallTextStyle.copyWith(color:Colors.white ),),
        ],
      ),
    );
  }
}
