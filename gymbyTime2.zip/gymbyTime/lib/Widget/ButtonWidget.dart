import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gym/FontStyle.dart';
class ButtonWidget extends StatelessWidget {
  final VoidCallback onPress;
  final String text;
  const ButtonWidget({Key? key, required this.onPress, required this.text, }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPress,
      child: Container(
        height: 38.h,
        width:130.w,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey,width: .5),
          borderRadius: BorderRadius.circular(20.w),
          boxShadow: [
            BoxShadow(
              color: Colors.blue,
              offset: const Offset(
                15.0,
                5.0,
              ),
              blurRadius: 35.0,
              spreadRadius: -8.0,
            ), //BoxShadow
            BoxShadow(
              color: Colors.white,
              offset: const Offset(10.0, 5.0),
              blurRadius: 40.0,
              spreadRadius: -23.0,
            ), //BoxShadow
          ],
        ),
        child:Center(child:Text(text,style: smallTextStyle.copyWith(fontSize: 13.sp,color: Colors.blue),)),),
    );
  }
}
