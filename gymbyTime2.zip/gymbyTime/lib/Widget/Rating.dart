//  import 'package:get/get.dart';
// import 'package:gym/Dashboard/Controller/homepage_controller.dart';
//
// class RatingController extends GetxController{
//   HomePageController controller=Get.put(HomePageController());
//   String searchValue='';
//   double ratingvalue=0.0;
//   String? ratings="No Rating";
//   _FaceBookURLApp(){
//     if(controller.homedetailsModel.value.data!.rating!=null)
//     {
//
//       if(controller.homedetailsModel.value.data!.rating!=null)
//       {
//         ratingvalue=double.parse(controller.homedetailsModel.value.data!.rating.toString());
//         if(ratingvalue>4.0)
//         {
//           ratings="Excellent";
//         } else if(ratingvalue>4.0 && ratingvalue<=5.0 ){
//           ratings="VeryGood";
//         }else if(ratingvalue>3 && ratingvalue<=4 ){
//           ratings="Good";
//         }else if(ratingvalue>2 && ratingvalue<=3 ){
//           ratings="fair";
//         }else if(ratingvalue>=0 && ratingvalue<=2 ){
//           ratings="Poor";
//         }else{
//           ratings="No Rating";
//         }
//       }
//       // ratingvalue=double.parse(value);
//
//      }
//   }
//
// }