
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/mathod/dailog_heaper.dart';
import 'package:loader_overlay/loader_overlay.dart';
import '../mathod/app_exception.dart';
class BaseController {
  void handleError(error) {
    Get.context!.loaderOverlay.hide();
    if (error is BadRequestException) {
      var message = error.message;
      errorSnack(message.toString());
    } else if (error is FetchDataException) {
      var message = error.message;
      errorSnack(message.toString());
    } else if (error is ApiNotRespondingException) {
      errorSnack("Oops! It took longer to respond.");
    }
    else{
      errorSnack("Something went wrong");
    }
  }
  showLoading(String? message) {
    DialogHelper.showLoading(message);
  }
  hideLoading() {
    DialogHelper.hideLoading();
  }
  errorSnack(String message)
  {
    Get.snackbar("Error", message,
       // backgroundGradient: LinearGradient(colors: [Colors.red,Colors.black45]),
      backgroundColor: Color(0xff00ffe5),
      titleText: Text("Error",style: smallText1Style.copyWith(color: Colors.red,fontSize: 20.sp),),
      messageText: Text(message,style:smallText1Style.copyWith(color: Colors.red,fontSize: 12.sp),),
      icon: Icon(Icons.cancel, color: Colors.red),
      snackPosition: SnackPosition.TOP,
      borderRadius: 10.r,
    );
  }
  successSnack(String message)
  {
    Get.snackbar(
      "Success", message,
      titleText: Text("Success",style: smallText1Style.copyWith(color: Colors.black,fontSize: 20.sp),),
      messageText: Text(message,style:smallText1Style.copyWith(color: Colors.black,fontSize: 12.sp),),
      // backgroundGradient: LinearGradient(colors: [Colors.green,Colors.black45]),
      backgroundColor: Color(0xff00ffe5),
      // icon: Icon(Icons.check, color: Colors.white),
      icon: Image(image: AssetImage("assets/images/su.png",)),
      snackPosition: SnackPosition.TOP,
      borderRadius: 10.r,
    );
  }
  warningSnack(String message)
  {
    Get.snackbar("Warning",message,
      backgroundGradient: LinearGradient(colors: [Colors.amber,Colors.black45]),
      icon: Icon(Icons.warning_amber, color: Colors.black),
      snackPosition: SnackPosition.TOP,
      borderRadius: 5,
    );
  }
}