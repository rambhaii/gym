import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gym/FontStyle.dart';
class Button2 extends StatelessWidget {
  final VoidCallback onPress;
  final String text;
  const Button2({Key? key, required this.onPress, required this.text, }) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onPress,
      child: Container(
        height: 38.h,
        width:130.w,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.white,width: 2.w),
          borderRadius: BorderRadius.circular(20.w),
          color: Color(0xff03dac6)
        ),
        child:Center(child:Text(text,style: smallTextStyle.copyWith(fontSize: 13.sp,color: Colors.black),)),),
    );
  }
}
