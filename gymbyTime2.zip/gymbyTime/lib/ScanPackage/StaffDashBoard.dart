import 'package:animate_do/animate_do.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';

import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../AppConstant/APIConstant.dart';
import '../Auth/controller/login_controller.dart';
import '../Dashboard/Controller/homepage_controller.dart';
import '../Dashboard/view/Profile/profile.dart';
import '../FontStyle.dart';
import '../mathod/AppContest.dart';
import 'StaffProfile.dart';

class StaffDashboard extends StatefulWidget {
  const StaffDashboard({Key? key}) : super(key: key);

  @override
  State<StaffDashboard> createState() => _StaffDashboardState();
}

class _StaffDashboardState extends State<StaffDashboard>
{
  Future<Position> getLocation() async {
    bool serviceEnabled;
    LocationPermission permission;
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
      return Future.error('Location services are disabled.');
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }
    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
  }
  HomePageController controller=Get.put(HomePageController());
  LoginController controller1=Get.put(LoginController());
  //String _scanBarcode = 'Unknown';

 /* @override
  void initState() {
    super.initState();
  }*/

  /*Future<void> startBarcodeScanStream() async {
    FlutterBarcodeScanner.getBarcodeStreamReceiver(
        '#ff6666', 'Cancel', true, ScanMode.BARCODE)!
        .listen((barcode) => print(barcode));
  }*/
 /* Future<void> scanBarcodeNormal() async {
    String barcodeScanRes;
    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
          '#ff6666', 'Cancel', true, ScanMode.BARCODE);
      print(barcodeScanRes);
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }
    if (!mounted) return;

    setState(() {
      _scanBarcode = barcodeScanRes;
    });
  }*/
  String _scanBarcode = '';

  @override
  void initState()
  {
    super.initState();
  }



  Future<void> scanQR() async {
    String barcodeScanRes;
    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode('#ff6666', 'Cancel', true, ScanMode.QR);
      if(barcodeScanRes.isNotEmpty)
        {

          String str1 = barcodeScanRes;
          List<String> str2 = str1.split(':');
          String st1 = str2.isNotEmpty ? str2[0] : '';
          String  st3= str2.length > 1 ? str2[1] : '';

          List<String> str4=st3.split(',');
          String bookingId=str4.isNotEmpty ? str4[0] : '';
          if(bookingId.isNotEmpty)
            {
              print("djfh"+bookingId);
             controller.getMyscanDataNetworkApi(bookingId);
            }

        }
      print(barcodeScanRes);
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }
    setState(() {
      _scanBarcode = barcodeScanRes;
    });
  }
  DateTime ?currentBackPressTime;
  @override
  Widget build(BuildContext context) {
    controller.postcurrentaddressNetworkApi();
    getLocation();
    return WillPopScope(
      onWillPop: onWillPop,
      child: Scaffold(

          backgroundColor:Colors.black,
          appBar: PreferredSize(
            preferredSize: Size.fromHeight(60.h),
            child: AppBar(
              // backgroundColor: Colors.white,
              elevation: 0,
              flexibleSpace: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                      begin: Alignment.topRight,
                      end: Alignment.topLeft,
                      colors: <Color>[Colors.orangeAccent, Colors.greenAccent]),
                ),
              ),
              title: Padding(
                padding: EdgeInsets.only(right: 8.w,top: 8.h),
                child:Row(
                  children: [
                    InkWell(
                      onTap: (){
                        Get.to(()=>staffProfile());
                      },
                      child: Container(
                        decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: Colors.white,width: 2.w)
                        ),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(50.r),
                          child: CachedNetworkImage(
                            fit: BoxFit.cover,
                            imageUrl:BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString(),
                            height:30.h,
                            width: 30.w,
                            placeholder: (context, url) =>
                                Center(child: const CircularProgressIndicator()),
                            errorWidget: (context, url, error) =>
                            const Icon(Icons.person,color: Colors.white,),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(width: 10.w,),
                    Container(
                      height: 50.h,
                      width: MediaQuery.of(context).size.width/1.8,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(GetStorage().read(AppConstant.userName),
                            style: bodyText1Style.copyWith(fontSize: 18.sp,color: Colors.black),),
                          SizedBox(height: 4.h,),
                          Obx(()=>
                              Text(controller.address.value,style:bodyboldStyle.copyWith(color:Colors.black/*Theme.of(context).textTheme.bodyText1!.color*/
                                  ,height: 1.h,fontSize: 10.sp),overflow: TextOverflow.ellipsis,maxLines: 2,),
                          ),
                        ],
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
              body:
              FadeInUp(
                delay: Duration(milliseconds: 450),
                child: Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(20.0),
                        child: Container(
                          height: 60.h,
                          width: MediaQuery.of(context).size.width,
                          child: Container(
                            height: 70.h,
                            width: 200.w,
                            child:  Column(
                              children: [
                                Text(" GYM NAME ",style: bodyText1Style.copyWith(
                                  fontSize: 18.sp,color: Colors.white,
                                  fontWeight: FontWeight.w800
                                ),),
                                SizedBox(height: 10,),
                                Text( GetStorage().read(AppConstant.gym_name).toString()+"",
                                  style: bodyText1Style.copyWith(fontSize: 16.sp,color: Colors.white),),
                              ],
                            )
                          ),
                        ),
                      ),
                      Center(
                        child:
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                              padding: EdgeInsets.zero,
                              elevation: 5,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30)
                              )
                          ),
                          onPressed: ()
                          {
                            scanQR();
                            controller.scanerData.value.data=null;
                            controller.scanerData.refresh();
                          },
                          child: Ink(
                            decoration: BoxDecoration(
                                gradient: LinearGradient(colors: [Colors.orangeAccent, Colors.greenAccent]),
                                borderRadius: BorderRadius.circular(5)
                            ),
                            child: Container(
                              padding: const EdgeInsets.symmetric(vertical: 15, horizontal: 50),
                              child:  Text('   Scan Barcode  ',style: bodyText4Style.copyWith(color: Colors.black), textAlign: TextAlign.center),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 50,),
                     Obx(() =>controller.scanerData.value.data!=null?

                     Padding(
                       padding: const EdgeInsets.all(15.0),
                       child: Container(
                         height: 250.h,
                         width: MediaQuery.of(context).size.width,
                         decoration: BoxDecoration(
                             color: Colors.grey,
                             border: Border.all(color: Colors.orange),
                             borderRadius: BorderRadius.circular(10)
                         ),
                         child: Padding(
                           padding: const EdgeInsets.all(10.0),
                           child: Column(
                             crossAxisAlignment: CrossAxisAlignment.start,
                             children: [
                               Row(
                                 children: [
                                   Text("Name:",style:bodyText1Style.copyWith(color: Colors.blue)  ), SizedBox(width: 10,),
                                   Text(controller.scanerData.value.data!.userName.toString(),style: smallTextStyle.copyWith(color: Colors.white),),
                                 ],
                               ), SizedBox(height: 10,),
                               Row(
                                 children:
                                 [
                                   Text("Booking No:",style:bodyText1Style.copyWith(color: Colors.blue)  ), SizedBox(width: 10,),
                                   Text(controller.scanerData.value.data!.bookingNo.toString(),style: smallTextStyle.copyWith(color: Colors.white),),

                                 ],
                               ),

                               SizedBox(height: 10,),
                               Row(
                                 children: [
                                   Text("Date & Time:",style:bodyText1Style.copyWith(color: Colors.blue)  ), SizedBox(width: 10,),
                                   Text(controller.scanerData.value.data!.date.toString() + " "+controller.scanerData.value.data!.time.toString(),style: smallTextStyle.copyWith(color: Colors.white),),


                                 ],
                               ),
                               SizedBox(height: 10,),
                               Row(
                                 children: [
                                   Text("Age:",style:bodyText1Style.copyWith(color: Colors.blue) ), SizedBox(width: 10,),
                                   Text(controller.scanerData.value.data!.age.toString() ,style: smallTextStyle.copyWith(color: Colors.white),),


                                 ],
                               ),
                               SizedBox(height: 10,),
                               Row(
                                 children:
                                 [
                                   Text("Height:",style:bodyText1Style.copyWith(color: Colors.blue) ), SizedBox(width: 10,),
                                   Text(controller.scanerData.value.data!.height.toString(),style: smallTextStyle.copyWith(color: Colors.white), ),
                                 ],
                               ),
                               SizedBox(height: 10,),
                               Row(
                                 children: [
                                   Text("Weight:",style:bodyText1Style.copyWith(color: Colors.blue)  ), SizedBox(width: 10,),
                                   Text(controller.scanerData.value.data!.weight.toString(),style: smallTextStyle.copyWith(color: Colors.white), ),


                                 ],
                               ),
                               SizedBox(height: 10,),
                               Row(
                                 children: [
                                   Text("Gender:",style:bodyText1Style.copyWith(color: Colors.blue)  ), SizedBox(width: 10,),
                                   Text(controller.scanerData.value.data!.gender.toString()==1?"Male":"Female",style: smallTextStyle.copyWith(color: Colors.white),),
                                 ],
                               ),
                               SizedBox(height: 10,),
                               Row(
                                 children: [
                                   Text("Gym Name:",style:bodyText1Style.copyWith(color: Colors.blue) ), SizedBox(width: 10,),
                                   Text(controller.scanerData.value.data!.zymName.toString(),style: smallTextStyle.copyWith(color: Colors.white),),


                                 ],
                               ),


                             ],
                           ),
                         ),
                       ),
                     ):Container() ) ,


                    ],
                  ),
                ),
              ) ,

      ),
    );
  }

  /*Future<void> scanQR() async {
    String barcodeScanRes;
    // Platform messages may fail, so we use a try/catch PlatformException.
    try {
      barcodeScanRes = await FlutterBarcodeScanner.scanBarcode(
          '#ff6666', 'Cancel', true, ScanMode.QR);
      print(barcodeScanRes);
    } on PlatformException {
      barcodeScanRes = 'Failed to get platform version.';
    }

    if (!mounted) return;

    setState(() {
      //_scanBarcode = barcodeScanRes;
    });
  }*/
  Future<bool> onWillPop() {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null || now.difference(currentBackPressTime!) > Duration(seconds: 2)) {
      currentBackPressTime = now;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Container(
                height: 30.h,
                child: Text("Press again to exit",style: smallTextStyle.copyWith(fontSize:17.sp),)),
            backgroundColor:Theme.of(context).appBarTheme.backgroundColor,
            elevation: 10, //shadow
            behavior: SnackBarBehavior.floating,
          )
      );
      return Future.value(false);
    }
    return Future.value(true);
  }
}
