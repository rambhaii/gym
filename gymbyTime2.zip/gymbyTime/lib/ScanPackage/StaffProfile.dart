import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/AppConstant/APIConstant.dart';
import 'package:gym/Auth/controller/login_controller.dart';
import 'package:gym/Auth/view/Splash_Screen.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/Dashboard/view/Profile/PaymenRefound.dart';
import 'package:gym/Dashboard/view/Profile/Profile_Edit.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/Widget/ButtonWidget.dart';
import 'package:gym/mathod/AppContest.dart';
import 'package:image_picker/image_picker.dart';

import 'ScanHstory.dart';
class staffProfile extends StatefulWidget {
  const staffProfile({Key? key}) : super(key: key);

  @override
  State<staffProfile> createState() => _image_pickerState();
}

class _image_pickerState extends State<staffProfile> {
  @override
  final HomePageController controller=Get.find();
  LoginController logincontroller=Get.put(LoginController());
  File? selectedImage;
  String base64Image = "";
  String gender = "male";
  int male = 0;

  // Future<void> choiceImage(type) async {
  //   var image;
  //   if (type == 'camara') {
  //     image = await ImagePicker()
  //         .pickImage(source: ImageSource.camera);
  //   } else {
  //     image = await ImagePicker()
  //         .pickImage(source: ImageSource.gallery);
  //   }
  //   if (image != null) {
  //     setState(() {
  //       selectedImage = File(image.path);
  //       base64Image = base64Encode(selectedImage!.readAsBytesSync());
  //     });
  //   }
  // }
  List<String> coin= ['100','200','300','400','500','600'
  ];
  List<String> tempArray = [];
  @override
  Widget build(BuildContext context) {

    print("object");
    return Scaffold
      (
      backgroundColor: Colors.black,
      appBar: AppBar(
        elevation: 0,
        title: Text("Profile",style:bodyText4Style.copyWith(fontSize: 22.sp,color: Colors.white),),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                begin: Alignment.topRight,
                end: Alignment.topLeft,
                colors: <Color>[Colors.greenAccent, Colors.orangeAccent]),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: FadeInUp(
          delay: const Duration(milliseconds: 450),
          child: Padding(
            padding: EdgeInsets.only(left: 22.w,right: 22.w,top: 40.h),
            child: Column(
              children: [
                Container(
                  height: 104.h,
                  width: 104.w,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.blue,
                        offset: const Offset(
                          5.0,
                          5.0,
                        ),
                        blurRadius: 30.0,
                        spreadRadius: -8.0,
                      ), //BoxShadow
                      BoxShadow(
                        color: Colors.white,
                        offset: const Offset(10.0, 5.0),
                        blurRadius: 40.0,
                        spreadRadius: -23.0,
                      ), //BoxShadow
                    ],
                  ),
                  child: Stack(
                    children: [

                      Obx(() =>logincontroller.rxPath.value.isEmpty
                          ?
                      Container(
                        decoration:  BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white),
                          image:  DecorationImage(
                              image: NetworkImage(BASE_URL+"/"+GetStorage().read(AppConstant.profileImg)),fit: BoxFit.fill
                          ),
                        ),
                        child: Container(

                        ),
                      ): Container(
                        decoration:  BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(),
                          image:  DecorationImage(
                              image: FileImage(File(logincontroller.rxPath.value)),fit: BoxFit.fill
                          ),
                        ),

                      ),
                      ),
                      Positioned(
                        bottom: 10.h,
                        right: 0,
                        left: 67.w,
                        child: InkWell(onTap: ()
                        {
                          showOptionDailog(context);
                        },child: Container(
                            height: 30.h,
                            width: 40.w,
                            child: Image.asset("assets/images/cam.png",
                              color: Colors.white.withOpacity(.8),)
                        ),
                        ),
                      ),

                    ],
                  ),
                ),
                SizedBox(height: 8.h,),
                Text(logincontroller.etName.text,style: bodyText1Style.copyWith(fontSize: 18.sp,color: Colors.white),),
                SizedBox(height: 20.h,),
                Row(
                  children: [
                    IconButton(onPressed: ()
                    {

                    },
                        icon: Image.asset(
                          "assets/images/Group 3082.png", height: 17.h,)),
                    SizedBox(width: 20.w,),
                    TextButton(onPressed: () {
                      Navigator.of(context).push(
                          MaterialPageRoute(builder: (context) => ProfileEdit()));
                    },
                        child: Text(
                          "Profile", style: bodyText2Style.copyWith(fontSize: 17.sp,color: Colors.white),
                        ))
                  ],
                ),
                SizedBox(height: 8.h,),
                Row(
                  children: [
                    IconButton(onPressed: ()
                    {

                    },
                        icon: Image.asset(
                          "assets/images/history.png", height: 17.h,)),
                    SizedBox(width: 20.w,),
                    TextButton(onPressed: ()
                    {
                      Navigator.of(context).push(
                          MaterialPageRoute(builder: (context) => ScanHistory()));
                    },
                        child: Text(
                          "Scan history", style: bodyText2Style.copyWith(fontSize: 17.sp,color: Colors.white),
                        ))
                  ],
                ),
                SizedBox(height: 8.h,),

                Row(
                  children: [
                    IconButton(onPressed: () {

                    },
                        icon: Image.asset("assets/images/logout.png", height: 20.h,)),
                    SizedBox(width: 20.w,),
                    TextButton(onPressed: (){
                      showAlertBox();
                    },
                        child: Text(
                          "Logout", style: bodyText2Style.copyWith(fontSize: 17.sp,color:Colors.white),))
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
  showOptionDailog(BuildContext context)
  {
    return showDialog(context: context, builder: (context) =>
        SimpleDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(4.0))),
          backgroundColor:Colors.grey,
          children: [
            SimpleDialogOption(
              onPressed: () {
                logincontroller.chooseImage(false);
                Get.back();
              },
              child: Row(
                children: [
                  Icon(Icons.image,color: Colors.cyanAccent,),
                  Text("   Gallery", style:smallTextStyle.copyWith(color: Colors.black))
                ],
              ),
            ),
            SimpleDialogOption(
              onPressed: () {  logincontroller.chooseImage(true);

              Get.back();
              },
              child: Row(
                children: [
                  Icon(Icons.camera_alt,color: Colors.cyanAccent,),
                  Text("   Camera", style:smallTextStyle.copyWith(color: Colors.black))
                ],
              ),
            ),
            SimpleDialogOption(
              onPressed: () => Get.back(),
              child: Row(
                children: [
                  Icon(Icons.clear,color: Colors.red,),
                  Text("  Cancel", style: smallTextStyle)
                ],
              ),
            ),
          ],
        ));
  }
  void showAlertBox()
  {
    Get.defaultDialog(
        title: 'Are you sure !',
        titleStyle: bodyText1Style.copyWith(fontSize: 22.sp,color:Colors.black),
        middleText: 'if you want to logout please press Yes otherwise No'
        ,middleTextStyle: smallTextStyle.copyWith(color: Colors.black),
        backgroundColor:Colors.grey,
        radius:5,
        textCancel: 'No',
        textConfirm: 'yes',
        confirmTextColor: Colors.black,
        cancelTextColor: Colors.black,
        onCancel: (){},
        onConfirm: ()
        {
          controller.logout();
        }
    );
  }
}
