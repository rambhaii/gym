import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/AppConstant/APIConstant.dart';
import 'package:gym/Auth/model/NotificationModel.dart';
import 'package:gym/Widget/BaseController.dart';
import 'package:gym/mathod/AppContest.dart';
import 'package:gym/mathod/BaseClient.dart';

class NotificationController extends GetxController
{
  GetStorage _storage = GetStorage();
  var notificationModel = NotificationModel().obs;
  final ScrollController scrollController1=ScrollController();
  RxBool  isLoadingNotificationPage=false.obs;
  int count=0;

  int start=0;
  @override
  void onInit()
  {
    // addItems();
    super.onInit();
  }

  // addItems() async
  // {
  //
  //   scrollController1.addListener
  //     (
  //           ()
  //       {
  //         if (scrollController1.position.maxScrollExtent == scrollController1.position.pixels)
  //         {
  //           if(isLoadingNotificationPage.value)
  //           { start=start+int.parse(notificationModel.value.page!.toString());
  //           getNotificationListLoadingNetworkApi(start);
  //           }
  //
  //         }
  //       });
  // }


  // getNotificationListLoadingNetworkApi(int start ) async
  // {
  //
  //   var response = await BaseClient()
  //       .get(getNotificationApi + "?lng=eng&limit=${20}&page=${start}&user_id==${_storage.read(AppConstant.id)}")
  //       .catchError(BaseController().handleError);
  //
  //   if (jsonDecode(response)["status"] == 1)
  //   {
  //
  //     if(isLoadingNotificationPage.value==true)
  //     {
  //
  //       notificationModel.value.data!.addAll(notificationModelFromJson(response).data!);
  //       notificationModel.refresh();
  //     }
  //   }
  //   else{
  //     isLoadingNotificationPage.value=false;
  //   }
  // }



  getNotificationListNetworkApi() async
  {

    Get.context!.loaderOverlay.show();
    var response = await BaseClient().get(getNotificationApi
        +"?lng=eng&limit=${100}&page=0&user_id==${_storage.read(AppConstant.id)}")
        .catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print(response+"dlfjoiyh");
    if (jsonDecode(response)["status"] == 1)
    {
      notificationModel.value = notificationModelFromMap(response);
      // isLoadingNotificationPage.value=true;
      return;
    }
    notificationModel.value = notificationModelFromMap(response);
    // BaseController().errorSnack(jsonDecode(response)["message"]);
  }

}