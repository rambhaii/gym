// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';
// import 'package:gym/Auth/controller/login_controller.dart';
// import 'package:gym/Auth/view/SignUp_Login.dart';
// import 'package:gym/Widget/ButtonWidget.dart';
// import 'package:gym/Widget/button2.dart';
// import 'package:gym/Widget/color.dart';
// import 'package:otp_text_field/otp_field.dart';
// import 'package:otp_text_field/style.dart';
// import 'package:pinput/pinput.dart';
// import '../../FontStyle.dart';
// class OtpVerify extends StatelessWidget {
//   OtpVerify({Key? key}) : super(key: key);
//   LoginController _controller=Get.put(LoginController());
//   final FirebaseAuth auth=FirebaseAuth.instance;
//   String etotp="";
//   var code='';
//   @override
//   Widget build(BuildContext context) {
//     _controller.startTimer();
//     // _controller.loginNetworkApi();
//     return
//       Scaffold(
//         backgroundColor:TColor.themecolor,
//       body: SingleChildScrollView(
//         child: Container(
//           width: MediaQuery.of(context).size.width,
//           height: MediaQuery.of(context).size.height,
//           child: Stack(
//             children: [
//               Container(
//                   width: MediaQuery.of(context).size.width,
//                   height: MediaQuery.of(context).size.height,
//                   decoration: BoxDecoration(
//                     color: Colors.black,
//                   ),
//                   child:Column(
//                     crossAxisAlignment: CrossAxisAlignment.center,
//                     mainAxisAlignment: MainAxisAlignment.start,
//                     children: [
//                       SizedBox(height: 100.h,),
//                      Image(image: AssetImage("assets/images/logo2.png")),
//                       SizedBox(height: 40.h,),
//                     ],
//                   )
//               ),
//               Container(
//                 width: MediaQuery.of(context).size.width,
//                 height: MediaQuery.of(context).size.height /2.4,
//                 decoration: BoxDecoration(
//                     borderRadius: BorderRadius.only(bottomRight:Radius.circular(70.r))
//                 ),
//               ),
//               Align(
//                 alignment: Alignment.bottomCenter,
//                 child: Container(
//                   width: MediaQuery.of(context).size.width,
//                   height: MediaQuery.of(context).size.height/1.666,
//                   decoration: BoxDecoration(
//                   ),
//                 ),
//               ),
//               Align(
//                 alignment: Alignment.bottomCenter,
//                 child: Container(
//                   width: MediaQuery.of(context).size.width,
//                   height: MediaQuery.of(context).size.height/1.4,
//                   padding: EdgeInsets.only(top: 40.h, bottom: 30.h),
//                   decoration: BoxDecoration(
//                       color: Color(0xFF2a2b2b),
//                       borderRadius: BorderRadius.only(topLeft:Radius.circular(100.r))
//                   ),
//                   child: Column(
//                     crossAxisAlignment: CrossAxisAlignment.center,
//                     // mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       Container(
//                         child: Column(
//                           crossAxisAlignment: CrossAxisAlignment.center,
//                           children: [
//                               SizedBox(height: 20.h,),
//                             Center(child: Text("Enter the verification code we\n just sent you on ${_controller.num.value.toString()}",
//                               style: smallTextStyle.copyWith(fontSize: 17.sp,color: Colors.white),)),
//                             SizedBox(height: 30.h,),
//                             Padding(
//                               padding:  EdgeInsets.only(top: 20.h),
//                               child: Text("Code ",style:smallTextStyle.copyWith(fontSize: 18.sp,color: Colors.grey),),
//                             ),
//                             Row(
//                               mainAxisAlignment: MainAxisAlignment.center,
//                               crossAxisAlignment: CrossAxisAlignment.center,
//                               children: [
//
//                                 Container(
//                                   width: 250.w,
//                                   height: 40.h,
//                                   child:Pinput(
//                                     onChanged: (value){
//                                       code=value;
//                                     },
//                                     length: 6,
//                                   )
//
//                                   /*OTPTextField(
//                                     length: 6,
//                                     onChanged: (value){
//                                     code=value;
//                                     },
//                                     width: MediaQuery.of(context).size.width,
//                                     fieldWidth: 30.w,
//                                     style:bodyText2Style.copyWith(fontSize: 18.sp,color: Colors.white),
//                                     textFieldAlignment: MainAxisAlignment.spaceAround,
//                                     fieldStyle: FieldStyle.underline,
//
//                                   ),*/
//                                 ),
//
//                               ],
//                             ),
//                             Container(
//                                 margin: EdgeInsets.only(top:20.h,right: 15.w,bottom: 50.h),
//                                 width:Get.width,
//                                 child: Obx(() =>  Row(
//                                   mainAxisAlignment: MainAxisAlignment.end,
//                                   children: [
//                                     Text(_controller.start.value.toString(),style: titleStyle.copyWith(fontSize: 16.sp,color: _controller.start.value!=0? Colors.blue:Colors.grey.withOpacity(0.4)),textAlign: TextAlign.end,),
//                                     TextButton(child:Text("Resend Code?",style: titleStyle.copyWith(fontSize: 16.sp,decoration: TextDecoration.underline,color: _controller.start.value==0?Colors.blue:Colors.white.withOpacity(0.4)),textAlign: TextAlign.end,),
//                                       onPressed:_controller.start.value==0? (){
//                                         // _controller.loginNetworkApi();
//                                         _controller.start.value=60;
//                                         _controller.startTimer();
//                                          //_controller.loginNetworkApi();
//                                         // print(_controller.loginNetworkApi()+"eguyufy");
//                                       }:null,
//                                     ),
//                                   ],
//                                 ),
//                                 )),
//                             Button2(onPress: () async{
//                               PhoneAuthCredential credential = PhoneAuthProvider.credential(verificationId: SignUp_Login.verify, smsCode:code);
//
//                               // Sign the user in (or link) with the credential
//                               await auth.signInWithCredential(credential);
//                               // Navigator.of(context).push(MaterialPageRoute(builder: (context) => LoginPage()));
//                               //_controller.verifyNetworkApi();
//                             }, text: 'VERIFY CODE',)
//                           ],
//                         ),
//                       ),
//
//                     ],
//                   ),
//                 ),
//               )
//
//             ],
//           ),
//         ),
//       ),
//       /*SingleChildScrollView(
//         child: SafeArea(
//           child: Container(
//             child: Column(
//               crossAxisAlignment: CrossAxisAlignment.center,
//               children: [
//                 Row(
//                   children: [
//                    IconButton(onPressed: (){
//                      Navigator.pop(context);
//                    }, icon: Image.asset("assets/images/back.png",
//                      color:Theme.of(context).textTheme.bodyText1!.color,)),
//                     SizedBox(width: 30.w,),
//                     Text("Verify",style: smallTextStyle.copyWith(fontSize: 22.sp,color: Theme.of(context).textTheme.bodyText1!.color),)
//                   ],
//                 ),
//                 const  SizedBox(height: 40,),
//                 const  SizedBox(height: 40,),
//                 Center(child: Text("Enter the verification code we just sent\n you on ${_controller.etMobile.text.toString()}",
//                   style: smallTextStyle,)),
//                   SizedBox(height: 50.h,),
//                 Row(
//                   mainAxisAlignment: MainAxisAlignment.center,
//                   crossAxisAlignment: CrossAxisAlignment.center,
//                   children: [
//                     Padding(
//                       padding: const EdgeInsets.only(top: 20.0),
//                       child: Text("Code ",style:smallTextStyle.copyWith(fontSize: 18.sp,color: Colors.grey),),
//                     ),
//                     Container(
//                       width: 150.w,
//                       height: 40.h,
//                       child: OTPTextField(
//                         length: 4,
//                         width: MediaQuery.of(context).size.width,
//                         fieldWidth: 30.w,
//                         style:TextStyle(
//                             fontSize: 17.sp,fontWeight: FontWeight.bold
//                         ),
//                         textFieldAlignment: MainAxisAlignment.spaceAround,
//                         fieldStyle: FieldStyle.underline,
//                         onCompleted: (pin) {
//                           etotp=pin;
//                           _controller.verifyNetworkApi(id, pin);
//                         },
//
//                       ),
//                     ),
//
//                   ],
//                 ),
//                 Container(
//                     margin: EdgeInsets.only(top:50,right: 15,bottom: 50),
//                     width:Get.width,
//                     child: Obx(() =>  Row(
//                       mainAxisAlignment: MainAxisAlignment.end,
//                       children: [
//                         Text(_controller.start.value.toString(),style: titleStyle.copyWith(fontSize: 16,color: _controller.start.value!=0? Colors.blue:Colors.grey.withOpacity(0.4)),textAlign: TextAlign.end,),
//                         TextButton(child:Text("Resend Code?",style: titleStyle.copyWith(fontSize: 16,decoration: TextDecoration.underline,color: _controller.start.value==0?Colors.blue:Colors.grey.withOpacity(0.4)),textAlign: TextAlign.end,),
//                           onPressed:_controller.start.value==0? (){
//                           // _controller.loginNetworkApi();
//                             _controller.start.value=60;
//                             _controller.startTimer();
//                               // _controller.loginNetworkApi();
//                               // print(_controller.loginNetworkApi()+"eguyufy");
//                           }:null,
//                         ),
//                       ],
//                     ),
//                     )),
//                 ButtonWidget(onPress: () {
//                   // Navigator.of(context).push(MaterialPageRoute(builder: (context) => LoginPage()));
//                   _controller.verifyNetworkApi(id, etotp);
//                 }, text: 'VERIFY CODE',)
//               ],
//             ),
//           ),
//         ),
//       ),*/
//     );
//   }
// }
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gym/Auth/controller/login_controller.dart';
import 'package:gym/Widget/ButtonWidget.dart';
import 'package:gym/Widget/button2.dart';
import 'package:gym/Widget/color.dart';
import 'package:otp_text_field/otp_field.dart';
import 'package:otp_text_field/style.dart';
import '../../FontStyle.dart';
class OtpVerify extends StatelessWidget {
  final String id;
  final String otp;
  OtpVerify({Key? key, required this.id,required this.otp,}) : super(key: key);
  LoginController _controller=Get.put(LoginController());
  String etotp="";
  @override
  Widget build(BuildContext context) {
    _controller.startTimer();
    // _controller.loginNetworkApi();
    return
      Scaffold(
        backgroundColor:TColor.themecolor,
        body: SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            child: Stack(
              children: [
                Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height,
                    decoration: BoxDecoration(
                      color: Colors.black,
                    ),
                    child:Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        SizedBox(height: 100.h,),
                        Image(image: AssetImage("assets/images/logo2.png")),
                        SizedBox(height: 40.h,),
                      ],
                    )
                ),
                Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height /2.4,
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(bottomRight:Radius.circular(70.r))
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height/1.666,
                    decoration: BoxDecoration(
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    height: MediaQuery.of(context).size.height/1.4,
                    padding: EdgeInsets.only(top: 40.h, bottom: 30.h),
                    decoration: BoxDecoration(
                        color: Color(0xFF2a2b2b),
                        borderRadius: BorderRadius.only(topLeft:Radius.circular(100.r))
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      // mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Container(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              SizedBox(height: 40.h,),
                              Center(child: Text("Enter the verification code we\n just sent you on ${_controller.etMobile.text.toString()}",
                                style: smallTextStyle.copyWith(fontSize: 17.sp,color: Colors.white),)),
                              SizedBox(height: 50.h,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Padding(
                                    padding:  EdgeInsets.only(top: 20.h),
                                    child: Text("Code ",style:smallTextStyle.copyWith(fontSize: 18.sp,color: Colors.grey),),
                                  ),
                                  Container(
                                    width: 150.w,
                                    height: 40.h,
                                    child: OTPTextField(
                                      length: 4,
                                      width: MediaQuery.of(context).size.width,
                                      fieldWidth: 30.w,
                                      style:bodyText2Style.copyWith(fontSize: 18.sp,color: Colors.white),
                                      textFieldAlignment: MainAxisAlignment.spaceAround,
                                      fieldStyle: FieldStyle.underline,
                                      onCompleted: (pin) {
                                        etotp=pin;
                                        _controller.verifyNetworkApi(id, pin);
                                      },

                                    ),
                                  ),

                                ],
                              ),
                              Container(
                                  margin: EdgeInsets.only(top:50.h,right: 15.w,bottom: 50.h),
                                  width:Get.width,
                                  child: Obx(() =>  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Text(_controller.start.value.toString(),style: titleStyle.copyWith(fontSize: 16.sp,color: _controller.start.value!=0? Colors.blue:Colors.grey.withOpacity(0.4)),textAlign: TextAlign.end,),
                                      TextButton(child:Text("Resend Code?",style: titleStyle.copyWith(fontSize: 16.sp,decoration: TextDecoration.underline,color: _controller.start.value==0?Colors.blue:Colors.white.withOpacity(0.4)),textAlign: TextAlign.end,),
                                        onPressed:_controller.start.value==0? (){
                                          // _controller.loginNetworkApi();
                                          _controller.start.value=30;
                                          _controller.startTimer();
                                          // _controller.loginNetworkApi();
                                          // print(_controller.loginNetworkApi()+"eguyufy");
                                        }:null,
                                      ),
                                    ],
                                  ),
                                  )),
                              Button2(onPress: () {
                                // Navigator.of(context).push(MaterialPageRoute(builder: (context) => LoginPage()));
                                _controller.verifyNetworkApi(id, etotp);
                              }, text: 'VERIFY CODE',)
                            ],
                          ),
                        ),

                      ],
                    ),
                  ),
                )

              ],
            ),
          ),
        ),
        /*SingleChildScrollView(
        child: SafeArea(
          child: Container(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                   IconButton(onPressed: (){
                     Navigator.pop(context);
                   }, icon: Image.asset("assets/images/back.png",
                     color:Theme.of(context).textTheme.bodyText1!.color,)),
                    SizedBox(width: 30.w,),
                    Text("Verify",style: smallTextStyle.copyWith(fontSize: 22.sp,color: Theme.of(context).textTheme.bodyText1!.color),)
                  ],
                ),
                const  SizedBox(height: 40,),
                const  SizedBox(height: 40,),
                Center(child: Text("Enter the verification code we just sent\n you on ${_controller.etMobile.text.toString()}",
                  style: smallTextStyle,)),
                  SizedBox(height: 50.h,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 20.0),
                      child: Text("Code ",style:smallTextStyle.copyWith(fontSize: 18.sp,color: Colors.grey),),
                    ),
                    Container(
                      width: 150.w,
                      height: 40.h,
                      child: OTPTextField(
                        length: 4,
                        width: MediaQuery.of(context).size.width,
                        fieldWidth: 30.w,
                        style:TextStyle(
                            fontSize: 17.sp,fontWeight: FontWeight.bold
                        ),
                        textFieldAlignment: MainAxisAlignment.spaceAround,
                        fieldStyle: FieldStyle.underline,
                        onCompleted: (pin) {
                          etotp=pin;
                          _controller.verifyNetworkApi(id, pin);
                        },

                      ),
                    ),

                  ],
                ),
                Container(
                    margin: EdgeInsets.only(top:50,right: 15,bottom: 50),
                    width:Get.width,
                    child: Obx(() =>  Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Text(_controller.start.value.toString(),style: titleStyle.copyWith(fontSize: 16,color: _controller.start.value!=0? Colors.blue:Colors.grey.withOpacity(0.4)),textAlign: TextAlign.end,),
                        TextButton(child:Text("Resend Code?",style: titleStyle.copyWith(fontSize: 16,decoration: TextDecoration.underline,color: _controller.start.value==0?Colors.blue:Colors.grey.withOpacity(0.4)),textAlign: TextAlign.end,),
                          onPressed:_controller.start.value==0? (){
                          // _controller.loginNetworkApi();
                            _controller.start.value=60;
                            _controller.startTimer();
                              // _controller.loginNetworkApi();
                              // print(_controller.loginNetworkApi()+"eguyufy");
                          }:null,
                        ),
                      ],
                    ),
                    )),
                ButtonWidget(onPress: () {
                  // Navigator.of(context).push(MaterialPageRoute(builder: (context) => LoginPage()));
                  _controller.verifyNetworkApi(id, etotp);
                }, text: 'VERIFY CODE',)
              ],
            ),
          ),
        ),
      ),*/
      );
  }
}
