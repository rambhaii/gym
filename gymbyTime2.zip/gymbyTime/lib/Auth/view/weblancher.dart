import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class weblancher extends StatelessWidget {
  const weblancher({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      body:  WebView(
        initialUrl: 'https://docs.google.com/gview?embedded=true&url=https://www.gymbyminute.com/web-assets/privacy-policy.pdf',
        javascriptMode: JavascriptMode.unrestricted,
      ),
    );
  }
}
