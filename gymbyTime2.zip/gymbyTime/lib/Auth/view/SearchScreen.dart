import 'package:animate_do/animate_do.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gym/AppConstant/APIConstant.dart';
import 'package:gym/Auth/model/GymListmodel.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/Dashboard/view/Home/RatingHistory.dart';
import 'package:gym/Dashboard/view/Home/home_deatails.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/Widget/color.dart';
class SearchScreen extends StatefulWidget {
  SearchScreen({Key? key}) : super(key: key);

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  HomePageController controller=Get.put(HomePageController());
  int show3 = 0;
  late bool dd;
  late String va;
  int count = 0;
  int cuntnumber = 0;
  double distencetomtr=0;
  double distencetokm=0;
  int decimalPlaces = 2;
  String Kilometer='';
  String meters='';
  late String keyMessage;
  FocusNode inputNode = FocusNode();
// to open keyboard call this function;
  void openKeyboard(){
    FocusScope.of(context).requestFocus(inputNode);
  }
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
   controller.getGymListSearchNetworkApi("");
  }
  Widget build(BuildContext context)
  {

    return new Scaffold(
      backgroundColor: Colors.black,
      body: Container(
        child: Column(
            children: <Widget>
            [
              SizedBox(height: 50.h),
              Container(
                height: 60.h,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20.r),
                ),
                child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: TextFormField(
                      textInputAction: TextInputAction.search,
                      onChanged: (value)
                      {
                        keyMessage = value;
                      },
                      controller: controller.searchkey,
                      focusNode: inputNode,
                      autofocus:true,
                      style: smallTextStyle.copyWith(color: Colors.white),
                      decoration: InputDecoration(
                          focusedBorder: OutlineInputBorder(
                            borderSide: BorderSide(color: Colors.white,),
                            borderRadius: BorderRadius.circular(30.r)
                          ),
                          enabledBorder:OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.white,),
                              borderRadius: BorderRadius.circular(30.r)
                          ),
                          labelStyle: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w400,
                            fontSize: 14,
                          ),
                          hintText: "Search...",
                          hintStyle: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.w400,
                            fontSize: 14,
                          ),
                          suffixIcon: InkWell(
                              onTap: ()
                              {
                                if (keyMessage.isNotEmpty)
                                {
                                controller.getGymListSearchNetworkApi(keyMessage);
                                keyMessage;
                                }
                              },
                              child: Icon(
                                Icons.search,
                                size: 20,color: Colors.white,
                              )),
                          border: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.grey),
                              borderRadius: BorderRadius.all(Radius.circular(5.0)))),
                    )),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Padding(
                      padding: EdgeInsets.only(left: 10.w, right: 10),
                      child: FadeInUp(
                          delay: const Duration(milliseconds: 450),
                          child: Stack(
                            children: [
                              Obx(() => controller.gymListModel.value.data != null
                                  ? ListView.builder(
                                  physics: const BouncingScrollPhysics(),
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  itemCount:
                                  controller.gymListModel.value.data!.length,
                                  itemBuilder: (ctx, index)
                                  {
                                    final datas = controller.gymListModel.value.data![index];
                                    double ratingvalue=0.0;
                                    String? ratings="No Rating";
                                    if(controller.gymListModel.value.data![index].rating!=null)
                                    {

                                      if(controller.gymListModel.value.data![index].rating.toString().isNotEmpty)
                                      {
                                        ratingvalue=double.parse(controller.gymListModel.value.data![index].rating.toString());
                                        if(ratingvalue>4.0)
                                        {
                                          ratings="Excellent";
                                        } else if(ratingvalue>3.0 && ratingvalue<=4.0 ){
                                          ratings="VeryGood";
                                        }else if(ratingvalue>2 && ratingvalue<=3 ){
                                          ratings="Good";
                                        }else if(ratingvalue>2 && ratingvalue<=3 ){
                                          ratings="fair";
                                        }else if(ratingvalue>=0 && ratingvalue<=2 ){
                                          ratings="Poor";
                                        }else{
                                          ratings="No Rating";
                                        }
                                      }
                                      // ratingvalue=double.parse(value);

                                    }
                                    double distence=double.parse(datas.distance.toString());
                                    distencetomtr=distence/100;

                                    distencetokm=distencetomtr/1000;
                                    Kilometer = distencetokm.toStringAsFixed(decimalPlaces);
                                    meters = distencetomtr.toStringAsFixed(decimalPlaces);
                                    return Padding(
                                      padding: EdgeInsets.only(left: 8.w, right: 8.w),
                                      child: InkWell(
                                        onTap: ()
                                        {
                                          Get.to(()=> home_deatails(datas.id.toString()));
                                          controller.gym_id.value = datas.id.toString();

                                        },
                                        child: Column(
                                          children: [
                                            Container(
                                              height: 80.h,
                                              width: MediaQuery.of(context).size.width,
                                              decoration: BoxDecoration(),
                                              child: Row(
                                                children: [
                                                  Align(
                                                    alignment: Alignment.topCenter,
                                                    child: ClipRRect(
                                                      borderRadius:
                                                      BorderRadius.circular(10.r),
                                                      child: Container(
                                                        height: 57.h,
                                                        width: 57.w,
                                                        decoration: BoxDecoration(
                                                            borderRadius:
                                                            BorderRadius.circular(
                                                                10.r),
                                                            boxShadow: [
                                                              BoxShadow(
                                                                color: Colors.blue,
                                                                offset: const Offset(
                                                                  5.0,
                                                                  5.0,
                                                                ),
                                                                blurRadius: 25.0,
                                                                spreadRadius: 2.0,
                                                              ), //BoxShadow
                                                              BoxShadow(
                                                                color: Colors.white,
                                                                offset: const Offset(
                                                                    10.0, 15.0),
                                                                blurRadius: 50.0,
                                                                spreadRadius: 13.0,
                                                              ),
                                                            ]),
                                                        child: CachedNetworkImage(
                                                          fit: BoxFit.cover,
                                                          imageUrl: BASE_URL +
                                                              "/" +
                                                              datas.profile
                                                                  .toString(),
                                                          height: 76.h,
                                                          width: 76.w,
                                                          placeholder: (context,
                                                              url) =>
                                                              Center(
                                                                  child:
                                                                  const CircularProgressIndicator()),
                                                          errorWidget: (context, url,
                                                              error) =>
                                                          const Icon(Icons.error),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Padding(
                                                    padding: EdgeInsets.only(
                                                        left: 15.w,
                                                        bottom: 8.h,
                                                        top: 4.h),
                                                    child: Container(
                                                      height: 80.h,
                                                      width: 160.w,
                                                      child: Column(
                                                        crossAxisAlignment:
                                                        CrossAxisAlignment.start,
                                                        mainAxisAlignment:
                                                        MainAxisAlignment.start,
                                                        children: [
                                                          Text(datas.zymName.toString().length > 40 ? datas.zymName.toString().substring(0, 40):datas.zymName.toString(),
                                                            style: bodyText1Style
                                                                .copyWith(fontSize: 14.sp,
                                                              color: TColor.white,),
                                                            maxLines: 1,
                                                          ),
                                                          Row(
                                                            children: [
                                                              datas.gymFor!=null? Container(
                                                                padding: EdgeInsets.only(left: 8.w,right: 8.w,top: 2.h,bottom: 2.h),
                                                                decoration: BoxDecoration(
                                                                    color:
                                                                    TColor.white,
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                        10.r)),
                                                                child: Center(
                                                                  child: Text(datas.categoryTitle.toString(),
                                                                    style: smallText1Style
                                                                        .copyWith(
                                                                        fontSize:
                                                                        9.sp,
                                                                        color: Colors
                                                                            .black /*color: Theme.of(context).textTheme.bodyText2!.color*/),
                                                                  ),
                                                                ),
                                                              ):Container(),
                                                              SizedBox(
                                                                width: 5.w,
                                                              ),
                                                              datas.gymFor!=null? Container(
                                                                padding: EdgeInsets.only(left: 8.w,right: 8.w,top: 2.h,bottom: 2.h),
                                                                decoration: BoxDecoration(
                                                                    color:
                                                                    TColor.white,
                                                                    borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                        10.r)),
                                                                child: Center(
                                                                  child: Text(
                                                                    datas.gymFor.toString(),
                                                                    style: smallText1Style
                                                                        .copyWith(
                                                                        fontSize:
                                                                        9.sp,
                                                                        color: Colors
                                                                            .black /*color: Theme.of(context).textTheme.bodyText2!.color*/),
                                                                  ),
                                                                ),
                                                              ):Container()
                                                            ],
                                                          ),
                                                          SizedBox(
                                                            height: 3.h,
                                                          ),
                                                          /* Obx(()
                                                    =>controller.feedback.value.data!=null ?*/
                                                          Row(
                                                            children: [
                                                              Container(
                                                                  height: 15.h,
                                                                  width: 20.w,
                                                                  decoration:
                                                                  BoxDecoration(
                                                                      color: Color(0xff018c04)),
                                                                  child: datas.rating!=null
                                                                      ? Center(
                                                                    child: Text(
                                                                      datas.rating
                                                                          .toString(),
                                                                      style: smallText1Style
                                                                          .copyWith(
                                                                          fontSize:
                                                                          10.sp,color: Colors.white),
                                                                    ),
                                                                  ):Container(
                                                                    color: Color(0xff018c04),
                                                                    child: Center(child: Text("0",style: smallText1Style
                                                                        .copyWith(
                                                                        fontSize:
                                                                        10.sp,color: Colors.white),)),)
                                                              ),
                                                              SizedBox(
                                                                width: 2.w,
                                                              ),
                                                              Container(
                                                                padding: EdgeInsets.all(3.w),
                                                                height: 15.h,
                                                                decoration:
                                                                BoxDecoration(
                                                                    color: Color(
                                                                        0xff437644)),
                                                                child: Center(
                                                                  child: Text(ratings.toString(),
                                                                    style: smallText1Style
                                                                        .copyWith(
                                                                        fontSize:
                                                                        9.sp,
                                                                        color: TColor
                                                                            .white),
                                                                  ),
                                                                ),
                                                              ),
                                                              SizedBox(
                                                                width: 2.w,
                                                              ),
                                                              InkWell(
                                                                  onTap: () {
                                                                    controller.gym_id.value = datas.id.toString();
                                                                    Get.to(() => RatingHistory(datas.id.toString()));
                                                                  },
                                                                  child: Text(
                                                                    datas.noRating.toString() +
                                                                        " Ratting >",
                                                                    style: smallTextStyle
                                                                        .copyWith(

                                                                        fontSize:
                                                                        8.sp,
                                                                        color: TColor
                                                                            .white),
                                                                  ))
                                                            ],
                                                          ),
                                                          Row(
                                                            children: [
                                                              Text("Approx ",style: smallText1Style
                                                                  .copyWith(
                                                                  color: Colors.grey
                                                                      .shade500,
                                                                  fontSize: 12.sp),),
                                                              Text(double.parse(meters)<=499.00?meters==null?"00":meters+"mtr".toString():Kilometer==null?"00":Kilometer+"km".toString(),
                                                                style: smallText1Style
                                                                    .copyWith(
                                                                    color: Colors.grey
                                                                        .shade500,
                                                                    fontSize: 12.sp),
                                                                textAlign:
                                                                TextAlign.justify,
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                  Spacer(),
                                                  Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                    children: [
                                                      // Text("luxury",style: bodyText1Style),
                                                      Row(
                                                        children: [
                                                          Container(
                                                            height: 16.h,
                                                            width: 10.w,
                                                            child: Text(
                                                              "₹ ",
                                                              style: bodyText2Style
                                                                  .copyWith(
                                                                  fontSize: 18.sp,
                                                                  color: Colors
                                                                      .blue),
                                                            ),
                                                          ),
                                                          Row(
                                                            children: [
                                                              Text(datas.price.toString().length>4? datas.price.toString().substring(0,4):datas.price.toString(),
                                                                  style: smallTextStyle.copyWith(color: Colors.white)),
                                                              Text(
                                                                "p/min",
                                                                style: bodyText2Style.copyWith(fontSize: 14.sp, color: Colors.white),
                                                              ),
                                                            ],
                                                          ),
                                                        ],
                                                      ),
                                                      SizedBox(
                                                        height: 8.h,
                                                      ),
                                                      InkWell(
                                                        onTap: () {

                                                          Get.to(()=> home_deatails(datas.id.toString()));
                                                          controller.gym_id.value = datas.id.toString();

                                                        },
                                                        child: Container(
                                                          height: 27.h,
                                                          width: 80.w,
                                                          decoration: BoxDecoration(
                                                              color:
                                                              Color(0xff03dac6),
                                                              border: Border.all(
                                                                  color:
                                                                  Colors.white),
                                                              borderRadius:
                                                              BorderRadius
                                                                  .circular(40.r)),
                                                          child: Center(
                                                              child: Text(
                                                                "BOOK",
                                                                style: TextStyle(
                                                                    color: Colors.white,
                                                                    fontSize: 13.sp,
                                                                    fontWeight:
                                                                    FontWeight.bold),
                                                              )),
                                                        ),
                                                      )
                                                    ],
                                                  )
                                                ],
                                              ),
                                            ),
                                            Divider()
                                          ],
                                        ),
                                      ),
                                    );
                                  })
                                  : Container()),
                              SizedBox(height: 30.h,),
                              Positioned(
                                  top: 450.h,
                                  left: 150.w,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                    ],
                                  ))
                            ],
                          )
                      ),
                    ),
                  ),
                ),
            ]
        ),),

      );
  }
}