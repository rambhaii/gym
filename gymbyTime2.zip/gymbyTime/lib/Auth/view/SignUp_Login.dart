// import 'package:animate_do/animate_do.dart';
// import 'package:firebase_auth/firebase_auth.dart';
//
// import 'package:flutter/material.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:get/get.dart';
// import 'package:gym/Auth/controller/login_controller.dart';
// import 'package:gym/Auth/view/Otp.dart';
// import 'package:gym/Auth/view/weblancher.dart';
//
// import 'package:gym/Widget/FirebaseServices.dart';
// import 'package:gym/Widget/color.dart';
// import 'package:gym/main.dart';
// import 'package:url_launcher/url_launcher.dart';
//
//
// import '../../FontStyle.dart';
// import '../../ScanPackage/Login.dart';
// // class SignUp_Login extends StatelessWidget {
// //   // SignUp_Login({Key? key}) : super(key: key);
// //
// //   LoginController _controller=Get.put(LoginController());
// //   TextEditingController countrycode=TextEditingController();
// //   var phone='';
// // @override
// // void initState(){
// //   // TODO:impliment initState
// //   countrycode.text="+91";
// //
// // }
// //   final _keyForm=GlobalKey<FormState>();
// //     String? deviceId;
// //     String? deviceEmail;
// class SignUp_Login extends StatefulWidget {
//   const SignUp_Login({Key? key}) : super(key: key);
//   static String verify="";
//   @override
//   State<SignUp_Login> createState() => _SignUp_LoginState();
// }
//
// class _SignUp_LoginState extends State<SignUp_Login> {
//   LoginController _controller=Get.put(LoginController());
//   TextEditingController countrycode = TextEditingController();
//   var phone='';
//   @override
//   void initState() {
//     // TODO: implement initState
//     countrycode.text = "+91";
//     super.initState();
//   }
//   final _keyForm=GlobalKey<FormState>();
//     String? deviceId;
//     String? deviceEmail;
//   @override
//   Widget build(BuildContext context) {
//     return
//       Material(
//       child: Container(
//         width: MediaQuery.of(context).size.width,
//         height: MediaQuery.of(context).size.height,
//         decoration: BoxDecoration(),
//         child: Stack(
//           children: [
//           Container(
//             width: MediaQuery.of(context).size.width,
//             height: MediaQuery.of(context).size.height,
//             decoration: BoxDecoration(
//               color:Colors.black,
//             ),
//             child:Column(
//               children: [
//                 SizedBox(height: 90.h,),
//                 Image(image: AssetImage("assets/images/logo2.png")),              ],
//             )
//           ),
//           Container(
//             width: MediaQuery.of(context).size.width,
//             height: MediaQuery.of(context).size.height /2.6,
//             decoration: BoxDecoration(
//                 borderRadius: BorderRadius.only(bottomRight:Radius.circular(70.r))
//             ),
//           ),
//           Align(
//             alignment: Alignment.bottomCenter,
//             child: Container(
//               width: MediaQuery.of(context).size.width,
//               height: MediaQuery.of(context).size.height/1.666,
//               decoration: BoxDecoration(
//               ),
//             ),
//           ),
//           Align(
//             alignment: Alignment.bottomCenter,
//             child: Container(
//               width: MediaQuery.of(context).size.width,
//               height: MediaQuery.of(context).size.height/1.4,
//               padding: EdgeInsets.only(top: 40.h, bottom: 30.h),
//               decoration: BoxDecoration(
//                   color: Color(0xFF2a2b2b),
//                   borderRadius: BorderRadius.only(topLeft:Radius.circular(100.r))
//               ),
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 // mainAxisAlignment: MainAxisAlignment.center,
//                 children: [
//                   Text("Sign In",style: bodyText1Style.copyWith(fontSize: 22.sp,color: Colors.white)),
//                   SizedBox(
//                     height: 30.h,
//                   ),
//                   Text("Enter your mobile number",style: smallTextStyle,),
//                 SizedBox(height:10.h),
//                 Padding(
//                   padding:  EdgeInsets.only(left:28.w,top: 18.w),
//                   child: Row(
//                   crossAxisAlignment: CrossAxisAlignment.start,
//                   mainAxisAlignment:MainAxisAlignment.start,
//                   children: [
//                     Expanded(flex:1,
//                         child: TextField(
//                             controller: countrycode,
//                             readOnly: true,
//                             decoration:const InputDecoration(
//
//                               enabledBorder: UnderlineInputBorder(
//                                 borderSide: BorderSide(width:2,color: Color(0xff3a3939)),
//                               ),
//                               focusedBorder: UnderlineInputBorder(
//
//                                 borderSide: BorderSide(width:2,color: Color(0xff3a3939)),
//                               ),
//                               isDense: true,
//                               // fillColor: Colors.white
//                             ),
//                             style: titleStyle.copyWith(color: Colors.white))),
//                     SizedBox(width: 8.w,),
//                     Expanded(flex:3,child: Form(
//                       child: TextField(
//                           onChanged: (value){
//                             phone=value;
//                           },
//                           keyboardType: TextInputType.number,
//                           decoration: const InputDecoration(
//                             enabledBorder: UnderlineInputBorder(
//                               borderSide: BorderSide(width:2,color: Color(0xff3a3939)),
//                             ),
//                             focusedBorder: UnderlineInputBorder(
//
//                               borderSide: BorderSide(width:2,color: Color(0xff3a3939)),
//                             ),
//                             counter: Offstage(),
//                             hintText: "0000000000",
//                             isDense: true,
//                             hintStyle:TextStyle(color:Colors.grey),
//                             contentPadding: EdgeInsets.symmetric(horizontal: 4, vertical: 8),
//
//                           ),
//                           /*validator: (value){
//                             if(value.toString().isEmpty)
//                             {
//                               return "Please enter mobile No.";
//                             }
//                             if(value!.length!=10)
//                             {
//                               return "Please enter 10 digits mobile number";
//                             }
//                           },*/
//                           maxLength: 10,
//
//                           style: titleStyle.copyWith(color: Colors.white)),
//                     )),
//                     Expanded(
//                       flex: 2,
//                       child: InkWell(
//                         onTap: ()async{
//                           // if(_keyForm.currentState!.validate()){
//
//                            // _controller.loginNetworkApi();
//                             await FirebaseAuth.instance.verifyPhoneNumber(
//                               phoneNumber:'${countrycode.text+phone}',
//                               verificationCompleted: (PhoneAuthCredential credential) {},
//                               verificationFailed: (FirebaseAuthException e) {},
//                               codeSent: (String verificationId, int? resendToken) {
//                                 SignUp_Login.verify=verificationId;
//                                 Get.to(()=>OtpVerify());
//                               },
//                               codeAutoRetrievalTimeout: (String verificationId) {},
//                             );
//
//                         },
//                         child: Container(
//                             height: 38.h,
//                             width: 38.w,
//                             child: Icon(Icons.arrow_forward,color:Colors.white,weight: .2,)),
//                       ),)
//                   ],
//               ),
//                 ),
//                   SizedBox(
//                     height: 30.h,
//                   ),
//                   Center(
//                     child: Text("Or Sign In With",style: smallTextStyle,),
//                   ),
//                   SizedBox(
//                     height: 30.h,
//                   ),
//                   Row(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       InkWell(onTap: ()
//                       async
//                       {
//                         UserCredential userCredential= await  FirebaseServices().signInWithGooglewithFirebase();
//                         if(userCredential!=null)
//                         {
//                           _controller.signUpwithSocialLoginNetworkApi(userCredential,deviceId??"");
//                         }
//
//                       },
//                         child: Container(
//                           height: 37.h,
//                           width: 37.w,
//                           decoration: BoxDecoration(
//                               borderRadius: BorderRadius.circular(50.r)
//                           ),
//                           child: Center(
//                             child: Image.asset("assets/images/Group 3085.png",color:Colors.white,),
//                           ),
//                         ),
//                       ),
//                       SizedBox(
//                         width: 50.w,
//                       ),
//                       InkWell(
//                         onTap: (){
//
//                         },
//                         child: Container(
//                           height: 37.h,
//                           width: 37.w,
//                           decoration: BoxDecoration(
//                             borderRadius: BorderRadius.circular(50.r),
//
//                           ),
//                           child: Center(
//                             child: Image.asset("assets/images/apple.png",color: Colors.white,),
//                           ),
//                         ),
//                       ),
//                     ],
//                   ),
//                   SizedBox(height: 30.h,),
//                   Center(
//                     child: InkWell(
//                       onTap: (){
//                          _controller.guestUserLogin();
//                       },
//                         child: Text("Login as guest",style: smallTextStyle.copyWith(color: Colors.white),)),
//                   ),
//                   SizedBox(
//                     height: 15.h,
//                   ),
//                   Center(
//                     child: Row(
//                       crossAxisAlignment: CrossAxisAlignment.center,
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//
//                         InkWell(
//                             onTap: ()
//                             { Get.to(Login());
//                             },
//                             child: Padding(
//                               padding:  EdgeInsets.only(left: 30.w),
//                               child: Text("Login as Gym Partner ",
//                                   style:smallTextStyle.copyWith(fontSize: 14.sp,color:Colors.white)),
//                             )),
//                         SizedBox(width: 20.w,),
//                         Icon(Icons.arrow_forward_outlined,color:Colors.white,weight: .1,),
//                       ],
//                     ),
//                   ),
//                   SizedBox(
//                     height: 10.h,
//                   ),
//
//                 ],
//               ),
//             ),
//           )
//
//         ],
//         ),
//
//       ),
//     );
//   }
//
//
//   _launchURL() async
//   {
//     const url = 'https://play.google.com/console/about/';
//     final uri = Uri.parse(url);
//     if (await canLaunchUrl(uri)) {
//       await launchUrl(uri);
//     } else {
//       throw 'Could not launch $url';
//     }
//   }
//
//
//
//
//
//
// }
import 'package:animate_do/animate_do.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gym/Auth/controller/login_controller.dart';
import 'package:gym/Auth/view/weblancher.dart';
import 'package:gym/Notification/Notification.dart';

import 'package:gym/Widget/FirebaseServices.dart';
import 'package:gym/Widget/color.dart';
import 'package:url_launcher/url_launcher.dart';


import '../../FontStyle.dart';
import '../../ScanPackage/Login.dart';
class SignUp_Login extends StatefulWidget {
  SignUp_Login({Key? key}) : super(key: key);

  @override
  State<SignUp_Login> createState() => _SignUp_LoginState();
}

class _SignUp_LoginState extends State<SignUp_Login> {
  LoginController _controller=Get.put(LoginController());

  NotificationServices notificationServices = NotificationServices();

  final _keyForm=GlobalKey<FormState>();

  String? deviceId;

  String? deviceEmail;

  @override
  void initState() {
    super.initState();
  notificationServices.requestNotificationPermission();
  notificationServices.isTokenRefresh();
  notificationServices.getDeviceToken().then((value){
    if (kDebugMode)
    {
      _controller.fcm_id.value=value;
      print("wdjkniuhfe"+value);
      print( _controller.fcm_id.value+"wknihe");
    }

  });
  }


  @override
  Widget build(BuildContext context) {
    return
      Material(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          decoration: BoxDecoration(),
          child: Stack(
            children: [
              Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  decoration: BoxDecoration(
                    color:Colors.black,
                  ),
                  child:Column(
                    children: [
                      SizedBox(height: 90.h,),
                      Image(image: AssetImage("assets/images/logo2.png")),              ],
                  )
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height /2.6,
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(bottomRight:Radius.circular(70.r))
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height/1.666,
                  decoration: BoxDecoration(
                  ),
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height/1.4,
                  padding: EdgeInsets.only(top: 40.h, bottom: 30.h),
                  decoration: BoxDecoration(
                      color: Color(0xFF2a2b2b),
                      borderRadius: BorderRadius.only(topLeft:Radius.circular(100.r))
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    // mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Sign In",style: bodyText1Style.copyWith(fontSize: 22.sp,color: Colors.white)),
                      SizedBox(
                        height: 30.h,
                      ),
                      Text("Enter your mobile number",style: smallTextStyle,),
                      SizedBox(height:10.h),
                      Padding(
                        padding:  EdgeInsets.only(left:28.w,top: 18.w),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment:MainAxisAlignment.start,
                          children: [
                            Expanded(flex:1,
                                child: TextFormField(
                                    readOnly: true,
                                    initialValue: "+91",
                                    decoration:const InputDecoration(

                                      enabledBorder: UnderlineInputBorder(
                                        borderSide: BorderSide(width:2,color: Color(0xff3a3939)),
                                      ),
                                      focusedBorder: UnderlineInputBorder(

                                        borderSide: BorderSide(width:2,color: Color(0xff3a3939)),
                                      ),
                                      isDense: true,
                                      // fillColor: Colors.white
                                    ),
                                    style: titleStyle.copyWith(color: Colors.white))),
                            SizedBox(width: 8.w,),
                            Expanded(flex:3,child: Form(
                              key: _keyForm,
                              child: TextFormField(
                                  controller: _controller.etMobile,
                                  inputFormatters: [FilteringTextInputFormatter.allow(RegExp(r'[0-9]')),],
                                  keyboardType: TextInputType.number,

                                  decoration: const InputDecoration(
                                    enabledBorder: UnderlineInputBorder(
                                      borderSide: BorderSide(width:2,color: Color(0xff3a3939)),
                                    ),
                                    focusedBorder: UnderlineInputBorder(

                                      borderSide: BorderSide(width:2,color: Color(0xff3a3939)),
                                    ),
                                    counter: Offstage(),
                                    hintText: "0000000000",
                                    isDense: true,
                                    hintStyle:TextStyle(color:Colors.grey),
                                    contentPadding: EdgeInsets.symmetric(horizontal: 4, vertical: 8),

                                  ),
                                  validator: (value){
                                    if(value.toString().isEmpty)
                                    {
                                      return "Please enter mobile No.";
                                    }
                                    if(value!.length!=10)
                                    {
                                      return "Please enter 10 digits mobile number";
                                    }
                                  },
                                  maxLength: 10,

                                  style: titleStyle.copyWith(color: Colors.white)),
                            )),
                            Expanded(
                              flex: 2,
                              child: InkWell(
                                onTap: (){
                                  if(_keyForm.currentState!.validate()){

                                    _controller.loginNetworkApi();

                                  }
                                },
                                child: Container(
                                    height: 38.h,
                                    width: 38.w,
/*
                            decoration: BoxDecoration(
                              border: Border.all(color: Colors.grey,width: .5),
                              shape: BoxShape.circle,
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.blue,
                                  offset: const Offset(
                                    5.0,
                                    5.0,
                                  ),
                                  blurRadius: 30.0,
                                  spreadRadius: -8.0,
                                ), //BoxShadow
                                BoxShadow(
                                  color: Colors.white,
                                  offset: const Offset(10.0, 5.0),
                                  blurRadius: 40.0,
                                  spreadRadius: -23.0,
                                ), //BoxShadow
                              ],
                            ),
*/
                                    child: Icon(Icons.arrow_forward,color:Colors.white,weight: .2,)),
                              ),)
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 30.h,
                      ),
                      Center(
                        child: Text("Or Sign In With",style: smallTextStyle,),
                      ),
                      SizedBox(
                        height: 30.h,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          InkWell(onTap: ()
                          async
                          {
                            UserCredential userCredential= await  FirebaseServices().signInWithGooglewithFirebase();
                            if(userCredential!=null)
                            {
                              _controller.signUpwithSocialLoginNetworkApi(userCredential,deviceId??"");
                            }

                          },
                            child: Container(
                              height: 37.h,
                              width: 37.w,
                              decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(50.r)
                              ),
                              child: Center(
                                child: Image.asset("assets/images/Group 3085.png",color:Colors.white,),
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 50.w,
                          ),
                          InkWell(
                            onTap: (){

                            },
                            child: Container(
                              height: 37.h,
                              width: 37.w,
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(50.r),

                              ),
                              child: Center(
                                child: Image.asset("assets/images/apple.png",color: Colors.white,),
                              ),
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 30.h,),
                      Center(
                        child: InkWell(
                            onTap: (){
                              _controller.guestUserLogin();
                            },
                            child: Text("Login as guest",style: smallTextStyle.copyWith(color: Colors.white),)),
                      ),
                      SizedBox(
                        height: 15.h,
                      ),
                      Center(
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [

                            InkWell(
                                onTap: ()
                                { Get.to(Login());
                                },
                                child: Padding(
                                  padding:  EdgeInsets.only(left: 30.w),
                                  child: Text("Login as Gym Partner ",
                                      style:smallTextStyle.copyWith(fontSize: 14.sp,color:Colors.white)),
                                )),
                            SizedBox(width: 20.w,),
                            Icon(Icons.arrow_forward_outlined,color:Colors.white,weight: .1,),
                          ],
                        ),
                      ),
                      SizedBox(
                        height: 10.h,
                      ),

                    ],
                  ),
                ),
              )

            ],
          ),

        ),
      );
  }

  _launchURL() async
  {
    const url = 'https://play.google.com/console/about/';
    final uri = Uri.parse(url);
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri);
    } else {
      throw 'Could not launch $url';
    }
  }
}
