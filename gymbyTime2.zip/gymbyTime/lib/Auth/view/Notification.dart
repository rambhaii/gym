import 'package:animate_do/animate_do.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gym/Auth/controller/NotificationController.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/Widget/color.dart';
class Notifications extends StatefulWidget {
  const Notifications({Key? key}) : super(key: key);

  @override
  State<Notifications> createState() => _NotificationsState();
}

  class _NotificationsState extends State<Notifications> {
    NotificationController controller=Get.put(NotificationController());
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller.getNotificationListNetworkApi();
  }
  Widget build(BuildContext context) {

    return Scaffold(
      backgroundColor: TColor.themecolor,
      appBar: AppBar(
        backgroundColor: TColor.themecolor,
        iconTheme: IconThemeData(
          color:TColor.white
        ),
        title: Text("Notification",style: bodyText2Style.copyWith(fontSize: 20.sp,color: TColor.white),),
      ),
         body:FadeInUp(
             delay: Duration(milliseconds: 450),
             child: Obx(()=>controller.notificationModel.value.data!=null?
                SingleChildScrollView(
                   child: Column(
                     crossAxisAlignment: CrossAxisAlignment.start,
                     children: [
                       Padding(
                         padding: const EdgeInsets.only(left: 18.0),
                         /* child: Text("24 April 2023",style: bodyText4Style.copyWith(color: Colors.blue,
                        fontWeight: FontWeight.bold,fontSize: 19.sp),)*/
                       ),
                       ListView.builder(
                           itemCount:controller.notificationModel.value.data!.length,
                           shrinkWrap: true,
                           physics: ScrollPhysics(),
                           scrollDirection: Axis.vertical,
                           itemBuilder: (context,index){
                             final data=controller.notificationModel.value.data![index];
                             return Container(
                                margin: EdgeInsets.all(5),
                               width: Get.width,
                               child: Column(
                                 children: [
                                   Row(
                                     children: [
                                       Container(
                                           height: 50.h,
                                           width: 50.w,
                                           alignment: Alignment.center,
                                           decoration: BoxDecoration(
                                             shape: BoxShape.circle,
                                             border: Border.all(
                                               width: 1.w,color: Colors.white),
                                           ),
                                           child: Icon(Icons.notification_add,color: Colors.white,)
                                       ),
                                       SizedBox(width: 8.w,),
                                       Container(
                                         width:MediaQuery.of(context).size.width/1.3,
                                         child: Column(
                                           mainAxisAlignment: MainAxisAlignment.center,
                                           crossAxisAlignment: CrossAxisAlignment.start,
                                           children: [
                                             Row(
                                               children: [
                                                 Container(
                                                   width:180.w,
                                                   child: Column(
                                                     crossAxisAlignment: CrossAxisAlignment.start,
                                                     children: [
                                                       Text(data.title.toString(),
                                                         style: smallTextStyle.copyWith(fontSize: 14.sp,color: Colors.white),),
                                                       // Text(data.,style: smallTextStyle.copyWith(fontSize: 10.sp,color: Colors.grey),),
                                                     ],
                                                   ),
                                                 ),
                                                 Spacer(),
                                                 Column(
                                                   mainAxisAlignment: MainAxisAlignment.start,
                                                   crossAxisAlignment: CrossAxisAlignment.start
                                                   ,
                                                   children: [
                                                     Text(data.addDate.toString().length > 19 ? data.addDate.toString()
                                                         .substring(0 ,19):data.addDate.toString(),maxLines: 2,
                                                       style: smallTextStyle.copyWith(color: Colors.grey,fontSize: 9.sp),),
                                                   ],
                                                 )
                                               ],
                                             )
                                           ],
                                         ),
                                       ),
                                       Spacer(),
                                     ],
                                   ),
                                 ],
                               ),
                             );
                           }),
                     ],
                   )
               ):Container()
             )
         ),
      // SingleChildScrollView(
      //   child:controller.notificationModel.value.data!=null
      //       ?
      //      Column(
      //       children: [
      //         ListView.builder(
      //             shrinkWrap: true,
      //             physics: BouncingScrollPhysics(),
      //             padding: EdgeInsets.all(5),
      //             scrollDirection: Axis.vertical,
      //             itemCount: controller.notificationModel.value.data!.length,
      //             itemBuilder:
      //             (context,index){
      //               final data=controller.notificationModel.value.data![index];
      //            return Column(
      //              children: [
      //                // Padding(
      //                //   padding:  EdgeInsets.only(left: 8.0.w,right: 8.w),
      //                //   child: data.title.toString()!=null ?
      //                //   Container(
      //                //     margin: EdgeInsets.only(top: 3),
      //                //     width: Get.width,
      //                //     decoration: BoxDecoration(
      //                //       borderRadius: BorderRadius.circular(10)
      //                //     ),
      //                //     padding: EdgeInsets.only(left: 15.w,right: 15.w,top: 5.h,bottom: 30.h),
      //                //    child:Column(
      //                //      crossAxisAlignment: CrossAxisAlignment.start,
      //                //      mainAxisAlignment: MainAxisAlignment.start,
      //                //      children: [
      //                //        Row(
      //                //          mainAxisAlignment: MainAxisAlignment.end,
      //                //          crossAxisAlignment: CrossAxisAlignment.end,
      //                //          children: [
      //                //            Text(data.addDate.toString().length > 19 ? data.addDate.toString()
      //                //                .substring(0 ,19):data.addDate.toString(),
      //                //              style: smallTextStyle.copyWith(color: Colors.grey,fontSize: 9.sp),),
      //                //          ],
      //                //        ),
      //                //        SizedBox(height: 10.h,),
      //                //        Text(data.title.toString(),style: smallTextStyle.copyWith(color: Colors.white),),
      //                //        Divider(color: Color(0xFF2a2b2b),)
      //                //      ],
      //                //    )):Container(),
      //                // ),
      //              ],
      //            );
      //         }),
      //       ],
      //     ):Container()
      // )
    );
  }
}
