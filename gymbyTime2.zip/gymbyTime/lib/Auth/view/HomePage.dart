import 'dart:ui';
import 'package:animate_do/animate_do.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:easy_search_bar/easy_search_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/AppConstant/APIConstant.dart';
import 'package:gym/Auth/controller/login_controller.dart';
import 'package:gym/Auth/view/Notification.dart';
import 'package:gym/Auth/view/SearchScreen.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/Dashboard/view/Booking.dart';
import 'package:gym/Dashboard/view/Home/Home.dart';
import 'package:gym/Dashboard/view/Home/home_deatails.dart';
import 'package:gym/Dashboard/view/Profile/profile.dart';
import 'package:gym/Dashboard/view/share.dart';
import 'package:gym/Widget/color.dart';
import 'package:gym/Widget/locationcontroller.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../Dashboard/view/Help.dart';
import '../../FontStyle.dart';
import '../../mathod/AppContest.dart';
class bottomNavigation extends StatefulWidget {
  const bottomNavigation({Key? key}) : super(key: key);

  @override
  State<bottomNavigation> createState() => _bottomNavigationState();
}

class _bottomNavigationState extends State<bottomNavigation> {
  /*void getLocation() async{
    await Geolocator.checkPermission();
    await Geolocator.requestPermission();
    Position position = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.high);
    print(position.latitude);
    print(position.longitude);
    controller.longitude.value=position.longitude;
    controller.latitude.value=position.latitude;
   // controller.address.value=position.
  }*/
  RxString searchValue=''.obs;
  Future<Position> getLocation() async {
    bool serviceEnabled;
    LocationPermission permission;
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      await Geolocator.openLocationSettings();
      return Future.error('Location services are disabled.');
    }
    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }
    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    return await Geolocator.getCurrentPosition(
        desiredAccuracy: LocationAccuracy.high);
  }
  Future<void> GetAddressFromLatLong() async {
    Position position = await getLocation();
    List<Placemark> placemarks =
    await placemarkFromCoordinates(position.latitude, position.longitude);

      controller.longitude.value=position.longitude;
      controller.latitude.value=position.latitude;
      Placemark place = placemarks[0];
      controller.address.value ="${place.street},${place.subLocality},${place.locality.toString()},${place.country}";

  }

  DateTime ?currentBackPressTime;
  int _currentIndex=0;
  List employee=[
    home(),
    details(),
    share(),
    music(),
    image_picker(),
  ];
  HomePageController controller=Get.put(HomePageController());
  LoginController _controller=Get.put(LoginController());
  LocationController contrllr=Get.put(LocationController());
  RxBool _isLightTheme = false.obs;

  Future<SharedPreferences> _prefs = SharedPreferences.getInstance();

  _saveThemeStatus() async {
    SharedPreferences pref = await _prefs;
    pref.setBool('theme', _isLightTheme.value);
  }

  _getThemeStatus() async
  {
    var _isLight = _prefs.then((SharedPreferences prefs) {
      return prefs.getBool('theme') != null ? prefs.getBool('theme') : true;
    }).obs;
    _isLightTheme.value = (await _isLight.value)!;
    Get.changeThemeMode(_isLightTheme.value ? ThemeMode.light : ThemeMode.dark);
  }
  @override
  Widget build(BuildContext context) {
    controller.getCategaryNetworkApi();
    controller.postcurrentaddressNetworkApi();
    getLocation();
     controller.getGymListNetworkApi();
    GetAddressFromLatLong();
    return WillPopScope(
      onWillPop: onWillPop,
      child: Stack(
        children: [
          Scaffold(
            backgroundColor: TColor.themecolor,
            appBar: PreferredSize(
              preferredSize: Size.fromHeight(65.h),
              child: AppBar(
                backgroundColor: Colors.black,
                // leading: Padding(
                //     padding: EdgeInsets.only(left: 8.w),
                //     child: FadeInLeftBig(
                //         delay: const Duration(milliseconds: 450),
                //         child: InkWell(
                //           onTap: (){
                //             setState(() {
                //               _currentIndex=4;
                //             });
                //           },
                //           child: Container(
                //             decoration: BoxDecoration(
                //
                //             ),
                //             child:Row(
                //               children: [
                //                 Container(
                //                   decoration: BoxDecoration(
                //                     shape: BoxShape.circle,
                //                     border: Border.all(color: Colors.white,width: 2.w)
                //                   ),
                //                   child: ClipRRect(
                //                     borderRadius: BorderRadius.circular(50.r),
                //                     child: CachedNetworkImage(
                //                       fit: BoxFit.cover,
                //                       imageUrl: BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString(),
                //                       height:30.h,
                //                       width: 30.w,
                //                       placeholder: (context, url) =>
                //                           Center(child: const CircularProgressIndicator()),
                //                       errorWidget: (context, url, error) =>
                //                       const Icon(Icons.person,color: Colors.white,),
                //                     ),
                //                   ),
                //                 ),SizedBox(width:5.w,),
                //                 Row(
                //                   crossAxisAlignment: CrossAxisAlignment.center,
                //                   mainAxisAlignment: MainAxisAlignment.center,
                //                   children: [
                //                     Icon(Icons.location_on_outlined,color: Colors.green,size: 25.sp,),
                //                     Container(
                //                       width: 165.w,
                //                       child: Column(
                //                         crossAxisAlignment: CrossAxisAlignment.center,
                //                         mainAxisAlignment: MainAxisAlignment.center,
                //                         children: [
                //                           Obx(()=>
                //                               Text(controller.address.value,style:bodyboldStyle.copyWith(color:Colors.white/*Theme.of(context).textTheme.bodyText1!.color*/
                //                                   ,height: 1.h,fontSize: 10.sp),overflow: TextOverflow.ellipsis,maxLines: 2,),
                //                           ),
                //                         ],
                //                       ),
                //                     ),
                //                   ],
                //                 ),
                //               ],
                //             ),
                //
                //            /* CircleAvatar(
                //                 radius: 20.w,
                //                 //backgroundImage: NetworkImage(BASE_URL+"/"+controller.image.toString())),
                //                 backgroundImage: NetworkImage(BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString())),*/
                //           ),))),
                title: Row(
                  children: [
                  InkWell(
                            onTap: (){
                              setState(() {
                                _currentIndex=4;
                              });
                            },
                            child: Container(
                              decoration: BoxDecoration(

                              ),
                              child:Row(
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      border: Border.all(color: Colors.white,width: 2.w)
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(50.r),
                                      child: CachedNetworkImage(
                                        fit: BoxFit.cover,
                                        imageUrl: BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString(),
                                        height:30.h,
                                        width: 30.w,
                                        placeholder: (context, url) =>
                                            Center(child: const CircularProgressIndicator()),
                                        errorWidget: (context, url, error) =>
                                        const Icon(Icons.person,color: Colors.white,),
                                      ),
                                    ),
                                  ),SizedBox(width:5.w,),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.location_on_outlined,color: Colors.green,size: 25.sp,),
                                      Container(
                                        width: 175.w,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Obx(()=>
                                                Text(controller.address.value,style:bodyboldStyle.copyWith(color:Colors.white/*Theme.of(context).textTheme.bodyText1!.color*/
                                                    ,height: 1.h,fontSize: 10.sp),overflow: TextOverflow.ellipsis,maxLines: 2,),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),))
                  ],
                ),
                actions: [

                  FadeInRight(
                    delay: const Duration(milliseconds: 450),
                    child: InkWell(onTap: (){
                         Get.to(()=>Notifications());
                         },
                      child: Container(
                          height: 20.h,
                          width: 20.w,
                          child: Image(image: AssetImage("assets/images/Group 12.png"))),
                    ),
                  ),
                  SizedBox(
                    width: 14.w,
                  ),
                  InkWell(onTap:(){
                    Get.to(()=>SearchScreen());
                  },child: Icon(Icons.search)),
                  SizedBox(width: 14.w,),
                ],

              ),
            ),
           /* PreferredSize(
              preferredSize: Size.fromHeight(65.h),
              child: EasySearchBar(
                  backgroundColor: Colors.black,
                  searchTextStyle: smallTextStyle.copyWith(color: Colors.white),
                  iconTheme: IconThemeData(
                      color: Colors.white
                  ),
                  searchHintText:"Search Hare",
                  leading: Padding(
                      padding: EdgeInsets.only(left: 8.w),
                      child: FadeInLeftBig(
                          delay: const Duration(milliseconds: 450),
                          child: InkWell(
                            onTap: (){
                              setState(() {
                                _currentIndex=4;
                              });
                            },
                            child: Container(
                              decoration: BoxDecoration(

                              ),
                              child:Row(
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(color: Colors.white,width: 2.w)
                                    ),
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(50.r),
                                      child: CachedNetworkImage(
                                        fit: BoxFit.cover,
                                        imageUrl: BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString(),
                                        height:30.h,
                                        width: 30.w,
                                        placeholder: (context, url) =>
                                            Center(child: const CircularProgressIndicator()),
                                        errorWidget: (context, url, error) =>
                                        const Icon(Icons.person,color: Colors.white,),
                                      ),
                                    ),
                                  ),SizedBox(width:5.w,),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Icon(Icons.location_on_outlined,color: Colors.green,size: 25.sp,),
                                      Container(
                                        width: 165.w,
                                        child: Column(
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Obx(()=>
                                                Text(controller.address.value,style:bodyboldStyle.copyWith(color:Colors.white*/



            /*Theme.of(context).textTheme.bodyText1!.color*//*
                                                    ,height: 1.h,fontSize: 10.sp),overflow: TextOverflow.ellipsis,maxLines: 2,),
                                            ),
                                          ],
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),

                              *//* CircleAvatar(
                                radius: 20.w,
                                //backgroundImage: NetworkImage(BASE_URL+"/"+controller.image.toString())),
                                backgroundImage: NetworkImage(BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString())),*//*
                            ),))),
                  *//*title: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(Icons.location_on_outlined,color: Colors.green,size: 25.sp,),
                    Container(
                      width: 150.w,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Obx(()=>
                              Text(controller.address.value,style:smallTextStyle.copyWith(color:Colors.white*//**//*Theme.of(context).textTheme.bodyText1!.color*//**//*
                                  ,height: 1.2.h,fontSize: 11.sp),overflow: TextOverflow.ellipsis,maxLines: 2,),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),*//*
                  title: Text(''),
                  actions: [
                    InkWell(onTap:(){
                      Get.to(()=>SearchScreen());
                    },child: Icon(Icons.search)),
                    SizedBox(width: 7.w,),
                    FadeInRight(
                      delay: const Duration(milliseconds: 450),
                      child: InkWell(onTap: (){
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => Notifications()));

                      },
                        child: Container(
                            height: 20.h,
                            width: 20.w,
                            child: Image(image: AssetImage("assets/images/Group 12.png"))),
                      ),
                    ),
                  ],
                  onSearch: (value) {
                    searchValue.value = value;
                  }
              ),
            ),*/



           // backgroundColor:Theme.of(context).appBarTheme.backgroundColor,
           /* appBar: PreferredSize(
              preferredSize: Size.fromHeight(60.h),
              child: AppBar(
                elevation: 0,
                  backgroundColor:TColor.themecolor,
                leading: Padding(
                  padding: EdgeInsets.only(left: 8.0),
                  child: FadeInLeftBig(
                    delay: const Duration(milliseconds: 450),
                    child: InkWell(
                      onTap: (){
                        setState(() {
                          _currentIndex=4;
                        });
                      },
                      child: Container(
                        height: 25.h,
                        width: 25.w,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.white),
                          shape: BoxShape.circle,
                          image: DecorationImage(
                            image:NetworkImage(BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString()),fit: BoxFit.fill
                          )
                        ),
                      )
                      */
            /*CircleAvatar(
                        radius: 10.w,
                        backgroundColor: Colors.amber.withOpacity(0.1),
                        //backgroundImage: NetworkImage(BASE_URL+"/"+controller.image.toString())),
                        backgroundImage: NetworkImage(BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString())),*/
            /*
                    ),
                  ),
                  ),
                leadingWidth: 45.w,
                title: Row(
                  children: [
                    Icon(Icons.location_on_outlined,color: Colors.green,size: 25.sp,),
                    Container(
                      width: 150.w,
                      child: Column(
                        children: [
                          Obx(()=>
                           Text(controller.address.value,style:smallTextStyle.copyWith(color:TColor.white,fontSize: 12.sp
                           ,height: 1),overflow: TextOverflow.ellipsis,maxLines: 2,),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                actions: [

                  SizedBox(width: 5.w,),
                  FadeInRight(
                    delay: const Duration(milliseconds: 450),
                    child: InkWell(onTap: (){
                      Navigator.of(context).push(MaterialPageRoute(builder: (context) => Notifications()));

                    },
                      child: Container(
                          height: 20.h,
                          width: 20.w,
                          child: Image(image: AssetImage("assets/images/Group 12.png"))),
                    ),
                  ),
                  SizedBox(width: 5.w,),
                ],
                ),
            ),*/
            body: employee[_currentIndex],
          ),

          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: 60.h,
              // margin: EdgeInsets.all(10.sp),
              decoration: BoxDecoration(
                shape: BoxShape.circle
              ),
              child: ClipRRect(
                 // borderRadius: BorderRadius.circular(40.r),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                  child: BottomNavigationBar(
                    showSelectedLabels: true,
                    showUnselectedLabels: true,
                    unselectedLabelStyle:bodyText3Style.copyWith(fontSize: 11.sp,color:TColor.white),
                    selectedLabelStyle:bodyText3Style.copyWith(color: Color(0xff03dac6)),
                    mouseCursor: MouseCursor.uncontrolled,
                    type: BottomNavigationBarType.fixed,
                    currentIndex: _currentIndex,
                    selectedItemColor: Color(0xff03dac6),
                    unselectedItemColor: Colors.grey,
                    unselectedIconTheme: IconThemeData(
                        color:TColor.white,
                        opacity: 1.0,
                        size: 30.0
                    ),
                    selectedFontSize: 14.sp,
                    // type: BottomNavigationBarType.fixed,
                    backgroundColor:TColor.themecolor,
                    onTap: (int index) {
                      setState((){
                        _currentIndex=index;
                      });
                    },
                    items: [
                      BottomNavigationBarItem(
                          label: 'Home',
                          icon: Image.asset("assets/images/home.png",width: 15.w,height: 15.h,color:TColor.white,)
                      ),
                      BottomNavigationBarItem(
                          label: 'Booking',
                          icon: Image.asset("assets/images/book.png",width: 15.w,height: 15.h,color:TColor.white,)),
                      BottomNavigationBarItem(
                          label: 'Invite',
                          icon: Image.asset("assets/images/share.png",width: 15.w,height: 15.h,color:TColor.white,)
                      ),
                      BottomNavigationBarItem(
                          label: 'Help',
                          icon: Image.asset("assets/images/music.png",width: 15.w,height: 15.h,color:TColor.white,)
                      ),
                      BottomNavigationBarItem(
                          label: 'Profile',
                          icon: Image.asset("assets/images/path.png",width: 15.w,height: 15.h,color:TColor.white,)
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Future<bool> onWillPop() {
    DateTime now = DateTime.now();
    if (currentBackPressTime == null || now.difference(currentBackPressTime!) > Duration(seconds: 2)) {
      currentBackPressTime = now;
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("Press again to exit"),
            backgroundColor:Theme.of(context).appBarTheme.backgroundColor,
            elevation: 10, //shadow
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(bottom: 70.h,left: 30.w,right: 30.w),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(50.r),
            ),
          )
      );
      return Future.value(false);
    }
    return Future.value(true);
  }
}
