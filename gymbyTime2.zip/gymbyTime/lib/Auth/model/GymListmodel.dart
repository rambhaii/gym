// To parse this JSON data, do
//
//     final gymListModel = gymListModelFromJson(jsonString);

import 'dart:convert';

GymListModel gymListModelFromJson(String str) => GymListModel.fromJson(json.decode(str));

String gymListModelToJson(GymListModel data) => json.encode(data.toJson());

class GymListModel {
  int? status;
  String? message;
  String? limit;
  int? page;
  List<Datum>? data;

  GymListModel({
    this.status,
    this.message,
    this.limit,
    this.page,
    this.data,
  });

  factory GymListModel.fromJson(Map<String, dynamic> json) => GymListModel(
    status: json["status"],
    message: json["message"],
    limit: json["limit"],
    page: json["page"],
    data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "limit": limit,
    "page": page,
    "Data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  String? id;
  String? categoryId;
  String? adminMasterId;
  String? name;
  String? zymName;
  String? email;
  String? gender;
  String? mobile;
  String? password;
  String? type;
  String? profile;
  String? stateId;
  String? cityId;
  String? zipCode;
  String? address;
  String? adharNo;
  String? panNo;
  String? gstNo;
  String? nearBy;
  String? accountNo;
  String? ifsc;
  String? accountType;
  String? accountHolder;
  String? bankName;
  String? aboutGym;
  String? description;
  String? latitude;
  String? longitude;
  String? walletAmount;
  String? morningShiftFrom;
  String? morningShiftTo;
  String? eveningShiftFrom;
  String? eveningShiftTo;
  String? price;
  dynamic gymFor;
  String? nearBy1;
  String? nearBy2;
  String? nearBy3;
  String? strengthImage;
  String? cardioImage;
  String? aerobicImage;
  String? yogaImage;
  String? otherImage;
  String? status;
  String? fitFor;
  DateTime? addDate;
  String? categoryTitle;
  String? per_min;
  String? stateTitle;
  String? cityName;
  String? rating;
  String? noRating;
  String? distance;

  Datum({
    this.id,
    this.categoryId,
    this.adminMasterId,
    this.name,
    this.zymName,
    this.email,
    this.gender,
    this.mobile,
    this.password,
    this.type,
    this.profile,
    this.stateId,
    this.cityId,
    this.zipCode,
    this.address,
    this.adharNo,
    this.panNo,
    this.gstNo,
    this.nearBy,
    this.accountNo,
    this.ifsc,
    this.accountType,
    this.accountHolder,
    this.bankName,
    this.aboutGym,
    this.description,
    this.latitude,
    this.longitude,
    this.walletAmount,
    this.morningShiftFrom,
    this.morningShiftTo,
    this.eveningShiftFrom,
    this.eveningShiftTo,
    this.price,
    this.gymFor,
    this.nearBy1,
    this.nearBy2,
    this.nearBy3,
    this.strengthImage,
    this.cardioImage,
    this.aerobicImage,
    this.yogaImage,
    this.otherImage,
    this.status,
    this.fitFor,
    this.addDate,
    this.categoryTitle,
    this.per_min,
    this.stateTitle,
    this.cityName,
    this.rating,
    this.noRating,
    this.distance,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    categoryId: json["category_id"],
    adminMasterId: json["admin_master_id"],
    name: json["name"],
    zymName: json["zym_name"],
    email: json["email"],
    gender: json["gender"],
    mobile: json["mobile"],
    password: json["password"],
    type: json["type"],
    profile: json["profile"],
    stateId: json["state_id"],
    cityId: json["city_id"],
    zipCode: json["zip_code"],
    address: json["address"],
    adharNo: json["adhar_no"],
    panNo: json["pan_no"],
    gstNo: json["gst_no"],
    nearBy: json["nearBy"],
    accountNo: json["account_no"],
    ifsc: json["ifsc"],
    accountType: json["account_type"],
    accountHolder: json["account_holder"],
    bankName: json["bank_name"],
    aboutGym: json["about_gym"],
    description: json["description"],
    latitude: json["latitude"],
    longitude: json["longitude"],
    walletAmount: json["wallet_amount"],
    morningShiftFrom: json["morning_shift_from"],
    morningShiftTo: json["morning_shift_to"],
    eveningShiftFrom: json["evening_shift_from"],
    eveningShiftTo: json["evening_shift_to"],
    price: json["price"],
    gymFor: json["gym_for"],
    nearBy1: json["near_by1"],
    nearBy2: json["near_by2"],
    nearBy3: json["near_by3"],
    strengthImage: json["strength_image"],
    cardioImage: json["cardio_image"],
    aerobicImage: json["aerobic_image"],
    yogaImage: json["yoga_image"],
    otherImage: json["other_image"],
    status: json["status"],
    fitFor: json["fit_for"],
    addDate: DateTime.parse(json["add_date"]),
    categoryTitle: json["categoryTitle"],
    per_min: json["per_min"],
    stateTitle: json["state_title"],
    cityName: json["city_Name"],
    rating: json["rating"],
    noRating: json["no_rating"],
    distance: json["distance"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "category_id": categoryId,
    "admin_master_id": adminMasterId,
    "name": name,
    "zym_name": zymName,
    "email": email,
    "gender": gender,
    "mobile": mobile,
    "password": password,
    "type": type,
    "profile": profile,
    "state_id": stateId,
    "city_id": cityId,
    "zip_code": zipCode,
    "address": address,
    "adhar_no": adharNo,
    "pan_no": panNo,
    "gst_no": gstNo,
    "nearBy": nearBy,
    "account_no": accountNo,
    "ifsc": ifsc,
    "account_type": accountType,
    "account_holder": accountHolder,
    "bank_name": bankName,
    "about_gym": aboutGym,
    "description": description,
    "latitude": latitude,
    "longitude": longitude,
    "wallet_amount": walletAmount,
    "morning_shift_from": morningShiftFrom,
    "morning_shift_to": morningShiftTo,
    "evening_shift_from": eveningShiftFrom,
    "evening_shift_to": eveningShiftTo,
    "price": price,
    "gym_for": gymFor,
    "near_by1": nearBy1,
    "near_by2": nearBy2,
    "near_by3": nearBy3,
    "strength_image": strengthImage,
    "cardio_image": cardioImage,
    "aerobic_image": aerobicImage,
    "yoga_image": yogaImage,
    "other_image": otherImage,
    "status": status,
    "fit_for": fitFor,
    "add_date": addDate!.toIso8601String(),
    "categoryTitle": categoryTitle,
    "per_min":per_min,
    "state_title": stateTitle,
    "city_Name": cityName,
    "rating": rating,
    "no_rating": noRating,
    "distance": distance,
  };
}
