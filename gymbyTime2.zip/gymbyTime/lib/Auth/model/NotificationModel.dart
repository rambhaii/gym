// To parse this JSON data, do
//
//     final notificationModel = notificationModelFromMap(jsonString);

import 'dart:convert';

NotificationModel notificationModelFromMap(String str) => NotificationModel.fromMap(json.decode(str));

String notificationModelToMap(NotificationModel data) => json.encode(data.toMap());

class NotificationModel {
  int? status;
  String? message;
  String? limit;
  int? page;
  List<Datum>? data;

  NotificationModel({
    this.status,
    this.message,
    this.limit,
    this.page,
    this.data,
  });

  factory NotificationModel.fromMap(Map<String, dynamic> json) => NotificationModel(
    status: json["status"],
    message: json["message"],
    limit: json["limit"],
    page: json["page"],
    data: List<Datum>.from(json["Data"].map((x) => Datum.fromMap(x))),
  );

  Map<String, dynamic> toMap() => {
    "status": status,
    "message": message,
    "limit": limit,
    "page": page,
    "Data": List<dynamic>.from(data!.map((x) => x.toMap())),
  };
}

class Datum {
  String? id;
  String? adminMaster;
  String? tblUserId;
  String? title;
  String? notiType;
  String? type;
  String? status;
  DateTime? addDate;
  String? modifyDate;
  dynamic? name;
  dynamic? profile;

  Datum({
    this.id,
    this.adminMaster,
    this.tblUserId,
    this.title,
    this.notiType,
    this.type,
    this.status,
    this.addDate,
    this.modifyDate,
    this.name,
    this.profile,
  });

  factory Datum.fromMap(Map<String, dynamic> json) => Datum(
    id: json["id"],
    adminMaster: json["admin_master"],
    tblUserId: json["tbl_user_id"],
    title:json["title"],
    notiType: json["noti_type"],
    type: json["type"],
    status: json["status"],
    addDate: DateTime.parse(json["add_date"]),
    modifyDate: json["modify_date"],
    name: json["name"],
    profile: json["profile"],
  );

  Map<String, dynamic> toMap() => {
    "id": id,
    "admin_master": adminMaster,
    "tbl_user_id": tblUserId,
    "title": title,
    "noti_type": notiType,
    "type": type,
    "status": status,
    "add_date": addDate!.toIso8601String(),
    "modify_date": modifyDate,
    "name": name,
    "profile": profile,
  };
}

enum Title { TEST_NOTIFICATION_1, TEST_NOTIFICATION }

final titleValues = EnumValues({
  "test notification ": Title.TEST_NOTIFICATION,
  "test notification 1": Title.TEST_NOTIFICATION_1
});

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    reverseMap = map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}
