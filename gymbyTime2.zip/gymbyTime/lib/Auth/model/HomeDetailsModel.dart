// // To parse this JSON data, do
// //
// //     final homeDetailsModel = homeDetailsModelFromJson(jsonString);
//
// import 'dart:convert';
//
// HomeDetailsModel homeDetailsModelFromJson(String str) => HomeDetailsModel.fromJson(json.decode(str));
//
// String homeDetailsModelToJson(HomeDetailsModel data) => json.encode(data.toJson());
//
// class HomeDetailsModel {
//   HomeDetailsModel({
//      this.status,
//      this.message,
//      this.data,
//   });
//
//   int? status;
//   String? message;
//   Data? data;
//
//   HomeDetailsModel copyWith({
//     int? status,
//     String? message,
//     Data? data,
//   }) =>
//       HomeDetailsModel(
//         status: status ?? this.status,
//         message: message ?? this.message,
//         data: data ?? this.data,
//       );
//
//   factory HomeDetailsModel.fromJson(Map<String, dynamic> json) => HomeDetailsModel(
//     status: json["status"],
//     message: json["message"],
//     data: Data.fromJson(json["Data"]??""),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "status": status,
//     "message": message,
//     "Data": data!.toJson(),
//   };
// }
//
// class Data {
//   Data({
//     required this.id,
//     required this.adminMasterId,
//     required this.name,
//     required this.zymName,
//     required this.email,
//     required this.mobile,
//     required this.password,
//     required this.type,
//     required this.profile,
//     required this.stateId,
//     required this.cityId,
//     required this.zipCode,
//     required this.address,
//     required this.description,
//     required this.latitude,
//     required this.longitude,
//     required this.walletAmount,
//     required this.status,
//     required this.addDate,
//     this.stateTitle,
//     this.cityName,
//     this.rating,
//     this.norating,
//     required this.noUserOnline,
//     required this.noUserOffline,
//     required this.imageList,
//     required this.amanities,
//   });
//
//   String id;
//   String adminMasterId;
//   String name;
//   String zymName;
//   String email;
//   String mobile;
//   String password;
//   String type;
//   String profile;
//   String stateId;
//   String cityId;
//   String zipCode;
//   String address;
//   String description;
//   String latitude;
//   String longitude;
//   String walletAmount;
//   String status;
//   String? rating;
//   String? norating;
//   DateTime addDate;
//   dynamic stateTitle;
//   dynamic cityName;
//   String noUserOnline;
//   String noUserOffline;
//   List<ImageList> imageList;
//   List<Amanity> amanities;
//
//   Data copyWith({
//     String? id,
//     String? adminMasterId,
//     String? name,
//     String? zymName,
//     String? email,
//     String? mobile,
//     String? password,
//     String? type,
//     String? profile,
//     String? stateId,
//     String? cityId,
//     String? zipCode,
//     String? address,
//     String? description,
//     String? latitude,
//     String? longitude,
//     String? walletAmount,
//     String? status,
//     DateTime? addDate,
//     dynamic stateTitle,
//     dynamic cityName,
//     String? noUserOnline,
//     String? noUserOffline,
//     List<ImageList>? imageList,
//     List<Amanity>? amanities,
//   }) =>
//       Data(
//         id: id ?? this.id,
//         adminMasterId: adminMasterId ?? this.adminMasterId,
//         name: name ?? this.name,
//         zymName: zymName ?? this.zymName,
//         email: email ?? this.email,
//         mobile: mobile ?? this.mobile,
//         password: password ?? this.password,
//         type: type ?? this.type,
//         profile: profile ?? this.profile,
//         stateId: stateId ?? this.stateId,
//         cityId: cityId ?? this.cityId,
//         zipCode: zipCode ?? this.zipCode,
//         address: address ?? this.address,
//         description: description ?? this.description,
//         latitude: latitude ?? this.latitude,
//         longitude: longitude ?? this.longitude,
//         walletAmount: walletAmount ?? this.walletAmount,
//         status: status ?? this.status,
//         addDate: addDate ?? this.addDate,
//         stateTitle: stateTitle ?? this.stateTitle,
//         cityName: cityName ?? this.cityName,
//         rating: rating ?? this.rating,
//         norating: norating ?? this.norating,
//         noUserOnline: noUserOnline ?? this.noUserOnline,
//         noUserOffline: noUserOffline ?? this.noUserOffline,
//         imageList: imageList ?? this.imageList,
//         amanities: amanities ?? this.amanities,
//       );
//
//   factory Data.fromJson(Map<String, dynamic> json) => Data(
//     id: json["id"],
//     adminMasterId: json["admin_master_id"],
//     name: json["name"],
//     zymName: json["zym_name"],
//     email: json["email"],
//     mobile: json["mobile"],
//     password: json["password"],
//     type: json["type"],
//     profile: json["profile"],
//     stateId: json["state_id"],
//     cityId: json["city_id"],
//     zipCode: json["zip_code"],
//     address: json["address"],
//     description: json["description"],
//     latitude: json["latitude"],
//     longitude: json["longitude"],
//     walletAmount: json["wallet_amount"],
//     status: json["status"],
//     addDate: DateTime.parse(json["add_date"]),
//     stateTitle: json["state_title"],
//     cityName: json["city_Name"],
//     rating:json["rating"],
//     norating:json["no_rating"],
//     noUserOnline: json["noUserOnline"]??"",
//     noUserOffline: json["noUserOffline"]??"",
//     imageList: List<ImageList>.from(json["imageList"].map((x) => ImageList.fromJson(x))),
//     amanities: List<Amanity>.from(json["amanities"].map((x) => Amanity.fromJson(x))),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "admin_master_id": adminMasterId,
//     "name": name,
//     "zym_name": zymName,
//     "email": email,
//     "mobile": mobile,
//     "password": password,
//     "type": type,
//     "profile": profile,
//     "state_id": stateId,
//     "city_id": cityId,
//     "zip_code": zipCode,
//     "address": address,
//     "description": description,
//     "latitude": latitude,
//     "longitude": longitude,
//     "wallet_amount": walletAmount,
//     "status": status,
//     "add_date": addDate.toIso8601String(),
//     "state_title": stateTitle,
//     "city_Name": cityName,
//     "noUserOnline": noUserOnline,
//     "noUserOffline": noUserOffline,
//     "imageList": List<dynamic>.from(imageList.map((x) => x.toJson())),
//     "amanities": List<dynamic>.from(amanities.map((x) => x.toJson())),
//   };
// }
//
// class Amanity {
//   Amanity({
//     required this.id,
//     required this.title,
//     required this.image,
//   });
//
//   String id;
//   String title;
//   String image;
//
//   Amanity copyWith({
//     String? id,
//     String? title,
//     String? image,
//   }) =>
//       Amanity(
//         id: id ?? this.id,
//         title: title ?? this.title,
//         image: image ?? this.image,
//       );
//
//   factory Amanity.fromJson(Map<String, dynamic> json) => Amanity(
//     id: json["id"],
//     title: json["title"],
//     image: json["image"],
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "title": title,
//     "image": image,
//   };
// }
//
// // enum Image { UPLOADS_AMANITIES_AM1_PNG, UPLOADS_AMANITIES_AM2_PNG }
// //
// // final imageValues = EnumValues({
// //   "uploads/amanities/am1.png": Image.UPLOADS_AMANITIES_AM1_PNG,
// //   "uploads/amanities/am2.png": Image.UPLOADS_AMANITIES_AM2_PNG
// // });
//
// class ImageList {
//   ImageList({
//     required this.id,
//     required this.image,
//   });
//
//   String id;
//   String image;
//
//   ImageList copyWith({
//     String? id,
//     String? image,
//   }) =>
//       ImageList(
//         id: id ?? this.id,
//         image: image ?? this.image,
//       );
//
//   factory ImageList.fromJson(Map<String, dynamic> json) => ImageList(
//     id: json["id"],
//     image: json["image"],
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "image": image,
//   };
// }
//
// class EnumValues<T> {
//   Map<String, T> map;
//   late Map<T, String> reverseMap;
//
//   EnumValues(this.map);
//
//   Map<T, String> get reverse {
//     reverseMap = map.map((k, v) => MapEntry(v, k));
//     return reverseMap;
//   }
// }
// To parse this JSON data, do
//
//     final homeDetailsModel = homeDetailsModelFromJson(jsonString);

import 'dart:convert';

HomeDetailsModel homeDetailsModelFromJson(String str) => HomeDetailsModel.fromJson(json.decode(str));

String homeDetailsModelToJson(HomeDetailsModel data) => json.encode(data.toJson());

class HomeDetailsModel {
  int? status;
  String? message;
  Data? data;

  HomeDetailsModel({
    this.status,
    this.message,
    this.data,
  });

  factory HomeDetailsModel.fromJson(Map<String, dynamic> json) => HomeDetailsModel(
    status: json["status"],
    message: json["message"],
    data: Data.fromJson(json["Data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "Data": data!.toJson(),
  };
}

class Data {
  String? id;
  String? categoryId;
  String? adminMasterId;
  String? name;
  String? zymName;
  String? email;
  String? mobile;
  String? password;
  String? type;
  String? profile;
  String? stateId;
  String? cityId;
  String? zipCode;
  String? address;
  String? nearBy;
  String? description;
  String? latitude;
  String? longitude;
  String? walletAmount;
  dynamic morningShiftFrom;
  dynamic morningShiftTo;
  dynamic eveningShiftFrom;
  dynamic eveningShiftTo;
  dynamic nearBy1;
  dynamic nearBy2;
  dynamic nearBy3;
  String? status;
  String? price;
  String? per_min;
  DateTime? addDate;
  String? categoryTitle;
  String? stateTitle;
  String? cityName;
  String? rating;
  String? noRating;
  String? distance;
  List<ImageList>? imageList;
  List<Amanity>? amanities;
  List<Service>? services;

  Data({
    this.id,
    this.categoryId,
    this.adminMasterId,
    this.name,
    this.zymName,
    this.email,
    this.mobile,
    this.password,
    this.type,
    this.profile,
    this.stateId,
    this.cityId,
    this.zipCode,
    this.address,
    this.nearBy,
    this.description,
    this.latitude,
    this.longitude,
    this.walletAmount,
    this.morningShiftFrom,
    this.morningShiftTo,
    this.eveningShiftFrom,
    this.eveningShiftTo,
    this.nearBy1,
    this.nearBy2,
    this.nearBy3,
    this.status,
    this.addDate,
    this.price,
    this.per_min,
    this.categoryTitle,
    this.stateTitle,
    this.cityName,
    this.rating,
    this.noRating,
    this.distance,
    this.imageList,
    this.amanities,
    this.services,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    id: json["id"],
    categoryId: json["category_id"],
    adminMasterId: json["admin_master_id"],
    name: json["name"],
    zymName: json["zym_name"],
    email: json["email"],
    mobile: json["mobile"],
    password: json["password"],
    type: json["type"],
    profile: json["profile"],
    stateId: json["state_id"],
    cityId: json["city_id"],
    zipCode: json["zip_code"],
    address: json["address"],
    nearBy: json["nearBy"],
    description: json["description"],
    latitude: json["latitude"],
    longitude: json["longitude"],
    walletAmount: json["wallet_amount"],
    morningShiftFrom: json["morning_shift_from"],
    morningShiftTo: json["morning_shift_to"],
    eveningShiftFrom: json["evening_shift_from"],
    eveningShiftTo: json["evening_shift_to"],
    nearBy1: json["near_by1"],
    nearBy2: json["near_by2"],
    nearBy3: json["near_by3"],
    status: json["status"],
    addDate: DateTime.parse(json["add_date"]),
    price: json["price"],
    per_min:json["per_min"],
    categoryTitle: json["categoryTitle"],
    stateTitle: json["state_title"],
    cityName: json["city_Name"],
    rating: json["rating"],
    noRating: json["no_rating"],
    distance: json["distance"],
    imageList: List<ImageList>.from(json["imageList"].map((x) => ImageList.fromJson(x))),
    amanities: List<Amanity>.from(json["amanities"].map((x) => Amanity.fromJson(x))),
    services: List<Service>.from(json["services"].map((x) => Service.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "category_id": categoryId,
    "admin_master_id": adminMasterId,
    "name": name,
    "zym_name": zymName,
    "email": email,
    "mobile": mobile,
    "password": password,
    "type": type,
    "profile": profile,
    "state_id": stateId,
    "city_id": cityId,
    "zip_code": zipCode,
    "address": address,
    "nearBy":nearBy,
    "description": description,
    "latitude": latitude,
    "longitude": longitude,
    "wallet_amount": walletAmount,
    "morning_shift_from": morningShiftFrom,
    "morning_shift_to": morningShiftTo,
    "evening_shift_from": eveningShiftFrom,
    "evening_shift_to": eveningShiftTo,
    "near_by1": nearBy1,
    "near_by2": nearBy2,
    "near_by3": nearBy3,
    "status": status,
    "add_date": addDate!.toIso8601String(),
    "price": price,
    "per_min": per_min,
    "categoryTitle": categoryTitle,
    "state_title": stateTitle,
    "city_Name": cityName,
    "rating": rating,
    "no_rating": noRating,
    "distance": distance,
    "imageList": List<dynamic>.from(imageList!.map((x) => x.toJson())),
    "amanities": List<dynamic>.from(amanities!.map((x) => x.toJson())),
    "services": List<dynamic>.from(services!.map((x) => x.toJson)),
  };
}

class Amanity {
  String? id;
  String? title;
  String? image;

  Amanity({
    this.id,
    this.title,
    this.image,
  });

  factory Amanity.fromJson(Map<String, dynamic> json) => Amanity(
    id: json["id"],
    title: json["title"],
    image: json["image"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "image": image,
  };
}

class ImageList {
  String? id;
  String? image;
  String? imgType;

  ImageList({
    this.id,
    this.image,
    this.imgType,
  });

  factory ImageList.fromJson(Map<String, dynamic> json) => ImageList(
    id: json["id"],
    image: json["image"],
    imgType: json["img_type"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "image": image,
    "img_type": imgType,
  };
}
class Service {
  String? id;
  String? title;
  String? image;

  Service({
    this.id,
    this.title,
    this.image,
  });

  factory Service.fromJson(Map<String, dynamic> json) => Service(
    id: json["id"],
    title: json["title"],
    image: json["image"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "image": image,
  };
}

