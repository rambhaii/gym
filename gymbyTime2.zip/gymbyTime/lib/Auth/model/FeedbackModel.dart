
import 'dart:convert';

FeedbackList feedbackListFromJson(String str) => FeedbackList.fromJson(json.decode(str));

String feedbackListToJson(FeedbackList data) => json.encode(data.toJson());

class FeedbackList {
  int? status;
  String? message;
  String? limit;
  int? page;
  List<Datum>? data;

  FeedbackList({
    this.status,
    this.message,
    this.limit,
    this.page,
    this.data,
  });

  factory FeedbackList.fromJson(Map<String, dynamic> json) => FeedbackList(
    status: json["status"],
    message: json["message"],
    limit: json["limit"],
    page: json["page"],
    data: List<Datum>.from(json["Data"].map((x) => Datum.fromJson(x))),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "limit": limit,
    "page": page,
    "Data": List<dynamic>.from(data!.map((x) => x.toJson())),
  };
}

class Datum {
  String? id;
  String? adminMasterId;
  String? usersId;
  String? rating;
  String? description;
  String? status;
  DateTime? addDate;
  String? modifyDate;
  String? name;
  String? profile;

  Datum({
    this.id,
    this.adminMasterId,
    this.usersId,
    this.rating,
    this.description,
    this.status,
    this.addDate,
    this.modifyDate,
    this.name,
    this.profile,
  });

  factory Datum.fromJson(Map<String, dynamic> json) => Datum(
    id: json["id"],
    adminMasterId: json["admin_master_id"],
    usersId: json["users_id"],
    rating: json["rating"],
    description: json["description"],
    status: json["status"],
    addDate: DateTime.parse(json["add_date"]),
    modifyDate: json["modify_date"],
    name: json["name"],
    profile: json["profile"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "admin_master_id": adminMasterId,
    "users_id": usersId,
    "rating": rating,
    "description": description,
    "status": status,
    "add_date": addDate!.toIso8601String(),
    "modify_date": modifyDate,
    "name": name,
    "profile": profile,
  };
}
