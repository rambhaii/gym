
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/Auth/view/HomePage.dart';
import 'package:gym/Auth/view/Splash.dart';
import 'package:gym/Auth/view/Splash_Screen.dart';
import 'package:gym/Widget/Dark.dart';
import 'package:in_app_update/in_app_update.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:upgrader/upgrader.dart';
import 'ScanPackage/StaffDashBoard.dart';

import 'mathod/AppContest.dart';
Future<void> main() async
{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);
  await GetStorage.init();
  runApp(MyApp());
}
@pragma('vm:entry-point')
Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message)async
{
  await Firebase.initializeApp();
  print(message.notification!.title.toString());
  print(message.notification!.body.toString());
  print(message.data.toString());
}
class MyApp extends StatelessWidget {

  @override
  Widget build(BuildContext context) {
    InAppUpdate.checkForUpdate().then((updateInfo) {
      if (updateInfo.updateAvailability == UpdateAvailability.updateAvailable) {
        //Logic to perform an update
      }
    });
    InAppUpdate.checkForUpdate().then((updateInfo) {
      if (updateInfo.updateAvailability == UpdateAvailability.updateAvailable) {
        if (updateInfo.immediateUpdateAllowed) {
          // Perform immediate update
          InAppUpdate.performImmediateUpdate().then((appUpdateResult) {
            if (appUpdateResult == AppUpdateResult.success) {
              //App Update successful
            }
          });
        } else if (updateInfo.flexibleUpdateAllowed) {
          //Perform flexible update
          InAppUpdate.startFlexibleUpdate().then((appUpdateResult) {
            if (appUpdateResult == AppUpdateResult.success) {
              //App Update successful
              InAppUpdate.completeFlexibleUpdate();
            }
          });
        }
      }
    });
    return ScreenUtilInit(
      designSize: const Size(360, 690),
      minTextAdapt: true,
      splitScreenMode: true,
      builder: (context , child){
        return  GlobalLoaderOverlay(
          useDefaultLoading: false,
          overlayOpacity: 0.1,
          overlayWidget: Center(
            child: Container(
                height: 41,
                width: 41,
                padding: const EdgeInsets.all(8),
                decoration: const BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                ),
                child: const CircularProgressIndicator(
                  color: Colors.black,
                  strokeWidth: 3.5,
                )
            ),
          ),
          child: GetMaterialApp(
          /* *//* themeMode:ThemeMode.system,
            theme: ThemeClass.lightTheme,
            darkTheme: ThemeClass.darkTheme,*//*
            theme: lightThemeData(context),
            darkTheme: darkThemeData(context),*/
            theme: ThemeData(
              primarySwatch: Colors.blue,
            ),
            home: UpgradeAlert(
              child: GetStorage().read(AppConstant.stafflogin).toString()=="1"?
              GetStorage().read(AppConstant.userName)!=null?
              GetStorage().read(AppConstant.userName).toString().isNotEmpty?StaffDashboard():
              Spalshscreen():Spalshscreen():
              GetStorage().read(AppConstant.userName)!=null? GetStorage().
               read(AppConstant.userName).toString().isNotEmpty?bottomNavigation():
              Spalshscreen():Spalshscreen(),
            ),
            debugShowCheckedModeBanner: false,
          ),
        );
      }
    );
  }
}
