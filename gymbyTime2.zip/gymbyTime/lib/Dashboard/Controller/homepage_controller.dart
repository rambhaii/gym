import 'dart:async';
import 'dart:convert';
import 'dart:ui';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:gym/Auth/controller/login_controller.dart';
import 'package:gym/Auth/model/BookModel.dart';
import 'package:gym/Auth/model/CategaryModel.dart';
import 'package:gym/Auth/model/FeedbackModel.dart';
import 'package:gym/Auth/model/GymListmodel.dart';
import 'package:gym/Auth/model/HomeDetailsModel.dart';
import 'package:gym/Auth/model/OfferModel.dart';
import 'package:gym/Auth/model/TransctionModel.dart';
import 'package:gym/Auth/view/Splash.dart';
import 'package:gym/Auth/view/Splash_Screen.dart';

import 'package:gym/Dashboard/Model/ContectUsModel.dart';
import 'package:gym/mathod/AppContest.dart';
import 'package:image_picker/image_picker.dart';
import 'package:loader_overlay/loader_overlay.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../AppConstant/APIConstant.dart';
import '../../AppConstant/ScanAppConstant.dart';
import '../../Auth/model/FaqModel.dart';
import '../../Auth/model/GymBookModel.dart';
import '../../FontStyle.dart';
import '../../ScanPackage/Model/ScanerModelData.dart';
import '../../ScanPackage/Model/ScannerModel.dart';
import '../../Widget/BaseController.dart';
import '../../mathod/BaseClient.dart';
import '../Model/BannerModel.dart';

class HomePageController extends GetxController{
  final ScrollController scrollController=ScrollController();

  late  GlobalKey<FormState> formKey2=GlobalKey<FormState>();
  TextEditingController searchkey = TextEditingController();
  RxBool _isLightTheme = false.obs;
  RxInt countvalue=0.obs;

  Future<void> counter() async
  {
    print("hii");
    try{
      final SharedPreferences prefs = await SharedPreferences.getInstance();
      int? counter = prefs.getInt('count');
      if(counter!=null)
      {
        counter = counter! + 1;
        await prefs.setInt("count", counter);
        countvalue.value = counter;
      }


    }catch(e)
    {
      print(e.toString());

    }



  }

  int start=0;
  int end=10;

  RxInt selectedIndex = 0.obs;
  RxInt setSelectedCategoryOfArtical = 0.obs;
  RxInt selectedComunityIndex = 0.obs;
  RxInt selectedServicesIndex = 0.obs;
  RxBool isCategorySelected = false.obs;
  RxBool isDob= true.obs;

  var bannerModel = BannerModel().obs;
  var contectModel=ContectUsModel().obs;
  var faqModel=FaqModel().obs;
  var categryModel=CategryModel().obs;
  var feedback=FeedbackList().obs;
  var transctionModel=TransctionModel().obs;
  var offerModel=OfferModel().obs;
  var homedetailsModel=HomeDetailsModel().obs;
  var booksModel=BookingModel().obs;
  var gymListModel=GymListModel().obs;
  var gymBestListModel=GymListModel().obs;
  var gymbookModel=GymBookModel().obs;
  var amountController = TextEditingController();
  RxInt male = 0.obs;
  RxInt fileLength = 0.obs;
  RxBool  isLoadingPage=false.obs;

  List<XFile>? imagesList = [];
  GetStorage _storage = GetStorage();
  String userName = "";
  String email = "";
  String image = "";
  String dob = "";
  int CategaryId=0;
  int fit_for=0;
  var bookid="";
  var id="";
  var walletammount="".obs;
  var ArrayCoin="0".obs;
  RxDouble latitude =0.0.obs;
  RxDouble longitude =0.0.obs;
  var address = ''.obs;
  @override
  void onInit()
  {
    userName = _storage.read(AppConstant.userName);
    email = _storage.read(AppConstant.email);
    image = _storage.read(AppConstant.profileImg);
    getBannerNetworkApi();

    print("fdjkhgjkfg");
    addItems();
    getBookNetworkApi();

    super.onInit();
  }

  addItems() async
  {
    scrollController.addListener
      (
            ()
        {
          print("fdjkhgjfdfghgfghkfg");
          if (scrollController.position.maxScrollExtent == scrollController.position.pixels)
          {
            if(isLoadingPage.value)
            {
              start=start+int.parse(booksModel.value.page!.toString());
              getBookingpageNationNetworkApi(start);

            }

          }
        });
  }


  getBookingpageNationNetworkApi(int end) async
  {
    print("dfjgfdkjg"+end.toString());
    var response = await BaseClient()
        .get(getBookApi +"?user_id=${_storage.read(AppConstant.id)}&limit=${10}&page=${end}").
    catchError(BaseController().handleError);


    if (jsonDecode(response)["status"] == 1)
    {
      if(isLoadingPage.value==true)
      {
        booksModel.value.data!.addAll(bookingModelFromJson(response).data!);
        booksModel.refresh();
      }
    }
    else{
      isLoadingPage.value=false;
      Fluttertoast.showToast(msg: "No more data availabel ! ");
    }

  }


  Category(){
    id=_storage.read(AppConstant.id);
  }

  getBannerNetworkApi() async {
    var response = await BaseClient()
        .get(getbannerApi + "?lng=eng")
        .catchError(BaseController().handleError);

    if (jsonDecode(response)["status"] == 1) {
      bannerModel.value = bannerModelFromJson(response);
      // print("dnjggud");
      // print(response);
      return;
    }
    BaseController().errorSnack(jsonDecode(response)["message"]);
  }
  logout() async {
    _storage.remove(AppConstant.id);
    _storage.remove(AppConstant.userId);
    _storage.remove(AppConstant.userName);
    _storage.remove(AppConstant.profileImg);
    _storage.remove(AppConstant.email);
    _storage.remove(AppConstant.phone);
    _storage.remove(AppConstant.age);
    _storage.remove(AppConstant.height);
    _storage.remove(AppConstant.stafflogin);
    _storage.remove(AppConstant.userType);
    Get.delete<LoginController>();
    final _auth = FirebaseAuth.instance;
    final _googleSignIn = GoogleSignIn();
    await _auth.signOut();
    await _googleSignIn.signOut();
    Get.offAll(() => Spalshscreen());
  }

  void selectMultipleImage() async {
    final ImagePicker _picker = ImagePicker();
    List<XFile>? imagesList2 = await _picker.pickMultiImage(
        imageQuality: 60, requestFullMetadata: true);
    if (imagesList2.isNotEmpty) {
      fileLength.value = imagesList2.length;
      imagesList = imagesList2;
    }
  }


  getCategaryNetworkApi() async {
    var response = await BaseClient()
        .get(getcategaryApi + "?lng=eng")
        .catchError(BaseController().handleError);
    // print(response);
    if (jsonDecode(response)["status"] == 1) {
      categryModel.value = categryModelFromJson(response);
      // print(response);
      return;
    }
    BaseController().errorSnack(jsonDecode(response)["message"]);
  }



  getFeedbackNetworkApi(String id) async {
    var response = await BaseClient()
        .get(getFeedbackStarApi +"? limit=200&page=0&gym_id=${gym_id}")
        .catchError(BaseController().handleError);
    print(response);
    print("hdyug8f6f"+ getFeedbackStarApi+"? limit=10&page=0&gym_id=${gym_id}");
    if (jsonDecode(response)["status"] == 1) {
      feedback.value = feedbackListFromJson(response);
      // print(response);
      return;
    }
    feedback.value = feedbackListFromJson(response);

    BaseController().errorSnack(jsonDecode(response)["message"]);
  }


  getGymListNetworkApi() async
  {
    // var response = await BaseClient()
    //     .get(getgymListApi + "?lng=eng&category_id=${CategaryId}")
    //     .catchError(BaseController().handleError);
    var response = await BaseClient()
        .get(getgymListApi + "?limit=500&page=0&searchkey=&category_id=${CategaryId}"
        "&latitude=${latitude}&longitude=${longitude}")
        .catchError(BaseController().handleError);
    print("debbugiugef"+response);
    if (jsonDecode(response)["status"] == 1) {
      gymListModel.value = gymListModelFromJson(response);
     // isLoadingPage.value=true;
      start=10;
      end=(end);
      // print(response);
      return;
    }
    BaseController().errorSnack(jsonDecode(response)["message"]);
  }


  getGymBestListNetworkApi() async
  {
    var response = await BaseClient()
        .get(getgymListApi + "?limit=100&page=0&searchkey=&category_id=${CategaryId}"
        "&latitude=${latitude}&longitude=${longitude}&fit_for=1")
        .catchError(BaseController().handleError);
    if (jsonDecode(response)["status"] == 1) {
      gymBestListModel.value = gymListModelFromJson(response);

      return;
    }
    gymBestListModel.value = gymListModelFromJson(response);
    // BaseController().errorSnack(jsonDecode(response)["message"]);
  }



  getGymListSearchNetworkApi(String SearchKey,) async
  {
    var response = await BaseClient()
        .get(getgymListApi + "?limit=500&page=0&searchkey=${SearchKey}&category_id=${CategaryId}"
        "&latitude=${latitude}&longitude=${longitude}")
        .catchError(BaseController().handleError);
    print("sdfsdf"+response);
    if (jsonDecode(response)["status"] == 1)
    {
      gymListModel.value = gymListModelFromJson(response);
      print(response);
      return;
    }
    BaseController().errorSnack(jsonDecode(response)["message"]);
  }

  getContectNetworkApi() async{
    var response = await BaseClient()
        .get(getcontectApi +"/lng=eng").
    catchError(BaseController().handleError);
    if(jsonDecode(response)["status"]==1) {
      contectModel.value = contectUsModelFromJson(response);
      print(response);
      return;
    }
    BaseController().errorSnack(jsonDecode(response)["message"]);

  }

  getOfferNetworkApi() async{
    var response = await BaseClient()
        .get(getOfferListApi +"/lng=eng${
        _storage.read(AppConstant.offerId,).toString().trim()

    }").
    catchError(BaseController().handleError);
    // print("ehuigiygf"+ response);
    if(jsonDecode(response)["status"]==1) {
      offerModel.value = offerModelFromJson(response);
      // print("dbgyigiguf");
      print(response);
      return;
    }
    BaseController().errorSnack(jsonDecode(response)["message"]);

  }
  getHomeDetailsNetworkApi(String id) async{

    print("hjmgvjxbchgjhfbghfchvbjhv"+id);
    var response = await BaseClient()
        .get(getHomeDetailsListApi +"?gym_id=${id}").
    catchError(BaseController().handleError);
    // print("ehuigiyjihfigf"+ response);
    if(jsonDecode(response)["status"]==1) {
      homedetailsModel.value = homeDetailsModelFromJson(response);
      // print("jjdhfjufgug");
      print(response);
      return;
    }
    BaseController().errorSnack(jsonDecode(response)["message"]);

  }


  getFaqNetworkApi() async{
    var response = await BaseClient()
        .get(getFaqApi +"?lng=eng&limit=10&page=0").
    catchError(BaseController().handleError);
    // print("ehuigiggirguig7"+response);
    if(jsonDecode(response)["status"]==1) {
      faqModel.value = faqModelFromJson(response);
      // print("hugugui76r57");
      print(response);
      return;
    }
    BaseController().errorSnack(jsonDecode(response)["message"]);

  }

  getBookNetworkApi() async
  {
    var response = await BaseClient().get(getBookApi +"?user_id=${_storage.read(AppConstant.id)}&limit=${10}&page=${0}").
    catchError(BaseController().handleError);
    print("======"+response);
    if(jsonDecode(response)["status"]==1)
    {
      booksModel.value = bookingModelFromJson(response);
      isLoadingPage.value=true;

    }
    else
    {
      booksModel.value = bookingModelFromJson(response);
      isLoadingPage.value=false;
    }
   /* BaseController().errorSnack(jsonDecode(response)["message"]);*/

  }


  getTransctionNetworkApi() async{
    var response = await BaseClient()
        .get(getTransctionApi +"?user_id=${_storage.read(AppConstant.id)}&limit=50&page=0").
    catchError(BaseController().handleError);
    // print("efhu7feriutfr"+response);
    if(jsonDecode(response)["status"]==1) {
      transctionModel.value = transctionModelFromJson(response);
      // print("dsfkkhuugih  $transctionModel.value");
      print(response);
      return;
    }
    /*BaseController().errorSnack(jsonDecode(response)["message"]);*/

  }


  Future<bool> postRaiseTicketNetworkApi(String message,subject) async {
    var bodyRequest = {
      "lng": language,
      "user_id":_storage.read(AppConstant.id),
      "subject": subject,
      "description": message
    };
    // print("edjuigfiygyub");
    // print(bodyRequest);

    Get.context!.loaderOverlay.show();
    var response = await BaseClient()
        .post(getRaiseTicketApi, bodyRequest)
        .catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    // print("ddhuif86df");
    print(response);
    if (jsonDecode(response)["status"] == 1) {
      // BaseController().successSnack(jsonDecode(response)["message"]);
      return true;
    }
    BaseController().errorSnack(jsonDecode(response)["message"]);
    return false;
  }

  var gym_id=''.obs;
  var date=''.obs;
  var time=''.obs;
  var coupon_id=''.obs;
  var coupon_code=''.obs;

  Future<bool> postgymookNetworkApi(context) async {
    /* var bodyRequest = {
      "lng": language,
      "user_id":_storage.read(AppConstant.id),
      "gym_id":gym_id,
      "coupon_id":coupon_id,
      "coupon_code":coupon_code,
      "date":"11/12/2022",
      "time":''
    };*/
    var bodyRequest = {
      "user_id":_storage.read(AppConstant.id),
      "gym_id":gym_id.toString(),
      "coupon_id":coupon_id.toString(),
      "coupon_code":coupon_code.toString(),
      "date":date.toString(),
      "time":time.toString()
    };
    print("book send data $bodyRequest");
    Get.context!.loaderOverlay.show();
    var response = await BaseClient()
        .post(getgymBookApi, bodyRequest)
        .catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();
    print(response);
    if (jsonDecode(response)["status"] == 1) {
      gymbookModel.value=gymBookModelFromJson(response);
      print("djihof8  $jsonDecode(response)[status] == 1");
      // BaseController().successSnack(jsonDecode(response)["message"]);
      getBookNetworkApi();
      Navigator.pop(context);
      return true;
    }
    BaseController().errorSnack(jsonDecode(response)["message"]);
    gymbookModel.value=gymBookModelFromJson(response);
    return false;
  }

  Future<bool> postcurrentaddressNetworkApi() async {
    var bodyRequest = {
      "user_id":_storage.read(AppConstant.id),
      "latitude":latitude.toString(),
      "longitude":longitude.toString(),
      "address":address.toString(),
    };
  print("fghfhf $bodyRequest");
     Get.context!.loaderOverlay.show();
    var response = await BaseClient()
        .post(getcurrentaddressApi, bodyRequest)
        .catchError(BaseController().handleError);
     Get.context!.loaderOverlay.hide();
    print(response);
    print("kdjkjhiygfvh"+response);
    if (jsonDecode(response)["status"] == 1)
    {
      walletammount.value=jsonDecode(response)["Data"]["wallet_amount"]??"0";
      // walletammount.value="500";
      // _storage.write(AppConstant.wallet_amount,jsonDecode(response)["Data"]["wallet_amount"]??"0");
      _storage.write(AppConstant.wallet_amount,jsonDecode(response)["Data"]["wallet_amount"]??"0");
      return true;
    }
    return false;
  }


  var amount=''.obs;
  var txt_id=''.obs;
  var status=''.obs;
  Future<bool>getpurchasePointsNetworkApi(transection_Id,String status) async {
    var bodyRequest = {
      "user_id":_storage.read(AppConstant.id),
      "coupon_id":coupon_id.toString(),
      "coupon_code":coupon_code.toString(),
      "amount":amountController.text.toString(),
      "txn_id":transection_Id.toString(),
      "status":status.toString(),
    };
    print("cdhui7gd  $bodyRequest");
    /* Future<bool> getpurchasePointsNetworkApi() async {
    var bodyRequest = {
      "user_id":_storage.read(AppConstant.id),
      "coupon_id":coupon_id,
      "coupon_code":coupon_code,
      "amount":amount,
      "txn_id":txt_id,
      "status":status,
    };*/

     Get.context!.loaderOverlay.show();
    var response = await BaseClient()
        .post(getpurchasePoints, bodyRequest)
        .catchError(BaseController().handleError);
     Get.context!.loaderOverlay.hide();
    print(response);
    print("kdjkjhiygfvh"+response);
    if (jsonDecode(response)["status"] == 1) {
      _storage.write(AppConstant.wallet_amount,jsonDecode(response)["Data"]["wallet_amount"]);
      return true;
      BaseController().successSnack(jsonDecode(response)["message"]);
    }
    return false;
    BaseController().errorSnack(jsonDecode(response)["message"]);
  }
  var scanerModelData=ScanerModelData().obs;

  getMyscanListNetworkApi()
  async{


    var response = await BaseClient()
        .get(getMyscanList +"?staff_id=${_storage.read(AppConstant.id)}&limit=500&page=0&searchkey").
    catchError(BaseController().handleError);
    print("zxvvdfgg  $response");
    if(jsonDecode(response)["status"]==1)
    {
      scanerModelData.value = scanerModelDataFromJson(response);
      print("zvdfgg  $response");
      print(response);
      return;
    }
    else
    {
      scanerModelData.value = scanerModelDataFromJson(response);
      BaseController().errorSnack(jsonDecode(response)["message"]);
    }

  }

  var scanerData=ScanerData().obs;
  Future<bool> getMyscanDataNetworkApi(String bookingNo) async
  {
    var bodyRequest =
    {
      "staff_id":_storage.read(AppConstant.id),
      "booking_no":bookingNo,
    };
    print("djfgjh"+bodyRequest.toString());
    Get.context!.loaderOverlay.show();
    var response = await BaseClient()
        .post(getMyscanData, bodyRequest)
        .catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();

    print("dgfghfhjj"+response);
    if (jsonDecode(response)["status"] == 1)
    {
      scanerData.value=scanerDataFromJson(response);
      BaseController().successSnack(jsonDecode(response)["message"]);
      return true;
    }
    else
    {
      print("dfgfmdgjkdfhg");
      BaseController().successSnack(jsonDecode(response)["message"]);
      scanerData.value=scanerDataFromJson(response);

      return false;
    }
  }


  Future<bool> getFeedbackRatingNetworkApi(String message,String rating) async
  {
    var bodyRequest =
    {
      "lng": language,
      "gym_id":gym_id.value,
      "user_id":_storage.read(AppConstant.id),
      "rating":rating,
      "description":message
    };
    print("djfgjh"+bodyRequest.toString());
    Get.context!.loaderOverlay.show();
    var response = await BaseClient()
        .post(getfeedbackApi, bodyRequest)
        .catchError(BaseController().handleError);
    Get.context!.loaderOverlay.hide();

    print("dgfghfhjj"+response);
    if (jsonDecode(response)["status"] == 1)
    {
      BaseController().successSnack(jsonDecode(response)["message"]);
      return true;
    }
    else
    {
      print("dfgfmdgjkdfhg");
      BaseController().successSnack(jsonDecode(response)["message"]);
      return false;
    }
  }
}


