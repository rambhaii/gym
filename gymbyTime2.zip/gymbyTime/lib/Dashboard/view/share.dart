import 'dart:ui';
import 'package:firebase_dynamic_links/firebase_dynamic_links.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/AppConstant/APIConstant.dart';
import 'package:gym/Auth/controller/FirebaseDynamicLink.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/Widget/ButtonWidget2.dart';
import 'package:gym/Widget/color.dart';
import 'package:gym/mathod/AppContest.dart';
import 'package:simple_gradient_text/simple_gradient_text.dart';
class share extends StatefulWidget {
  const share({Key? key}) : super(key: key);

  @override
  State<share> createState() => _shareState();
}
class _shareState extends State<share> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: TColor.themecolor,
      body:SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Column(
            children: [
              // Card(
              //   shape: RoundedRectangleBorder(
              //     borderRadius: BorderRadius.circular(20.r)
              //   ),
              //   child: Container(
              //     height: 210.h,
              //     width: Get.width,
              //     decoration: BoxDecoration(
              //       color: Color(0xFF2a2b2b),
              //       borderRadius: BorderRadius.circular(20.r)
              //     ),
              //     child: Column(
              //       crossAxisAlignment: CrossAxisAlignment.start,
              //       children: [
              //         Text("Invite",style: smallTextStyle.copyWith(fontSize: 34.sp),),
              //         Text("    GymByMinute",style: smallTextStyle.copyWith(fontSize: 34.sp),),
              //        Text("          Get",style: smallTextStyle.copyWith(fontSize: 34.sp),),
              //         Text("              this",style: smallTextStyle.copyWith(fontSize: 34.sp)),
              //       ],
              //     ),
              //   ),
              // ),
              // SizedBox(height: 20.h,),
              // ButtonWidget2(onPress: ()
              // async {
              //   String generateDeeplink=await FirebaseDynamicLinkService
              //       .buildDynamicLinks(
              //       "App link",
              //       "",
              //       "",
              //       false,2, GetStorage().read(AppConstant.id), "");
              // }, text: 'Share',),
              //
              // SizedBox(height: 20.h,),
              // ButtonWidget2(onPress: () async {
              //   String generateDeeplink=await FirebaseDynamicLinkService
              //       .buildDynamicLinks(
              //       "App link",
              //       "",
              //       "",
              //       false,1, GetStorage().read(AppConstant.id), "");
              // }, text: 'Earned Coin',),
              //
              // SizedBox(height: 60.h,)
              Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.r)
                ),
                child: Container(
                  height: 170.h,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.r),
                    image: DecorationImage(
                      image: AssetImage("assets/images/share.jpg")
                    )
                  ),
                ),
              ),
              SizedBox(height:15.h,),
              Text("Invite your friends to join GymByMinute and earn 60 minutes!"
                ,style: bodyboldStyle.copyWith(fontSize: 26.sp,color: Colors.white,height:1.2.h),),
              SizedBox(height: 10.h,),
              Text("Share your unique referral code or link with friends and family."
                  " When they sign up using your referral code and complete thire first"
                  " workout.both of you will receive 60 minutes as a reward.",
                style: smallTextStyle.copyWith(color: Colors.white,),textAlign: TextAlign.justify,),
              SizedBox(height: 20.h,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  InkWell(
                    onTap: () async {
                      String generateDeeplink=await FirebaseDynamicLinkService
                          .buildDynamicLinks(
                          "App link",
                          "",
                          "",
                          false,1, GetStorage().read(AppConstant.id), "");
                        },
                    child: Text("SHARE",style: bodybold2Style.copyWith(
                        color: Colors.white,fontSize: 27.sp,fontWeight: FontWeight.bold,),),
                  ),
                  InkWell(onTap: () async{
                    String generateDeeplink=await FirebaseDynamicLinkService
                        .buildDynamicLinks(
                        "App link",
                        "",
                        "",
                        false,1, GetStorage().read(AppConstant.id), "");
                  },
                    child: Container(
                     height: 60.h,
                     width: 60.w,
                     child: Image.asset("assets/images/in2.png",color: Colors.white,),
                     ),
                  ),
                  Text("'NSKJD007SDN'",style: bodyboldStyle.copyWith(color: Colors.white,),),
                ],
              ),
              SizedBox(height: 10.h,),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text("EARNED MINS ",style: bodybold2Style.copyWith(color: Colors.white,fontSize: 25.sp),),
                  Container(
                    height: 30.h,
                    width: 30.w,
                    child: Image.asset("assets/images/t.png",color: Colors.white,),
                  ),
                  Text(" 60",style: bodybold2Style.copyWith(color: Colors.white,fontSize: 25.sp),)
                ],
              )
            ],
          ),
        ),
      )
    );
  }
}