import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui';

import 'package:animate_do/animate_do.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/Dashboard/view/Home/Home_offer.dart';
import 'package:gym/Dashboard/view/Home/Rating.dart';
import 'package:gym/Dashboard/view/Home/home_deatails.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/Widget/ButtonWidget.dart';
import 'package:gym/Widget/ButtonWidget2.dart';
import 'package:gym/Widget/LodingWidget.dart';
import 'package:gym/Widget/color.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import '../../AppConstant/APIConstant.dart';
class details extends StatefulWidget {
  const details({Key? key}) : super(key: key);

  @override
  State<details> createState() => _detailsState();
}


class _detailsState extends State<details> {
  late var _razorpay;

  @override
  void initState() {
    // TODO: implement initState
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    super.initState();
    controller.getBookNetworkApi();
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    print("Payment Done");
    var transection_Id='${response.paymentId}';
    if(response !="PaymentSuccessResponse"){
      controller.getpurchasePointsNetworkApi(transection_Id,"2");
    }else{

    }

    controller.amountController.clear();
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    print("Payment Fail");
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
  }
  HomePageController controller=Get.put(HomePageController());
  TextEditingController _textDate=TextEditingController();
  TextEditingController _textTime=TextEditingController();
  var gmail,date,time,bookingId,image;
  int start=0;
  @override
  Widget build(BuildContext context) {
    controller.getGymListNetworkApi();

    return Scaffold(
      backgroundColor: TColor.themecolor,
      body: FadeInUp(
        delay: const Duration(milliseconds: 450),
        child: SingleChildScrollView(
          controller: controller.scrollController,
          child: Obx(()=>controller.booksModel.value.data!=null
              ?
            Column(
              children:
              [
              ListView.builder(
                itemCount: controller.booksModel.value.data!.length,
                shrinkWrap: true,
                physics: BouncingScrollPhysics(),
                itemBuilder:
                (context, int index) {
                  final datas=controller.booksModel.value.data![index];
                  Uint8List bytes= base64.decode(datas.qrimage.toString());
                  return Padding(
                    padding:  EdgeInsets.only(left: 8.0,right: 8,top: 8.h),
                    child: Card(
                      elevation: .3,
                      shadowColor: Colors.blue,
                      child: Column(
                        children: [
                          Container(
                            color:TColor.box,
                            padding: EdgeInsets.all(5.w),
                            width: MediaQuery.of(context).size.width,
                            child: Row(
                              children: [
                                Container(
                                  padding: EdgeInsets.only(left:5.w,right: 5.w),
                                  height: 80.h,
                                  width: MediaQuery.of(context).size.width/1.4,
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          Text(datas.zymName.toString().length>25?datas.zymName.toString().substring(0,25):datas.zymName.toString(),style:bodyText2Style.copyWith(color: Colors.blue) ,overflow: TextOverflow.ellipsis,),
                                          Spacer(),
                                          Text(datas.check_in.toString().isNotEmpty?"check_Out":datas.check_Out.toString().isNotEmpty?"Done":"Check_in",style: bodyText2Style.copyWith(color: Colors.green)),
                                        ],
                                      ),
                                     SizedBox(height: 3.h,),
                                      Text(datas.date.toString(),style: smallTextStyle.copyWith(fontSize: 12 ,color: TColor.white,),),
                                      Row(
                                        children: [
                                          Text(datas.time.toString(),style: smallTextStyle.copyWith(fontSize: 12, color: TColor.white,),),
                                          Spacer(),
                                          InkWell(
                                            onTap: (){
                                              controller.gym_id.value=datas.adminMasterId.toString();
                                              print( "aasadsa ${controller.gym_id.value}");
                                              Get.to(()=>RateUsApp(datas.adminMasterId.toString()));

                                            },
                                            child: Container(
                                              height: 18.h,
                                              width: 70.w,
                                              decoration: BoxDecoration(
                                                border: Border.all(color: Color(0xff03dac6),),
                                                borderRadius: BorderRadius.circular(10.r)
                                              ),
                                              child: Center(child: Text("Rate Us",style:bodyText2Style.copyWith(fontSize: 12.sp ,color: TColor.white,))),
                                            ),
                                          )
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          InkWell(

                                            onTap:(){

                                              Get.to(()=>home_deatails(datas.adminMasterId.toString()));
                                              controller.gym_id.value=datas.adminMasterId.toString();
                                              Timer(Duration(seconds: 1), ()
                                              {
                                                bottomSheetBook();

                                              });
                                            },
                                            child: Container(
                                              height: 25.h,
                                              width: 100.w,
                                              decoration: BoxDecoration(
                                                  color: Color(0xff03dac6),
                                                  borderRadius: BorderRadius.circular(40.r)
                                              ),
                                              child: Center(child: Text("ReBook",style:smallTextStyle.copyWith( color: TColor.white,))),
                                            ),
                                          ),
                                          Spacer(),
                                          Text("BOOKING ID ",style:bodyText2Style.copyWith(fontSize: 12.sp,color: Colors.grey),),
                                          Text(datas.bookingNo.toString(),style:bodyText2Style.copyWith(fontSize: 12.sp, color: TColor.white,)),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                                Spacer(),
                                InkWell(
                                  onTap: (){
                                    RegExp exp = RegExp(r"<[^>]*>",multiLine: true,caseSensitive: true);
                                    gmail=datas.zymName.toString();
                                    image=datas.qrimage.toString();
                                    date=datas.date.toString();
                                    time=datas.time.toString();
                                    bookingId=datas.bookingNo.toString();
                                    qrmodelbottom(gmail,date,time,bookingId,image);
                                    print(datas.qrimage.toString().replaceAll(exp, "")+"fiji");
                                  },
                                  child: Column(
                                    children: [
                                      Container(
                                        height: 55.h,
                                        width: MediaQuery.of(context).size.width/6,
                                        decoration: BoxDecoration(
                                        ),
                                        child: Image.memory(
                                          bytes,
                                          fit: BoxFit.cover,
                                        )
                                      ),
                                    ],
                                  ) ,
                                ),

                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  );

                  //   Padding(
                  //   padding: const EdgeInsets.only(left: 10.0,right: 10,top: 10),
                  //   child: Card(
                  //     elevation: 1,
                  //     shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  //     shadowColor: Colors.blue,
                  //     child: Container(
                  //     height: 75.h,
                  //     width: MediaQuery.of(context).size.width,
                  //     decoration: BoxDecoration(
                  //     border: Border.all(color: Colors.blue),
                  //     borderRadius: BorderRadius.circular(10)
                  //     ),
                  //       child: Padding(
                  //         padding: const EdgeInsets.all(8),
                  //         child: Column(
                  //           children: [
                  //             Row(
                  //               crossAxisAlignment: CrossAxisAlignment.start,
                  //               mainAxisAlignment: MainAxisAlignment.start,
                  //               children: [
                  //                Row(
                  //                  mainAxisAlignment: MainAxisAlignment.start,
                  //                  crossAxisAlignment: CrossAxisAlignment.start,
                  //                  children: [
                  //                    Column(
                  //                      crossAxisAlignment: CrossAxisAlignment.start,
                  //                      mainAxisAlignment: MainAxisAlignment.start,
                  //                      children: [
                  //                        Text("Fitness Pro Gym",style: bodyText1Style,),
                  //                            Text("22 march 2023",style: smallTextStyle.copyWith(fontSize: 10)),
                  //                            Row(
                  //                              children: [
                  //                                Text("06:00 am",style: smallTextStyle.copyWith(fontSize: 10),),
                  //
                  //                              ],
                  //                            ),
                  //                           // Row(
                  //                           //   children: [
                  //                           //     Text("BOOKING ID"),
                  //                           //     Text("98754336864")
                  //                           //   ],
                  //                           // )
                  //                      ],
                  //                    ),
                  //                    SizedBox(width: 70.w,),
                  //                    Text("Check-In",style: bodyText1Style.copyWith(color: Colors.green,),),
                  //                  ],
                  //                ),
                  //
                  //                 Spacer(),
                  //                 Padding(
                  //                   padding: const EdgeInsets.only(left: 8.0,right: 8),
                  //                   child: Container(
                  //                     height: 53.h,
                  //                     width:53.w,
                  //                     child: Image.asset("assets/images/qrcode.png"),
                  //                   ),
                  //                 )
                  //               ],
                  //             ),
                  //           ],
                  //         ),
                  //       ),
                  //     ),
                  //   ),
                  // );

                 }),
                SizedBox(height: 60.h,),
              ],
            ):
            Center(
              child: FadeInUp(
                delay: Duration(microseconds: 450),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      height: 200.h,
                      width: Get.width,
                      child: Image.asset("assets/images/empty.png"),
                    ),
                    Text("Your Bokking Is Empty!",style: bodyText2Style.copyWith(fontSize: 19.sp,color: Colors.white),)
                  ],

                ),
              )
            ),

          ),
        ),
      ),
    );
  }
  void fullsecuse()
  {
    Timer(Duration(seconds: 2), ()
    {
      Navigator.pop(context);
      ShowModel();

    });

    final double h = MediaQuery.of(context).size.height;
    final double w = MediaQuery.of(context).size.width;
    showModalBottomSheet(
        context: context,
        barrierColor: Colors.black.withOpacity(0.1),
        isScrollControlled: true,
        backgroundColor:TColor.themecolor,
        builder: (context) {
          return SingleChildScrollView(
            child: Padding(padding:EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                child: FadeInUp(
                  delay: Duration(milliseconds: 250),
                  child: ClipRRect(
                    child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                        child: Container(
                          height: Get.height/1.5,

                          padding: EdgeInsets.all(10),
                          // height: h * 0.45,
                          width: double.infinity,
                          //
                          child: Column(
                            children: [
                              SizedBox(height: 10.h,),
                              Container(
                                width: 40.w,
                                height: 6.h,
                                decoration: BoxDecoration(
                                    border: Border.all(width: 0.5, color: Colors.black12),
                                    color: Colors.transparent,
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                              Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:
                                  [
                                    Container(
                                        height: 400.h,
                                        width: 400.w,
                                        child: Image(image:AssetImage("assets/images/check2.gif"))),
                                  ]
                              ),
                            ],
                          ),

                        )
                    ),

                  ),
                )
            ),
          );
        }
    );
  }
  void ShowModel()
  {
    final double h = MediaQuery.of(context).size.height;
    final double w = MediaQuery.of(context).size.width;
    showModalBottomSheet(
        context: context,
        barrierColor: Colors.black.withOpacity(0.1),
        isScrollControlled: true,
        backgroundColor:TColor.themecolor,
        builder: (context) {
          Uint8List bytes= base64.decode(controller.gymbookModel.value.data!.qrimage.toString());
          return SingleChildScrollView(
            child: Padding(padding:EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                child: FadeInUp(
                  delay: Duration(milliseconds: 250),
                  child: ClipRRect(
                    child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                        child: Container(
                          height: Get.height/1.5,

                          padding: EdgeInsets.all(10),
                          // height: h * 0.45,
                          width: double.infinity,
                          //
                          child: Column(
                            children: [
                              SizedBox(height: 10.h,),
                              Container(
                                width: 40.w,
                                height: 6.h,
                                decoration: BoxDecoration(
                                    border: Border.all(width: 0.5, color: Colors.black12),
                                    color: Colors.transparent,
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                              Obx(()=>controller.gymbookModel.value.data!=null ?
                              Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children:
                                  [
                                    SizedBox(height: 10.h,),
                                    Text(controller.gymbookModel.value.data!.zymName.toString(),style: smallTextStyle.copyWith(fontSize: 20.sp)),
                                    SizedBox(height: 10.h,),
                                    Text(controller.gymbookModel.value.data!.date.toString(),style:smallTextStyle,),
                                    Text(controller.gymbookModel.value.data!.time.toString(),style:smallTextStyle,),
                                    SizedBox(height: 20.h,),
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text("BOOKING ID ",style: smallTextStyle,),
                                        Text(controller.gymbookModel.value.data!.bookingNo.toString(),
                                          style: smallTextStyle,),
                                      ],
                                    ),
                                    SizedBox(height: 10.h,),
                                    Container(
                                        height: 130.h,
                                        width: 130.h,
                                        child: Image.memory(
                                          bytes,
                                          fit: BoxFit.cover,
                                        )
                                    )

                                  ]
                              ):Container()
                              ),
                            ],
                          ),

                        )
                    ),

                  ),
                )
            ),
          );
        }
    );
  }
  void ShowDailog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(10)), //this right here
            child: Container(
              color: TColor.themecolor,
              height: 250.h,
              width: MediaQuery.of(context).size.width,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                      child: TextField(
                        style: bodyText1Style.copyWith(fontSize: 30.sp,color: TColor.white),
                        controller: controller.amountController,
                        keyboardType: TextInputType.number,

                        decoration:
                        InputDecoration(
                          prefixIcon:Container(
                            padding: EdgeInsets.only(top: 8.h),
                            height: 30.h,
                            width: 20.w,
                            child: Text("Rs.",style: bodyText1Style.copyWith(fontSize: 30.sp,color: TColor.white),),
                          ),
                          hintText: " Enter your Amount",
                          prefixStyle:bodyText1Style.copyWith(fontSize: 30.sp,color: TColor.white),
                          hintStyle: smallTextStyle.copyWith(fontSize: 18.sp,color: TColor.white),
                          enabledBorder: const UnderlineInputBorder(
                            borderSide: BorderSide(color: Color(
                                0x4DFFFFFF)),
                          ),
                          focusedBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          errorBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          focusedErrorBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    // CupertinoButton(
                    //     color: Colors.blue,
                    //     child: Text("Pay Amount",style: smallTextStyle.copyWith(fontSize:22.sp,color: Colors.white),),
                    //     onPressed: () {
                    //       var options = {
                    //           'key': "rzp_test_Ujd8385mQjXqFH",
                    //           'amount': (int.parse(amountController.text) * 100)
                    //             .toString(), //So its pay 500
                    //           'name': 'Satya jaisawal',
                    //           'description': 'testing',
                    //           'timeout': 300, // in seconds
                    //           'prefill': {
                    //           'contact': '9876543210',
                    //           'email': 'satyajaisawal@gmail.com'
                    //         }
                    //       };
                    //       _razorpay.open(options);
                    //       Get.back();
                    //     }),
                    ButtonWidget(onPress: ()
                    {
                      var options = {
                        'key': "rzp_test_Ujd8385mQjXqFH",
                        'amount': (int.parse(controller.amountController.text) * 100).toString(), //So its pay 500
                        'name': 'Satya jaisawal',
                        'description': 'testing',
                        'timeout': 300, // in seconds
                        'prefill': {
                          'contact': '9876543210',
                          'email': 'satyajaisawal@gmail.com'
                        }
                      };
                      _razorpay.open(options);
                      Get.back();
                    }, text: "Pay Amount")
                  ],
                ),
              ),
            ),
          );
        });
  }
  void bottomSheetBook()
  {
    final double h = MediaQuery.of(context).size.height;
    final double w = MediaQuery.of(context).size.width;
    showModalBottomSheet(
        context: context,
        barrierColor: Colors.black.withOpacity(0.1),
        isScrollControlled: true,
        backgroundColor:TColor.themecolor,
        builder: (context) {
          GetStorage _storage=GetStorage();
          controller.postcurrentaddressNetworkApi();
          return  SingleChildScrollView(
            child: Padding(padding:EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                child: ClipRRect(
                  child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                      child: Container(
                        height: Get.height/1.5,
                        padding: EdgeInsets.all(10),
                        // height: h * 0.45,
                        width: double.infinity,
                        //
                        child: Column(
                          children: [
                            SizedBox(height: 10,),
                            Container(
                              width: 40.w,
                              height: 6.h,
                              decoration: BoxDecoration(
                                  border: Border.all(width: 0.5, color: Colors.grey),
                                  color: Colors.transparent,
                                  borderRadius: BorderRadius.circular(10)),
                            ),
                            const SizedBox(height: 10,),
                            FadeInUp(
                              delay: Duration(milliseconds: 450),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children:
                                [
                                  Text("Gym",style: smallTextStyle.copyWith(color: TColor.grey),),
                                  Row(
                                    children: [
                                      Text(controller.homedetailsModel.value.data!.zymName.toString(),style: bodyText1Style.copyWith(fontSize:19.sp,color: TColor.white),),
                                      Spacer(),
                                      Container(
                                          height: 20.h,
                                          width: 20.w,
                                          child:
                                          Image(image: AssetImage("assets/images/coin.png"))),
                                      Text(" 2.00 C/min",style: smallTextStyle.copyWith(fontSize:18.sp,color: TColor.white)),
                                    ],
                                  ),
                                  SizedBox(height: 20.h,),
                                  Text("Date Time",style: smallText1Style.copyWith(color: TColor.grey),),
                                  SizedBox(height: 10.h,),
                                  Container(
                                    height:40.h,
                                    width: 300.w,
                                    child: Form(
                                      key: controller.formKey2,
                                      child: Row(
                                        children: [
                                          Container(
                                            height: 40.h,
                                            width: 140.w,
                                            child:  TextFormField(
                                              controller: _textDate,
                                              decoration: InputDecoration(
                                                enabledBorder: const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                errorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedErrorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                fillColor: Colors.white,
                                                hintText: "DD/MM/YYYY",
                                                errorStyle: TextStyle(fontSize: 6.sp),
                                                hintStyle: smallText1Style.copyWith(fontSize: 15.sp,color: TColor.white),
                                                border: OutlineInputBorder(),
                                              ),
                                              validator: (value) {
                                                if(value.toString().isEmpty)
                                                {
                                                  return "Please Enter Date";
                                                }
                                                return null;
                                              },
                                              readOnly: true,
                                              onTap: () async{
                                                final Datet = await
                                                showDatePicker(
                                                  context: context,
                                                  initialDate: DateTime.now(),
                                                  firstDate: DateTime.now(),
                                                  lastDate: DateTime(2050),
                                                  builder:  (context, child) {
                                                    return Theme(
                                                      data: Theme.of(context).copyWith(
                                                        colorScheme: ColorScheme.light(
                                                          primary: Colors.grey,
                                                          onPrimary: Colors.white,
                                                          onSurface: Colors.blueAccent,
                                                        ),
                                                        textButtonTheme: TextButtonThemeData(
                                                          style: TextButton.styleFrom(
                                                            primary: Colors.green,
                                                          ),
                                                        ),
                                                      ),
                                                      child: child!,
                                                    );
                                                  },
                                                );
                                                if(Datet !=null){
                                                  String formattedDate=
                                                  DateFormat('d MMMM y').format(Datet);
                                                  setState(() {
                                                    _textDate.text=formattedDate;
                                                    controller.date.value=formattedDate;
                                                  });
                                                }
                                              },
                                              style: bodyText1Style.copyWith(fontSize:17.sp,color: TColor.white ),
                                            ),
                                          ),
                                          Container(
                                            height: 40.h,
                                            width: 140.w,
                                            child: TextFormField(
                                              controller: _textTime,
                                              decoration: InputDecoration(
                                                enabledBorder: const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedErrorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                errorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                hintText: "00:00",
                                                errorStyle: TextStyle(fontSize: 6.sp,color: TColor.white),
                                                hintStyle: smallText1Style.copyWith(fontSize:15.sp,color: TColor.white),
                                                border: OutlineInputBorder(
                                                ),
                                              ),
                                              validator: (value) {
                                                if(value.toString().isEmpty)
                                                {
                                                  return "Please Enter Time";
                                                }
                                                return null;
                                              },
                                              readOnly: true,
                                              onTap: () async{
                                                final time = await
                                                showTimePicker(
                                                  context: context,
                                                  initialTime: TimeOfDay.now(),
                                                  builder:  (context, child) {
                                                    return Theme(
                                                      data: Theme.of(context).copyWith(
                                                        colorScheme: ColorScheme.light(
                                                          primary: Colors.grey,
                                                          onPrimary: Colors.white,
                                                          onSurface: Colors.blueAccent,
                                                        ),
                                                        textButtonTheme: TextButtonThemeData(
                                                          style: TextButton.styleFrom(
                                                            primary: Colors.green,
                                                          ),
                                                        ),
                                                      ),
                                                      child: child!,
                                                    );
                                                  },
                                                );
                                                setState(() {
                                                  if(time !=null){
                                                    _textTime.text=time.format(context);
                                                    controller.time.value=time.format(context);
                                                  }
                                                });
                                              },
                                              style:bodyText1Style.copyWith(fontSize:17.sp ) ,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10.h,
                                  ),
                                  InkWell( onTap: (){

                                  },
                                    child: Container(
                                      height: 50.h,
                                      width: MediaQuery.of(context).size.width,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          border: Border.all(color: Colors.deepOrange)
                                      ),
                                      child: Row(
                                        children: [
                                          SizedBox(
                                            width: 10.w,
                                          ),
                                          Container(
                                            height: 40.h,
                                            width: 40.w,
                                            child: Image.asset("assets/images/off.png",height: 30,width: 30,) ,
                                          ),
                                          SizedBox(
                                            width: 10.w,
                                          ),
                                          Text("Apply Offer",style: smallTextStyle,),
                                          Spacer(),
                                          IconButton(onPressed: (){
                                            Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomeOffer()));
                                          }, icon: Icon(Icons.arrow_forward_ios_outlined,color: TColor.white))
                                        ],
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 20.h,),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        padding: EdgeInsets.all(10),
                                        height: 50.h,
                                        width: 50.w,
                                        decoration: BoxDecoration(
                                          border: Border.all(color: Colors.blue),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Image.asset("assets/images/wallet.png"),
                                      ),
                                      SizedBox(width: 10.w,),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Text("Available coins",style: smallTextStyle.copyWith(fontSize: 15.sp),),
                                          Row(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                  height: 18.h,
                                                  width: 18.w,
                                                  child: Image(image: AssetImage("assets/images/coin.png"))),
                                              SizedBox(width: 4.w,),
                                              Obx(()=>
                                                  Text(controller.walletammount.value.toString(),
                                                    style:smallTextStyle.copyWith(fontSize: 15.sp),))
                                            ],
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(height: 20.h,),
                                  Obx(
                                        ()=> Column(
                                      children: [
                                        int.parse(controller.walletammount.value.toString())<60? Center(
                                            child: Text("need 60 more coins to book your move",
                                              style: smallTextStyle.copyWith(color: Colors.red),)):Text(""),
                                        SizedBox(height: 30.h,),
                                        int.parse(controller.walletammount.value.toString())<60? Center(
                                          child: ButtonWidget2(onPress: () {
                                            ShowDailog();
                                          },
                                            text: 'Purchase',),
                                        ):Center(
                                          child: ButtonWidget2(onPress: () async {
                                            if(controller.formKey2.currentState!.validate())
                                            {
                                              bool v= await controller.postgymookNetworkApi(context);
                                              if(v==true)
                                              {
                                                fullsecuse();
                                                Timer(Duration(seconds: 1),()
                                                {
                                                });
                                              }
                                            }

                                          },
                                            text: 'Book',),
                                        ),

                                      ],
                                    ),
                                  )

                                ],
                              ),
                            ),
                          ],
                        ),

                      )
                  ),

                )
            ),
          );
/*
          return SingleChildScrollView(
            child: Padding(padding:EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                child: ClipRRect(
                  child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                      child: Container(
                        height: Get.height/1.5,
                        padding: EdgeInsets.all(10),
                        // height: h * 0.45,
                        width: double.infinity,
                      //
                        child: Column(
                          children: [
                            SizedBox(height: 10,),
                            Container(
                              width: 40.w,
                              height: 6.h,
                              decoration: BoxDecoration(
                                  border: Border.all(width: 0.5, color: Colors.black12),
                                  color: Colors.transparent,
                                  borderRadius: BorderRadius.circular(10)),
                            ),
                            const SizedBox(height: 10,),
                            FadeInUp(
                              delay: Duration(milliseconds: 450),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children:
                                [
                                  Text("Gym",style: smallTextStyle,),
                                Row(
                                  children: [
                                   Text("Fitness Pro Gym",style: bodyText1Style.copyWith(fontSize:19.sp),),
                                   Spacer(),
                                   Container(
                                     height: 20.h,
                                       width: 20.w,
                                       child:
                                       Image(image: AssetImage("assets/images/coin.png"))),
                                   Text(" 2.00 C/min",style: smallTextStyle.copyWith(fontSize:18.sp)),
                                  ],
                                ),
                                  SizedBox(height: 20.h,),
                                  Text("Date Time",style: smallText1Style,),
                                  SizedBox(height: 10.h,),
                                  Container(
                                    height:40.h,
                                    width: 300.w,
                                    child: Form(
                                      key: controller.formKey2,
                                      child: Row(
                                        children: [
                                          Container(
                                            height: 40.h,
                                            width: 140.w,
                                            child:  TextFormField(
                                              controller: _textDate,
                                              decoration: InputDecoration(
                                                enabledBorder: const UnderlineInputBorder(
                                                  borderSide: BorderSide(color: Color(
                                                      0x4DFFFFFF)),
                                                ),
                                                focusedBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                errorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedErrorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                fillColor: Colors.white,
                                                hintText: "DD/MM/YYYY",
                                                errorStyle: TextStyle(fontSize: 6.sp),
                                                hintStyle: smallText1Style.copyWith(fontSize: 15.sp),
                                                border: OutlineInputBorder(),
                                              ),
                                              validator: (value) {
                                                if(value.toString().isEmpty)
                                                {
                                                  return "Please Enter Date";
                                                }
                                                return null;
                                              },
                                              readOnly: true,
                                              onTap: () async{
                                                final Datet = await
                                                showDatePicker(
                                                    context: context,
                                                    initialDate: DateTime.now(),
                                                    firstDate: DateTime.now(),
                                                    lastDate: DateTime(2050));
                                                if(Datet !=null){
                                                  String formattedDate=
                                                  DateFormat('d MMMM y').format(Datet);
                                                  setState(() {
                                                    _textDate.text=formattedDate;
                                                    controller.date.value=formattedDate;
                                                  });
                                                }
                                              },
                                              style: bodyText1Style.copyWith(fontSize:17.sp ),
                                            ),
                                          ),
                                          Container(
                                            height: 40.h,
                                            width: 140.w,
                                            child: TextFormField(
                                              controller: _textTime,
                                              decoration: InputDecoration(
                                                enabledBorder: const UnderlineInputBorder(
                                                  borderSide: BorderSide(color: Color(
                                                      0x4DFFFFFF)),
                                                ),
                                                focusedErrorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                errorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                hintText: "00:00",
                                                errorStyle: TextStyle(fontSize: 6.sp),
                                                hintStyle: smallText1Style.copyWith(fontSize:15.sp),
                                                border: OutlineInputBorder(
                                                ),
                                              ),
                                              validator: (value) {
                                                if(value.toString().isEmpty)
                                                {
                                                  return "Please Enter Time";
                                                }
                                                return null;
                                              },
                                              readOnly: true,
                                              onTap: () async{
                                                final time = await
                                                showTimePicker(
                                                    context: context,
                                                    initialTime: TimeOfDay.now()
                                                );
                                                setState(() {
                                                  if(time !=null){
                                                    _textTime.text=time.format(context);
                                                    controller.time.value=time.format(context);
                                                  }
                                                });
                                              },
                                              style:bodyText1Style.copyWith(fontSize:17.sp ) ,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                 SizedBox(
                                   height: 10.h,
                                 ),
                                 InkWell( onTap: (){

                                 },
                                   child: Container(
                                     height: 50.h,
                                     width: MediaQuery.of(context).size.width,
                                     decoration: BoxDecoration(
                                       borderRadius: BorderRadius.circular(10),
                                       border: Border.all(color: Colors.deepOrange)
                                     ),
                                     child: Row(
                                       children: [
                                         SizedBox(
                                           width: 10.w,
                                         ),
                                         Container(
                                           height: 40.h,
                                           width: 40.w,
                                           child: Image.network("https://i.gifer.com/ZKZu.gif",height: 30,width: 30,) ,
                                         ),
                                         SizedBox(
                                           width: 10.w,
                                         ),
                                         Text("Apply Offer",style: smallTextStyle,),
                                         Spacer(),
                                         IconButton(onPressed: (){
                                           Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomeOffer()));
                                         }, icon: Icon(Icons.arrow_forward_ios_outlined))
                                       ],
                                     ),
                                   ),
                                 ),
                                  SizedBox(height: 20.h,),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        padding: EdgeInsets.all(10),
                                        height: 50.h,
                                        width: 50.w,
                                        decoration: BoxDecoration(
                                          border: Border.all(color: Colors.blue),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Image.asset("assets/images/wallet.png"),
                                      ),
                                      SizedBox(width: 10.w,),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Text("Available coins",style: smallTextStyle.copyWith(fontSize: 15.sp),),
                                          Row(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                height: 18.h,
                                                  width: 18.w,
                                                  child: Image(image: AssetImage("assets/images/coin.png"))),
                                              SizedBox(width: 4.w,),
                                              Text(_storage.read(AppConstant.wallet_amount).toString().trim(),style:smallTextStyle.copyWith(fontSize: 15.sp),)
                                            ],
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(height: 20.h,),
                                  int.parse(_storage.read(AppConstant.wallet_amount).toString().trim())<60? Center(
                                      child: Text("need 60 more coins to book your move",
                                    style: smallTextStyle.copyWith(color: Colors.red),)):Text(""),
                                    SizedBox(height: 30.h,),
                                  int.parse(_storage.read(AppConstant.wallet_amount).toString().trim())<60? Center(
                                    child: ButtonWidget(onPress: () {
                                      controller.getpurchasePointsNetworkApi();
                                      print("hchchghfgf11");
                                    },
                                      text: 'Purchase',),
                                  ):Center(
                                   child: ButtonWidget(onPress: () async {
                                     if(controller.formKey2.currentState!.validate())
                                     {
                                       bool v= await controller.postgymookNetworkApi(context);
                                          if(v==true)
                                            {
                                              fullsecuse();
                                              Timer(Duration(seconds: 1),()
                                              {


                                              });
                                            }



                                     }

                                   },
                                     text: 'Book',),
                                 )
                                ],
                              ),
                            ),
                          ],
                        ),

                      )
                  ),

                )
            ),
          );
*/
        }
    );
  }
  void qrmodelbottom(gmail,date,time,bookingId,image) {
    final double h = MediaQuery.of(context).size.height;
    final double w = MediaQuery.of(context).size.width;
    showModalBottomSheet(
        context: context,
        barrierColor: Colors.black.withOpacity(0.1),
        isScrollControlled: true,
        backgroundColor: TColor.themecolor,
        builder: (context,) {
          Uint8List bytes= base64.decode(image.toString());
          print("djkfuygyf  $bytes");
          return
                 SingleChildScrollView(
                child: Padding(padding: EdgeInsets.only(bottom: MediaQuery
                    .of(context)
                    .viewInsets
                    .bottom),
                    child: ClipRRect(
                      child: BackdropFilter(
                          filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                          child: Container(
                            height: Get.height / 1.7,
                            padding: EdgeInsets.all(10),
                            // height: h * 0.45,
                            width: double.infinity,
                            //
                            child: Column(
                              children: [
                                SizedBox(height: 10.h,),
                                Container(
                                  width: 40.w,
                                  height: 6.h,
                                  decoration: BoxDecoration(
                                      border: Border.all(
                                          width: 0.5, color: Colors.grey),
                                      color: Colors.transparent,
                                      borderRadius: BorderRadius.circular(10)),
                                ),
                                 SizedBox(height: 35.h,),
                                FadeInUp(
                                  delay: Duration(milliseconds: 450),
                                  child: Center(
                                    child: Column(
                                      children: [
                                        Text(gmail,style: smallTextStyle.copyWith(fontSize: 18.sp),),
                                        SizedBox(height: 10.h,),
                                        Text(date.toString(),style: smallTextStyle,),
                                        Text(time.toString(),style: smallTextStyle,),
                                        SizedBox(height: 20.h,),
                                        Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Text("Booking ID  ",style: smallTextStyle.copyWith(color: Colors.grey),),
                                            Text(bookingId,style: smallTextStyle,)
                                          ],
                                        ),
                                        SizedBox(height: 30.h,),
                                        Container(
                                          height: 130.h,
                                          width: 130.h,
                                          child: Image.memory(
                                            bytes,
                                            fit: BoxFit.cover,
                                          )
                                        )

                                      ],
                                    ),
                                  ),
                                )
                              ],
                            ),

                          )
                      ),

                    )
                ),
             );
        }
    );
  }
}
