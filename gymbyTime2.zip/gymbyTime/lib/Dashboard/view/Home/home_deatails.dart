import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui';

import 'package:animate_do/animate_do.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:easy_search_bar/easy_search_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/AppConstant/APIConstant.dart';
import 'package:gym/Auth/controller/login_controller.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/Dashboard/view/Home/Home_offer.dart';
import 'package:gym/Dashboard/view/Home/Rating.dart';
import 'package:gym/Dashboard/view/Home/RatingHistory.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/Widget/ButtonWidget.dart';
import 'package:gym/Widget/UtilMethod.dart';
import 'package:gym/Widget/color.dart';
import 'package:gym/mathod/AppContest.dart';
import 'package:intl/intl.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
import '../../../Widget/ButtonWidget2.dart';
import '../../../Widget/button2.dart';
class home_deatails extends StatefulWidget
{
 final String id;
const home_deatails(this.id,{Key? key}) : super(key: key);

@override
State<home_deatails> createState() => _home_deatailsState();
}

class _home_deatailsState extends State<home_deatails> {
  late var _razorpay;
  List<String> data2=[];
  @override
  void initState() {
    // TODO: implement initState
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    super.initState();
    controller.getHomeDetailsNetworkApi(widget.id);
    String data="${controller.homedetailsModel.value.data?.nearBy.toString()}";
    print(data+"edniugf");
     data2=data.split(",");
    print(data2[0]+"dhiuugifg");
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    print("Payment Done");
    var transection_Id='${response.paymentId}';
    if(response !="PaymentSuccessResponse"){
      controller.getpurchasePointsNetworkApi(transection_Id,"2");
    }else{

    }

    controller.amountController.clear();
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    print("Payment Fail");
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
  }
  PageController _pageController = PageController();
  TextEditingController _textDate=TextEditingController();
  TextEditingController _textTime=TextEditingController();
  HomePageController controller=Get.put(HomePageController());
  LoginController _controller=Get.put(LoginController());
  double currentPage = 0;
  double distance=0.0;
  int currentIndex = 0;
  bool showAllItems = true;
  String Kilometer='';
  String meters='';
  double distencetomtr=0;
  double distencetokm=0;
  int decimalPlaces = 2;
  List displayedItems = [];
  static const _kDuration = const Duration(milliseconds: 360);
  static const _kCurve = Curves.ease;
  nextFunction() {
    _pageController.nextPage(duration: _kDuration, curve: _kCurve);
  }
  previousFunction() {
    _pageController.previousPage(duration: _kDuration, curve: _kCurve);
  }

  onChangedFunction(int index) {
    setState(() {
      currentIndex = index;
    });
  }
  String searchValue='';
  double ratingvalue=0.0;
  String? ratings="No Rating";
  @override
  Widget build(BuildContext context)
  {
    if(controller.homedetailsModel.value.data?.rating!=null)
    {

      if(controller.homedetailsModel.value.data!.rating.toString().isNotEmpty)
      {
        ratingvalue=double.parse(controller.homedetailsModel.value.data!.rating.toString());
        if(ratingvalue>4.0)
        {
          ratings="Excellent";
        } else if(ratingvalue>4.0 && ratingvalue<=5.0 ){
          ratings="VeryGood";
        }else if(ratingvalue>3 && ratingvalue<=4 ){
          ratings="Good";
        }else if(ratingvalue>2 && ratingvalue<=3 ){
          ratings="fair";
        }else if(ratingvalue>=0 && ratingvalue<=2 ){
          ratings="Poor";
        }else{
          ratings="No Rating";
        }
      }
      // ratingvalue=double.parse(value);

    }
    distance=double.parse("2000");
    distencetokm=distance/1000;
    Kilometer = distencetokm.toStringAsFixed(decimalPlaces);
    meters = distance.toStringAsFixed(decimalPlaces);
    // double distence=double.parse(controller.homedetailsModel.value.data!.distance.toString());
    // distencetomtr=distence/100;
    // print("{fenhrhfhrf $distence}");
    // distencetokm=distencetomtr/1000;
    // Kilometer = distencetokm.toStringAsFixed(decimalPlaces);
    // meters = distencetomtr.toStringAsFixed(decimalPlaces);
    return Scaffold(
      backgroundColor: TColor.themecolor,
      appBar: PreferredSize(
        preferredSize: Size.fromHeight(40.h),
        child: AppBar(
          backgroundColor:TColor.themecolor ,
          elevation: 0,
          leading: IconButton(onPressed: (){
            Navigator.pop(context);
          },icon: Image.asset("assets/images/back.png",height: 25.h,width:25.w,color: Colors.white,),),
        ),
      ),
      floatingActionButton: ButtonWidget2(onPress: () {
        if(GetStorage().read(AppConstant.userType).toString()=='2'){
          UtilsMethod.PopupBox(context, '2');
        }else{
          bottomSheetBook();
        }
       // bottomSheetBook();
        // print(GetStorage().read(AppConstant.userType).toString()+"efhiggfnjfb");

      }, text: 'Book',

      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
      body: Obx(()=>controller.homedetailsModel.value.data!=
          null
          ? RefreshIndicator(
          onRefresh: (){
            return Future.delayed(Duration.zero, () {
              controller.getHomeDetailsNetworkApi(widget.id);
            });
          },
          child:SingleChildScrollView(
          child: Stack(
          children:[
            FadeInUp(
            delay: const Duration(milliseconds: 450),
            child: Column(
              children: [
                Container(
                  height: 240.h,
                  child: Stack(
                    children: [
                      Obx(()=>controller.homedetailsModel.value.data!.imageList!.isNotEmpty
                      ?
                         Container(
                          height: 200.h,
                          width: MediaQuery.of(context).size.width,
                          decoration: BoxDecoration(
                          ),
                          child:  CarouselSlider.builder(
                            itemCount:controller.homedetailsModel.value.data!.imageList!.length,
                            options: CarouselOptions(
                              aspectRatio: 1.0,
                              enlargeCenterPage: true,
                              viewportFraction: 1,
                              autoPlay: true,
                              autoPlayAnimationDuration: Duration(milliseconds: 800),
                              autoPlayInterval: Duration(seconds: 3),
                              autoPlayCurve: Curves.fastOutSlowIn,
                            ),
                            itemBuilder: (ctx, index, realIdx) {
                              final dataa=controller.homedetailsModel.value.data!.imageList![index];
                              return ClipRRect(
                                child: Container(
                                  height: 230.h,
                                  width: MediaQuery.of(context).size.width,
                                  decoration: BoxDecoration(
                                      image: DecorationImage(
                                        image:NetworkImage(
                                          BASE_URL+"/"+dataa.image.toString(),
                                        ),fit:BoxFit.fill,
                                      )
                                  ),
                                  child: Row(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                     Padding(
                                       padding: const EdgeInsets.all(8.0),
                                       child: Container(
                                           height: 20.h,
                                           width: 100.w,
                                           decoration: BoxDecoration(
                                             borderRadius: BorderRadius.circular(20.r),
                                             color: Colors.black,
                                           ),
                                           child: Center(child: Text(dataa.imgType=="1"?
                                           "Strength":dataa.imgType=="2"?"Cardio":
                                           dataa.imgType=="3"?"Aerobic":dataa.imgType=="4"?"Yoga":dataa.imgType=="5"?"Other":"",style: smallTextStyle.copyWith
                                             (fontSize: 8.sp,color: Colors.white),))),
                                     )
                                    ],
                                  ),
                                ),
                              );
                            },
                          )
                        ):Container(
                        height: 180.h,
                        width: Get.width,
                        child:Image.asset("assets/images/emptydata.jpg",fit: BoxFit.fill,) ,
                      )
                      ),
                      Positioned(
                        top: 170.h,
                        left: 20.w,
                        child: Container(
                          padding: EdgeInsets.all(18.w),
                          height: 70.h,
                          width: 70.w,
                          decoration: BoxDecoration(
                              color:Colors.black,
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.white,width: 3),
                            image: DecorationImage(
                              image: NetworkImage(BASE_URL+"/"+controller.homedetailsModel.value.data!.profile.toString()),fit: BoxFit.fill
                            )
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                Padding(
                  padding:  EdgeInsets.all(12.0.w),
                  child: Container(
                    width: MediaQuery
                        .of(context)
                        .size
                        .width,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Container(
                              width: 180.w,
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(controller.homedetailsModel.value.data!.zymName.toString().length > 40 ? controller.homedetailsModel.value.data!.zymName.toString().substring(0, 40):controller.homedetailsModel.value.data!.zymName.toString(),
                                    style:bodyText1Style.copyWith(fontSize: 18.sp,color: Color(0xff03dac6)),maxLines: 2,),
                                  Row(
                                    children: [
                                      Text("₹ ",style: smallTextStyle.copyWith(color: Colors.white),),
                                      Text(controller.homedetailsModel.value.data!.per_min.toString().length>5?controller.homedetailsModel.value.data!.per_min.toString().substring(0,5):controller.homedetailsModel.value.data!.per_min.toString(),style: smallTextStyle.copyWith(color: Colors.white),),
                                      Text(" p/min",style: smallTextStyle.copyWith(color: Colors.white),)
                                    ],
                                  ),
                                  Text("Morning Shift ${controller.homedetailsModel.value.data!.morningShiftFrom.toString()} Am to ${controller.homedetailsModel.value.data!.morningShiftTo.toString()} Am",maxLines:1,style: smallTextStyle.copyWith(fontSize: 9.sp,color: Color(
                                      0xffffb500)),),
                                  Text("Evening Shift ${controller.homedetailsModel.value.data!.eveningShiftFrom.toString()} pm to ${controller.homedetailsModel.value.data!.eveningShiftTo.toString()} pm",style: smallTextStyle.copyWith(fontSize: 9.sp,color: Color(0xffffb500)),maxLines: 1,),

                                ],
                              ),
                            ),
                            Spacer(),
                            Container(
                                width: 140.w,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Text("Apporox ", style: smallTextStyle.copyWith(fontSize: 13.sp,color: Colors.white),),
                                        Text(double.parse(meters)<=499.00?meters==null?"00":meters+"mtr".toString():Kilometer==null?"00":Kilometer+"km".toString(),
                                        style: smallTextStyle.copyWith(fontSize: 11.sp,color: Colors.white),),
                                      ],
                                    ),
                                    Text(controller.address.value, style: smallTextStyle.copyWith(fontSize: 8.sp,),),
                                    SizedBox(height: 10.w,),
                                    Row(
                                      children:[
                                        Container(
                                          height:15.sp,
                                          width: 20.sp,
                                          decoration: BoxDecoration(
                                              color: Color(
                                                  0xff018c04)
                                          ),
                                          child:controller.homedetailsModel.value.data!.rating!=null?Center(
                                            child: Text(controller.homedetailsModel.value.data!.rating.toString(),style: smallText1Style.copyWith(fontSize:10.sp,color:Colors.white),),
                                          ):Container(child: Center(child: Text("0",style:smallText1Style.copyWith(fontSize:10.sp,color: Colors.white))),)
                                        ),
                                        SizedBox(width: 2.w,),
                                        Container(
                                          padding: EdgeInsets.only(left: 3.w,right: 3),
                                          height:15.h,
                                          decoration: BoxDecoration(
                                              color: Color(0xff437644)
                                          ),
                                          child:Center(
                                            child: Text(ratings.toString(),style: smallText1Style.copyWith(fontSize:9.sp,color: Colors.white),),
                                          ),
                                        ),
                                        SizedBox(width: 2.w,),
                                        InkWell(
                                            onTap: (){
                                              controller.gym_id.value = controller.homedetailsModel.value.data!.id.toString();
                                              Get.to(() => RatingHistory(controller.homedetailsModel.value.data!.id.toString()));
                                            },
                                            child: Text(controller.homedetailsModel.value.data!.noRating.toString()+" Rating >",
                                              style: smallTextStyle.copyWith(fontSize: 8.sp),))
                                      ],
                                    ),
                                  ],
                                ),
                            )
                          ],
                        ),
                    ],
                  ),
              ),
                ),
                Obx(()=>controller.homedetailsModel.value.data!.services!.isNotEmpty?
                   Padding(
                     padding:  EdgeInsets.only(left: 8.0.w,right: 12.w),
                     child: GridView.builder(
                            gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                             maxCrossAxisExtent: 80,
                             childAspectRatio: 4 /1,
                             crossAxisSpacing: 5,
                             mainAxisSpacing:5
                            ),
                             shrinkWrap: true,
                            itemCount:controller.homedetailsModel.value.data!.services!.length,
                            itemBuilder: (BuildContext ctx, index) {
                           final servi=controller.homedetailsModel.value.data!.services![index];
                           return Container(
                             margin: EdgeInsets.only(left: 5),
                             decoration: BoxDecoration(
                               borderRadius: BorderRadius.circular(20.r),
                               color: Colors.white,
                             ),
                             child: Center(child: Text(servi.title.toString(),
                               style: smallTextStyle.copyWith(color: Colors.black,fontSize: 9),)),
                           );
                         }),
                   ):Container()
                ),
              Padding(
                padding:  EdgeInsets.only(left: 12.0.w,right: 12.w),
                child: Row(
                  children: [
                    Text("Amenities",
                      style: bodyboldStyle.copyWith(fontSize: 18.sp,color: Colors.white),),
                    Spacer(),
                    TextButton(
                        onPressed:(){
                          setState(() {
                            showAllItems =!showAllItems;
                          });
                        },
                        child: Text(showAllItems ?'View All >': 'View Less',style: smallTextStyle.copyWith(fontSize: 9.sp,color: Colors.white),))
                  ],
                ),
              ),
                   Obx(()=>controller.homedetailsModel.value.data!.amanities!.isNotEmpty
                       ?
                       Padding(
                       padding: const EdgeInsets.all(5.0),
                       child: GridView.count(
                        physics: ScrollPhysics(),
                        crossAxisCount: 3,
                        crossAxisSpacing: 2.0,
                        mainAxisSpacing: 3.0,
                        childAspectRatio: 3.4 / 4,
                        shrinkWrap: true,
                        children: List.generate(showAllItems? controller.homedetailsModel.value.data!.amanities!.length>3?3:controller.homedetailsModel.value.data!.amanities!.length:controller.homedetailsModel.value.data!.amanities!.length, (index) {
                          final data2=controller.homedetailsModel.value.data!.amanities![index];
                          var image=BASE_URL+"/"+data2.image.toString();
                          print("jjegdyugfr"+image);
                          return StreamBuilder<Object>(
                            stream: null,
                            builder: (context, snapshot) {
                              return Column(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(5.w),
                                    height: 60.h,
                                    // width: 60.w,
                                    decoration: BoxDecoration(
                                        border: Border.all(),
                                        shape: BoxShape.circle,
                                        image: DecorationImage(
                                            image: NetworkImage(BASE_URL+"/"+data2.image.toString()),fit:BoxFit.fill,
                                        )
                                    ),
                                  ),
                                  SizedBox(height: 5,),
                                  Container(
                                    //height:40.h,
                                    // width:60.w,
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Center(child: Text(data2.title.toString(),style: smallTextStyle.copyWith(fontSize: 12.sp),maxLines: 3,textAlign: TextAlign.center,)),
                                      ],
                                    ),
                                  )
                                ],

                                );
                            }
                          );
                          },),
                        ),
                      ):Container()
                   ),

                Padding(
                  padding:  EdgeInsets.only(left: 12.0.w,right: 12.w),
                  child: Row(
                    children: [
                      Text("Near By",
                        style: bodyboldStyle.copyWith(fontSize: 18.sp,color: Colors.white),),
                    ],
                  ),
                ),
                SizedBox(height: 10.h,),
                Obx(()=>controller.homedetailsModel.value.data!.nearBy!=null?
                Padding(
                  padding:  EdgeInsets.only(left: 8.0.w,right: 12.w),
                  child: Container(
                    height: 25.h,
                    width: Get.width,
                    child: ListView.builder(
                        itemCount: data2.length,
                        physics: BouncingScrollPhysics(),
                        scrollDirection:Axis.horizontal,
                        shrinkWrap: true,
                        itemBuilder: (context,index){
                      return Padding(
                        padding: EdgeInsets.only(right: 8.0),
                        child: Container(
                          padding: EdgeInsets.only(left: 10.w,right: 10.w),
                          height: 20.h,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.white),
                            borderRadius: BorderRadius.circular(20.r)
                          ),
                          child:Center(child: Text(data2[index].toString(),
                            style: smallTextStyle.copyWith(color: Colors.white,fontSize: 9),) ),
                        ),
                      );
                    }),
                  )
                  // GridView.builder(
                  //     gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                  //         maxCrossAxisExtent: 200,
                  //         childAspectRatio: 4 /.5,
                  //         crossAxisSpacing: 5,
                  //         mainAxisSpacing:5),
                  //         shrinkWrap: true,
                  //         physics: ScrollPhysics(),
                  //         itemCount:data2.length,
                  //         itemBuilder: (BuildContext ctx, index) {
                  //       return Container(
                  //         margin: EdgeInsets.only(left: 5),
                  //         height: 10.h,
                  //         decoration: BoxDecoration(
                  //           border: Border.all(color: Colors.white),
                  //           borderRadius: BorderRadius.circular(20.r),
                  //         ),
                  //         child: Center(child: Text(data2[index].toString(),
                  //           style: smallTextStyle.copyWith(color: Colors.white,fontSize: 9),)),
                  //       );
                  //     }),
                ):Container()
                ),
                // Padding(
                //   padding:  EdgeInsets.only(left: 12.0.w,right: 12.w),
                //   child: Row(
                //     children: [
                //       controller.homedetailsModel.value.data!.nearBy!.isNotEmpty?Container(
                //         padding: EdgeInsets.all(3.w),
                //         height: 20.h,
                //         width: MediaQuery.of(context).size.width/2.3,
                //         decoration: BoxDecoration(
                //             border: Border.all(color: Colors.white),
                //             borderRadius: BorderRadius.circular(20.r)
                //         ),
                //         child: Center(child: Text(data2[0],style:smallTextStyle.copyWith(fontSize:10.sp,color: Colors.white),)),
                //       ):Container(),
                //       SizedBox(width: 5,),
                //       controller.homedetailsModel.value.data!.nearBy!.isNotEmpty?Container(
                //         padding: EdgeInsets.all(2),
                //         height: 20.h,
                //         width: MediaQuery.of(context).size.width/2.3,
                //         decoration: BoxDecoration(
                //             border: Border.all(color: Colors.white),
                //             borderRadius: BorderRadius.circular(20.r)
                //         ),
                //         child: Center(
                //           child: Text(data2[1],
                //             style: smallTextStyle.copyWith(color: Colors.white,fontSize:11.sp),maxLines: 1,),
                //         ),
                //       ):Container(),
                //     ],
                //   ),
                // ),
                // SizedBox(height: 10.h,),
                // Padding(
                //   padding:  EdgeInsets.only(left: 12.0.w,right: 12.w),
                //   child: Row(
                //     mainAxisAlignment: MainAxisAlignment.start,
                //     crossAxisAlignment: CrossAxisAlignment.start,
                //     children: [
                //       controller.homedetailsModel.value.data!.nearBy!=null?Container(
                //         height: 20.h,
                //         width: MediaQuery.of(context).size.width/2.3,
                //         decoration: BoxDecoration(
                //             border: Border.all(color: Colors.white),
                //             borderRadius: BorderRadius.circular(20.r)
                //         ),
                //         child: Center(
                //           child: Text(data2[2],
                //             style: smallTextStyle.copyWith(color: Colors.white,fontSize:11.sp),maxLines: 1,),
                //         ),
                //       ):Container(),
                //     ],
                //   ),
                // ),
                SizedBox(height: 70.h,),],
            ),
          ),]
        ),
      )):Container()
      ),
    );
  }

  void toggleShowAllItems() {
    setState(() {
      if (showAllItems) {
        displayedItems = controller.homedetailsModel.value.data!.amanities!;
      } else {
        displayedItems = List.from(controller.homedetailsModel.value.data!.amanities!);
      }
      showAllItems = !showAllItems;
    });
  }
  void bottomSheetBook()
  {
    final double h = MediaQuery.of(context).size.height;
    final double w = MediaQuery.of(context).size.width;
    showModalBottomSheet(
        context: context,
        barrierColor: Colors.black.withOpacity(0.1),
        isScrollControlled: true,
        backgroundColor: Colors.black,
        // backgroundColor:Color(0xFF2a2b2b),
        builder: (context) {
          GetStorage _storage=GetStorage();
          controller.postcurrentaddressNetworkApi();
          return  SingleChildScrollView(
            child: Padding(padding:EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20.r),
                  child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                      child: Container(
                        decoration: BoxDecoration(
                          // border: Border.all(color: Color(0xff2a2a2a)),
                          // borderRadius: BorderRadius.circular(20.r)
                        ),
                        height: Get.height/1.5,
                        padding: EdgeInsets.all(10),
                        // height: h * 0.45,
                        width: double.infinity,
                        //
                        child: Column(
                          children: [
                            SizedBox(height: 10,),
                            Container(
                              width: 40.w,
                              height: 6.h,
                              decoration: BoxDecoration(
                                  border: Border.all(width: 0.5, color: Colors.grey),
                                  color: Colors.transparent,
                                  borderRadius: BorderRadius.circular(10)),
                            ),
                            const SizedBox(height: 10,),
                            FadeInUp(
                              delay: Duration(milliseconds: 450),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children:
                                [
                                  Row(
                                    children: [
                                      Text("Gym",style: smallTextStyle.copyWith(color: TColor.grey),),
                                      Spacer(),
                                      /*Container(
                                          height: 20.h,
                                          width: 20.w,
                                          child:
                                          Image(image: AssetImage("assets/images/coin2.png"))),*/
                                      Text("₹",style:smallTextStyle.copyWith(fontSize: 18.sp,color: Colors.white),),
                                      Text(controller.homedetailsModel.value.data!.per_min.toString()+" p/min",style: smallTextStyle.copyWith(fontSize:18.sp,color: TColor.white)),
                                    ],
                                  ),
                                  Text(controller.homedetailsModel.value.data!.zymName.toString(),style: bodyText1Style.copyWith(fontSize:15.sp,color: TColor.white),maxLines: 3,overflow: TextOverflow.ellipsis,),

                                  SizedBox(height: 20.h,),
                                  Text("Date Time",style: smallText1Style.copyWith(color: TColor.grey),),
                                  SizedBox(height: 10.h,),
                                  Container(
                                    height:40.h,
                                    width: 300.w,
                                    child: Form(
                                      key: controller.formKey2,
                                      child: Row(
                                        children: [
                                          Container(
                                            height: 40.h,
                                            width: 140.w,
                                            child:  TextFormField(
                                              controller: _textDate,
                                              decoration: InputDecoration(
                                                enabledBorder: const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                errorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedErrorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                fillColor: Colors.white,
                                                hintText: "DD/MM/YYYY",
                                                errorStyle: TextStyle(fontSize: 6.sp),
                                                hintStyle: smallText1Style.copyWith(fontSize: 15.sp,color: TColor.white),
                                                border: OutlineInputBorder(),
                                              ),
                                              validator: (value) {
                                                if(value.toString().isEmpty)
                                                {
                                                  return "Please Enter Date";
                                                }
                                                return null;
                                              },
                                              readOnly: true,
                                              onTap: () async{
                                                final Datet = await
                                                showDatePicker(
                                                    context: context,
                                                    initialDate: DateTime.now(),
                                                    firstDate: DateTime.now(),
                                                    lastDate: DateTime(2050),
                                                  builder:  (context, child) {
                                                    return Theme(
                                                      data: Theme.of(context).copyWith(
                                                        colorScheme: ColorScheme.light(
                                                          primary: Colors.black,
                                                          onPrimary: Colors.white,
                                                          onSurface: Colors.black,
                                                        ),
                                                        textButtonTheme: TextButtonThemeData(
                                                          style: TextButton.styleFrom(
                                                            primary: Colors.black,
                                                          ),
                                                        ),
                                                      ),
                                                      child: child!,
                                                    );
                                                  },
                                                );
                                                if(Datet !=null){
                                                  String formattedDate=
                                                  DateFormat('d MMMM y').format(Datet);
                                                  setState(() {
                                                    _textDate.text=formattedDate;
                                                    controller.date.value=formattedDate;
                                                  });
                                                }
                                              },
                                              style: bodyText1Style.copyWith(fontSize:17.sp,color: TColor.white ),
                                            ),
                                          ),
                                          Container(
                                            height: 40.h,
                                            width: 140.w,
                                            child: TextFormField(
                                              controller: _textTime,
                                              decoration: InputDecoration(
                                                enabledBorder: const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedErrorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                errorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                hintText: "00:00",
                                                errorStyle: TextStyle(fontSize: 6.sp,color: TColor.white),
                                                hintStyle: smallText1Style.copyWith(fontSize:15.sp,color: TColor.white),
                                                border: OutlineInputBorder(
                                                ),
                                              ),
                                              validator: (value) {
                                                if(value.toString().isEmpty)
                                                {
                                                  return "Please Enter Time";
                                                }
                                                return null;
                                              },
                                              readOnly: true,
                                              onTap: () async{
                                                print("jkfdhgkj"+TimeOfDay.now().toString());
                                                String selecttime=TimeOfDay.now().toString();
                                               // selecttime.split()

                                                String hr='';
                                                String min='';
                                                // Timer tme = new Timer(hr,min,0);//seconds by default set to zero
                                                // Format formatter;
                                                // formatter = new SimpleDateFormat("h:mm a");
                                                // return formatter.format(tme);
                                                final time = await
                                                showTimePicker(

                                                    context: context,
                                                    initialTime: TimeOfDay.now(),
                                                  builder:  (context, child) {
                                                    return Theme(
                                                      data: Theme.of(context).copyWith(
                                                        colorScheme: ColorScheme.light(
                                                          primary: Colors.black,
                                                          onPrimary: Colors.white,
                                                          onSurface: Colors.black,
                                                        ),
                                                        textButtonTheme: TextButtonThemeData(
                                                          style: TextButton.styleFrom(
                                                            primary: Colors.black,
                                                          ),
                                                        ),
                                                      ),
                                                      child: child!,
                                                    );
                                                  },
                                                );
                                                setState(() {
                                                  if(time !=null){
                                                    _textTime.text=time.format(context);
                                                    controller.time.value=time.format(context);
                                                  }
                                                });
                                              },
                                              style:bodyText1Style.copyWith(fontSize:17.sp,color: Colors.white ) ,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                  SizedBox(
                                    height: 10.h,
                                  ),
                                  InkWell( onTap: (){

                                  },
                                    child: Container(
                                      height: 50.h,
                                      width: MediaQuery.of(context).size.width,
                                      decoration: BoxDecoration(
                                          borderRadius: BorderRadius.circular(10),
                                          border: Border.all(color: Colors.deepOrange)
                                      ),
                                      child: Row(
                                        children: [
                                          SizedBox(
                                            width: 10.w,
                                          ),
                                          Container(
                                            height: 40.h,
                                            width: 40.w,
                                            child: Image.asset("assets/images/off.png",height: 30,width: 30,) ,
                                          ),
                                          SizedBox(
                                            width: 10.w,
                                          ),
                                          Text("Apply Offer",style: smallTextStyle,),
                                          Spacer(),
                                          IconButton(onPressed: (){
                                            Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomeOffer()));
                                          }, icon: Icon(Icons.arrow_forward_ios_outlined,color: TColor.white))
                                        ],
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 20.h,),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        padding: EdgeInsets.all(10),
                                        height: 50.h,
                                        width: 50.w,
                                        decoration: BoxDecoration(
                                          border: Border.all(color: Colors.blue),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Image.asset("assets/images/wallet.png"),
                                      ),
                                      SizedBox(width: 10.w,),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Text("Available coins",style: smallTextStyle.copyWith(fontSize: 15.sp),),
                                          Row(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                             /* Container(
                                                  height: 23.h,
                                                  width: 23.w,
                                                  child: Image(image: AssetImage("assets/images/coin3.png"))),*/
                                              Text("₹",style:smallTextStyle.copyWith(fontSize: 15.sp),),
                                              SizedBox(width: 4.w,),
                                              Obx(()=>
                                                  Text(controller.walletammount.value.toString(),
                                                    style:smallTextStyle.copyWith(fontSize: 15.sp),))
                                            ],
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(height: 20.h,),
                                  Obx(
                                   ()=> Column(
                                      children: [
                                        double.parse(controller.walletammount.value.toString())<60?
                                        Center(
                                            child: Text("need 60 more coins to book your move",
                                              style: smallTextStyle.copyWith(color: Colors.red),)):Text(""),
                                        SizedBox(height: 30.h,),
                                        double.parse(controller.walletammount.value.toString())<60? Center(
                                          child: ButtonWidget2(onPress: () {
                                            ShowDailog();
                                          },
                                            text: 'Purchase',),
                                        ):Center(
                                          child: ButtonWidget2(onPress: () async {
                                            if(controller.formKey2.currentState!.validate())
                                            {
                                              bool v= await controller.postgymookNetworkApi(context);
                                              if(v==true)
                                              {
                                                fullsecuse();
                                                Timer(Duration(seconds: 1),()
                                                {
                                                });
                                              }
                                            }

                                          },
                                            text: 'Book',),
                                        ),

                                      ],
                                    ),
                                  )

                                ],
                              ),
                            ),
                          ],
                        ),

                      )
                  ),

                )
            ),
          );
/*
          return SingleChildScrollView(
            child: Padding(padding:EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                child: ClipRRect(
                  child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                      child: Container(
                        height: Get.height/1.5,
                        padding: EdgeInsets.all(10),
                        // height: h * 0.45,
                        width: double.infinity,
                      //
                        child: Column(
                          children: [
                            SizedBox(height: 10,),
                            Container(
                              width: 40.w,
                              height: 6.h,
                              decoration: BoxDecoration(
                                  border: Border.all(width: 0.5, color: Colors.black12),
                                  color: Colors.transparent,
                                  borderRadius: BorderRadius.circular(10)),
                            ),
                            const SizedBox(height: 10,),
                            FadeInUp(
                              delay: Duration(milliseconds: 450),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children:
                                [
                                  Text("Gym",style: smallTextStyle,),
                                Row(
                                  children: [
                                   Text("Fitness Pro Gym",style: bodyText1Style.copyWith(fontSize:19.sp),),
                                   Spacer(),
                                   Container(
                                     height: 20.h,
                                       width: 20.w,
                                       child:
                                       Image(image: AssetImage("assets/images/coin.png"))),
                                   Text(" 2.00 C/min",style: smallTextStyle.copyWith(fontSize:18.sp)),
                                  ],
                                ),
                                  SizedBox(height: 20.h,),
                                  Text("Date Time",style: smallText1Style,),
                                  SizedBox(height: 10.h,),
                                  Container(
                                    height:40.h,
                                    width: 300.w,
                                    child: Form(
                                      key: controller.formKey2,
                                      child: Row(
                                        children: [
                                          Container(
                                            height: 40.h,
                                            width: 140.w,
                                            child:  TextFormField(
                                              controller: _textDate,
                                              decoration: InputDecoration(
                                                enabledBorder: const UnderlineInputBorder(
                                                  borderSide: BorderSide(color: Color(
                                                      0x4DFFFFFF)),
                                                ),
                                                focusedBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                errorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedErrorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                fillColor: Colors.white,
                                                hintText: "DD/MM/YYYY",
                                                errorStyle: TextStyle(fontSize: 6.sp),
                                                hintStyle: smallText1Style.copyWith(fontSize: 15.sp),
                                                border: OutlineInputBorder(),
                                              ),
                                              validator: (value) {
                                                if(value.toString().isEmpty)
                                                {
                                                  return "Please Enter Date";
                                                }
                                                return null;
                                              },
                                              readOnly: true,
                                              onTap: () async{
                                                final Datet = await
                                                showDatePicker(
                                                    context: context,
                                                    initialDate: DateTime.now(),
                                                    firstDate: DateTime.now(),
                                                    lastDate: DateTime(2050));
                                                if(Datet !=null){
                                                  String formattedDate=
                                                  DateFormat('d MMMM y').format(Datet);
                                                  setState(() {
                                                    _textDate.text=formattedDate;
                                                    controller.date.value=formattedDate;
                                                  });
                                                }
                                              },
                                              style: bodyText1Style.copyWith(fontSize:17.sp ),
                                            ),
                                          ),
                                          Container(
                                            height: 40.h,
                                            width: 140.w,
                                            child: TextFormField(
                                              controller: _textTime,
                                              decoration: InputDecoration(
                                                enabledBorder: const UnderlineInputBorder(
                                                  borderSide: BorderSide(color: Color(
                                                      0x4DFFFFFF)),
                                                ),
                                                focusedErrorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                focusedBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                errorBorder:const UnderlineInputBorder(
                                                  borderSide: BorderSide.none,
                                                ),
                                                hintText: "00:00",
                                                errorStyle: TextStyle(fontSize: 6.sp),
                                                hintStyle: smallText1Style.copyWith(fontSize:15.sp),
                                                border: OutlineInputBorder(
                                                ),
                                              ),
                                              validator: (value) {
                                                if(value.toString().isEmpty)
                                                {
                                                  return "Please Enter Time";
                                                }
                                                return null;
                                              },
                                              readOnly: true,
                                              onTap: () async{
                                                final time = await
                                                showTimePicker(
                                                    context: context,
                                                    initialTime: TimeOfDay.now()
                                                );
                                                setState(() {
                                                  if(time !=null){
                                                    _textTime.text=time.format(context);
                                                    controller.time.value=time.format(context);
                                                  }
                                                });
                                              },
                                              style:bodyText1Style.copyWith(fontSize:17.sp ) ,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                 SizedBox(
                                   height: 10.h,
                                 ),
                                 InkWell( onTap: (){

                                 },
                                   child: Container(
                                     height: 50.h,
                                     width: MediaQuery.of(context).size.width,
                                     decoration: BoxDecoration(
                                       borderRadius: BorderRadius.circular(10),
                                       border: Border.all(color: Colors.deepOrange)
                                     ),
                                     child: Row(
                                       children: [
                                         SizedBox(
                                           width: 10.w,
                                         ),
                                         Container(
                                           height: 40.h,
                                           width: 40.w,
                                           child: Image.network("https://i.gifer.com/ZKZu.gif",height: 30,width: 30,) ,
                                         ),
                                         SizedBox(
                                           width: 10.w,
                                         ),
                                         Text("Apply Offer",style: smallTextStyle,),
                                         Spacer(),
                                         IconButton(onPressed: (){
                                           Navigator.of(context).push(MaterialPageRoute(builder: (context) => HomeOffer()));
                                         }, icon: Icon(Icons.arrow_forward_ios_outlined))
                                       ],
                                     ),
                                   ),
                                 ),
                                  SizedBox(height: 20.h,),
                                  Row(
                                    crossAxisAlignment: CrossAxisAlignment.center,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Container(
                                        padding: EdgeInsets.all(10),
                                        height: 50.h,
                                        width: 50.w,
                                        decoration: BoxDecoration(
                                          border: Border.all(color: Colors.blue),
                                          shape: BoxShape.circle,
                                        ),
                                        child: Image.asset("assets/images/wallet.png"),
                                      ),
                                      SizedBox(width: 10.w,),
                                      Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        mainAxisAlignment: MainAxisAlignment.start,
                                        children: [
                                          Text("Available coins",style: smallTextStyle.copyWith(fontSize: 15.sp),),
                                          Row(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            mainAxisAlignment: MainAxisAlignment.start,
                                            children: [
                                              Container(
                                                height: 18.h,
                                                  width: 18.w,
                                                  child: Image(image: AssetImage("assets/images/coin.png"))),
                                              SizedBox(width: 4.w,),
                                              Text(_storage.read(AppConstant.wallet_amount).toString().trim(),style:smallTextStyle.copyWith(fontSize: 15.sp),)
                                            ],
                                          ),
                                        ],
                                      )
                                    ],
                                  ),
                                  SizedBox(height: 20.h,),
                                  int.parse(_storage.read(AppConstant.wallet_amount).toString().trim())<60? Center(
                                      child: Text("need 60 more coins to book your move",
                                    style: smallTextStyle.copyWith(color: Colors.red),)):Text(""),
                                    SizedBox(height: 30.h,),
                                  int.parse(_storage.read(AppConstant.wallet_amount).toString().trim())<60? Center(
                                    child: ButtonWidget(onPress: () {
                                      controller.getpurchasePointsNetworkApi();
                                      print("hchchghfgf11");
                                    },
                                      text: 'Purchase',),
                                  ):Center(
                                   child: ButtonWidget(onPress: () async {
                                     if(controller.formKey2.currentState!.validate())
                                     {
                                       bool v= await controller.postgymookNetworkApi(context);
                                          if(v==true)
                                            {
                                              fullsecuse();
                                              Timer(Duration(seconds: 1),()
                                              {


                                              });
                                            }



                                     }

                                   },
                                     text: 'Book',),
                                 )
                                ],
                              ),
                            ),
                          ],
                        ),

                      )
                  ),

                )
            ),
          );
*/
        }
    );
  }

  void fullsecuse()
  {
    Timer(Duration(seconds: 2), ()
    {
      Navigator.pop(context);
      ShowModel();

    });

    final double h = MediaQuery.of(context).size.height;
    final double w = MediaQuery.of(context).size.width;
    showModalBottomSheet(
        context: context,
        barrierColor: Colors.black.withOpacity(0.1),
        isScrollControlled: true,
        backgroundColor:TColor.themecolor,
        builder: (context) {
          return SingleChildScrollView(
            child: Padding(padding:EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                child: FadeInUp(
                  delay: Duration(milliseconds: 250),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20.r),
                    child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                        child: Container(
                          decoration: BoxDecoration(
                              // border: Border.all(color: Color(0xff2a2a2a)),
                              // borderRadius: BorderRadius.circular(20.r)
                          ),
                          height: Get.height/1.5,

                          padding: EdgeInsets.all(10),
                          // height: h * 0.45,
                          width: double.infinity,
                          //
                          child: Column(
                            children: [
                              SizedBox(height: 10.h,),
                              Container(
                                width: 40.w,
                                height: 6.h,
                                decoration: BoxDecoration(
                                    border: Border.all(width: 0.5, color: Colors.white),
                                    color: Colors.transparent,
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                              Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children:
                                  [
                                    Container(
                                        height: 400.h,
                                        width: 400.w,
                                        child: Image(image:AssetImage("assets/images/check2.gif"))),
                                  ]
                              ),
                            ],
                          ),

                        )
                    ),

                  ),
                )
            ),
          );
        }
    );
  }
  void ShowModel()
  {
    final double h = MediaQuery.of(context).size.height;
    final double w = MediaQuery.of(context).size.width;
    showModalBottomSheet(
        context: context,
        barrierColor: Colors.black.withOpacity(0.1),
        isScrollControlled: true,
        backgroundColor:TColor.themecolor,
        builder: (context) {
          Uint8List bytes= base64.decode(controller.gymbookModel.value.data!.qrimage.toString());
          return SingleChildScrollView(
            child: Padding(padding:EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
                child: FadeInUp(
                  delay: Duration(milliseconds: 450),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(20.r),
                    child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                        child: Container(
                          height: Get.height/1.5,
                          decoration: BoxDecoration(
                              // border: Border.all(color: Color(0xff2a2a2a)),
                              // borderRadius: BorderRadius.circular(20.r)
                          ),
                          padding: EdgeInsets.all(10),
                          // height: h * 0.45,
                          width: double.infinity,
                          //
                          child: Column(
                            children: [
                              SizedBox(height: 10.h,),
                              Container(
                                width: 40.w,
                                height: 6.h,
                                decoration: BoxDecoration(
                                    border: Border.all(width: 0.5, color: Colors.white),
                                    color: Colors.transparent,
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                              Obx(()=>controller.gymbookModel.value.data!=null ?
                              Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children:
                                  [
                                    SizedBox(height: 10.h,),
                                    Text(controller.gymbookModel.value.data!.zymName.toString(),style: smallTextStyle.copyWith(fontSize: 20.sp,color: Colors.white)),
                                    SizedBox(height: 10.h,),
                                    Text(controller.gymbookModel.value.data!.date.toString(),style:smallTextStyle.copyWith(color: Colors.white)),
                                    Text(controller.gymbookModel.value.data!.time.toString(),style:smallTextStyle.copyWith(color: Colors.white)),
                                    SizedBox(height: 20.h,),
                                    Row(
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Text("BOOKING ID ",style: smallTextStyle,),
                                        Text(controller.gymbookModel.value.data!.bookingNo.toString(),
                                          style: smallTextStyle,),
                                      ],
                                    ),
                                    SizedBox(height: 10.h,),
                                    Container(
                                        height: 130.h,
                                        width: 130.h,
                                        child: Image.memory(
                                          bytes,
                                          fit: BoxFit.cover,
                                        )
                                    )

                                  ]
                              ):Container()
                              ),
                            ],
                          ),

                        )
                    ),

                  ),
                )
            ),
          );
        }
    );
  }
  void ShowDailog() {
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(10)), //this right here
            child: Container(
              color: Color(0xFF2a2b2b),
              height: 250.h,
              width: MediaQuery.of(context).size.width,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                      child: TextField(
                        style: bodyText1Style.copyWith(fontSize: 30.sp,color: TColor.white),
                        controller: controller.amountController,
                        keyboardType: TextInputType.number,

                        decoration:
                        InputDecoration(
                          prefixIcon:Container(
                            padding: EdgeInsets.only(top: 8.h),
                            height: 30.h,
                            width: 20.w,
                            child: Text("Rs.",style: bodyText1Style.copyWith(fontSize: 30.sp,color: TColor.white),),
                          ),
                          hintText: " Enter your Amount",
                          prefixStyle:bodyText1Style.copyWith(fontSize: 30.sp,color: TColor.white),
                          hintStyle: smallTextStyle.copyWith(fontSize: 18.sp,color: TColor.white),
                          enabledBorder: const UnderlineInputBorder(
                            borderSide: BorderSide(color: Color(
                                0x4DFFFFFF)),
                          ),
                          focusedBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          errorBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          focusedErrorBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    // CupertinoButton(
                    //     color: Colors.blue,
                    //     child: Text("Pay Amount",style: smallTextStyle.copyWith(fontSize:22.sp,color: Colors.white),),
                    //     onPressed: () {
                    //       var options = {
                    //           'key': "rzp_test_Ujd8385mQjXqFH",
                    //           'amount': (int.parse(amountController.text) * 100)
                    //             .toString(), //So its pay 500
                    //           'name': 'Satya jaisawal',
                    //           'description': 'testing',
                    //           'timeout': 300, // in seconds
                    //           'prefill': {
                    //           'contact': '9876543210',
                    //           'email': 'satyajaisawal@gmail.com'
                    //         }
                    //       };
                    //       _razorpay.open(options);
                    //       Get.back();
                    //     }),
                    Button2(onPress: ()
                    {
                      var options = {
                        'key': "rzp_test_OHTqA7IIPOS1xA",
                        'amount': (int.parse(controller.amountController.text) * 100).toString(), //So its pay 500
                        'name': 'Satya jaisawal',
                        'description': 'testing',
                        'timeout': 300, // in seconds
                        'prefill': {
                          'contact': '9876543210',
                          'email': 'satyajaisawal@gmail.com'
                        }
                      };
                      _razorpay.open(options);
                      Get.back();
                    }, text: "Pay Amount")
                  ],
                ),
              ),
            ),
          );
        });
  }
  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }
}