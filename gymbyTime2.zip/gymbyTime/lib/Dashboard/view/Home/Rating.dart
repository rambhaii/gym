// import 'package:flutter/material.dart';
// import 'package:flutter_rating_bar/flutter_rating_bar.dart';
// import 'package:flutter_screenutil/flutter_screenutil.dart';
// import 'package:gym/FontStyle.dart';
// class Rating extends StatefulWidget {
//   @override
//   _RatingState createState() => _RatingState();
// }
//
// class _RatingState extends State<Rating> {
//   late final _ratingController;
//   late double _rating;
//
//   double _userRating = 3.0;
//   int _ratingBarMode = 1;
//   double _initialRating = 2.0;
//   bool _isRTLMode = false;
//   bool _isVertical = false;
//
//   IconData? _selectedIcon;
//
//   @override
//   void initState() {
//     super.initState();
//     _ratingController = TextEditingController(text: '3.0');
//     _rating = _initialRating;
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//           appBar: AppBar(
//             iconTheme: IconThemeData(color: Theme.of(context).textTheme.bodyText2!.color),
//             title: Text('Rating',style: smallTextStyle.copyWith(fontSize: 20.sp,color: Theme.of(context).textTheme.bodyText2!.color),),
//             actions: [
//               IconButton(
//                 icon: Icon(Icons.change_circle_outlined),
//                 color:Theme.of(context).textTheme.bodyText2!.color,
//                 onPressed: () async {
//                   _selectedIcon = await showDialog<IconData>(
//                     context: context,
//                     builder: (context) => IconAlert(),
//                   );
//                   _ratingBarMode = 1;
//                   setState(() {});
//                 },
//               ),
//             ],
//           ),
//           body: Directionality(
//             textDirection: _isRTLMode ? TextDirection.rtl : TextDirection.ltr,
//             child: SingleChildScrollView(
//               child: Column(
//                 crossAxisAlignment: CrossAxisAlignment.center,
//                 mainAxisSize: MainAxisSize.min,
//                 children: <Widget>[
//                   SizedBox(
//                     height: 40.0,
//                   ),
//                   _heading('Rating Bar'),
//                   _ratingBar(_ratingBarMode),
//                   SizedBox(height: 20.0),
//                   Text(
//                     'Rating: $_rating',
//                     style: bodyText2Style,
//                   ),
//                   SizedBox(height: 40.0),
//                   _heading('Rating Indicator'),
//                   RatingBarIndicator(
//                     rating: _userRating,
//                     itemBuilder: (context, index) => Icon(
//                       _selectedIcon ?? Icons.star,
//                       color: Colors.green,
//                     ),
//                     itemCount: 5,
//                     itemSize: 50.0,
//                     unratedColor: Colors.amber.withAlpha(50),
//                     direction: _isVertical ? Axis.vertical : Axis.horizontal,
//                   ),
//                   SizedBox(height: 20.0),
//                   Padding(
//                     padding: EdgeInsets.symmetric(horizontal: 16.0),
//                     child: TextFormField(
//                       controller: _ratingController,
//                       keyboardType: TextInputType.number,
//                       decoration: InputDecoration(
//                         border: OutlineInputBorder(),
//                         hintText: 'Enter rating',
//                         labelText: 'Enter rating',
//                         suffixIcon: MaterialButton(
//                           onPressed: () {
//                             _userRating =
//                                 double.parse(_ratingController.text ?? '0.0');
//                             setState(() {
//
//                             });
//                           },
//                           child: Text('Rate',style: smallTextStyle,),
//                         ),
//                       ),
//                     ),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         );
//   }
//
//
//   Widget _ratingBar(int mode) {
//     switch (mode) {
//       case 1:
//         return RatingBar.builder(
//           initialRating: _initialRating,
//           minRating: 1,
//           direction: _isVertical ? Axis.vertical : Axis.horizontal,
//           allowHalfRating: true,
//           unratedColor: Colors.greenAccent.withAlpha(50),
//           itemCount: 5,
//           itemSize: 50.0,
//           itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
//           itemBuilder: (context, _) => Icon(
//             _selectedIcon ?? Icons.star,
//             color: Colors.greenAccent,
//           ),
//           onRatingUpdate: (rating) {
//             setState(() {
//               _rating = rating;
//             });
//           },
//           updateOnDrag: true,
//         );
//       case 2:
//         return RatingBar(
//           initialRating: _initialRating,
//           direction: _isVertical ? Axis.vertical : Axis.horizontal,
//           allowHalfRating: true,
//           itemCount: 5,
//           ratingWidget: RatingWidget(
//             full: _image('assets/heart.png'),
//             half: _image('assets/heart_half.png'),
//             empty: _image('assets/heart_border.png'),
//           ),
//           itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
//           onRatingUpdate: (rating) {
//             setState(() {
//               _rating = rating;
//             });
//           },
//           updateOnDrag: true,
//         );
//       case 3:
//         return RatingBar.builder(
//           initialRating: _initialRating,
//           direction: _isVertical ? Axis.vertical : Axis.horizontal,
//           itemCount: 5,
//           itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
//           itemBuilder: (context, index) {
//             switch (index) {
//               case 0:
//                 return Icon(
//                   Icons.sentiment_very_dissatisfied,
//                   color: Colors.red,
//                 );
//               case 1:
//                 return Icon(
//                   Icons.sentiment_dissatisfied,
//                   color: Colors.redAccent,
//                 );
//               case 2:
//                 return Icon(
//                   Icons.sentiment_neutral,
//                   color: Colors.amber,
//                 );
//               case 3:
//                 return Icon(
//                   Icons.sentiment_satisfied,
//                   color: Colors.lightGreen,
//                 );
//               case 4:
//                 return Icon(
//                   Icons.sentiment_very_satisfied,
//                   color: Colors.green,
//                 );
//               default:
//                 return Container();
//             }
//           },
//           onRatingUpdate: (rating) {
//             setState(() {
//               _rating = rating;
//             });
//           },
//           updateOnDrag: true,
//         );
//       default:
//         return Container();
//     }
//   }
//
//   Widget _image(String asset) {
//     return Image.asset(
//       asset,
//       height: 30.0,
//       width: 30.0,
//       color: Colors.amber,
//     );
//   }
//
//   Widget _heading(String text) => Column(
//     children: [
//       Text(
//         text,
//         style:smallTextStyle.copyWith(fontSize: 23.sp)
//       ),
//       SizedBox(
//         height: 20.0,
//       ),
//     ],
//   );
// }
//
// class IconAlert extends StatelessWidget {
//   @override
//   Widget build(BuildContext context) {
//     return AlertDialog(
//       title: Text(
//         'Select Icon',
//         style: smallTextStyle.copyWith(fontSize: 20.sp)
//       ),
//       shape: RoundedRectangleBorder(
//         borderRadius: BorderRadius.circular(10.0),
//       ),
//       titlePadding: EdgeInsets.all(12.0),
//       contentPadding: EdgeInsets.all(0),
//       content: Wrap(
//         children: [
//           _iconButton(context, Icons.home),
//           _iconButton(context, Icons.airplanemode_active),
//           _iconButton(context, Icons.euro_symbol),
//           _iconButton(context, Icons.beach_access),
//           _iconButton(context, Icons.attach_money),
//           _iconButton(context, Icons.music_note),
//           _iconButton(context, Icons.android),
//           _iconButton(context, Icons.toys),
//           _iconButton(context, Icons.language),
//           _iconButton(context, Icons.landscape),
//           _iconButton(context, Icons.ac_unit),
//           _iconButton(context, Icons.star),
//         ],
//       ),
//     );
//   }
//
//   Widget _iconButton(BuildContext context, IconData icon) => IconButton(
//     icon: Icon(icon),
//     onPressed: () => Navigator.pop(context, icon),
//     splashColor: Colors.greenAccent,
//     color: Colors.green,
//   );
// }
import 'dart:async';
import 'dart:convert';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:get/get_core/src/get_main.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/Auth/controller/login_controller.dart';
import 'package:gym/Auth/view/HomePage.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/ScanPackage/Login.dart';
import 'package:gym/Widget/circlebutton.dart';
import 'package:gym/Widget/color.dart';
import 'package:gym/mathod/AppContest.dart';
class RateUsApp extends StatefulWidget {
  RateUsApp(String string, {Key? key}) : super(key: key);
  @override
  State<RateUsApp> createState() => _RateUsAppState();
}

class _RateUsAppState extends State<RateUsApp> {
  TextEditingController etmessage = TextEditingController();
  HomePageController controller=Get.put(HomePageController());
  LoginController _controller =Get.put(LoginController());
  late String ratingvalue;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: TColor.themecolor,
      ),
      backgroundColor: TColor.themecolor,
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(20),
          child: Column(
            children:
            [
              Image(image: AssetImage("assets/images/logo2.png")),
              SizedBox(height: 30.h,),
              Container(child: Text("Like Using This Gym, Show some Love",
                style: titleStyle.copyWith(fontSize: 14.sp,color: TColor.white,
                    fontWeight: FontWeight.w900),),),
              SizedBox(height: 30,),
              RatingBar.builder(
                initialRating: 0,
                minRating: 1,
                direction: Axis.horizontal,
                allowHalfRating: false,
                unratedColor: Colors.grey,
                itemCount: 5,
                itemPadding: EdgeInsets.symmetric(horizontal: 8.0),
                itemBuilder: (context, _) => Icon(
                  Icons.star,
                  color: Colors.amber,
                ),
                onRatingUpdate: (rating)
                {
                  ratingvalue=rating.toString();
                  print("safsffg"+rating.toString());
                },
              ),
              Column(
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Container(
                      padding: EdgeInsets.only(
                        top: 30,),
                      child: Container(
                          padding: EdgeInsets.all(5),
                          child: Container(
                            padding: EdgeInsets.zero,
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.all(
                                    Radius.circular(8)),
                            ),
                            width: double.infinity,
                            child: Column(
                              children: [
                                // TextFormField(
                                //   minLines: 5,
                                //   maxLines: null,
                                //   controller: etmessage,
                                //   keyboardType:
                                //   TextInputType.multiline,
                                //   decoration: InputDecoration(
                                //     alignLabelWithHint: true,
                                //     border: InputBorder.none,
                                //     labelText: "Write Here.....",
                                //     labelStyle: smallTextStyle.copyWith(color: Colors.white)
                                //   ),
                                //   style: smallTextStyle.copyWith(color: Colors.white),
                                // ),
                                TextFormField(
                                  maxLines: null,
                                  minLines: 5,
                                  controller: etmessage,
                                  keyboardType: TextInputType.multiline,
                                  style: smallTextStyle,
                                  decoration: InputDecoration(
                                    alignLabelWithHint: true,
                                    enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                        borderSide: BorderSide(
                                            color:Colors.blue.shade50
                                        )
                                    ),
                                    border: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                        borderSide: BorderSide(
                                            color:Colors.blue
                                        )
                                    ),
                                    errorBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                        borderSide: BorderSide(
                                            color:Colors.blue
                                        )
                                    ),
                                    focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.all(Radius.circular(10.0)),
                                        borderSide: BorderSide(
                                            width: 1,color:Colors.blue
                                        )
                                    ),

                                    labelText: "Write Here.....",
                                    labelStyle: smallTextStyle.copyWith(color: Colors.grey),
                                  ),
                                )

                              ],
                            ),
                          )
                      )
                  ),
                  SizedBox(height: 10.h,),
                  Row(
                    mainAxisAlignment:
                    MainAxisAlignment.end,
                    children: [
                      CircularButton(
                          onPress: ()
                          {
                            if(etmessage.text.isEmpty)
                            {
                              Fluttertoast.showToast(msg: "Please Enter your comments",

                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.CENTER,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: Colors.red,
                                  textColor: Colors.yellow  );
                            }
                            else if (ratingvalue.isEmpty)
                            {
                              Fluttertoast.showToast(msg: "please select rating",

                                  toastLength: Toast.LENGTH_SHORT,
                                  gravity: ToastGravity.BOTTOM,
                                  timeInSecForIosWeb: 1,
                                  backgroundColor: Colors.red,
                                  textColor: Colors.yellow  );
                            }
                            else {
                              controller.getFeedbackRatingNetworkApi(etmessage.text, ratingvalue,);
                              Timer(Duration(seconds: 2), () {
                                // 5 seconds over, navigate to Page2.
                                // Navigator.push(context, MaterialPageRoute(builder: (_) => bottomNavigation()));
                                Get.offAll(()=>bottomNavigation());
                              });
                            }
                          }
                      ),
                    ],
                  )
                ],
              )

            ],
          ),
        ),
      ),
    );
  }




}
