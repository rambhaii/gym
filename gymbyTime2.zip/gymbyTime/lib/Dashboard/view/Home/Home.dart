import 'dart:ui';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:animate_do/animate_do.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:dots_indicator/dots_indicator.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/Auth/controller/login_controller.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/Dashboard/view/Home/Home_offer.dart';
import 'package:gym/Dashboard/view/Home/RatingHistory.dart';
import 'package:gym/Dashboard/view/Home/home_deatails.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/Widget/LodingWidget.dart';
import 'package:gym/Widget/UtilMethod.dart';
import 'package:gym/Widget/color.dart';
import 'package:gym/Widget/filter.dart';
import 'package:loader_overlay/loader_overlay.dart';

import '../../../AppConstant/APIConstant.dart';
import '../../../mathod/AppContest.dart';

class home extends StatefulWidget {
  const home({Key? key}) : super(key: key);
  @override
  State<home> createState() => _homeState();
}

class _homeState extends State<home> {
  RxBool isLoading = false.obs;
  double distencetomtr=0;
  double distencetokm=0;
  int decimalPlaces = 2;
  var items = [
    'Rs.700',
    'Rs.1000',
    'Rs.1500',
    'Rs.1800',
    'Rs.2000',
    'Rs.3000',
    'Rs.4000',
    'Rs.5000',
  ];
  String dropdownvalue = 'Rs.700';
  double _currentSliderValue = 20;
  int _current = 0;
  String Kilometer='';
  String meters='';
  double distance=0.0;
  var currentSliderIndex = 0.obs;
 /* final CarouselController _controller = CarouselController();*/
  RangeValues _currentRangeValues = const RangeValues(700, 4000);
  String SearchKey = "";
  GetStorage _storage = GetStorage();
  PageController _pageController = PageController(initialPage: 0);
  HomePageController controller = Get.put(HomePageController());
  LoginController _controller=Get.put(LoginController());
  double currentPage = 0;
  int currentIndex = 0;

  onChangedFunction(int index) {
    setState(() {
      currentIndex = index;
    });
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller.getGymListNetworkApi();
    controller.getGymBestListNetworkApi();
    controller.getOfferNetworkApi();
  }
  @override
  // void startLoading() {
  //     isLoading.value = true;
  //   Future.delayed(Duration(seconds: 2), () {
  //       isLoading.value = false;
  //   });
  //
  // }
  Widget build(BuildContext context) {
    controller.CategaryId = 0;
    controller.postcurrentaddressNetworkApi();
    // controller.getGymListNetworkApi("","");

    return Scaffold(
        backgroundColor: Colors.black,
        body: SafeArea(
          child: SingleChildScrollView(
            child: Obx(
              ()=> RefreshIndicator(
                onRefresh: (){
                  return Future.delayed(Duration.zero, () {
                    controller.getGymListNetworkApi();
                    controller.getGymBestListNetworkApi();
                    controller.getOfferNetworkApi();
                  });
                },
                child: Padding(
                  padding: EdgeInsets.only(left: 10.w, right: 10),
                  child: FadeInUp(
                    delay: const Duration(milliseconds: 450),
                    child: Stack(
                      children: [
                        Column(
                          children: [
                            /* FadeInUp(
                            child: Card(
                              elevation:4,
                              shadowColor: Colors.white,
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(40)
                              ),
                              child: Padding(
                                padding: EdgeInsets.all(10.w),
                                child: Container(
                                  height: 20.h,
                                  child: TextField(
                                    onChanged: (value){
                                     SearchKey=value;
                                  },
                                    style: smallTextStyle,
                                    decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderSide: BorderSide.none,
                                            borderRadius: BorderRadius.circular(40.r)
                                              ),
                                        hintText: "find Intrest",
                                        hintStyle: smallTextStyle.copyWith(color: Colors.grey),
                                        contentPadding: EdgeInsets.only(top: 10.h,left: 30.w),
                                        suffixIcon: InkWell(onTap:()
                                        {
                                        if (SearchKey.isNotEmpty)
                                        {print("object"+SearchKey);
                                          controller.getGymListSearchNetworkApi(SearchKey);
                                        }
                                        },child: Icon(Icons.search,color: Colors.grey,size: 17.sp,))
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),*/
                            Obx(() => controller.bannerModel.value.data != null
                                ? Container(
                                    height: 170.h,
                                    width: MediaQuery.of(context).size.width,
                                    child: CarouselSlider.builder(
                                      itemCount:
                                          controller.bannerModel.value.data!.length,
                                      options: CarouselOptions(
                                        aspectRatio: 2.0,
                                        enlargeCenterPage: true,
                                        viewportFraction: 1,
                                        autoPlay: true,
                                        autoPlayAnimationDuration:
                                            Duration(milliseconds: 800),
                                        autoPlayInterval: Duration(seconds: 3),
                                        autoPlayCurve: Curves.fastOutSlowIn,
                                      ),
                                      itemBuilder: (ctx, index, realIdx) {
                                        final datas =
                                            controller.bannerModel.value.data![index];
                                        return ClipRRect(
                                          borderRadius: BorderRadius.circular(10.r),
                                          child: Container(
                                            height: 180.h,
                                            width: MediaQuery.of(context).size.width,
                                            child: CachedNetworkImage(
                                              fit: BoxFit.fill,
                                              imageUrl: BASE_URL +
                                                  "/" +
                                                  datas.image.toString(),
                                              height: 76.h,
                                              width: 76.w,
                                              placeholder: (context, url) => Center(
                                                  child:
                                                      const CircularProgressIndicator()),
                                              errorWidget: (context, url, error) =>
                                                  const Icon(Icons.error),
                                            ),
                                          ),
                                        );
                                      },
                                    ))
                                : Container()),
                            SizedBox(
                              height: 10.h,
                            ),
                          Obx(() => controller.categryModel.value.data != null
                          ?
                            Container(
                              width: MediaQuery.of(context).size.width,
                              height: 70.h,
                              child: ListView.builder(
                                  itemCount: controller.categryModel.value.data!.length,
                                  scrollDirection: Axis.horizontal,
                                  itemBuilder: (context, index) {
                                    final data2 = controller
                                        .categryModel.value.data![index];
                                    return Padding(
                                      padding: EdgeInsets.only(right: 20.w),
                                      child: InkWell(
                                        onTap: (){
                                          isLoading.value = true;
                                          Future.delayed(Duration(seconds: 2), () {
                                            isLoading.value = false;
                                          });
                                          controller.CategaryId =
                                           int.parse(data2.id.toString());
                                          controller.getGymListNetworkApi();
                                         // startLoading();
                                        },
                                        child: Container(
                                          padding: EdgeInsets.only(left: 5.w, top: 5.h),
                                          height: 60.h,
                                          width: 105.w,

                                          decoration: BoxDecoration(
                                              color: Color(0xff262626),
                                            borderRadius: BorderRadius.circular(10.r),
                                            border: Border.all(color: Color(0xff4f5252))
                                          ),
                                          child: Row(
                                            children: [
                                              Container(
                                                height: 60.h,
                                                width: 55.w,
                                                child: Column(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.start,
                                                  children: [
                                                    Text(
                                                      data2.title.toString(),
                                                      style: bodyText2Style.copyWith(
                                                          color: Color(0xffafef4c),
                                                          fontSize:12.3.sp),
                                                    ),
                                                    Text("Gym",
                                                        style: smallTextStyle.copyWith(
                                                            color: TColor.white,
                                                            fontSize: 10.sp))
                                                  ],
                                                ),
                                              ),
                                              Container(
                                                height: 60.h,
                                                width: 40.w,
                                                child: Image.network(
                                                  BASE_URL+"/"+data2.image.toString(),
                                                  fit: BoxFit.fitHeight,
                                                ),
                                              )
                                            ],
                                          ),
                                        ),
                                      ),
                                    );
                                  }),
                            ):Container()
                          ),
                            SizedBox(
                              height: 15.h,
                            ),
                            Obx(()=>
                               controller.offerModel.value.data!=null? Container(
                                  height: 60.h,
                                  width: MediaQuery.of(context).size.width,
                                  child: InkWell(
                                    onTap: () {
                                      Navigator.of(context).push(MaterialPageRoute(
                                          builder: (context) => HomeOffer()));
                                    },
                                    child: Row(
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(8.w),
                                          child: Container(
                                            height: 50.h,
                                            width: 50.w,
                                            child: Image.asset(
                                              "assets/images/off.png",
                                              height: 50.h,
                                              width: 100.w,
                                            ),
                                          ),
                                        ),
                                        Container(
                                            height: 70.h,
                                            width: 200.w,
                                            child: CarouselSlider.builder(
                                              itemCount:controller.offerModel.value.data!.length,
                                              options: CarouselOptions(
                                                aspectRatio: 2.0,
                                                enlargeCenterPage: true,
                                                viewportFraction: 1,
                                                autoPlay: true,
                                                onPageChanged: (index, reason) {
                                                    currentSliderIndex.value = index;
                                                },
                                                autoPlayAnimationDuration:
                                                    Duration(milliseconds: 800),
                                                autoPlayInterval: Duration(seconds: 3),
                                                autoPlayCurve: Curves.fastOutSlowIn,
                                              ),
                                              itemBuilder: (ctx, index, realIdx) {
                                                final datas=controller.offerModel.value.data![index];
                                                return ClipRRect(
                                                  borderRadius: BorderRadius.circular(10.r),
                                                  child: Container(
                                                    height: 180.h,
                                                    width: MediaQuery.of(context).size.width,
                                                    child: Column(
                                                      mainAxisAlignment:
                                                          MainAxisAlignment.center,
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment.start,
                                                      children: [
                                                        Text(
                                                          datas.title.toString(),
                                                          style: bodyText1Style.copyWith(
                                                              fontSize: 13.sp,
                                                              color: TColor.white),
                                                        ),
                                                        SizedBox(
                                                          height: 3.h,
                                                        ),
                                                        Text(
                                                          datas.description.toString(),
                                                          style: smallTextStyle.copyWith(
                                                              fontSize: 11.sp,
                                                              color: TColor.white),maxLines: 2,
                                                        )
                                                      ],
                                                    ),
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                        Expanded(
                                          child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.center,
                                              mainAxisAlignment: MainAxisAlignment.center,
                                              children: [
                                                Obx(() => Text(
                                                  currentSliderIndex.toString()+"/${controller.offerModel.value.data!.length}",
                                                  style:smallTextStyle.copyWith(fontSize: 12.sp,color: Colors.blue),
                                                ),),
                                                SizedBox(height: 3.0,),
                                                Obx(() => DotsIndicator(
                                                    dotsCount: controller.offerModel.value.data!.length,
                                                    position: currentSliderIndex.value,
                                                    decorator: DotsDecorator(
                                                      spacing: EdgeInsets.only(right: 3.0),
                                                      size: const Size.square(5.0),
                                                      activeSize: const Size(6.0, 5.0),
                                                      activeColor: Colors.green,
                                                      activeShape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                      ],
                                    ),
                                  ),
                              ):Container(),
                            ),
                            SizedBox(height: 15.h,),
                            Padding(
                              padding:  EdgeInsets.all(8.w),
                              child: Row(
                                children: [
                                  Text(
                                    "Best Fit For You",
                                    style: bodyboldStyle.copyWith(
                                        fontSize: 17.sp, color: Colors.white,fontWeight: FontWeight.w700),
                                  )
                                ],
                              ),
                            ),
                            /*Obx(() => controller.categryModel.value.data != null
                                ? */
                            Obx(()=>controller.gymBestListModel.value.data!=null
                                ?
                             Container(
                                      width: MediaQuery.of(context).size.width,
                                      height: 90.h,
                                      child: ListView.builder(
                                          physics:  BouncingScrollPhysics(),
                                          scrollDirection: Axis.horizontal,
                                          shrinkWrap: true,
                                          itemCount:controller.gymBestListModel.value.data!.length,
                                          itemBuilder: (ctx, index) {
                                            final dataw=controller.gymBestListModel.value.data![index];
                                            return Padding(
                                              padding: EdgeInsets.all(8.w),
                                              child: InkWell(
                                                onTap: () {
                                                  Get.to(()=> home_deatails(dataw.id.toString()));
                                                  controller.gym_id.value = dataw.id.toString();
                                                },
                                                child: Container(
                                                  height: 60.h,
                                                  width: 60.w,
                                                  child: Column(
                                                    children: [
                                                      Container(
                                                        height: 55.h,
                                                        width: 55.w,
                                                        decoration: BoxDecoration(
                                                            shape: BoxShape.circle,
                                                            border: Border.all(
                                                                color: Colors.white,
                                                                width: 2.w),
                                                            image: DecorationImage(
                                                                image: NetworkImage(BASE_URL+"/"+dataw.profile.toString()),
                                                                fit: BoxFit.fill)),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            );
                                          }),
                                    ):Container()
                            ),
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Row(
                                children: [
                                  Text("Nearby Gyms",
                                      style: bodyboldStyle.copyWith(
                                        fontSize: 18.sp,
                                        color: TColor.white,
                                      )),
                                  Spacer(),
                                  InkWell(
                                      onTap: () {
                                        filterShowModel();
                                      },
                                      child: Icon(Icons.tune, color: TColor.white)),
                                  Text("Filter",
                                      style:
                                          smallText1Style.copyWith(color: TColor.white)),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: 15.h,
                            ),
                            Obx(() => controller.gymListModel.value.data != null
                                ? ListView.builder(
                                    physics: const BouncingScrollPhysics(),
                                    scrollDirection: Axis.vertical,
                                    shrinkWrap: true,
                                    itemCount:
                                        controller.gymListModel.value.data!.length,
                                    itemBuilder: (ctx, index)
                                    {
                                      final datas = controller.gymListModel.value.data![index];
                                      double ratingvalue=0.0;
                                      String? ratings="No Rating";
                                        if(controller.gymListModel.value.data![index].rating!=null)
                                        {

                                            if(controller.gymListModel.value.data![index].rating.toString().isNotEmpty)
                                            {
                                               ratingvalue=double.parse(controller.gymListModel.value.data![index].rating.toString());
                                              if(ratingvalue>4.0)
                                              {
                                                ratings="Excellent";
                                              } else if(ratingvalue>3.0 && ratingvalue<=4.0 ){
                                                ratings="VeryGood";
                                              }else if(ratingvalue>2 && ratingvalue<=3 ){
                                                ratings="Good";
                                              }else if(ratingvalue>2 && ratingvalue<=3 ){
                                                ratings="fair";
                                              }else if(ratingvalue>=0 && ratingvalue<=2 ){
                                                ratings="Poor";
                                              }else{
                                                ratings="No Rating";
                                              }
                                            }
                                           // ratingvalue=double.parse(value);

                                        }
                                        distance=double.parse(datas.distance.toString());
                                        // distencetomtr=distence/100;
                                        distencetokm=distance/1000;
                                       Kilometer = distencetokm.toStringAsFixed(decimalPlaces);
                                       meters = distance.toStringAsFixed(decimalPlaces);
                                     // print("erfowdenherihtrh ${Kilometer}");
                                    //
                                    // if(controller.gymListModel.value.data![index].price!=null)
                                    // {
                                    //   double gympricemonth=double.parse(datas.price.toString());
                                    //   double gympriceofday=gympricemonth/30;
                                    //   print("hewuiiufe${gympriceofday}");
                                    //   double gympriceofmin=gympriceofday/60;
                                    //   print("hewuiifguygereufe${gympriceofmin}");
                                    // }
                                      return Padding(
                                        padding: EdgeInsets.only(left: 8.w, right: 8.w),
                                        child: InkWell(
                                          onTap: ()
                                          {
                                            controller.gym_id.value = datas.id.toString();
                                            Get.to(()=> home_deatails(datas.id.toString()));
                                          },
                                          child: Column(
                                            children: [
                                              Container(
                                                height: 80.h,
                                                width: MediaQuery.of(context).size.width,
                                                decoration: BoxDecoration(),
                                                child: Row(
                                                  children: [
                                                    Align(
                                                      alignment: Alignment.topCenter,
                                                      child: ClipRRect(
                                                        borderRadius:
                                                            BorderRadius.circular(10.r),
                                                        child: Container(
                                                          height: 57.h,
                                                          width: 57.w,
                                                          decoration: BoxDecoration(
                                                              borderRadius:
                                                                  BorderRadius.circular(
                                                                      10.r),
                                                              boxShadow: [
                                                                BoxShadow(
                                                                  color: Colors.blue,
                                                                  offset: const Offset(
                                                                    5.0,
                                                                    5.0,
                                                                  ),
                                                                  blurRadius: 25.0,
                                                                  spreadRadius: 2.0,
                                                                ), //BoxShadow
                                                                BoxShadow(
                                                                  color: Colors.white,
                                                                  offset: const Offset(
                                                                      10.0, 15.0),
                                                                  blurRadius: 50.0,
                                                                  spreadRadius: 13.0,
                                                                ),
                                                              ]),
                                                          child: CachedNetworkImage(
                                                            fit: BoxFit.cover,
                                                            imageUrl: BASE_URL +
                                                                "/" +
                                                                datas.profile
                                                                    .toString(),
                                                            height: 76.h,
                                                            width: 76.w,
                                                            placeholder: (context,
                                                                    url) =>
                                                                Center(
                                                                    child:
                                                                        const CircularProgressIndicator()),
                                                            errorWidget: (context, url,
                                                                    error) =>
                                                                const Icon(Icons.error),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Padding(
                                                      padding: EdgeInsets.only(
                                                          left: 15.w,
                                                          bottom: 8.h,
                                                          top: 4.h),
                                                      child: Container(
                                                        height: 80.h,
                                                        width: 160.w,
                                                        child: Column(
                                                          crossAxisAlignment:
                                                              CrossAxisAlignment.start,
                                                          mainAxisAlignment:
                                                              MainAxisAlignment.start,
                                                          children: [
                                                            Text(datas.zymName.toString().length > 40 ? datas.zymName.toString().substring(0, 40):datas.zymName.toString(),
                                                              style: bodyText1Style
                                                                  .copyWith(fontSize: 14.sp,
                                                                      color: TColor.white,),
                                                              maxLines: 1,
                                                            ),
                                                            Row(
                                                              children: [
                                                                datas.gymFor!=null? Container(
                                                                  padding: EdgeInsets.only(left: 8.w,right: 8.w,top: 2.h,bottom: 2.h),
                                                                  decoration: BoxDecoration(
                                                                      color:
                                                                          TColor.white,
                                                                      borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                                  10.r)),
                                                                  child: Center(
                                                                    child: Text(datas.categoryTitle.toString(),
                                                                      style: smallText1Style
                                                                          .copyWith(
                                                                              fontSize:
                                                                                  9.sp,
                                                                              color: Colors
                                                                                  .black /*color: Theme.of(context).textTheme.bodyText2!.color*/),
                                                                    ),
                                                                  ),
                                                                ):Container(),
                                                                SizedBox(
                                                                  width: 5.w,
                                                                ),
                                                                datas.gymFor!=null? Container(
                                                                  padding: EdgeInsets.only(left: 8.w,right: 8.w,top: 2.h,bottom: 2.h),
                                                                  decoration: BoxDecoration(
                                                                      color:
                                                                          TColor.white,
                                                                      borderRadius:
                                                                          BorderRadius
                                                                              .circular(
                                                                                  10.r)),
                                                                  child: Center(
                                                                    child: Text(
                                                                      datas.gymFor.toString(),
                                                                      style: smallText1Style
                                                                          .copyWith(
                                                                              fontSize:
                                                                                  9.sp,
                                                                              color: Colors
                                                                                  .black /*color: Theme.of(context).textTheme.bodyText2!.color*/),
                                                                    ),
                                                                  ),
                                                                ):Container()
                                                              ],
                                                            ),
                                                            SizedBox(
                                                              height: 3.h,
                                                            ),
                                                            /* Obx(()
                                                          =>controller.feedback.value.data!=null ?*/
                                                            Row(
                                                              children: [
                                                                Container(
                                                                  height: 15.h,
                                                                  width: 20.w,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                          color: Color(0xff018c04)),
                                                                  child: datas.rating!=null
                                                                      ? Center(
                                                                      child: Text(
                                                                        datas.rating
                                                                            .toString(),
                                                                        style: smallText1Style
                                                                            .copyWith(
                                                                                fontSize:
                                                                                    10.sp,color: Colors.white),
                                                                      ),
                                                                    ):Container(
                                                                      color: Color(0xff018c04),
                                                                      child: Center(child: Text("0",style: smallText1Style
                                                                          .copyWith(
                                                                          fontSize:
                                                                          10.sp,color: Colors.white),)),)
                                                                ),
                                                                SizedBox(
                                                                  width: 2.w,
                                                                ),
                                                                Container(
                                                                  padding: EdgeInsets.all(3.w),
                                                                  height: 15.h,
                                                                  decoration:
                                                                      BoxDecoration(
                                                                          color: Color(
                                                                              0xff437644)),
                                                                  child: Center(
                                                                    child: Text(ratings.toString(),
                                                                      style: smallText1Style
                                                                          .copyWith(
                                                                              fontSize:
                                                                                  9.sp,
                                                                              color: TColor
                                                                                  .white),
                                                                    ),
                                                                  ),
                                                                ),
                                                                SizedBox(
                                                                  width: 2.w,
                                                                ),
                                                                InkWell(
                                                                    onTap: () {
                                                                      controller.gym_id.value = datas.id.toString();
                                                                      Get.to(() => RatingHistory(datas.id.toString()));
                                                                    },
                                                                    child: Text(
                                                                      datas.noRating.toString() +
                                                                          " Ratting >",
                                                                      style: smallTextStyle
                                                                          .copyWith(

                                                                              fontSize:
                                                                                  8.sp,
                                                                              color: TColor
                                                                                  .white),
                                                                    ))
                                                              ],
                                                            ),

                                                            /*:Container(
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  height:15.h,
                                                                  width: 20.w,
                                                                  decoration: BoxDecoration(
                                                                      color: Color(
                                                                          0xff018c04)
                                                                  ),
                                                                  child:Center(
                                                                    child: Text("0",style: smallText1Style.copyWith(fontSize:10.sp),),
                                                                  ),
                                                                ),
                                                                SizedBox(width: 2.w,),
                                                                Container(
                                                                  height:15.h,
                                                                  width: 43.w,
                                                                  decoration: BoxDecoration(
                                                                      color: Color(0xff437644)
                                                                  ),
                                                                  child:Center(
                                                                    child: Text("NoRating",style: smallText1Style.copyWith(fontSize:7.sp),),
                                                                  ),
                                                                ),
                                                                SizedBox(width: 2.w,),
                                                                InkWell(
                                                                    onTap: (){
                                                                      Get.to(()=>RateUsApp());
                                                                    },
                                           exe                         child: Text("0 Rattings >",style: smallTextStyle.copyWith(fontSize: 8.sp),))

                                                              ],
                                                            ),
                                                          )*/
                                                            //),
                                                            /* Text(datas.description.toString(),maxLines:2,style:smallTextStyle.copyWith(color: Colors.grey.shade500,fontSize: 12.sp,height: 1.h
                                                          ),textAlign: TextAlign.justify,),*/
                                                            Row(
                                                              children: [
                                                                Text("Approx ",style: smallText1Style
                                                                    .copyWith(
                                                                    color: Colors.grey
                                                                        .shade500,
                                                                    fontSize: 12.sp),),
                                                                Text(double.parse(meters)<=499.00?meters==null?"00":meters+"mtr".toString():Kilometer==null?"00":Kilometer+"km".toString(),
                                                                    // Text(double.parse(meters)<=499.00?meters==null?"00":meters+"mtr".toString():Kilometer==null?"00":Kilometer+"km".toString(),
                                                                    style: smallText1Style
                                                                        .copyWith(
                                                                            color: Colors.grey
                                                                                .shade500,
                                                                            fontSize: 12.sp),
                                                                    textAlign: TextAlign.justify,
                                                                  )
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    Spacer(),
                                                    Column(
                                                      crossAxisAlignment:
                                                          CrossAxisAlignment.end,
                                                      children: [
                                                        // Text("luxury",style: bodyText1Style),
                                                        Row(
                                                          children: [
                                                            Container(
                                                              height: 16.h,
                                                              width: 10.w,
                                                              child: Text(
                                                                "₹ ",
                                                                style: bodyText2Style
                                                                    .copyWith(
                                                                        fontSize: 18.sp,
                                                                        color: Colors
                                                                            .blue),
                                                              ),
                                                            ),
                                                            Row(
                                                              children: [
                                                                Text(datas.per_min.toString().length>4? datas.per_min.toString().substring(0,4):datas.per_min.toString(),
                                                                    style: smallTextStyle.copyWith(color: Colors.white)),
                                                                Text(
                                                                  "p/min",
                                                                  style: bodyText2Style.copyWith(fontSize: 14.sp, color: Colors.white),
                                                                ),
                                                              ],
                                                            ),
                                                          ],
                                                        ),
                                                        SizedBox(
                                                          height: 8.h,
                                                        ),
                                                        InkWell(
                                                          onTap: () {
                                                              controller.gym_id.value = datas.id.toString();
                                                              print("controller.gym_id.value====>>>>>");
                                                              print(controller.gym_id.value);
                                                              Get.to(()=> home_deatails(datas.id.toString()));
                                                          },
                                                          child: Container(
                                                            height: 27.h,
                                                            width: 80.w,
                                                            decoration: BoxDecoration(
                                                                color:
                                                                    Color(0xff03dac6),
                                                                border: Border.all(
                                                                    color:
                                                                        Colors.white),
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(40.r)),
                                                            child: Center(
                                                                child: Text(
                                                              "BOOK",
                                                              style: TextStyle(
                                                                  color: Colors.white,
                                                                  fontSize: 13.sp,
                                                                  fontWeight:
                                                                      FontWeight.bold),
                                                            )),
                                                          ),
                                                        )
                                                      ],
                                                    )
                                                  ],
                                                ),
                                              ),
                                              Divider()
                                            ],
                                          ),
                                        ),
                                      );
                                    })
                                : Container()),
                            SizedBox(height: 30.h,)
                          ],
                        ),
                        Positioned(
                           top: 450.h,
                            left: 150.w,
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            isLoading.value? CupertinoActivityIndicator(color: Colors.white,radius: 15.w,):Container()
                          ],
                        ))
                      ],
                    )
                  ),
                ),
              ),
            ),
          ),
        ));
  }

  void filterShowModel() {
    final double h = MediaQuery.of(context).size.height;
    final double w = MediaQuery.of(context).size.width;
    showModalBottomSheet(
        context: context,
        barrierColor: Colors.black.withOpacity(0.1),
        isScrollControlled: true,
        backgroundColor: TColor.themecolor,
        builder: (context) {
          GetStorage _storage = GetStorage();
          controller.postcurrentaddressNetworkApi();
          return StatefulBuilder(builder: (context, setState) {
            return SingleChildScrollView(
              child: Padding(
                  padding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom),
                  child: ClipRRect(
                    child: BackdropFilter(
                        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                        child: Container(
                          height: Get.height / 1.5,
                          padding: EdgeInsets.all(10),
                          // height: h * 0.45,
                          width: double.infinity,
                          //
                          child: Column(
                            children: [
                              SizedBox(
                                height: 10,
                              ),
                              Container(
                                width: 40,
                                height: 6,
                                decoration: BoxDecoration(
                                    border: Border.all(
                                        width: 0.5, color: Colors.grey),
                                    color: Colors.transparent,
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                              SizedBox(
                                height: 20.h,
                              ),
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  Text(
                                    "Filter",
                                    style: smallTextStyle.copyWith(
                                        fontSize: 22.sp),
                                  )
                                ],
                              ),
                              Column(
                                children: [
                                  Text(
                                    "Price",
                                    style: smallTextStyle.copyWith(
                                        fontSize: 22.sp),
                                  ),
                                  SizedBox(
                                    height: 20.h,
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      const Text("From:"),
                                      Expanded(
                                        child: RangeSlider(
                                          values: _currentRangeValues,
                                          min: 700,
                                          max: 4000,
                                          divisions: 10,
                                          labels: RangeLabels(
                                            _currentRangeValues.start
                                                .round()
                                                .toString(),
                                            _currentRangeValues.end
                                                .round()
                                                .toString(),
                                          ),
                                          onChanged: (RangeValues values) {
                                            print(
                                                "Range value Start ${values.start}");
                                            print(
                                                "Range value End ${values.end}");
                                            setState(() {
                                              _currentRangeValues = values;
                                            });
                                          },
                                        ),
                                      ),
                                      const Text("To"),
                                    ],
                                  ),
                                ],
                              ),
                              DropdownButton(
                                // Initial Value
                                value: dropdownvalue,
                                style: smallTextStyle.copyWith(
                                    color: Colors.white),

                                // Down Arrow Icon
                                icon: const Icon(Icons.keyboard_arrow_down),

                                // Array list of items
                                items: items.map((String items) {
                                  return DropdownMenuItem(
                                    value: items,
                                    child: Text(
                                      items,
                                      style: smallTextStyle.copyWith(
                                          color: Color(0xff04d9b0)),
                                    ),
                                  );
                                }).toList(),
                                // After selecting the desired option,it will
                                // change button value to selected value
                                onChanged: (String? newValue) {
                                  setState(() {
                                    dropdownvalue = newValue!;
                                  });
                                },
                              ),
                            ],
                          ),
                        )),
                  )),
            );
          });
        });
  }
}

class Item {
  final String title;
  final String image;
  final String discription;

  Item({
    required this.title,
    required this.image,
    required this.discription,
  });
}
