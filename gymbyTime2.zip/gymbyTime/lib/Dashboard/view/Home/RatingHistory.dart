import 'package:animate_do/animate_do.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/AppConstant/APIConstant.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/Widget/color.dart';
import 'package:gym/mathod/AppContest.dart';
import 'package:readmore/readmore.dart';
class RatingHistory extends StatefulWidget {
  const RatingHistory(String string, {Key? key}) : super(key: key);

  @override
  State<RatingHistory> createState() => _RatingHistoryState();
}

class _RatingHistoryState extends State<RatingHistory> {
  HomePageController controller=Get.put(HomePageController());
  late String ratingvalue;
  String id='';
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller.getFeedbackNetworkApi(id);
    controller.getGymListNetworkApi();
  }
  Widget build(BuildContext context) {
controller.postcurrentaddressNetworkApi();
    return Scaffold(
      backgroundColor: TColor.themecolor,
      appBar: AppBar(
        backgroundColor: TColor.themecolor,
        title: Text("Ratings and reviews",style: smallTextStyle.copyWith(fontSize: 20.sp,color: Colors.white),),
      ),
      body: Obx(()=> SingleChildScrollView(
        child: Column(
           children: [
             Column(
               children:controller.feedback.value.data!=null
                   ? List.generate(controller.feedback.value.data!.length, (index) {
                    final data=controller.feedback.value.data![index];
                     return GestureDetector(
                      child: Padding(
                        padding: EdgeInsets.all(10.w),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Container(
                              height: 50.h,
                              width: Get.width,
                              child: Row(
                                children: [
                                  Container(
                                    height: 43.h,
                                    width: 43.w,
                                    decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border: Border.all(color: Colors.white)
                                    ),child: ClipRRect(
                                    borderRadius: BorderRadius.circular(100.r),
                                    child: CachedNetworkImage(
                                      fit: BoxFit.cover,
                                      imageUrl: BASE_URL+"/"+data.profile.toString(),
                                      height:45.h,
                                      width: 45.w,
                                      placeholder: (context, url) =>
                                          Center(child: const CircularProgressIndicator()),
                                      errorWidget: (context, url, error) =>
                                          Icon(Icons.person,color: Colors.black,size: 100.sp,),
                                    ),
                                  ),

                                  ),
                                  SizedBox(width: 15.w,),
                                  Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisAlignment: MainAxisAlignment.center,
                                    children: [
                                      Text(data.name.toString(),style: smallText1Style.copyWith(color: Colors.white)),
                                      // ListView.builder(
                                      //     shrinkWrap: true,
                                      //     itemCount: data.rating!.length,
                                      //     itemBuilder: (context,index){
                                      //       return Icon(Icons.add);
                                      //
                                      // })
                                      RatingBar.builder(
                                        initialRating: 5,
                                        minRating: 5,
                                        direction: Axis.horizontal,
                                        itemSize: 15,
                                        // tapOnlyMode: true,
                                        unratedColor: Colors.grey,
                                        // glowColor: Colors.cyan,
                                        allowHalfRating: false,
                                        itemCount:int.parse(data.rating.toString()),
                                        itemPadding: EdgeInsets.symmetric(horizontal: 1.0),
                                        itemBuilder: (context, _) => Icon(
                                          Icons.star,
                                          color: Colors.green,
                                        ), onRatingUpdate: (int) {
                                      },
                                      ),
                                    ],
                                  ),Spacer(),
                                  Text(data.addDate.toString().length>10?data.addDate.toString().substring(0,19):data.addDate.toString(),style: smallTextStyle.copyWith(fontSize: 10.sp),),
                                ],
                              ),
                            ),
                            ReadMoreText(
                              data.description.toString(),
                              style:
                              smallTextStyle.copyWith(),
                              textAlign: TextAlign.justify,
                              trimLines: 2,
                              colorClickableText: Colors.pink,
                              trimMode: TrimMode.Line,
                              trimCollapsedText: 'Show more',
                              trimExpandedText: '  Show less',
                              moreStyle: smallTextStyle.copyWith(color: Colors.blue),
                              lessStyle: smallTextStyle.copyWith(color: Colors.blue),
                            ),
                            Divider(color: Colors.grey,)
                          ],
                        ),
                      ),
                     );
                   }):[
                 Center(
                   child: CupertinoActivityIndicator(),
                 )
               ]
             )

           ],
          /*ListView.builder(
              itemCount:controller.feedback.value.data!.length,
              shrinkWrap: true,
              physics: BouncingScrollPhysics(),
              itemBuilder: (context,index){
                final data=controller.feedback.value.data![index];
            return Container(
              margin: EdgeInsets.only(top: 5.h),
              height: 100.h,
              width: Get.width,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                   height: 50.h,
                    width: Get.width,
                    child: Row(
                      children: [
                        Container(
                          height: 43.h,
                          width: 43.w,
                          decoration: BoxDecoration(
                           shape: BoxShape.circle,
                            border: Border.all(color: Colors.white)
                          ),child: ClipRRect(
                          borderRadius: BorderRadius.circular(100.r),
                            child: CachedNetworkImage(
                            fit: BoxFit.cover,
                            imageUrl: BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString(),
                            height:45.h,
                            width: 45.w,
                            placeholder: (context, url) =>
                                Center(child: const CircularProgressIndicator()),
                            errorWidget: (context, url, error) =>
                                Icon(Icons.person,color: Colors.black,size: 100.sp,),
                        ),
                          ),

                        ),
                        SizedBox(width: 15.w,),
                        Text(data.name.toString(),style: smallText1Style.copyWith(color: Colors.white))
                      ],
                    ),
                  ),
                  Container(
                    height: 30.h,
                    width: Get.width,
                    child: Text(data.addDate.toString(),style: smallTextStyle,),
                  ),
                  Text(data.description.toString(),style: smallTextStyle.copyWith(color:Colors.white),)
                ],
              ),
            );
          }):Center(
            child: FadeInUp(
              delay: Duration(microseconds: 450),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 200.h,
                    width: Get.width,
                    child: Image.asset("assets/images/empty.png"),
                  ),
                  Text("Rating is Empty!",style: bodyText2Style.copyWith(fontSize: 19.sp,color: Colors.white),)
                ],
              ),
            )*/
        ),
      )
      ),
    );
  }
}
