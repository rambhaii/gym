import 'dart:convert';
import 'dart:io';
import 'dart:ui';
import 'package:animate_do/animate_do.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/AppConstant/APIConstant.dart';
import 'package:gym/Auth/controller/login_controller.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/Dashboard/view/Profile/Adress.dart';
import 'package:gym/Dashboard/view/Profile/Help.dart';
import 'package:gym/Dashboard/view/Profile/PaymenRefound.dart';
import 'package:gym/Dashboard/view/Profile/Profile_Edit.dart';
import 'package:gym/Dashboard/view/Profile/Wallet.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/Widget/ButtonWidget.dart';
import 'package:gym/Widget/UtilMethod.dart';
import 'package:gym/Widget/color.dart';
import 'package:gym/mathod/AppContest.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
class image_picker extends StatefulWidget {
  const image_picker({Key? key}) : super(key: key);

  @override
  State<image_picker> createState() => _image_pickerState();
}

class _image_pickerState extends State<image_picker> {
  late var _razorpay;

  @override
  void initState() {
    // TODO: implement initState
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    super.initState();
    controller.postcurrentaddressNetworkApi();
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    print("Payment Done");
    var transection_Id='${response.paymentId}';
    if(response !="PaymentSuccessResponse"){
      controller.getpurchasePointsNetworkApi(transection_Id,"2");

    }else{

    }

    controller.amountController.clear();
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    print("Payment Fail");
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
  }
  @override
  final HomePageController controller=Get.find();
  LoginController logincontroller=Get.put(LoginController());
  File? selectedImage;
  String base64Image = "";
  String gender = "male";
  int male = 0;
  GetStorage _storage=GetStorage();
  // Future<void> choiceImage(type) async {
  //   var image;
  //   if (type == 'camara') {
  //     image = await ImagePicker()
  //         .pickImage(source: ImageSource.camera);
  //   } else {
  //     image = await ImagePicker()
  //         .pickImage(source: ImageSource.gallery);
  //   }
  //   if (image != null) {
  //     setState(() {
  //       selectedImage = File(image.path);
  //       base64Image = base64Encode(selectedImage!.readAsBytesSync());
  //     });
  //   }
  // }
  List<String> coin= ['100','200','300','400','500','600'
  ];
  List<String> tempArray = [];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: TColor.themecolor,
      body: SingleChildScrollView(
        child: FadeInUp(
          delay: const Duration(milliseconds: 450),
          child: Padding(
            padding: EdgeInsets.only(left: 22.w,right: 22.w),
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: Colors.grey),
                    shape: BoxShape.circle
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(50.r),
                    child: CachedNetworkImage(
                      fit: BoxFit.cover,
                      imageUrl: BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString(),
                      height:100.h,
                      width: 100.w,
                      placeholder: (context, url) =>
                          Center(child: const CircularProgressIndicator()),
                      errorWidget: (context, url, error) =>
                       Icon(Icons.person,color: Colors.black,size: 100.sp,),
                    ),
                  ),
                ),
                /*Container(
                  height: 104.h,
                  width: 104.w,
                    decoration: BoxDecoration(
                      border: Border.all(color: Colors.blue),
                      shape: BoxShape.circle
                    ),
                    child: CircleAvatar(
                radius: 10.w,
                backgroundColor: Colors.amber.withOpacity(0.1),
                //backgroundImage: NetworkImage(BASE_URL+"/"+controller.image.toString())),
                backgroundImage: NetworkImage(BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString())),
                ),*/
/*
              Container(
              height: 104.h,
              width: 104.w,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(),
                boxShadow: [
                  BoxShadow(
                    color:Colors.blue,
                    offset: const Offset(
                      5.0,
                      5.0,
                    ),
                    blurRadius: 25.0,
                    spreadRadius: -15.0,
                  ), //BoxShadow
                  BoxShadow(
                    color:Colors.blue,
                    offset: const Offset(10.0, 5.0),
                    blurRadius: 50.0,
                    spreadRadius: -13.0,
                  ), //BoxShadow
                ],
              ),
              child: Stack(
                children: [

                  Obx(() =>logincontroller.rxPath.value.isEmpty
                      ?
                  Container(
                    decoration:  BoxDecoration(
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.black),
                      image:  DecorationImage(
                          image: NetworkImage(BASE_URL+"/"+controller.image),fit: BoxFit.fill
                      ),
                    ),
                    child: Container(

                    ),
                  ): Container(
                    decoration:  BoxDecoration(
                     shape: BoxShape.circle,
                      border: Border.all(),
                      image:  DecorationImage(
                          image: FileImage(File(logincontroller.rxPath.value)),fit: BoxFit.fill
                      ),
                    ),
                  ),
                  ),
                  Positioned(
                      bottom: 10.h,
                      right: 0,
                      left: 67.w,
                      child: InkWell(onTap: (){
                        print(BASE_URL+"/"+controller.image+"dhiuggfy");
                        showOptionDailog(context);
                      },child: Container(
                          height: 30.h,
                          width: 40.w,
                          child: Image.asset("assets/images/cam.png",
                            color: Colors.grey.withOpacity(.8),)),),),

                ],
              ),
            ),
*/
                SizedBox(height: 8.h,),
                Text(GetStorage().read(AppConstant.userName),style: bodyText1Style.copyWith(fontSize: 18.sp, color: TColor.white,),),
                SizedBox(height: 20.h,),
                Row(
                  children: [
                    IconButton(onPressed: () {},
                        icon: Image.asset(
                          "assets/images/Group 3082.png", height: 17.h,)),
                    SizedBox(width: 20.w,),
                    TextButton(onPressed: () {
                      if(GetStorage().read(AppConstant.userType).toString()=="2"){
                        UtilsMethod.PopupBox(context, '2');
                      }else{
                        Get.to(()=>ProfileEdit());
                      }
                    },
                        child: Text(
                          "Profile", style: bodyText2Style.copyWith(fontSize: 17.sp,color: TColor.white),
                        ))
                  ],
                ),
                SizedBox(height: 8.h,),
                Row(
                  children: [
                    IconButton(onPressed: () {},
                        icon: Image.asset(
                          "assets/images/wallet-line.png", height: 15.h,)),
                    SizedBox(width: 20.w,),
                    TextButton(onPressed: () {
                      if(GetStorage().read(AppConstant.userType).toString()=="2"){
                        UtilsMethod.PopupBox(context, '2');
                      }else{
                        Get.to(()=>Wallet());
                      }
                    },
                        child: Text(
                          "Wallet", style: bodyText2Style.copyWith(fontSize: 17.sp,color: TColor.white),))
                  ],
                ),
                SizedBox(height: 8.h,),
                Row(
                  children: [
                    IconButton(onPressed: () {},
                        icon: Image.asset(
                          "assets/images/arrow-loop.png", height:15.h,)),
                    SizedBox(width: 20.w,),
                    TextButton(onPressed: () {
                      Navigator.of(context).push(
                          MaterialPageRoute(builder: (context) => PaymentMethod()));
                    },
                        child: Text("Payment & Refund",
                          style: bodyText2Style.copyWith(fontSize: 17.sp,color: TColor.white),))
                  ],
                ),
                Row(
                  children: [
                    IconButton(onPressed: () {},
                        icon: Image.asset(
                          "assets/images/help.png", height: 25.h,color: Color(0xff00c7c7,),)),
                    SizedBox(width: 20.w,),
                    TextButton(onPressed: () {
                     Get.to(()=>Help());
                    },
                        child: Text(
                          "Help", style: bodyText2Style.copyWith(fontSize: 17.sp,color: TColor.white),))
                  ],
                ),
                SizedBox(height: 8.h,),
                SizedBox(height: 30.h,),
                Row(
                  children: [
                    IconButton(onPressed: () {

                    },
                        icon: Image.asset("assets/images/logout.png", height: 20.h,)),
                    SizedBox(width: 20.w,),
                    TextButton(onPressed: (){
                      print("hsdfdhg");
                      showAlertBox();
                         },
                        child: Text(
                          "Logout", style: bodyText2Style.copyWith(fontSize: 17.sp,color: TColor.white),))
                  ],
                ),
                SizedBox(height: 50.h,)
              ],
            ),
          ),
        ),
      ),
    );
  }
  showOptionDailog(BuildContext context) {
    return showDialog(context: context, builder: (context) =>
        SimpleDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(4.0))),
          backgroundColor: Theme
              .of(context)
              .dialogBackgroundColor
              .withOpacity(0.9),
          children: [
            SimpleDialogOption(
              onPressed: () {
                logincontroller.chooseImage(false);
                Get.back();
              },
              child: Row(
                children: [
                  Icon(Icons.image,color: Colors.blue,),
                  Text("   Gallery", style:smallTextStyle)
                ],
              ),
            ),
            SimpleDialogOption(
              onPressed: () {  logincontroller.chooseImage(true);

              Get.back();
              },
              child: Row(
                children: [
                  Icon(Icons.camera_alt,color: Colors.blue,),
                  Text("   Camera", style:smallTextStyle)
                ],
              ),
            ),
            SimpleDialogOption(
              onPressed: () => Get.back(),
              child: Row(
                children: [
                  Icon(Icons.clear,color: Colors.red,),
                  Text("  Cancel", style: smallTextStyle)
                ],
              ),
            ),
          ],
        ));
  }
  int SelectCoin=0;
  void WalletBottom() {
    final double h = MediaQuery.of(context).size.height;
    final double w = MediaQuery.of(context).size.width;
    showModalBottomSheet(
        context: context,
        barrierColor: Colors.black.withOpacity(0.1),
        isScrollControlled: true,
        backgroundColor:TColor.themecolor,
        builder: (context) {
          GetStorage _storage=GetStorage();
          controller.postcurrentaddressNetworkApi();
         return StatefulBuilder(builder: (context,setState){
           return SingleChildScrollView(
             child: Padding(padding: EdgeInsets.only(bottom: MediaQuery
                 .of(context)
                 .viewInsets
                 .bottom),
                 child: ClipRRect(
                   child: BackdropFilter(
                       filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                       child: Container(
                         height: Get.height / 1.5,
                         padding: EdgeInsets.all(10),
                         // height: h * 0.45,
                         width: double.infinity,
                         //
                         child: Column(
                           children: [
                             SizedBox(height: 10,),
                             Container(
                               width: 40,
                               height: 6,
                               decoration: BoxDecoration(
                                   border: Border.all(
                                       width: 0.5, color: Colors.grey),
                                   color: Colors.transparent,
                                   borderRadius: BorderRadius.circular(10)),
                             ),
                             const SizedBox(height: 10,),
                             Row(
                               crossAxisAlignment: CrossAxisAlignment.center,
                               mainAxisAlignment: MainAxisAlignment.center,
                               children: [
                                 Text("Available coins",style: smallText1Style.copyWith(fontSize: 22.sp,color: Colors.white),),
                                 SizedBox(
                                   width: 40.w,
                                 ),
                                 Container(
                                     height:20.h,
                                     width: 20.h,
                                     child: Image(image: AssetImage("assets/images/coin.png"))),
                                 SizedBox(width: 10.w,),
                           Obx(()=> Text(controller.walletammount.value.toString(),style:smallTextStyle.copyWith(fontSize: 15.sp),))
                               ],
                             ),
                             Padding(
                               padding:  EdgeInsets.only(left: 20.w,right: 20.w,top: 28.h),
                               child: Column(
                                 crossAxisAlignment: CrossAxisAlignment.start,
                                 mainAxisAlignment: MainAxisAlignment.start,
                                 children: [
                                   Text("CHOOSE ONE OF THESE....",style: smallText1Style.copyWith(color: Colors.white),),
                                 ],
                               ),
                             ),
                             SizedBox(height: 10.h,),
                             Container(
                               // margin: co3nst EdgeInsets.only(top: 7),
                               width: MediaQuery.of(context).size.width,
                               height:35.h,
                               child: ListView.builder(
                                   physics: const BouncingScrollPhysics(),
                                   scrollDirection: Axis.horizontal,
                                   itemCount: coin.length,
                                   itemBuilder: (context, index) {
                                     return GestureDetector(
                                       onTap: () {
                                         setState(() {
                                           SelectCoin = index;
                                           controller.ArrayCoin.value=coin[index].toString();
                                           controller.amountController.text=coin[index].toString();
                                         });
                                       },
                                       child: Container(
                                         width: 70.w,
                                         height: 20.w,
                                         margin: EdgeInsets.only(left: 10),
                                         decoration: BoxDecoration(
                                           border: Border.all(
                                               color: SelectCoin == index
                                                   ? Colors.blue
                                                   : Colors.grey.shade400,
                                               width: Colors.blue == index ? 1 : 1),
                                           borderRadius: BorderRadius.circular(3),
                                         ),
                                         child: Center(
                                          child: Row(
                                           crossAxisAlignment: CrossAxisAlignment.center,
                                           mainAxisAlignment: MainAxisAlignment.center,
                                           children: [
                                             Container(
                                               height: 20.h,
                                               width: 20.w,
                                             child: Image(image: AssetImage("assets/images/coin.png"))),
                                             SizedBox(width: 5.w,),
                                             Text(coin[index].toString(),style: smallTextStyle,),
                                           ],
                                         )),
                                       ),
                                     );
                                   }),
                             ),
                             SizedBox(height: 30.h,),
                             Obx(
                               ()=> Center(
                                 child: Text( controller.ArrayCoin.value,style: bodyText1Style.copyWith(fontSize: 30.sp,color: Colors.white,
                                     decoration: TextDecoration.underline),),
                               ),
                             ),
                             Center(child: Text("1 coin is equal to 1 rupees",
                               style: smallTextStyle.copyWith(color: Colors.red),)),
                             SizedBox(height: 30.h,),
                             Center(child: ButtonWidget(onPress: () {
                               PurceshPointModel();
                             }, text: 'Purchase',))
                           ],
                         ),

                       )
                   ),
                 )
             ),
           );
         });
        }
    );
  }

  void showAlertBox()
  {

    print("object");
    Get.defaultDialog(
      titlePadding: EdgeInsets.all(30.w),
      contentPadding: EdgeInsets.all(20.w),
      backgroundColor: Color(0xFF2a2b2b),
        title: 'Are you sure !',
        titleStyle: bodyText1Style.copyWith(fontSize: 22.sp ,color: TColor.white,),
        middleText: 'if you want to logout please press Yes otherwise No',middleTextStyle: smallTextStyle.copyWith( color: TColor.white,),
        radius:5,
        textCancel: 'No',
        cancelTextColor: TColor.white,
        textConfirm: 'yes',
        onCancel: (){},
        onConfirm: ()
        {
          print("dhug7ttd");
          controller.logout();
        }
    );
  }

  void PurceshPointModel()  {
    showDialog(
        context: context,

        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(10)), //this right here
            child: Container(
              height: 250.h,
              width: MediaQuery.of(context).size.width,
              color: TColor.themecolor,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                      child: TextField(
                        style: bodyText1Style.copyWith(fontSize: 30.sp,color: Colors.white),
                        controller: controller.amountController,
                        keyboardType: TextInputType.number,

                        decoration:
                        InputDecoration(
                          prefixIcon:Container(
                            padding: EdgeInsets.only(top: 8.h),
                            height: 30.h,
                            width: 20.w,
                            child: Text("Rs.",style: bodyText1Style.copyWith(fontSize: 30.sp,color: Colors.white),),
                          ),
                          hintText: " Enter your Amount",
                          prefixStyle:bodyText1Style.copyWith(fontSize: 30.sp),
                          hintStyle: smallTextStyle.copyWith(fontSize: 18.sp),
                          enabledBorder: const UnderlineInputBorder(
                            borderSide: BorderSide(color: Color(
                                0x4DFFFFFF)),
                          ),
                          focusedBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          errorBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          focusedErrorBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    // CupertinoButton(
                    //     color: Colors.blue,
                    //     child: Text("Pay Amount",style: smallTextStyle.copyWith(fontSize:22.sp,color: Colors.white),),
                    //     onPressed: () {
                    //       var options = {
                    //           'key': "rzp_test_Ujd8385mQjXqFH",
                    //           'amount': (int.parse(amountController.text) * 100)
                    //             .toString(), //So its pay 500
                    //           'name': 'Satya jaisawal',
                    //           'description': 'testing',
                    //           'timeout': 300, // in seconds
                    //           'prefill': {
                    //           'contact': '9876543210',
                    //           'email': 'satyajaisawal@gmail.com'
                    //         }
                    //       };
                    //       _razorpay.open(options);
                    //       Get.back();
                    //     }),
                    ButtonWidget(onPress: ()
                    {
                      var options = {
                        'key': "rzp_test_OHTqA7IIPOS1xA",
                        'amount': (int.parse(controller.amountController.text) * 100).toString(), //So its pay 500
                        'name': 'Fahad',
                        'description': 'testing',
                        'timeout': 300, // in seconds
                        'prefill': {
                         'contact': '7007740253',
                          'email': 'gymbyminute@gmail.com'
                        }
                      };
                      _razorpay.open(options);
                      Get.back();
                    }, text: "Pay Amount")
                  ],
                ),
              ),
            ),
          );
        });
  }
  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }
}
