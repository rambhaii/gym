import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/AppConstant/APIConstant.dart';
import 'package:gym/Auth/controller/login_controller.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/FontStyle.dart';
import 'package:gym/Widget/ButtonWidget.dart';
import 'package:gym/Widget/button2.dart';
import 'package:gym/Widget/color.dart';
import 'package:gym/mathod/AppContest.dart';
import 'package:razorpay_flutter/razorpay_flutter.dart';
class Wallet extends StatefulWidget {
  const Wallet({Key? key}) : super(key: key);

  @override
  State<Wallet> createState() => _WalletState();
}

class _WalletState extends State<Wallet> {
  LoginController logincontroller=Get.put(LoginController());
  HomePageController controller=Get.put(HomePageController());
  late var _razorpay;

  @override
  void initState() {
    // TODO: implement initState
    _razorpay = Razorpay();
    _razorpay.on(Razorpay.EVENT_PAYMENT_SUCCESS, _handlePaymentSuccess);
    _razorpay.on(Razorpay.EVENT_PAYMENT_ERROR, _handlePaymentError);
    _razorpay.on(Razorpay.EVENT_EXTERNAL_WALLET, _handleExternalWallet);
    super.initState();
  }

  void _handlePaymentSuccess(PaymentSuccessResponse response) {
    print("Payment Done");
    var transection_Id='${response.paymentId}';
    if(response !="PaymentSuccessResponse"){
      controller.getpurchasePointsNetworkApi(transection_Id,"2");

    }else{

    }

    controller.amountController.clear();
  }

  void _handlePaymentError(PaymentFailureResponse response) {
    print("Payment Fail");
  }

  void _handleExternalWallet(ExternalWalletResponse response) {
  }
  @override

  // Future<void> choiceImage(type) async {
  //   var image;
  //   if (type == 'camara') {
  //     image = await ImagePicker()
  //         .pickImage(source: ImageSource.camera);
  //   } else {
  //     image = await ImagePicker()
  //         .pickImage(source: ImageSource.gallery);
  //   }
  //   if (image != null) {
  //     setState(() {
  //       selectedImage = File(image.path);
  //       base64Image = base64Encode(selectedImage!.readAsBytesSync());
  //     });
  //   }
  // }
  List<String> coin= ['100','200','300','400','500','600'
  ];
  List<String> tempArray = [];
 /* @override
  void initState() {
    // TODO: implement initState
    super.initState();
    controller.postcurrentaddressNetworkApi();
  }*/
  int SelectCoin=0;
  Widget build(BuildContext context) {
    controller.postcurrentaddressNetworkApi();
    return Scaffold(
      backgroundColor: TColor.themecolor,
      body:SingleChildScrollView(
        child: Container(
          width: MediaQuery.of(context).size.width,
          height: MediaQuery.of(context).size.height,
          child: Stack(
            children: [
              Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height,
                  decoration: BoxDecoration(
                  ),
              ),
              Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height /2.2,
                decoration: BoxDecoration(
                  // color: Color(0xFFDAD9D9),
                  color: Colors.teal,
                    borderRadius: BorderRadius.only(bottomRight:Radius.circular(30.r),bottomLeft: Radius.circular(30.r))
                ),
                child:Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 35.h,),
                    Row(
                      children: [
                        IconButton(onPressed: (){
                          Navigator.pop(context);
                        }, icon: Icon(Icons.arrow_back)),
                        Text("My Wallet",style: smallTextStyle.copyWith(fontSize: 20.sp,color: Colors.black),),
                        Spacer(),
                        Container(
                          height:80.h,
                          width: 80.w,
                          decoration: BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(20.r),
                            child: CachedNetworkImage(
                              fit: BoxFit.cover,
                              imageUrl: BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString(),
                              height:80.h,
                              width: 80.w,
                              placeholder: (context, url) =>
                                  Center(child: const CircularProgressIndicator()),
                              errorWidget: (context, url, error) =>
                               Icon(Icons.person,color: Colors.black,size: 30.sp,),
                            ),
                          ),
                        ),
                       SizedBox(width: 10.w,)
                      ],
                    ),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text("Hello Her/Him !",style: smallTextStyle.copyWith(fontSize: 17.sp,color: Colors.black),),
                          Padding(
                            padding:  EdgeInsets.only(left: 28.w,top: 10.h),
                            child: Text(GetStorage().read(AppConstant.userName),style: bodyboldStyle.copyWith(fontSize: 22.sp,color: Colors.black),),
                          )
                        ],
                      ),
                    ),
                    SizedBox(height: 20.h,),
                    Padding(
                      padding: const EdgeInsets.all(8.0),
                      child: Container(
                        height: 70.h,
                        width: Get.width,
                        decoration: BoxDecoration(
                          color: Color(0xFF2a2b2b).withOpacity(.5),
                          borderRadius: BorderRadius.circular(20.r)
                        ),child:Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding:  EdgeInsets.only(left: 18.w,top: 5.h),
                            child: Text("Total Balance:-",style: smallTextStyle.copyWith(color: Colors.white),),
                          ),
                          SizedBox(height: 7.h,),
                         /* Text("₹ 987654.00",style: bodyboldStyle.copyWith(fontSize: 22.sp,color: Colors.white
                          ),)*/
                          Obx(()=> Center(
                            child: Text("₹ "+controller.walletammount.value.toString(),
                              style:bodyboldStyle.copyWith(fontSize: 22.sp,color: Colors.white),),
                          ))
                        ],
                      ),
                      ),
                    )
                  ],
                )
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height/1.666,
                  decoration: BoxDecoration(
                  ),
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height/1.9,
                  padding: EdgeInsets.only(top: 40.h, bottom: 30.h),
                  decoration: BoxDecoration(
                     // borderRadius: BorderRadius.only(topLeft:Radius.circular(100.r),topRight: Radius.circular(100.r))
                  ),
                  child: Column(
                    children: [
                      Text("CHOOSE ONE OF THESE....",style: smallText1Style.copyWith(color: Colors.white),),
                      SizedBox(height: 10.h,),
                      Container(
                        // margin: co3nst EdgeInsets.only(top: 7),
                        width: MediaQuery.of(context).size.width,
                        height:35.h,
                        child: ListView.builder(
                            physics: const BouncingScrollPhysics(),
                            scrollDirection: Axis.horizontal,
                            itemCount: coin.length,
                            itemBuilder: (context, index) {
                              return GestureDetector(
                                onTap: () {
                                  setState(() {
                                    SelectCoin = index;
                                    controller.ArrayCoin.value=coin[index].toString();
                                    controller.amountController.text=coin[index].toString();
                                  });
                                },
                                child: Container(
                                  width: 70.w,
                                  height: 20.w,
                                  margin: EdgeInsets.only(left: 10),
                                  decoration: BoxDecoration(
                                    border: Border.all(
                                        color: SelectCoin == index
                                            ? Colors.blue
                                            : Colors.grey.shade400,
                                        width: Colors.blue == index ? 1 : 1),
                                    borderRadius: BorderRadius.circular(3),
                                  ),
                                  child: Center(
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        children: [
                                          Container(
                                              height: 20.h,
                                              width: 15.w,
                                              child:Text("₹",style: smallTextStyle.copyWith(fontSize: 18.sp),) ),
                                          Text(coin[index].toString(),style: smallTextStyle,),
                                        ],
                                      )),
                                ),
                              );
                            }),
                      ),
                      SizedBox(height: 40.h,),
                      Obx(
                            ()=> Center(
                          child: Text( "₹ "+controller.ArrayCoin.value,style: bodyText1Style.copyWith(fontSize: 30.sp,color: Colors.white,
                              decoration: TextDecoration.underline),),
                        ),
                      ),
                      Text("₹ 1 is equal to 1 coin",
                        style: smallTextStyle.copyWith(color: Colors.red),),
                      SizedBox(height: 50.h,),
                      Center(child: Button2(onPress: () {
                        PurceshPointModel();
                      }, text: 'Add Amount',))
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
  void PurceshPointModel()  {
    showDialog(
        context: context,

        builder: (BuildContext context) {
          return Dialog(
            shape: RoundedRectangleBorder(
                borderRadius:
                BorderRadius.circular(10)), //this right here
            child: Container(
              height: 250.h,
              width: MediaQuery.of(context).size.width,
              color: TColor.themecolor,
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 30),
                      child: TextField(
                        style: bodyText1Style.copyWith(fontSize: 30.sp,color: Colors.white),
                        controller: controller.amountController,
                        keyboardType: TextInputType.number,

                        decoration:
                        InputDecoration(
                          prefixIcon:Container(
                            padding: EdgeInsets.only(top: 8.h),
                            height: 30.h,
                            width: 20.w,
                            child: Text("Rs.",style: bodyText1Style.copyWith(fontSize: 30.sp,color: Colors.white),),
                          ),
                          hintText: " Enter your Amount",
                          prefixStyle:bodyText1Style.copyWith(fontSize: 30.sp),
                          hintStyle: smallTextStyle.copyWith(fontSize: 18.sp),
                          enabledBorder: const UnderlineInputBorder(
                            borderSide: BorderSide(color: Color(
                                0x4DFFFFFF)),
                          ),
                          focusedBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          errorBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                          focusedErrorBorder:const UnderlineInputBorder(
                            borderSide: BorderSide.none,
                          ),
                        ),
                      ),
                    ),
                    // CupertinoButton(
                    //     color: Colors.blue,
                    //     child: Text("Pay Amount",style: smallTextStyle.copyWith(fontSize:22.sp,color: Colors.white),),
                    //     onPressed: () {
                    //       var options = {
                    //           'key': "rzp_test_Ujd8385mQjXqFH",
                    //           'amount': (int.parse(amountController.text) * 100)
                    //             .toString(), //So its pay 500
                    //           'name': 'Satya jaisawal',
                    //           'description': 'testing',
                    //           'timeout': 300, // in seconds
                    //           'prefill': {
                    //           'contact': '9876543210',
                    //           'email': 'satyajaisawal@gmail.com'
                    //         }
                    //       };
                    //       _razorpay.open(options);
                    //       Get.back();
                    //     }),
                    Button2(onPress: ()
                    {
                      var options = {
                        'key': "rzp_test_Ujd8385mQjXqFH",
                        'amount': (int.parse(controller.amountController.text) * 100).toString(), //So its pay 500
                        'name': 'Satya jaisawal',
                        'description': 'testing',
                        'timeout': 300, // in seconds
                        'prefill': {
                          'contact': '9876543210',
                          'email': 'satyajaisawal@gmail.com'
                        }
                      };
                      _razorpay.open(options);
                      Get.back();
                    }, text: "Pay Amount")
                  ],
                ),
              ),
            ),
          );
        });
  }
  @override
  void dispose() {
    super.dispose();
    _razorpay.clear();
  }
}
