import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:gym/FontStyle.dart';
class Address extends StatefulWidget {
  const Address({Key? key}) : super(key: key);

  @override
  State<Address> createState() => _AddressState();
}

class _AddressState extends State<Address> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Theme.of(context).textTheme.bodyText2!.color,
        ),
        title: Text("Address History",style: bodyText2Style.copyWith(fontSize: 20.sp,color: Theme.of(context).textTheme.bodyText2!.color),),
      ),
      body: Center(
        child: Text("Hello World"),
      ),
    );
  }
}
