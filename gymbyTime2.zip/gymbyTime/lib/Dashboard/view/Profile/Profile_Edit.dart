import 'dart:io';
import 'dart:math';
import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:gym/AppConstant/APIConstant.dart';
import 'package:gym/Widget/EditTextWidget.dart';
import 'package:gym/Widget/color.dart';
import '../../../Auth/controller/login_controller.dart';
import '../../../FontStyle.dart';
import '../../../Widget/circlewidget.dart';
import '../../../mathod/AppContest.dart';
import '../../Controller/homepage_controller.dart';
class ProfileEdit extends StatefulWidget {
  const ProfileEdit({Key? key}) : super(key: key);

  @override
  State<ProfileEdit> createState() => _ProfileEditState();
}

class _ProfileEditState extends State<ProfileEdit> {
  LoginController logincontroller=Get.put(LoginController());
  GetStorage _storage = GetStorage();
  @override
  HomePageController controller=Get.find();
  String gender = "male";
  RxInt male = 0.obs;
  // HomePageController controller=Get.put(HomePageController());
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    logincontroller.setEtDataController();
    male.value=int.parse(_storage.read(AppConstant.gender).toString().trim());
  }
  @override
  Widget build(BuildContext context)
  {

    return
      //Scaffold(
      /*appBar: AppBar(
        elevation: 0,
        title: Text("Edit Profile",style: smallTextStyle.copyWith(fontSize: 18.sp,color: Theme.of(context).textTheme.bodyText1!.color),),
        leading: IconButton(onPressed: (){
          Navigator.pop(context);
        },icon: Image.asset("assets/images/back.png",height: 25.h,width:25.w,color: Colors.grey,),),
      ),
        body:*/
      Scaffold(
        backgroundColor: TColor.themecolor,
        appBar: PreferredSize(
          preferredSize: Size.fromHeight(40.h),
          child: AppBar(
            backgroundColor: TColor.themecolor,
            iconTheme: IconThemeData(
            color: TColor.white
            ),
            title: Text("Edit Profile",style: smallTextStyle.copyWith(fontSize: 18.sp,
                color: TColor.white),),
          ),
        ),
        body: SingleChildScrollView(
          child: Container(
            width: MediaQuery.of(context).size.width,
            height: MediaQuery.of(context).size.height,
            decoration: BoxDecoration(),
            child: Stack(
              children: [
              Container(
                width: MediaQuery.of(context).size.width,
                height: MediaQuery.of(context).size.height,
                decoration: BoxDecoration(
                    color: TColor.themecolor,
                ),
                child: Column(
                  children: [
                    SizedBox(height: 10.h,),
                    Container(
                      height: 100.h,
                      width: 100.w,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(),
                        boxShadow: [
                          BoxShadow(
                            color:Colors.blue,
                            offset: const Offset(
                              5.0,
                              5.0,
                            ),
                            blurRadius: 25.0,
                            spreadRadius: -15.0,
                          ), //BoxShadow
                          BoxShadow(
                            color:Colors.blue,
                            offset: const Offset(10.0, 5.0),
                            blurRadius: 50.0,
                            spreadRadius: -13.0,
                          ), //BoxShadow
                        ],
                      ),

                      child: Stack(
                        children: [

                          Obx(() =>logincontroller.rxPath.value.isEmpty
                              ?
                          Container(
                            decoration:  BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(color: Colors.black),
                              image:  DecorationImage(
                                  // image: NetworkImage(BASE_URL+"/"+controller.image),fit: BoxFit.fill
                                image: NetworkImage(BASE_URL+"/"+GetStorage().read(AppConstant.profileImg).toString()),fit: BoxFit.fill
                              ),
                            ),
                            child: Container(
                            ),
                          ): Container(
                            decoration:  BoxDecoration(
                              shape: BoxShape.circle,
                              border: Border.all(),
                              image:  DecorationImage(
                                  image: FileImage(File(logincontroller.rxPath.value)),fit: BoxFit.fill
                              ),
                            ),
                          ),
                          ),
                          Positioned(
                            bottom: 10.h,
                            right: 0,
                            left: 67.w,
                            child: InkWell(onTap: (){
                              print(BASE_URL+"/"+controller.image+"dhiuggfy");
                              showOptionDailog(context);
                            },child: Container(
                                height: 30.h,
                                width: 40.w,
                                child: Image.asset("assets/images/camera.png",
                                  )),),),

                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height/1.30,
                  decoration: BoxDecoration(
                    color: TColor.themecolor,
                  ),
                ),
              ),
              Align(
                alignment: Alignment.bottomCenter,
                child: Container(
                  width: MediaQuery.of(context).size.width,
                  height: MediaQuery.of(context).size.height/1.30,
                  padding: EdgeInsets.only(top: 40, bottom: 30),
                  decoration: BoxDecoration(
                      color: Color(0xFF2a2b2b),
                      borderRadius: BorderRadius.only(topLeft:Radius.circular(70))
                  ),
                  child: Column(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left:24.w,right: 24.w,),
                          child:
                          Column(
                            children: [
                              Form(
                                  key: logincontroller.formKey,
                                  child: Column(
                                    children: [

                                      EditTextWidget(
                                        controller:logincontroller.etName,
                                        hint: 'Name',
                                        validator: (value)
                                        {
                                          if(value.toString().isEmpty){
                                            return "Plese Enter Name";
                                          }
                                          return null;
                                        },
                                      ),
                                      SizedBox(height: 15,),
                                      EditTextWidget(controller: logincontroller.etEmail,hint: 'Email',
                                        validator: (value){
                                          if(value.toString().isEmpty)
                                          {
                                            return "Please Enter Email";
                                          }
                                          if(!GetUtils.isEmail(value))
                                          {
                                            return "Please Enter Valid Email";
                                          }
                                          return null;
                                        },
                                        type: TextInputType.emailAddress,
                                      ),

                                      SizedBox(height: 15,),
                                      EditTextWidget(controller:logincontroller.etAge,hint: 'Age',
                                        validator: (value){
                                          if(value.toString().isEmpty){
                                            return "Please Enter Age";
                                          }
                                          return null;
                                        },
                                        type: TextInputType.number,
                                        length: 3,
                                      ),
                                      SizedBox(height:8.h,),
                                      EditTextWidget(controller: logincontroller.etWiegth,hint: 'Wieght',
                                        validator: (value){
                                          if(value.toString().isEmpty){
                                            return "Please Enter Wieght";
                                          }
                                          return null;
                                        },
                                        type: TextInputType.number,
                                        length: 3,
                                      ),
                                      SizedBox(height: 8.h,),
                                      EditTextWidget(controller: logincontroller.etHeight,hint: 'Height',
                                        validator:  (value)
                                        {
                                          if(value.toString().isEmpty)
                                          {
                                            return "Please Enter Height";
                                          }
                                          return null;
                                        },
                                        type: TextInputType.number,
                                        length: 3,
                                      ),
                                    ],
                                  )),

                              SizedBox(height: 35.h,),

                              Obx(
                                    ()=> Row(
                                  children: [
                                    Radio(
                                        value: 1,
                                        groupValue: male.value,
                                        activeColor: Colors.blue,
                                        fillColor:  MaterialStateColor.resolveWith((states) => Colors.white),
                                        onChanged: (value) {
                                          setState(() {
                                            male.value = value!;
                                            gender="Female";
                                            // _storage.write(AppConstant.gender,male.value.toString());
                                          });
                                        }
                                    ),
                                    Text("Male",style: bodyText2Style.copyWith(color: Colors.white),),
                                    Radio(
                                        value: 2,
                                        groupValue: male.value,
                                        fillColor:  MaterialStateColor.resolveWith((states) => Colors.white),
                                        activeColor: Colors.blue,
                                        onChanged: (value)
                                        {
                                          setState(() {
                                            male.value = value!;
                                            // _storage.write(AppConstant.gender,male.value.toString());
                                            gender="Female";
                                          });
                                        }
                                    ),
                                    Text("Female",style: bodyText2Style.copyWith(color:Colors.white),),
                                  ],
                                ),
                              ),
                              SizedBox(height: 15,),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(right: 18.0),
                                    child:
                                    CButton(onPress: () {
                                      if(GetStorage().read(AppConstant.stafflogin).toString()=="1")
                                      {
                                        logincontroller. UpdateProfilStaffNetworkApi(male.value);
                                        print("staff1");
                                      }
                                      else
                                      {
                                        logincontroller.UpdateProfileNetworkApi(male.value);
                                        print("user2");
                                      }
                                    },),
                                  ),
                                ],
                              ),

                            ],
                          ),
                        ),
                      ]
                  ),
                ),
              )

            ],
            ),

          ),
        ),
      );
  }
       /* FadeInUp(
          delay: Duration(milliseconds: 450),
          child: SingleChildScrollView(

            child: Column(
                children: [
                  Padding(
                    padding: EdgeInsets.only(left:24.w,right: 24.w,),

                    child:
                       Column(

                        children: [

                          SizedBox(height: 25.h,),
                         Form(
                           key: logincontroller.formKey,
                             child: Column(
                              children: [

                             EditTextWidget(controller: logincontroller.etName,
                               hint: 'Name',
                               validator: (value)
                               {
                                 if(value.toString().isEmpty){
                                   return "Plese Enter Name";
                                 }
                                 return null;
                               },
                             ),
                             SizedBox(height: 15,),
                             EditTextWidget(controller: logincontroller.etEmail,hint: 'Email',
                               validator: (value){
                                 if(value.toString().isEmpty)
                                 {
                                   return "Please Enter Email";
                                 }
                                 if(!GetUtils.isEmail(value))
                                 {
                                   return "Please Enter Valid Email";
                                 }
                                 return null;
                               },
                               type: TextInputType.emailAddress,
                             ),

                             SizedBox(height: 15,),
                             EditTextWidget(controller:logincontroller.etAge,hint: 'Age',
                               validator: (value){
                                 if(value.toString().isEmpty){
                                   return "Please Enter Age";
                                 }
                                 return null;
                               },
                               type: TextInputType.text,

                               : 10,
                             ),
                             SizedBox(height:8.h,),
                             EditTextWidget(controller: logincontroller.etWiegth,hint: 'Wieght',
                               validator: (value){
                                 if(value.toString().isEmpty){
                                   return "Please Enter Wieght";
                                 }
                                 return null;
                               },
                               type: TextInputType.text,
                             ),
                             SizedBox(height: 8.h,),
                             EditTextWidget(controller: logincontroller.etHeight,hint: 'Height',
                               validator:  (value)
                               {
                                 if(value.toString().isEmpty)
                                 {
                                   return "Please Enter Height";
                                 }
                                 return null;
                               },
                               type: TextInputType.text,
                             ),
                           ],
                         )),

                          SizedBox(height: 35.h,),

                          Obx(
                              ()=> Row(
                              children: [
                                Radio(
                                    value: 1,
                                    groupValue: male.value,
                                    activeColor: Colors.blue,
                                    onChanged: (value) {
                                      setState(() {
                                        male.value = value!;
                                        gender="Female";
                                       // _storage.write(AppConstant.gender,male.value.toString());
                                      });
                                    }
                                ),
                                Text("Male",style: bodyText2Style.copyWith(color: Colors.grey),),
                                Radio(
                                    value: 2,
                                    groupValue: male.value,
                                    activeColor: Colors.blue,
                                    onChanged: (value)
                                    {
                                      setState(() {
                                        male.value = value!;
                                       // _storage.write(AppConstant.gender,male.value.toString());
                                        gender="Female";
                                      });
                                    }
                                ),
                                Text("Female",style: bodyText2Style.copyWith(color: Colors.grey),),
                              ],
                            ),
                          ),
                          SizedBox(height: 15,),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(right: 18.0),
                                child:
                                CButton(onPress: () {
                                  if(GetStorage().read(AppConstant.stafflogin).toString()=="1")
                                  {
                                    logincontroller. UpdateProfilStaffNetworkApi(male.value);
                                    print("staff1");
                                  }
                                  else
                                  {
                                    logincontroller.UpdateProfileNetworkApi(male.value);
                                    print("user2");
                                  }
                                },),
                              ),
                            ],
                          ),

                        ],
                      ),
                    ),
                ]
            ),
          ),
        )*/

  void EditBottomChanged() {
    final double h = MediaQuery.of(context).size.height;
    final double w = MediaQuery.of(context).size.width;
    showModalBottomSheet(
        context: context,
        barrierColor: Colors.black.withOpacity(0.1),
        isScrollControlled: true,
        backgroundColor:TColor.themecolor,
        builder: (context) {
          return SingleChildScrollView(
            child: Padding(padding: EdgeInsets.only(bottom: MediaQuery
                .of(context)
                .viewInsets
                .bottom),
                child: ClipRRect(
                  child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                      child: Container(
                        height: Get.height / 1.5,
                        padding: EdgeInsets.all(10),
                        // height: h * 0.45,
                        width: double.infinity,
                        //
                        child: Column(
                          children: [
                            SizedBox(height: 10,),
                            Container(
                              width: 40,
                              height: 6,
                              decoration: BoxDecoration(
                                  border: Border.all(
                                      width: 0.5, color: Colors.black12),
                                  color: Colors.transparent,
                                  borderRadius: BorderRadius.circular(10)),
                            ),
                             Container(
                               height: 300.h,
                               width: 300.w,
                               child: Image.asset("assets/images/check2.gif"),
                             ),
                            Text("your Profile has been change!",style: smallText1Style.copyWith(fontSize: 19.sp),)
                          ],
                        ),

                      )
                  ),

                )
            ),
          );
        }
    );
  }

  showOptionDailog(BuildContext context) {
    return showDialog(context: context, builder: (context) =>
        SimpleDialog(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.all(Radius.circular(4.0))),
          backgroundColor: Color(0xFF2a2b2b),
          children: [
            SimpleDialogOption(
              onPressed: () {
                logincontroller.chooseImage(false);
                Get.back();
              },
              child: Row(
                children: [
                  Icon(Icons.image,color: Colors.blue,),
                  Text("   Gallery", style:smallTextStyle)
                ],
              ),
            ),
            Padding(
              padding:  EdgeInsets.only(left: 20.w,right: 20.w),
              child: Divider(color: Colors.grey.shade800,),
            ),
            SimpleDialogOption(
              onPressed: () {  logincontroller.chooseImage(true);

              Get.back();
              },
              child: Row(
                children: [
                  Icon(Icons.camera_alt,color: Colors.blue,),
                  Text("   Camera", style:smallTextStyle)
                ],
              ),
            ),
            Padding(
              padding:  EdgeInsets.only(left: 20.w,right: 20.w),
              child: Divider(color: Colors.grey.shade800,),
            ),
            SimpleDialogOption(
              onPressed: () => Get.back(),
              child: Row(
                children: [
                  Icon(Icons.clear,color: Colors.red,),
                  Text("  Cancel", style: smallTextStyle)
                ],
              ),
            ),
            Padding(
              padding:  EdgeInsets.only(left: 20.w,right: 20.w),
              child: Divider(color: Colors.grey.shade800,),
            ),
          ],
        ));
  }
}
