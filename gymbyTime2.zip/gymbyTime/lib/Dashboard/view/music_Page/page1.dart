import 'package:animate_do/animate_do.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:gym/Dashboard/Controller/homepage_controller.dart';
import 'package:gym/Widget/color.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../../FontStyle.dart';
class page1 extends StatefulWidget {
  const page1({Key? key}) : super(key: key);
  @override
  State<page1> createState() => _page1State();
}
class _page1State extends State<page1> {
  HomePageController controller=Get.put(HomePageController());
  _launchURLApp() async
  {
    final url =controller.contectModel.value.data!.instaLink.toString();
    if (await canLaunch(url)) {
      await launch(url, forceSafariVC: true, forceWebView: false);
    } else {
      throw 'Could not launch $url';
    }
  }
  _twitterURLApp() async {
    final url = controller.contectModel.value.data!.twitterLink.toString();
    if (await canLaunch(url)) {
      await launch(url, forceSafariVC: true, forceWebView: false);
    } else {
      throw 'Could not launch $url';
    }
  }
  _FaceBookURLApp() async {
    final url = controller.contectModel.value.data!.fbLink.toString();
    if (await canLaunch(url)) {
      await launch(url, forceSafariVC: true, forceWebView: false);
    } else {
      throw 'Could not launch $url';
    }
  }
  _launchCaller() async {
    final url = "tel:"+controller.contectModel.value.data!.mobile.toString();
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
  _luncherMail() async {
    final url = "mailto:"+controller.contectModel.value.data!.email.toString();
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }
  @override
  Widget build(BuildContext context) {
    controller.getContectNetworkApi();
    return Scaffold(
      backgroundColor: TColor.themecolor,
      body:Obx(()=>controller.contectModel.value.data!=null ?
         FadeInUp(
           delay: Duration(milliseconds: 50),
           child: SingleChildScrollView(
             child: Padding(
              padding:  EdgeInsets.only(left: 8.w,right: 8.w,top: 13.h),
              child: Column(
                children: [
                  SizedBox(height: 10.h,),
                  Text(controller.contectModel.value.data!.shortDescription.toString(),style: smallTextStyle.copyWith(color: Colors.white),textAlign: TextAlign.justify,),
                  SizedBox(height: 30.h,),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                    InkWell(onTap:(){},child: Icon(Icons.location_on,color: Color(0xF506A895),)),
                      Padding(
                        padding:  EdgeInsets.only(left: 18.w),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Text(controller.contectModel.value.data!.title.toString(),
                              style:bodyText1Style.copyWith(fontSize: 18.sp,color: Colors.white) ,maxLines: 3,),
                            SizedBox(height:
                              5.h,),
                            Container(
                              width: 230.w,
                              child: Text(controller.contectModel.value.data!.address.toString(),
                                style: smallTextStyle.copyWith(fontSize: 15.sp,color: Colors.white),
                                maxLines: 3,overflow: TextOverflow.ellipsis,),
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                  SizedBox(height:20.h,),
                  InkWell(
                    onTap:_luncherMail,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                      Icon(Icons.email,color: Color(0xF506A895)),
                        Padding(
                          padding: const EdgeInsets.only(left: 18.0),
                          child: Text(controller.contectModel.value.data!.email.toString(),style:smallTextStyle.copyWith(color: Colors.white),),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 20.h,),
                  InkWell(
                    onTap: _launchCaller,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                      Icon(Icons.phone,color: Color(0xF506A895),),
                        Padding(
                          padding: const EdgeInsets.only(left: 18.0),
                          child: Text(controller.contectModel.value.data!.mobile.toString(),style:smallTextStyle.copyWith(color: Colors.white),),
                        )
                      ],
                    ),
                  ),
                  SizedBox(height: 30.h,),
                  Row(
                    children: [
                      IconButton(onPressed: _launchURLApp,
                          icon: Image.asset("assets/images/instaa.png",height: 30.h,width: 30.w,)),
                      IconButton(onPressed: _twitterURLApp,
                          icon: Image.asset("assets/images/twi.png",height: 40.h,width: 40.w,)),
                      IconButton(onPressed: _FaceBookURLApp,
                          icon: Image.asset("assets/images/facebook.png",height: 30.h,width: 30.w,color: Colors.lightBlue,)),
                    ],
                  ),
                  SizedBox(height: 30.h,)

                ],
              ),
        ),
           ),
         ):Container()
      )
    );
  }

}
