
import 'APIConstant.dart';
const signInAsStaff="${BASE_URL}/api/StaffMaster/signInStaff";
const otpverifyApi="${BASE_URL}/api/StaffMaster/verifyStaffOTP";
const getMyscanList="${BASE_URL}/api/StaffMaster/getMyscanList";
const getMyscanData="${BASE_URL}/api/StaffMaster/checkIn_CheckutByStaff";
const updateStaffProfile="${BASE_URL}/api/StaffMaster/updateStaffProfile";